# perfSense – Script Parser Module

Internal AI-powered API performance testing tool. This phase implements the **Script Parser** module only.

## Features

- **Upload** LoadRunner (`.c`, `.txt`), JMeter (`.jmx`), or HAR (`.har`) script files
- **Auto-detect** script type from extension and content
- **Parse** and extract API requests (URL, method, headers, payload)
- **Preserve** transaction names and execution order
- **Generate** executable Python script using `requests`
- **Store** parsed data (MongoDB by default, or Oracle with migration scripts provided)
- **UI** to upload, view parsed APIs, and view generated Python script

## Prerequisites

- Python 3.10+
- Node.js 18+ (for frontend)
- MongoDB (optional; if not running, the app uses in-memory storage)

## Backend Setup and Run

```bash
cd /Users/vihanthakur/Downloads/perfSense
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r backend/requirements.txt
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

Backend will be at **http://localhost:8000**.  
- API docs: http://localhost:8000/docs  
- Health: http://localhost:8000/health  

## Frontend Setup and Run

```bash
cd /Users/vihanthakur/Downloads/perfSense/frontend
npm install
npm run dev
```

Frontend runs at **http://localhost:3000**.

## Database

Store priority: **MySQL (DATABASE_URL)** → Oracle → MongoDB → FileStore → InMemory.

### MySQL (recommended – fixes "Script not found")

1. Install PyMySQL: `pip install pymysql`
2. Set `DATABASE_URL` and run the migration once:

```bash
export DATABASE_URL="mysql+pymysql://root:xrbn2614@localhost:3306/xrbn_db"
cd /Users/vihanthakur/Downloads/perfSense
PYTHONPATH=. python -m backend.db.migrations.run_mysql_migration
```

3. Start the backend with the same env (or add to `.env` / shell):

```bash
export DATABASE_URL="mysql+pymysql://root:xrbn2614@localhost:3306/xrbn_db"
PYTHONPATH=. uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

- Migration creates database `xrbn_db` if missing, and tables `scripts`, `transactions`, `python_scripts`.
- SQL schema: `backend/db/migrations/mysql_schema.sql`

### Other stores

- **Oracle**: Install `oracledb`, set `ORACLE_DSN`, `ORACLE_USER`, `ORACLE_PASSWORD`, run `backend/db/migrations/oracle_schema.sql`.
- **MongoDB**: If reachable at `localhost:27017`, backend uses DB `perfsense`.
- **No MySQL/Mongo/Oracle**: FileStore (JSON file) then InMemory (data lost on restart).

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/upload-script` | Upload script file; returns script, transactions, and generated Python |
| GET | `/scripts` | List all uploaded scripts |
| GET | `/scripts/{id}/transactions` | Parsed API list for a script |
| GET | `/scripts/{id}/python-script` | Generated Python script (text) |

## Example Scripts

In `example_scripts/`:

- `sample_loadrunner.c` – LoadRunner VuGen-style script
- `sample.jmx` – JMeter HTTP samplers
- `sample.har` – HAR with two requests

Use the Upload page to upload any of these and then open “View APIs” and “Python script” for that script.

## Project Layout

```
perfSense/
├── backend/
│   ├── main.py
│   ├── api/upload_api.py
│   ├── services/script_parser_service.py
│   ├── parsers/
│   │   ├── loadrunner_parser.py
│   │   ├── jmeter_parser.py
│   │   └── har_parser.py
│   ├── models/script_model.py
│   ├── db/
│   │   ├── db_connection.py
│   │   └── migrations/oracle_schema.sql
│   └── utils/
│       ├── script_type_detector.py
│       └── python_script_generator.py
├── frontend/          # React (Vite)
├── example_scripts/
└── README.md
```

## Flow

1. User uploads a script on the Upload page.
2. Backend detects type (LoadRunner / JMeter / HAR), parses the file, stores script and transactions, and generates the Python script.
3. User is redirected to the script’s parsed APIs table (Execution Order, Transaction Name, Method, URL).
4. From Scripts list or script page, user can open “Python script” to see the generated `requests`-based code.

Correlation, ML, and execution engine are **not** part of this phase.

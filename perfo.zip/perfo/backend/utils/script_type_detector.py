"""Detect script type from file extension and content. Only HAR is supported."""
import json
from typing import Literal

ScriptType = Literal["har", "unknown"]


def detect_script_type(filename: str, content: bytes) -> ScriptType:
    """
    Detect script type based on file extension and content.
    Returns 'har' or 'unknown'.
    """
    ext = _get_extension(filename).lower()
    text = content.decode("utf-8", errors="ignore")[:8192]

    if ext == ".har":
        if text.strip().startswith("{") and ("log" in text and "entries" in text):
            return "har"
        try:
            data = json.loads(content.decode("utf-8"))
            if isinstance(data, dict) and "log" in data and "entries" in data.get("log", {}):
                return "har"
        except Exception:
            pass
        return "unknown"

    # Fallback: content-based HAR detection for files without explicit extension
    if text.strip().startswith("{") and "entries" in text and "request" in text:
        try:
            data = json.loads(content.decode("utf-8"))
            if isinstance(data, dict) and "log" in data and "entries" in data.get("log", {}):
                return "har"
        except Exception:
            pass

    return "unknown"


def _get_extension(filename: str) -> str:
    if "." in filename:
        return "." + filename.rsplit(".", 1)[-1]
    return ""

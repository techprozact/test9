"""Convert parsed transactions into executable Python script using requests.Session."""
import json
import re
from urllib.parse import unquote_plus, urlparse

from backend.models.script_model import TransactionBase

_STATIC_EXTENSIONS = frozenset([
    ".css", ".js", ".map", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico",
    ".woff", ".woff2", ".ttf", ".eot", ".otf", ".cur", ".bmp", ".tiff", ".avif",
    ".mp4", ".webm", ".mp3", ".wav", ".ogg", ".m4a", ".pdf", ".zip", ".xml",
])

_WELL_KNOWN_HEADERS: dict[str, str] = {
    "accept": "Accept",
    "accept-charset": "Accept-Charset",
    "accept-encoding": "Accept-Encoding",
    "accept-language": "Accept-Language",
    "authorization": "Authorization",
    "cache-control": "Cache-Control",
    "content-length": "Content-Length",
    "content-type": "Content-Type",
    "cookie": "Cookie",
    "host": "Host",
    "origin": "Origin",
    "referer": "Referer",
    "set-cookie": "Set-Cookie",
    "user-agent": "User-Agent",
    "x-requested-with": "X-Requested-With",
}

_BROWSER_HEADER_PREFIXES = (
    "sec-fetch-",
    "sec-ch-",
)

_BROWSER_HEADERS_EXACT = frozenset([
    "upgrade-insecure-requests",
    "priority",
    "pragma",
    "cache-control",
    "dnt",
])

_SESSION_MANAGED_HEADERS = frozenset([
    "cookie", "set-cookie", "set-cookie2",
    "x-csrftoken", "csrftoken",
])

_AUTO_SET_HEADERS = frozenset([
    "host",
    "content-length",
    "accept-encoding",
    "accept-language",
    "connection",
    "accept-charset",
])

_USEFUL_HEADERS = frozenset([
    "accept",
    "content-type",
    "authorization",
    "referer",
    "origin",
    "user-agent",
    "x-requested-with",
])


def _normalize_header_name(name: str) -> str:
    key = name.lower().strip()
    if key in _WELL_KNOWN_HEADERS:
        return _WELL_KNOWN_HEADERS[key]
    return "-".join(part.capitalize() for part in key.split("-"))


def _add_referer_origin(
    headers: dict, method: str, url: str, previous_url: str = "",
) -> dict:
    """Add Referer and Origin for mutating requests if missing.

    Required by Django, Rails, and Spring Security CSRF validation.
    """
    if method.upper() not in ("POST", "PUT", "PATCH", "DELETE"):
        return headers
    lower_keys = {k.lower() for k in headers}
    if "referer" not in lower_keys:
        ref = previous_url or url
        if ref:
            headers["Referer"] = ref
    if "origin" not in lower_keys:
        try:
            p = urlparse(url)
            if p.scheme and p.netloc:
                headers["Origin"] = f"{p.scheme}://{p.netloc}"
        except Exception:
            pass
    return headers


def _clean_headers(headers: dict) -> dict:
    """Remove browser-only, session-managed, and auto-set headers; normalize names.

    Keeps only headers useful for HTTP replay: Accept, Content-Type,
    Authorization, Referer, Origin, User-Agent, X-Requested-With,
    and custom X-* application headers.
    """
    if not headers:
        return {}
    out: dict[str, str] = {}
    for k, v in headers.items():
        key = k.lower().strip()

        if key in _SESSION_MANAGED_HEADERS or "cookie" in key or "csrf" in key:
            continue

        if any(key.startswith(p) for p in _BROWSER_HEADER_PREFIXES):
            continue

        if key in _BROWSER_HEADERS_EXACT:
            continue

        if key in _AUTO_SET_HEADERS:
            continue

        if key not in _USEFUL_HEADERS and not key.startswith("x-"):
            continue

        normalized = _normalize_header_name(k)
        if normalized not in out:
            out[normalized] = v
    return out


# ---------------------------------------------------------------------------
# Content-Type detection & payload resolution
# ---------------------------------------------------------------------------

def _detect_request_content_type(headers: dict) -> str:
    """Extract the request Content-Type (without parameters like charset)."""
    for k, v in (headers or {}).items():
        if k.lower().strip() == "content-type":
            return v.lower().split(";")[0].strip()
    return ""


def _parse_form_urlencoded(raw: str) -> dict[str, str]:
    """Parse 'key=val&key2=val2' into a flat dict with URL-decoded keys/values."""
    result: dict[str, str] = {}
    for pair in raw.split("&"):
        if "=" in pair:
            key, _, value = pair.partition("=")
            result[unquote_plus(key)] = unquote_plus(value)
        elif pair.strip():
            result[pair.strip()] = ""
    return result


def _is_raw_wrapper(payload: dict) -> bool:
    """True if payload is the {'raw': '...'} wrapper from _parse_post_data."""
    return (
        isinstance(payload, dict)
        and "raw" in payload
        and len(payload) == 1
        and isinstance(payload["raw"], str)
    )


def _resolve_payload(payload: dict | None, headers: dict) -> tuple[str | None, str]:
    """Determine the correct payload representation and requests kwarg.

    Returns (payload_code, kwarg) where kwarg is 'json', 'data', or ''.
    payload_code is the Python source for the payload variable, or None if no payload.
    """
    if payload is None:
        return None, ""

    ct = _detect_request_content_type(headers)
    raw_str = payload.get("raw", "") if _is_raw_wrapper(payload) else None

    if ct == "application/json":
        if raw_str is not None:
            try:
                parsed = json.loads(raw_str)
                if isinstance(parsed, dict):
                    return _payload_repr(parsed), "json"
                return _payload_repr({"value": parsed}), "json"
            except (json.JSONDecodeError, TypeError, ValueError):
                return repr(raw_str), "data"
        return _payload_repr(payload), "json"

    if ct == "application/x-www-form-urlencoded":
        if raw_str is not None:
            parsed = _parse_form_urlencoded(raw_str)
            if parsed:
                return _payload_repr(parsed), "data"
            return repr(raw_str), "data"
        clean = {k: v for k, v in payload.items() if k != "raw"}
        return _payload_repr(clean) if clean else _payload_repr(payload), "data"

    if ct.startswith("multipart/form-data"):
        if raw_str is not None:
            parsed = _parse_form_urlencoded(raw_str)
            if parsed:
                return _payload_repr(parsed), "data"
            return repr(raw_str), "data"
        return _payload_repr(payload), "data"

    if ct == "text/plain":
        if raw_str is not None:
            return repr(raw_str), "data"
        return _payload_repr(payload), "data"

    # Unknown / missing Content-Type — infer from shape
    if raw_str is not None:
        try:
            parsed = json.loads(raw_str)
            if isinstance(parsed, dict):
                return _payload_repr(parsed), "json"
        except (json.JSONDecodeError, TypeError, ValueError):
            pass
        if "=" in raw_str and "&" in raw_str:
            parsed = _parse_form_urlencoded(raw_str)
            if parsed:
                return _payload_repr(parsed), "data"
        return repr(raw_str), "data"

    return _payload_repr(payload), "json"


def is_business_request(transaction: TransactionBase) -> bool:
    """Return True if this transaction looks like a business/API request (exclude static assets)."""
    url = (transaction.request_url or "").lower().split("?")[0].split("#")[0]
    for ext in _STATIC_EXTENSIONS:
        if url.endswith(ext) or ext + "?" in url or ext + "#" in url:
            return False
    return True


def filter_business_only(transactions: list[TransactionBase]) -> list[TransactionBase]:
    """Return only transactions that look like business/API requests (no PNG, CSS, etc.)."""
    return [t for t in transactions if is_business_request(t)]


def _transaction_identity(t: TransactionBase) -> tuple:
    """Identity key for dedup: method + URL path + query + payload."""
    url = (t.request_url or "").strip()
    try:
        payload_key = json.dumps(t.payload, sort_keys=True) if t.payload else ""
    except (TypeError, ValueError):
        payload_key = ""
    return ((t.http_method or "GET").upper(), url, payload_key)


def dedup_within_groups(
    groups: list[list[TransactionBase]],
) -> list[list[TransactionBase]]:
    """Remove consecutive identical requests within each transaction group."""
    result: list[list[TransactionBase]] = []
    for group in groups:
        if not group:
            result.append(group)
            continue
        deduped: list[TransactionBase] = [group[0]]
        for t in group[1:]:
            if _transaction_identity(t) != _transaction_identity(deduped[-1]):
                deduped.append(t)
        result.append(deduped)
    return result


# ---------------------------------------------------------------------------
# Redirect follow detection and removal
# ---------------------------------------------------------------------------

_REDIRECT_STATUSES = frozenset([301, 302, 303])


def _get_response_location(response: dict | None) -> str:
    """Extract the Location header from a response dict (case-insensitive)."""
    if not response:
        return ""
    for k, v in (response.get("headers") or {}).items():
        if k.lower() == "location":
            return v
    return ""


def _urls_match_for_redirect(location: str, target_url: str) -> bool:
    """Check if a redirect Location value matches a target URL."""
    if not location or not target_url:
        return False
    loc = location.rstrip("/")
    target = target_url.rstrip("/")
    if loc == target:
        return True
    try:
        target_path = urlparse(target).path.rstrip("/")
        loc_path = urlparse(loc).path.rstrip("/") if "://" in loc else loc.split("?")[0].rstrip("/")
        return bool(loc_path) and loc_path == target_path
    except Exception:
        return False


def _remove_redirect_follows(transactions: list[TransactionBase]) -> list[TransactionBase]:
    """Remove GET text/html requests that are redirect follow-ups.

    Two detection passes:
    1. Explicit redirect follow: prev returned 301/302/303 with Location
       header matching the current request URL.
    2. Post-redirect chain: after POST/PUT/PATCH/DELETE that returned 3xx,
       remove consecutive GET text/html that form the redirect chain
       (intermediate 3xx hops + the first 2xx destination page).

    requests.Session with allow_redirects=True handles these automatically,
    so including them in the generated script is redundant.
    """
    if len(transactions) < 2:
        return transactions

    n = len(transactions)
    exclude = [False] * n

    for i in range(1, n):
        curr = transactions[i]
        if (curr.http_method or "GET").upper() != "GET":
            continue

        prev = transactions[i - 1]
        prev_status = (prev.response or {}).get("status", 0)
        if prev_status not in _REDIRECT_STATUSES:
            continue

        location = _get_response_location(prev.response)
        if location and _urls_match_for_redirect(location, curr.request_url or ""):
            exclude[i] = True

    i = 0
    while i < n:
        t = transactions[i]
        method = (t.http_method or "GET").upper()
        status = (t.response or {}).get("status", 0)

        if method in ("POST", "PUT", "PATCH", "DELETE") and 300 <= status < 400:
            j = i + 1
            dest_found = False
            while j < n:
                tj = transactions[j]
                tj_method = (tj.http_method or "GET").upper()
                if tj_method != "GET":
                    break
                tj_ct = ((tj.response or {}).get("content_type") or "").lower()
                if "text/html" not in tj_ct and tj_ct:
                    break
                tj_status = (tj.response or {}).get("status", 0)
                if 300 <= tj_status < 400:
                    exclude[j] = True
                    j += 1
                elif not dest_found:
                    exclude[j] = True
                    dest_found = True
                    j += 1
                else:
                    break
            i = j
        else:
            i += 1

    out = []
    for i, t in enumerate(transactions):
        if exclude[i]:
            print(f"[ScriptGen] Removed redirect navigation: {t.http_method} {t.request_url}")
        else:
            out.append(t)
    return out


# ---------------------------------------------------------------------------
# Login GET pruning (deferred from HAR pipeline to preserve GET for correlation)
# ---------------------------------------------------------------------------

_LOGIN_PATH_KEYWORDS = frozenset([
    "login", "signin", "sign-in", "sign_in", "authenticate", "auth", "session",
])


def _is_login_page_get(t: TransactionBase) -> bool:
    """True if this is a GET to a login/auth page (the HTML form, not the submission)."""
    if (t.http_method or "").upper() != "GET":
        return False
    try:
        path = urlparse(t.request_url or "").path or "/"
    except Exception:
        path = "/"
    segments = path.lower().strip("/").split("/")
    return any(seg in _LOGIN_PATH_KEYWORDS for seg in segments)


def _is_login_post(t: TransactionBase) -> bool:
    """True if this is a POST login/authentication request."""
    if (t.http_method or "").upper() != "POST":
        return False
    try:
        path = urlparse(t.request_url or "").path or "/"
    except Exception:
        path = "/"
    segments = path.lower().strip("/").split("/")
    return any(seg in _LOGIN_PATH_KEYWORDS for seg in segments)


def _remove_redundant_login_gets(transactions: list[TransactionBase]) -> list[TransactionBase]:
    """When both GET /login and POST /login exist, drop the GET page load from the script.

    The HAR pipeline preserves both so the correlation engine can extract CSRF tokens
    from the GET response. By the time this runs, correlation is complete and the GET
    is no longer needed in the generated script.
    """
    has_login_post = any(_is_login_post(t) for t in transactions)
    if not has_login_post:
        return transactions
    out = []
    for t in transactions:
        if _is_login_page_get(t):
            print(f"[ScriptGen] Removed redundant login GET: {t.request_url}")
            continue
        out.append(t)
    return out


def _path_and_query(url: str) -> str:
    """Return path + query (no scheme/host) for use with BASE_URL."""
    try:
        p = urlparse(url)
        path = p.path or "/"
        if p.query:
            return path + "?" + p.query
        return path
    except Exception:
        return url


def generate_python_script(
    transactions: list[TransactionBase],
    business_only: bool = True,
    base_url: str | None = None,
    summary: dict | None = None,
    transaction_groups: list[list[TransactionBase]] | None = None,
    transaction_names: list[str] | None = None,
) -> str:
    """
    Generate executable Python script using requests.Session for stateful cookie management.

    All cookie/session/csrf headers are stripped from individual requests.
    requests.Session automatically propagates cookies across requests.
    """
    # Prune redirect follow navigations (requests.Session auto-follows 3xx).
    transactions = _remove_redirect_follows(transactions)
    if transaction_groups:
        transaction_groups = [_remove_redirect_follows(g) for g in transaction_groups]

    # Prune redundant login page GETs now that correlation has already run.
    # The HAR pipeline deliberately keeps GET /login so the correlation engine
    # can extract CSRF tokens from the HTML response.
    transactions = _remove_redundant_login_gets(transactions)
    if transaction_groups:
        transaction_groups = [_remove_redundant_login_gets(g) for g in transaction_groups]

    effective_base = (base_url or "").strip().rstrip("/") or "https://example.com"
    lines = [
        "#!/usr/bin/env python3",
        '"""Generated by perfSense. Run: python script.py. Requires: pip install requests"""',
        "",
    ]
    if summary:
        lines.append("# HAR Summary")
        lines.append("# -----------")
        lines.append("# Total HAR requests: {}".format(summary.get("total_har_requests", "?")))
        if summary.get("third_party_removed"):
            lines.append("# Third-party removed: {}".format(summary.get("third_party_removed")))
        lines.append("# Static resources removed: {}".format(summary.get("static_resources_removed", "?")))
        if summary.get("cdn_infrastructure_removed"):
            lines.append("# Cloudflare/CDN infrastructure removed: {}".format(summary.get("cdn_infrastructure_removed")))
        lines.append("# Telemetry requests removed: {}".format(summary.get("telemetry_requests_removed", "?")))
        lines.append("# Polling requests removed: {}".format(summary.get("polling_requests_removed", "?")))
        lines.append("# Typing suggestion requests collapsed: {}".format(summary.get("typing_suggestion_requests_collapsed", "?")))
        lines.append("# Business APIs detected: {}".format(summary.get("business_apis_detected", "?")))
        lines.append("# Transactions detected: {}".format(summary.get("transactions_detected", "?")))
        if summary.get("validation_excluded", 0) > 0:
            lines.append("# Validation excluded (noise removed before script): {}".format(summary.get("validation_excluded")))
        lines.append("")
    lines.extend(["import requests", "", ""])
    lines.append(f'BASE_URL = "{_escape(effective_base)}"')
    lines.append("")
    lines.append("session = requests.Session()")
    lines.append("")
    lines.append("")

    last_url = ""
    if transaction_groups and transaction_names and len(transaction_groups) == len(transaction_names):
        transaction_groups = dedup_within_groups(transaction_groups)
        func_names = []
        for i, (group, name) in enumerate(zip(transaction_groups, transaction_names)):
            func_name = _sanitize_func_name(name)
            if func_name and func_name[0].isdigit():
                func_name = "t_" + func_name
            func_names.append(func_name)
            lines.append(f"def {func_name}():")
            if len(group) == 0:
                lines.append("    pass")
                lines.append("    return None")
            elif len(group) == 1:
                _emit_single_request(lines, group[0], previous_url=last_url)
                lines.append("    return response")
                last_url = group[0].request_url or ""
            else:
                lines.append("    responses = []")
                for t in group:
                    _emit_request_in_list(lines, t, previous_url=last_url)
                    last_url = t.request_url or ""
                lines.append("    return responses[-1]")
            lines.append("")
            lines.append("")
    else:
        if business_only:
            transactions = filter_business_only(transactions)
        seen_names: set[str] = set()
        func_names = []
        for i, t in enumerate(transactions):
            base_name = _sanitize_func_name(t.transaction_name)
            func_name = base_name
            idx = 0
            while func_name in seen_names:
                idx += 1
                func_name = f"{base_name}_{idx}"
            seen_names.add(func_name)
            func_names.append(func_name)
            lines.append(f"def {func_name}():")
            _emit_single_request(lines, t, previous_url=last_url)
            lines.append("    return response")
            last_url = t.request_url or ""
            lines.append("")
            lines.append("")

    lines.append("def main():")
    for fn in func_names:
        lines.append(f"    {fn}()")
    lines.append("")
    lines.append("")
    lines.append('if __name__ == "__main__":')
    lines.append("    main()")
    lines.append("")
    return "\n".join(lines)


def _emit_single_request(
    lines: list[str], t: TransactionBase, previous_url: str = "",
) -> None:
    """Emit a single request using session.get/post/etc with correct payload kwarg."""
    path_query = _path_and_query(t.request_url or "")
    if not path_query.startswith("/"):
        path_query = "/" + path_query
    clean = _clean_headers(t.headers or {})
    method = (t.http_method or "GET").lower()
    clean = _add_referer_origin(clean, method, t.request_url or "", previous_url)
    lines.append(f'    url = BASE_URL + "{_escape(path_query)}"')
    lines.append(f"    headers = {_dict_repr(clean)}")
    payload_code, kwarg = _resolve_payload(t.payload, t.headers or {})
    if payload_code is not None and kwarg:
        lines.append(f"    payload = {payload_code}")
        lines.append(f"    response = session.{method}(url, headers=headers, {kwarg}=payload)")
    else:
        lines.append(f"    response = session.{method}(url, headers=headers)")


def _emit_request_in_list(
    lines: list[str], t: TransactionBase, previous_url: str = "",
) -> None:
    """Emit a request appended to responses[] using session with correct payload kwarg."""
    path_query = _path_and_query(t.request_url or "")
    if not path_query.startswith("/"):
        path_query = "/" + path_query
    clean = _clean_headers(t.headers or {})
    method = (t.http_method or "GET").lower()
    clean = _add_referer_origin(clean, method, t.request_url or "", previous_url)
    lines.append(f'    url = BASE_URL + "{_escape(path_query)}"')
    lines.append(f"    headers = {_dict_repr(clean)}")
    payload_code, kwarg = _resolve_payload(t.payload, t.headers or {})
    if payload_code is not None and kwarg:
        lines.append(f"    payload = {payload_code}")
        lines.append(f"    responses.append(session.{method}(url, headers=headers, {kwarg}=payload))")
    else:
        lines.append(f"    responses.append(session.{method}(url, headers=headers))")


def _sanitize_func_name(name: str) -> str:
    """Turn transaction name into valid Python function name."""
    s = re.sub(r"[^a-zA-Z0-9_]", "_", name)
    s = s.strip("_") or "transaction"
    if s and s[0].isdigit():
        s = "t_" + s
    return s or "transaction"


def _escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _dict_repr(d: dict) -> str:
    if not d:
        return "{}"
    parts = [f'"{_escape(k)}": "{_escape(v)}"' for k, v in d.items()]
    return "{" + ", ".join(parts) + "}"


def _payload_repr(payload: dict) -> str:
    try:
        s = json.dumps(payload, indent=4)
        s = s.replace("null", "None").replace("true", "True").replace("false", "False")
        return s
    except (TypeError, ValueError):
        return "{}"

-- MySQL schema for perfSense Script Parser
-- Run this once to create tables (or use: python -m backend.db.migrations.run_mysql_migration)

CREATE TABLE IF NOT EXISTS scripts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    script_name VARCHAR(500) NOT NULL,
    script_type VARCHAR(50) NOT NULL,
    upload_time DATETIME(6) NOT NULL,
    INDEX idx_upload_time (upload_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    script_id VARCHAR(50) NOT NULL,
    transaction_name VARCHAR(500) NOT NULL,
    request_url VARCHAR(4000) NOT NULL,
    http_method VARCHAR(20) NOT NULL,
    headers LONGTEXT,
    payload LONGTEXT,
    execution_order INT NOT NULL,
    INDEX idx_script_id (script_id),
    INDEX idx_script_order (script_id, execution_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS python_scripts (
    script_id VARCHAR(50) PRIMARY KEY,
    code LONGTEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS scenarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scenario_name VARCHAR(500) NOT NULL,
    description TEXT,
    duration VARCHAR(50),
    ramp_up VARCHAR(50),
    ramp_down VARCHAR(50),
    scripts_json LONGTEXT,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    INDEX idx_scenario_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS test_runs (
    id VARCHAR(36) PRIMARY KEY,
    scenario_id VARCHAR(50),
    scenario_snapshot LONGTEXT,
    status VARCHAR(30) NOT NULL DEFAULT 'INITIALIZING',
    start_time DATETIME(6),
    end_time DATETIME(6),
    planned_duration_secs INT,
    ramp_up_secs INT,
    ramp_down_secs INT,
    total_users_target INT DEFAULT 0,
    total_users_spawned INT DEFAULT 0,
    engine_node_id VARCHAR(100) DEFAULT 'local',
    error_message TEXT,
    created_at DATETIME(6) NOT NULL,
    INDEX idx_test_run_status (status),
    INDEX idx_test_run_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS request_telemetry (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    test_run_id VARCHAR(36) NOT NULL,
    script_id VARCHAR(50) NOT NULL,
    virtual_user_id VARCHAR(100) NOT NULL,
    iteration INT NOT NULL DEFAULT 1,
    iteration_id VARCHAR(80) NOT NULL DEFAULT '',
    sequence_number INT NOT NULL DEFAULT 0,
    request_start_ts DATETIME(6) NOT NULL,
    request_end_ts DATETIME(6) NOT NULL,
    response_time_ms INT NOT NULL,
    http_status_code INT,
    success TINYINT(1) NOT NULL DEFAULT 1,
    error_message TEXT,
    request_method VARCHAR(10) NOT NULL,
    api_path VARCHAR(2000),
    bytes_sent INT DEFAULT 0,
    bytes_received INT DEFAULT 0,
    INDEX idx_telemetry_run (test_run_id),
    INDEX idx_telemetry_run_script (test_run_id, script_id),
    INDEX idx_telemetry_ts (test_run_id, request_start_ts),
    INDEX idx_telemetry_iteration (test_run_id, iteration_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

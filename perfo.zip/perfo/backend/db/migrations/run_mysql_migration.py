"""
Run MySQL migration: create database (if needed) and tables from DATABASE_URL.
Usage (from project root):
  export DATABASE_URL="mysql+pymysql://root:xrbn2614@localhost:3306/xrbn_db"
  PYTHONPATH=. python -m backend.db.migrations.run_mysql_migration
Or:
  cd /path/to/perfSense && PYTHONPATH=. python backend/db/migrations/run_mysql_migration.py
"""
import os
import sys

# Ensure project root is on path
_here = os.path.dirname(os.path.abspath(__file__))
_root = os.path.abspath(os.path.join(_here, "..", "..", ".."))
if _root not in sys.path:
    sys.path.insert(0, _root)

def main():
    url = os.environ.get("DATABASE_URL", "").strip()
    if not url or "mysql" not in url.lower():
        print("Set DATABASE_URL (e.g. export DATABASE_URL='mysql+pymysql://root:password@localhost:3306/xrbn_db')")
        sys.exit(1)

    try:
        import pymysql
    except ImportError:
        print("Install pymysql: pip install pymysql")
        sys.exit(1)
    from backend.db.db_connection import _parse_database_url
    kwargs = _parse_database_url(url)
    if not kwargs:
        print("Invalid DATABASE_URL format. Use: mysql+pymysql://user:pass@host:port/database")
        sys.exit(1)

    schema_sql = """
CREATE TABLE IF NOT EXISTS scripts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    script_name VARCHAR(500) NOT NULL,
    script_type VARCHAR(50) NOT NULL,
    upload_time DATETIME(6) NOT NULL,
    INDEX idx_upload_time (upload_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    script_id VARCHAR(50) NOT NULL,
    transaction_name VARCHAR(500) NOT NULL,
    request_url VARCHAR(4000) NOT NULL,
    http_method VARCHAR(20) NOT NULL,
    headers LONGTEXT,
    payload LONGTEXT,
    execution_order INT NOT NULL,
    INDEX idx_script_id (script_id),
    INDEX idx_script_order (script_id, execution_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS python_scripts (
    script_id VARCHAR(50) PRIMARY KEY,
    code LONGTEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""

    # Ensure database exists
    conn_no_db = pymysql.connect(
        host=kwargs["host"],
        port=kwargs["port"],
        user=kwargs["user"],
        password=kwargs["password"],
        charset="utf8mb4",
    )
    try:
        with conn_no_db.cursor() as cur:
            cur.execute(f"CREATE DATABASE IF NOT EXISTS `{kwargs['database']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        conn_no_db.commit()
    finally:
        conn_no_db.close()

    conn = pymysql.connect(
        host=kwargs["host"],
        port=kwargs["port"],
        user=kwargs["user"],
        password=kwargs["password"],
        database=kwargs["database"],
        charset="utf8mb4",
    )
    try:
        for stmt in schema_sql.strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                with conn.cursor() as cur:
                    cur.execute(stmt)
        conn.commit()
        print(f"Migration OK: tables created in database '{kwargs['database']}'")
    except Exception as e:
        print("Migration failed:", e)
        sys.exit(1)
    finally:
        conn.close()


if __name__ == "__main__":
    main()

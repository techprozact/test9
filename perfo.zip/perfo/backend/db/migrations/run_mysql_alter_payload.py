"""
Fix "Data too long for column 'payload'" by changing transactions.headers and transactions.payload to LONGTEXT.
Run once after you already have the tables:
  export DATABASE_URL="mysql+pymysql://root:YOUR_PASSWORD@localhost:3306/xrbn_db"
  cd /path/to/perfSense && PYTHONPATH=. python backend/db/migrations/run_mysql_alter_payload.py
"""
import os
import sys

_here = os.path.dirname(os.path.abspath(__file__))
_root = os.path.abspath(os.path.join(_here, "..", "..", ".."))
if _root not in sys.path:
    sys.path.insert(0, _root)

def main():
    url = os.environ.get("DATABASE_URL", "").strip()
    if not url or "mysql" not in url.lower():
        print("Set DATABASE_URL (e.g. export DATABASE_URL='mysql+pymysql://root:password@localhost:3306/xrbn_db')")
        sys.exit(1)
    try:
        import pymysql
    except ImportError:
        print("pip install pymysql")
        sys.exit(1)
    from backend.db.db_connection import _parse_database_url
    kwargs = _parse_database_url(url)
    if not kwargs:
        print("Invalid DATABASE_URL")
        sys.exit(1)
    conn = pymysql.connect(
        host=kwargs["host"],
        port=kwargs["port"],
        user=kwargs["user"],
        password=kwargs["password"],
        database=kwargs["database"],
        charset="utf8mb4",
    )
    try:
        with conn.cursor() as cur:
            cur.execute("ALTER TABLE transactions MODIFY COLUMN headers LONGTEXT")
            cur.execute("ALTER TABLE transactions MODIFY COLUMN payload LONGTEXT")
        conn.commit()
        print("Done. transactions.headers and transactions.payload are now LONGTEXT.")
    except Exception as e:
        print("Error:", e)
        sys.exit(1)
    finally:
        conn.close()

if __name__ == "__main__":
    main()

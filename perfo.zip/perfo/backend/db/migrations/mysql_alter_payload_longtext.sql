-- Fix "Data too long for column 'payload'" - change TEXT to LONGTEXT for large request bodies.
-- Run once: mysql -u root -p xrbn_db < backend/db/migrations/mysql_alter_payload_longtext.sql
-- Or use: python backend/db/migrations/run_mysql_migration.py (it runs this if tables exist)

ALTER TABLE transactions MODIFY COLUMN headers LONGTEXT;
ALTER TABLE transactions MODIFY COLUMN payload LONGTEXT;

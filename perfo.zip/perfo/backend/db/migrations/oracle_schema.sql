-- Oracle schema for perfSense Script Parser module
-- Run this when switching from MongoDB to Oracle

-- Sequences for generated IDs
CREATE SEQUENCE scripts_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE transactions_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

-- Scripts table
CREATE TABLE scripts (
    id NUMBER PRIMARY KEY,
    script_name VARCHAR2(500) NOT NULL,
    script_type VARCHAR2(50) NOT NULL,
    upload_time TIMESTAMP DEFAULT SYSTIMESTAMP
);

-- Transactions table (parsed API requests)
CREATE TABLE transactions (
    id NUMBER PRIMARY KEY,
    script_id NUMBER NOT NULL,
    transaction_name VARCHAR2(500) NOT NULL,
    request_url VARCHAR2(4000) NOT NULL,
    http_method VARCHAR2(20) NOT NULL,
    headers CLOB,
    payload CLOB,
    execution_order NUMBER NOT NULL,
    CONSTRAINT fk_trans_script FOREIGN KEY (script_id) REFERENCES scripts(id) ON DELETE CASCADE
);

-- Generated Python script storage
CREATE TABLE python_scripts (
    script_id NUMBER PRIMARY KEY,
    code CLOB NOT NULL,
    CONSTRAINT fk_py_script FOREIGN KEY (script_id) REFERENCES scripts(id) ON DELETE CASCADE
);

-- Indexes
CREATE INDEX idx_transactions_script_id ON transactions(script_id);
CREATE INDEX idx_scripts_upload_time ON scripts(upload_time);

-- Trigger to use sequence for scripts.id
CREATE OR REPLACE TRIGGER scripts_before_insert
BEFORE INSERT ON scripts
FOR EACH ROW
BEGIN
    IF :NEW.id IS NULL THEN
        SELECT scripts_seq.NEXTVAL INTO :NEW.id FROM DUAL;
    END IF;
END;
/

-- Trigger to use sequence for transactions.id
CREATE OR REPLACE TRIGGER transactions_before_insert
BEFORE INSERT ON transactions
FOR EACH ROW
BEGIN
    IF :NEW.id IS NULL THEN
        SELECT transactions_seq.NEXTVAL INTO :NEW.id FROM DUAL;
    END IF;
END;
/

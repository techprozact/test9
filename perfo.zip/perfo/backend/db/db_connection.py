"""Database connection and store. MySQL (DATABASE_URL) > Oracle > MongoDB > FileStore > InMemoryStore."""
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

# Try Oracle first
try:
    import oracledb
    ORACLE_AVAILABLE = True
except ImportError:
    ORACLE_AVAILABLE = False

# MongoDB fallback
try:
    from pymongo import MongoClient
    from bson import ObjectId
    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False

# MySQL (DATABASE_URL)
try:
    import pymysql
    PYMYSQL_AVAILABLE = True
except ImportError:
    PYMYSQL_AVAILABLE = False

# Singleton stores
_mysql_store: "MySQLStore | None" = None
_in_memory_store: "InMemoryStore | None" = None
_mongo_store: "MongoStore | None" = None
_file_store: "FileStore | None" = None


def _parse_database_url(url: str) -> dict | None:
    """Parse DATABASE_URL (e.g. mysql+pymysql://user:pass@host:port/dbname) into connection kwargs."""
    if not url or not re.match(r"^mysql(\+pymysql)?://", url.strip(), re.I):
        return None
    try:
        parsed = urlparse(url)
        if "mysql" not in (parsed.scheme or "").lower():
            return None
        host = parsed.hostname or "localhost"
        port = parsed.port if parsed.port is not None else 3306
        user = parsed.username or "root"
        password = unquote(parsed.password) if parsed.password else ""
        database = (parsed.path or "/").strip("/")
        if not database:
            return None
        return {
            "host": host,
            "port": port,
            "user": user,
            "password": password,
            "database": database,
        }
    except Exception:
        return None


def get_db_store():
    """
    Return a DB store implementation.
    MySQL (DATABASE_URL) -> Oracle -> MongoDB -> FileStore -> InMemoryStore.
    """
    global _mysql_store, _in_memory_store, _mongo_store, _file_store
    db_url = os.environ.get("DATABASE_URL", "").strip()
    if db_url and PYMYSQL_AVAILABLE:
        kwargs = _parse_database_url(db_url)
        if kwargs:
            try:
                if _mysql_store is None:
                    _mysql_store = MySQLStore(**kwargs)
                return _mysql_store
            except Exception:
                _mysql_store = None
    if ORACLE_AVAILABLE:
        try:
            return OracleStore()
        except Exception:
            pass
    if MONGO_AVAILABLE:
        try:
            if _mongo_store is None:
                client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=2000)
                client.server_info()
                _mongo_store = MongoStore(client)
            return _mongo_store
        except Exception:
            pass
    if _file_store is None:
        try:
            _file_store = FileStore()
        except Exception:
            pass
    if _file_store is not None:
        return _file_store
    if _in_memory_store is None:
        _in_memory_store = InMemoryStore()
    return _in_memory_store


def _serialize_dt(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _serialize_dt(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_serialize_dt(v) for v in obj]
    return obj


class FileStore:
    """Persistent store using a single JSON file. Survives restarts and works across requests."""

    def __init__(self, file_path: str | None = None):
        if file_path is None:
            base = Path(__file__).resolve().parent
            file_path = str(base / "perfsense_data.json")
        self._path = file_path
        self._load()

    def _load(self) -> None:
        if os.path.isfile(self._path):
            try:
                with open(self._path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self._scripts = data.get("scripts", {})
                self._transactions = data.get("transactions", {})
                self._python_scripts = data.get("python_scripts", {})
                self._scenarios = data.get("scenarios", {})
                self._next_script_id = data.get("next_script_id", 1)
                self._next_tx_id = data.get("next_tx_id", 1)
            except Exception:
                self._scripts = {}
                self._transactions = {}
                self._python_scripts = {}
                self._scenarios = {}
                self._next_script_id = 1
                self._next_tx_id = 1
        else:
            self._scripts = {}
            self._transactions = {}
            self._python_scripts = {}
            self._scenarios = {}
            self._next_script_id = 1
            self._next_tx_id = 1

    def _save(self) -> None:
        data = {
            "scripts": self._scripts,
            "transactions": self._transactions,
            "python_scripts": self._python_scripts,
            "scenarios": self._scenarios,
            "next_script_id": self._next_script_id,
            "next_tx_id": self._next_tx_id,
        }
        data = _serialize_dt(data)
        path = Path(self._path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def insert_script(self, script_name: str, script_type: str) -> dict:
        sid = str(self._next_script_id)
        self._next_script_id += 1
        rec = {
            "id": sid,
            "script_name": script_name,
            "script_type": script_type,
            "upload_time": datetime.now(timezone.utc).isoformat(),
        }
        self._scripts[sid] = rec
        self._transactions[sid] = []
        self._save()
        return rec

    def insert_transaction(
        self,
        script_id: str,
        transaction_name: str,
        request_url: str,
        http_method: str,
        headers: dict,
        payload: dict | None,
        execution_order: int,
        response: dict | None = None,
    ) -> dict:
        tid = str(self._next_tx_id)
        self._next_tx_id += 1
        rec = {
            "id": tid,
            "script_id": script_id,
            "transaction_name": transaction_name,
            "request_url": request_url,
            "http_method": http_method,
            "headers": headers or {},
            "payload": payload,
            "execution_order": execution_order,
            "response": response,
        }
        self._transactions.setdefault(script_id, []).append(rec)
        self._save()
        return rec

    def save_python_script(self, script_id: str, code: str) -> None:
        self._python_scripts[script_id] = code
        self._save()

    def get_all_scripts(self) -> list[dict]:
        return sorted(
            self._scripts.values(),
            key=lambda x: x.get("upload_time", ""),
            reverse=True,
        )

    def get_script(self, script_id: str) -> dict | None:
        if not script_id or not str(script_id).strip():
            return None
        return self._scripts.get(str(script_id).strip())

    def get_transactions(self, script_id: str) -> list[dict]:
        if not script_id or not str(script_id).strip():
            return []
        tx_list = self._transactions.get(str(script_id).strip(), [])
        return sorted(tx_list, key=lambda x: x.get("execution_order", 0))

    def get_python_script(self, script_id: str) -> str | None:
        if not script_id or not str(script_id).strip():
            return None
        return self._python_scripts.get(str(script_id).strip())

    def delete_script(self, script_id: str) -> bool:
        sid = str(script_id).strip()
        if sid not in self._scripts:
            return False
        self._scripts.pop(sid, None)
        self._transactions.pop(sid, None)
        self._python_scripts.pop(sid, None)
        self._save()
        return True

    def insert_scenario(self, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict:
        sid = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        rec = {"id": sid, "scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "created_at": now, "updated_at": now}
        self._scenarios[sid] = rec
        self._save()
        return rec

    def update_scenario(self, scenario_id: str, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict | None:
        sid = str(scenario_id).strip()
        if sid not in self._scenarios:
            return None
        rec = self._scenarios[sid]
        rec.update({"scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "updated_at": datetime.now(timezone.utc).isoformat()})
        self._save()
        return rec

    def get_all_scenarios(self) -> list[dict]:
        return sorted(self._scenarios.values(), key=lambda x: x.get("updated_at", ""), reverse=True)

    def get_scenario(self, scenario_id: str) -> dict | None:
        return self._scenarios.get(str(scenario_id).strip())

    def delete_scenario(self, scenario_id: str) -> bool:
        sid = str(scenario_id).strip()
        if sid not in self._scenarios:
            return False
        self._scenarios.pop(sid, None)
        self._save()
        return True

    # ── Test Runs ──

    def insert_test_run(self, run_id, scenario_id, scenario_snapshot, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id="local") -> dict:
        now = datetime.now(timezone.utc).isoformat()
        rec = {"id": run_id, "scenario_id": scenario_id, "scenario_snapshot": scenario_snapshot, "status": "INITIALIZING", "start_time": now, "end_time": None, "planned_duration_secs": planned_duration_secs, "ramp_up_secs": ramp_up_secs, "ramp_down_secs": ramp_down_secs, "total_users_target": total_users_target, "total_users_spawned": 0, "engine_node_id": engine_node_id, "error_message": "", "created_at": now}
        if not hasattr(self, "_test_runs"):
            self._test_runs = {}
        self._test_runs[run_id] = rec
        self._save()
        return rec

    def update_test_run(self, run_id, **kwargs) -> dict | None:
        if not hasattr(self, "_test_runs"):
            self._test_runs = {}
        rec = self._test_runs.get(run_id)
        if not rec:
            return None
        for k, v in kwargs.items():
            if v is not None and k in rec:
                rec[k] = v.isoformat() if hasattr(v, "isoformat") else v
        self._save()
        return rec

    def get_test_run(self, run_id) -> dict | None:
        if not hasattr(self, "_test_runs"):
            self._test_runs = {}
        return self._test_runs.get(str(run_id))

    def get_all_test_runs(self) -> list[dict]:
        if not hasattr(self, "_test_runs"):
            self._test_runs = {}
        return sorted(self._test_runs.values(), key=lambda x: x.get("created_at", ""), reverse=True)

    def delete_test_run(self, run_id) -> None:
        if not hasattr(self, "_test_runs"):
            self._test_runs = {}
        self._test_runs.pop(str(run_id), None)
        if not hasattr(self, "_telemetry"):
            self._telemetry = []
        self._telemetry = [r for r in self._telemetry if r.get("test_run_id") != str(run_id)]
        self._save()

    def insert_telemetry_batch(self, records: list[dict]) -> None:
        if not hasattr(self, "_telemetry"):
            self._telemetry = []
        self._telemetry.extend(records)

    def get_telemetry(self, test_run_id, limit=500, offset=0) -> list[dict]:
        if not hasattr(self, "_telemetry"):
            self._telemetry = []
        filtered = [r for r in self._telemetry if r.get("test_run_id") == test_run_id]
        return filtered[offset:offset + limit]


class InMemoryStore:
    """In-memory store for development when no DB is available."""

    def __init__(self):
        self._scripts: dict[str, dict] = {}
        self._transactions: dict[str, list[dict]] = {}
        self._python_scripts: dict[str, str] = {}
        self._scenarios: dict[str, dict] = {}
        self._id = 0

    def _next_id(self) -> str:
        self._id += 1
        return str(self._id)

    def insert_script(self, script_name: str, script_type: str) -> dict:
        sid = self._next_id()
        rec = {
            "id": sid,
            "script_name": script_name,
            "script_type": script_type,
            "upload_time": datetime.now(timezone.utc),
        }
        self._scripts[sid] = rec
        self._transactions[sid] = []
        return rec

    def insert_transaction(
        self,
        script_id: str,
        transaction_name: str,
        request_url: str,
        http_method: str,
        headers: dict,
        payload: dict | None,
        execution_order: int,
        response: dict | None = None,
    ) -> dict:
        tid = self._next_id()
        rec = {
            "id": tid,
            "script_id": script_id,
            "transaction_name": transaction_name,
            "request_url": request_url,
            "http_method": http_method,
            "headers": headers,
            "payload": payload,
            "execution_order": execution_order,
            "response": response,
        }
        self._transactions.setdefault(script_id, []).append(rec)
        return rec

    def save_python_script(self, script_id: str, code: str) -> None:
        self._python_scripts[script_id] = code

    def get_all_scripts(self) -> list[dict]:
        return sorted(self._scripts.values(), key=lambda x: x.get("upload_time", ""), reverse=True)

    def get_script(self, script_id: str) -> dict | None:
        if not script_id or not str(script_id).strip():
            return None
        return self._scripts.get(str(script_id).strip())

    def get_transactions(self, script_id: str) -> list[dict]:
        if not script_id or not str(script_id).strip():
            return []
        tx_list = self._transactions.get(str(script_id).strip(), [])
        return sorted(tx_list, key=lambda x: x.get("execution_order", 0))

    def get_python_script(self, script_id: str) -> str | None:
        if not script_id or not str(script_id).strip():
            return None
        return self._python_scripts.get(str(script_id).strip())

    def delete_script(self, script_id: str) -> bool:
        sid = str(script_id).strip()
        if sid not in self._scripts:
            return False
        self._scripts.pop(sid, None)
        self._transactions.pop(sid, None)
        self._python_scripts.pop(sid, None)
        return True

    def insert_scenario(self, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict:
        sid = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        rec = {"id": sid, "scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "created_at": now, "updated_at": now}
        self._scenarios[sid] = rec
        return rec

    def update_scenario(self, scenario_id: str, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict | None:
        sid = str(scenario_id).strip()
        if sid not in self._scenarios:
            return None
        rec = self._scenarios[sid]
        rec.update({"scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "updated_at": datetime.now(timezone.utc)})
        return rec

    def get_all_scenarios(self) -> list[dict]:
        return sorted(self._scenarios.values(), key=lambda x: x.get("updated_at", ""), reverse=True)

    def get_scenario(self, scenario_id: str) -> dict | None:
        return self._scenarios.get(str(scenario_id).strip())

    def delete_scenario(self, scenario_id: str) -> bool:
        sid = str(scenario_id).strip()
        if sid not in self._scenarios:
            return False
        self._scenarios.pop(sid, None)
        return True

    # ── Test Runs ──

    def insert_test_run(self, run_id, scenario_id, scenario_snapshot, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id="local") -> dict:
        now = datetime.now(timezone.utc)
        rec = {"id": run_id, "scenario_id": scenario_id, "scenario_snapshot": scenario_snapshot, "status": "INITIALIZING", "start_time": now, "end_time": None, "planned_duration_secs": planned_duration_secs, "ramp_up_secs": ramp_up_secs, "ramp_down_secs": ramp_down_secs, "total_users_target": total_users_target, "total_users_spawned": 0, "engine_node_id": engine_node_id, "error_message": "", "created_at": now}
        self._test_runs = getattr(self, "_test_runs", {})
        self._test_runs[run_id] = rec
        return rec

    def update_test_run(self, run_id, **kwargs) -> dict | None:
        self._test_runs = getattr(self, "_test_runs", {})
        rec = self._test_runs.get(run_id)
        if not rec:
            return None
        for k, v in kwargs.items():
            if v is not None and k in rec:
                rec[k] = v
        return rec

    def get_test_run(self, run_id) -> dict | None:
        self._test_runs = getattr(self, "_test_runs", {})
        return self._test_runs.get(str(run_id))

    def get_all_test_runs(self) -> list[dict]:
        self._test_runs = getattr(self, "_test_runs", {})
        return sorted(self._test_runs.values(), key=lambda x: x.get("created_at", ""), reverse=True)

    def delete_test_run(self, run_id) -> None:
        self._test_runs = getattr(self, "_test_runs", {})
        self._test_runs.pop(str(run_id), None)
        self._telemetry = getattr(self, "_telemetry", [])
        self._telemetry = [r for r in self._telemetry if r.get("test_run_id") != str(run_id)]

    def insert_telemetry_batch(self, records: list[dict]) -> None:
        self._telemetry = getattr(self, "_telemetry", [])
        self._telemetry.extend(records)

    def get_telemetry(self, test_run_id, limit=500, offset=0) -> list[dict]:
        self._telemetry = getattr(self, "_telemetry", [])
        filtered = [r for r in self._telemetry if r.get("test_run_id") == test_run_id]
        return filtered[offset:offset + limit]


class MySQLStore:
    """MySQL store using DATABASE_URL. Persists across restarts."""

    def __init__(self, host: str, port: int, user: str, password: str, database: str):
        self._kwargs = {
            "host": host,
            "port": port,
            "user": user,
            "password": password,
            "database": database,
            "charset": "utf8mb4",
            "cursorclass": pymysql.cursors.DictCursor,
            "autocommit": True,
        }

    def _conn(self):
        return pymysql.connect(**self._kwargs)

    def insert_script(self, script_name: str, script_type: str) -> dict:
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO scripts (script_name, script_type, upload_time) VALUES (%s, %s, %s)",
                    (script_name, script_type, datetime.now(timezone.utc)),
                )
                sid = cur.lastrowid
            return {
                "id": str(sid),
                "script_name": script_name,
                "script_type": script_type,
                "upload_time": datetime.now(timezone.utc),
            }
        finally:
            conn.close()

    def insert_transaction(
        self,
        script_id: str,
        transaction_name: str,
        request_url: str,
        http_method: str,
        headers: dict,
        payload: dict | None,
        execution_order: int,
        response: dict | None = None,
    ) -> dict:
        conn = self._conn()
        try:
            headers_json = json.dumps(headers or {})
            payload_json = json.dumps(payload) if payload is not None else None
            response_json = json.dumps(response) if response is not None else None
            with conn.cursor() as cur:
                try:
                    cur.execute(
                        """INSERT INTO transactions
                        (script_id, transaction_name, request_url, http_method, headers, payload, execution_order, response)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                        (script_id, transaction_name, request_url, http_method, headers_json, payload_json, execution_order, response_json),
                    )
                except Exception:
                    cur.execute(
                        """INSERT INTO transactions
                        (script_id, transaction_name, request_url, http_method, headers, payload, execution_order)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                        (script_id, transaction_name, request_url, http_method, headers_json, payload_json, execution_order),
                    )
                tid = cur.lastrowid
            return {
                "id": str(tid),
                "script_id": script_id,
                "transaction_name": transaction_name,
                "request_url": request_url,
                "http_method": http_method,
                "headers": headers or {},
                "payload": payload,
                "execution_order": execution_order,
                "response": response,
            }
        finally:
            conn.close()

    def save_python_script(self, script_id: str, code: str) -> None:
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO python_scripts (script_id, code) VALUES (%s, %s) ON DUPLICATE KEY UPDATE code = VALUES(code)",
                    (script_id, code),
                )
        finally:
            conn.close()

    def get_all_scripts(self) -> list[dict]:
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id, script_name, script_type, upload_time FROM scripts ORDER BY upload_time DESC")
                rows = cur.fetchall()
            return [
                {"id": str(r["id"]), "script_name": r["script_name"], "script_type": r["script_type"], "upload_time": r["upload_time"]}
                for r in rows
            ]
        finally:
            conn.close()

    def get_script(self, script_id: str) -> dict | None:
        if not script_id or not str(script_id).strip():
            return None
        sid = str(script_id).strip()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT id, script_name, script_type, upload_time FROM scripts WHERE id = %s",
                    (sid,),
                )
                row = cur.fetchone()
            if not row:
                return None
            row = {k.lower(): v for k, v in row.items()} if isinstance(row, dict) else row
            return {
                "id": str(row.get("id", "")),
                "script_name": row.get("script_name", ""),
                "script_type": row.get("script_type", ""),
                "upload_time": row.get("upload_time"),
            }
        finally:
            conn.close()

    def get_transactions(self, script_id: str) -> list[dict]:
        if not script_id or not str(script_id).strip():
            return []
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                try:
                    cur.execute(
                        "SELECT id, script_id, transaction_name, request_url, http_method, headers, payload, execution_order, response FROM transactions WHERE script_id = %s ORDER BY execution_order",
                        (str(script_id).strip(),),
                    )
                except Exception:
                    cur.execute(
                        "SELECT id, script_id, transaction_name, request_url, http_method, headers, payload, execution_order FROM transactions WHERE script_id = %s ORDER BY execution_order",
                        (str(script_id).strip(),),
                    )
                rows = cur.fetchall()
            out = []
            for r in rows:
                headers = r["headers"]
                if isinstance(headers, str):
                    try:
                        headers = json.loads(headers)
                    except Exception:
                        headers = {}
                payload = r["payload"]
                if isinstance(payload, str) and payload:
                    try:
                        payload = json.loads(payload)
                    except Exception:
                        payload = {"raw": payload}
                response = r.get("response")
                if isinstance(response, str) and response:
                    try:
                        response = json.loads(response)
                    except Exception:
                        response = None
                out.append({
                    "id": str(r["id"]),
                    "script_id": str(r["script_id"]),
                    "transaction_name": r["transaction_name"],
                    "request_url": r["request_url"],
                    "http_method": r["http_method"],
                    "headers": headers or {},
                    "payload": payload,
                    "execution_order": r["execution_order"],
                    "response": response,
                })
            return out
        finally:
            conn.close()

    def get_python_script(self, script_id: str) -> str | None:
        if not script_id or not str(script_id).strip():
            return None
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT code FROM python_scripts WHERE script_id = %s", (str(script_id).strip(),))
                row = cur.fetchone()
            return row["code"] if row else None
        finally:
            conn.close()

    def delete_script(self, script_id: str) -> bool:
        sid = str(script_id).strip()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM transactions WHERE script_id = %s", (sid,))
                cur.execute("DELETE FROM python_scripts WHERE script_id = %s", (sid,))
                cur.execute("DELETE FROM scripts WHERE id = %s", (sid,))
                affected = cur.rowcount
            return affected > 0
        finally:
            conn.close()

    def _ensure_scenarios_table(self):
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS scenarios (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        scenario_name VARCHAR(500) NOT NULL,
                        description TEXT,
                        duration VARCHAR(50),
                        ramp_up VARCHAR(50),
                        ramp_down VARCHAR(50),
                        scripts_json LONGTEXT,
                        created_at DATETIME(6) NOT NULL,
                        updated_at DATETIME(6) NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """)
        finally:
            conn.close()

    def insert_scenario(self, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict:
        self._ensure_scenarios_table()
        now = datetime.now(timezone.utc)
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO scenarios (scenario_name, description, duration, ramp_up, ramp_down, scripts_json, created_at, updated_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                    (scenario_name, description, duration, ramp_up, ramp_down, scripts_json, now, now),
                )
                sid = cur.lastrowid
            return {"id": str(sid), "scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "created_at": now, "updated_at": now}
        finally:
            conn.close()

    def update_scenario(self, scenario_id: str, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict | None:
        self._ensure_scenarios_table()
        now = datetime.now(timezone.utc)
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE scenarios SET scenario_name=%s, description=%s, duration=%s, ramp_up=%s, ramp_down=%s, scripts_json=%s, updated_at=%s WHERE id=%s",
                    (scenario_name, description, duration, ramp_up, ramp_down, scripts_json, now, scenario_id),
                )
                if cur.rowcount == 0:
                    return None
                cur.execute("SELECT id, scenario_name, description, duration, ramp_up, ramp_down, scripts_json, created_at, updated_at FROM scenarios WHERE id=%s", (scenario_id,))
                row = cur.fetchone()
            if not row:
                return None
            return {k: (str(v) if k == "id" else v) for k, v in row.items()}
        finally:
            conn.close()

    def get_all_scenarios(self) -> list[dict]:
        self._ensure_scenarios_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id, scenario_name, description, duration, ramp_up, ramp_down, scripts_json, created_at, updated_at FROM scenarios ORDER BY updated_at DESC")
                rows = cur.fetchall()
            return [{"id": str(r["id"]), **{k: v for k, v in r.items() if k != "id"}} for r in rows]
        finally:
            conn.close()

    def get_scenario(self, scenario_id: str) -> dict | None:
        self._ensure_scenarios_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id, scenario_name, description, duration, ramp_up, ramp_down, scripts_json, created_at, updated_at FROM scenarios WHERE id=%s", (str(scenario_id).strip(),))
                row = cur.fetchone()
            if not row:
                return None
            return {"id": str(row["id"]), **{k: v for k, v in row.items() if k != "id"}}
        finally:
            conn.close()

    def delete_scenario(self, scenario_id: str) -> bool:
        self._ensure_scenarios_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM scenarios WHERE id=%s", (str(scenario_id).strip(),))
                return cur.rowcount > 0
        finally:
            conn.close()

    # ── Test Runs ──

    def _ensure_test_runs_table(self):
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS test_runs (
                        id VARCHAR(36) PRIMARY KEY,
                        scenario_id VARCHAR(50),
                        scenario_snapshot LONGTEXT,
                        status VARCHAR(30) NOT NULL DEFAULT 'INITIALIZING',
                        start_time DATETIME(6),
                        end_time DATETIME(6),
                        planned_duration_secs INT,
                        ramp_up_secs INT,
                        ramp_down_secs INT,
                        total_users_target INT DEFAULT 0,
                        total_users_spawned INT DEFAULT 0,
                        engine_node_id VARCHAR(100) DEFAULT 'local',
                        error_message TEXT,
                        created_at DATETIME(6) NOT NULL,
                        INDEX idx_test_run_status (status),
                        INDEX idx_test_run_created (created_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """)
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS request_telemetry (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        test_run_id VARCHAR(36) NOT NULL,
                        script_id VARCHAR(50) NOT NULL,
                        virtual_user_id VARCHAR(100) NOT NULL,
                        iteration INT NOT NULL DEFAULT 1,
                        iteration_id VARCHAR(80) NOT NULL DEFAULT '',
                        sequence_number INT NOT NULL DEFAULT 0,
                        request_start_ts DATETIME(6) NOT NULL,
                        request_end_ts DATETIME(6) NOT NULL,
                        response_time_ms INT NOT NULL,
                        http_status_code INT,
                        success TINYINT(1) NOT NULL DEFAULT 1,
                        error_message TEXT,
                        request_method VARCHAR(10) NOT NULL,
                        api_path VARCHAR(2000),
                        bytes_sent INT DEFAULT 0,
                        bytes_received INT DEFAULT 0,
                        INDEX idx_telemetry_run (test_run_id),
                        INDEX idx_telemetry_run_script (test_run_id, script_id),
                        INDEX idx_telemetry_ts (test_run_id, request_start_ts),
                        INDEX idx_telemetry_iteration (test_run_id, iteration_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """)
        finally:
            conn.close()

    def insert_test_run(self, run_id, scenario_id, scenario_snapshot, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id="local") -> dict:
        self._ensure_test_runs_table()
        now = datetime.now(timezone.utc)
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO test_runs (id, scenario_id, scenario_snapshot, status, start_time, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id, created_at) VALUES (%s,%s,%s,'INITIALIZING',%s,%s,%s,%s,%s,%s,%s)",
                    (run_id, scenario_id, scenario_snapshot, now, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id, now),
                )
            return {"id": run_id, "scenario_id": scenario_id, "status": "INITIALIZING", "start_time": now, "created_at": now}
        finally:
            conn.close()

    def update_test_run(self, run_id, **kwargs) -> dict | None:
        self._ensure_test_runs_table()
        if not kwargs:
            return self.get_test_run(run_id)
        sets = []
        vals = []
        for k, v in kwargs.items():
            if v is not None:
                sets.append(f"{k}=%s")
                vals.append(v)
        if not sets:
            return self.get_test_run(run_id)
        vals.append(run_id)
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(f"UPDATE test_runs SET {', '.join(sets)} WHERE id=%s", vals)
            return self.get_test_run(run_id)
        finally:
            conn.close()

    def get_test_run(self, run_id) -> dict | None:
        self._ensure_test_runs_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM test_runs WHERE id=%s", (str(run_id),))
                row = cur.fetchone()
            return row if row else None
        finally:
            conn.close()

    def get_all_test_runs(self) -> list[dict]:
        self._ensure_test_runs_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM test_runs ORDER BY created_at DESC")
                return cur.fetchall()
        finally:
            conn.close()

    def delete_test_run(self, run_id) -> None:
        self._ensure_test_runs_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM request_telemetry WHERE test_run_id=%s", (str(run_id),))
                cur.execute("DELETE FROM test_runs WHERE id=%s", (str(run_id),))
            conn.commit()
        finally:
            conn.close()

    def insert_telemetry_batch(self, records: list[dict]) -> None:
        if not records:
            return
        self._ensure_test_runs_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                sql = """INSERT INTO request_telemetry
                    (test_run_id, script_id, virtual_user_id, iteration,
                     iteration_id, sequence_number,
                     request_start_ts, request_end_ts, response_time_ms,
                     http_status_code, success, error_message,
                     request_method, api_path, bytes_sent, bytes_received)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                rows = [
                    (r["test_run_id"], r["script_id"], r["virtual_user_id"], r["iteration"],
                     r.get("iteration_id", ""), r.get("sequence_number", 0),
                     r["request_start_ts"], r["request_end_ts"], r["response_time_ms"],
                     r["http_status_code"], 1 if r["success"] else 0, r.get("error_message", ""),
                     r["request_method"], r["api_path"], r.get("bytes_sent", 0), r.get("bytes_received", 0))
                    for r in records
                ]
                cur.executemany(sql, rows)
        finally:
            conn.close()

    def get_telemetry(self, test_run_id, limit=500, offset=0) -> list[dict]:
        self._ensure_test_runs_table()
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT * FROM request_telemetry WHERE test_run_id=%s ORDER BY request_start_ts LIMIT %s OFFSET %s",
                    (test_run_id, limit, offset),
                )
                return cur.fetchall()
        finally:
            conn.close()


class MongoStore:
    """MongoDB store for scripts and transactions."""

    def __init__(self, client=None):
        self._client = client or MongoClient("mongodb://localhost:27017/")
        self._db = self._client["perfsense"]
        self._scripts = self._db["scripts"]
        self._transactions = self._db["transactions"]
        self._python_scripts = self._db["python_scripts"]

    def insert_script(self, script_name: str, script_type: str) -> dict:
        doc = {
            "script_name": script_name,
            "script_type": script_type,
            "upload_time": datetime.now(timezone.utc),
        }
        r = self._scripts.insert_one(doc)
        doc["id"] = str(r.inserted_id)
        return doc

    def insert_transaction(
        self,
        script_id: str,
        transaction_name: str,
        request_url: str,
        http_method: str,
        headers: dict,
        payload: dict | None,
        execution_order: int,
        response: dict | None = None,
    ) -> dict:
        doc = {
            "script_id": script_id,
            "transaction_name": transaction_name,
            "request_url": request_url,
            "http_method": http_method,
            "headers": headers or {},
            "payload": payload,
            "execution_order": execution_order,
            "response": response,
        }
        r = self._transactions.insert_one(doc)
        doc["id"] = str(r.inserted_id)
        return doc

    def save_python_script(self, script_id: str, code: str) -> None:
        self._python_scripts.update_one(
            {"script_id": script_id},
            {"$set": {"script_id": script_id, "code": code}},
            upsert=True,
        )

    def get_all_scripts(self) -> list[dict]:
        out = []
        for doc in self._scripts.find().sort("upload_time", -1):
            doc["id"] = str(doc.pop("_id", doc.get("id", "")))
            if "id" not in doc or not doc["id"]:
                doc["id"] = str(doc.get("_id", ""))
            out.append(doc)
        return out

    def get_script(self, script_id: str) -> dict | None:
        if not script_id or not str(script_id).strip():
            return None
        script_id = str(script_id).strip()
        try:
            if len(script_id) == 24 and all(c in "0123456789abcdefABCDEF" for c in script_id):
                doc = self._scripts.find_one({"_id": ObjectId(script_id)})
            else:
                doc = self._scripts.find_one({"id": script_id})
        except Exception:
            doc = self._scripts.find_one({"id": script_id})
        if not doc:
            return None
        doc["id"] = str(doc.get("_id", doc.get("id", "")))
        return doc

    def get_transactions(self, script_id: str) -> list[dict]:
        if not script_id or not str(script_id).strip():
            return []
        script_id = str(script_id).strip()
        out = []
        for doc in self._transactions.find({"script_id": script_id}).sort("execution_order", 1):
            doc["id"] = str(doc.pop("_id", doc.get("id", "")))
            out.append(doc)
        return out

    def get_python_script(self, script_id: str) -> str | None:
        rec = self._python_scripts.find_one({"script_id": script_id})
        return rec.get("code") if rec else None

    def delete_script(self, script_id: str) -> bool:
        script_id = str(script_id).strip()
        try:
            oid = ObjectId(script_id) if len(script_id) == 24 else None
        except Exception:
            oid = None
        query = {"_id": oid} if oid else {"id": script_id}
        result = self._scripts.delete_one(query)
        self._transactions.delete_many({"script_id": script_id})
        self._python_scripts.delete_many({"script_id": script_id})
        return result.deleted_count > 0

    def insert_scenario(self, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict:
        now = datetime.now(timezone.utc)
        doc = {"scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "created_at": now, "updated_at": now}
        col = self._db["scenarios"]
        r = col.insert_one(doc)
        doc["id"] = str(r.inserted_id)
        return doc

    def update_scenario(self, scenario_id: str, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict | None:
        col = self._db["scenarios"]
        now = datetime.now(timezone.utc)
        try:
            oid = ObjectId(scenario_id) if len(scenario_id) == 24 else None
        except Exception:
            oid = None
        query = {"_id": oid} if oid else {"id": scenario_id}
        result = col.find_one_and_update(query, {"$set": {"scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "updated_at": now}}, return_document=True)
        if not result:
            return None
        result["id"] = str(result.pop("_id", result.get("id", "")))
        return result

    def get_all_scenarios(self) -> list[dict]:
        col = self._db["scenarios"]
        out = []
        for doc in col.find().sort("updated_at", -1):
            doc["id"] = str(doc.pop("_id", doc.get("id", "")))
            out.append(doc)
        return out

    def get_scenario(self, scenario_id: str) -> dict | None:
        col = self._db["scenarios"]
        try:
            oid = ObjectId(scenario_id) if len(scenario_id) == 24 else None
        except Exception:
            oid = None
        doc = col.find_one({"_id": oid} if oid else {"id": scenario_id})
        if not doc:
            return None
        doc["id"] = str(doc.pop("_id", doc.get("id", "")))
        return doc

    def delete_scenario(self, scenario_id: str) -> bool:
        col = self._db["scenarios"]
        try:
            oid = ObjectId(scenario_id) if len(scenario_id) == 24 else None
        except Exception:
            oid = None
        result = col.delete_one({"_id": oid} if oid else {"id": scenario_id})
        return result.deleted_count > 0

    # ── Test Runs ──

    def insert_test_run(self, run_id, scenario_id, scenario_snapshot, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id="local") -> dict:
        now = datetime.now(timezone.utc)
        doc = {"_id": run_id, "id": run_id, "scenario_id": scenario_id, "scenario_snapshot": scenario_snapshot, "status": "INITIALIZING", "start_time": now, "end_time": None, "planned_duration_secs": planned_duration_secs, "ramp_up_secs": ramp_up_secs, "ramp_down_secs": ramp_down_secs, "total_users_target": total_users_target, "total_users_spawned": 0, "engine_node_id": engine_node_id, "error_message": "", "created_at": now}
        self._db["test_runs"].insert_one(doc)
        doc["id"] = run_id
        return doc

    def update_test_run(self, run_id, **kwargs) -> dict | None:
        if not kwargs:
            return self.get_test_run(run_id)
        updates = {k: v for k, v in kwargs.items() if v is not None}
        self._db["test_runs"].update_one({"_id": run_id}, {"$set": updates})
        return self.get_test_run(run_id)

    def get_test_run(self, run_id) -> dict | None:
        doc = self._db["test_runs"].find_one({"_id": str(run_id)})
        if doc:
            doc["id"] = str(doc.pop("_id", doc.get("id", "")))
        return doc

    def get_all_test_runs(self) -> list[dict]:
        out = []
        for doc in self._db["test_runs"].find().sort("created_at", -1):
            doc["id"] = str(doc.pop("_id", doc.get("id", "")))
            out.append(doc)
        return out

    def delete_test_run(self, run_id) -> None:
        self._db["request_telemetry"].delete_many({"test_run_id": str(run_id)})
        self._db["test_runs"].delete_one({"_id": str(run_id)})

    def insert_telemetry_batch(self, records: list[dict]) -> None:
        if records:
            self._db["request_telemetry"].insert_many(records)

    def get_telemetry(self, test_run_id, limit=500, offset=0) -> list[dict]:
        out = []
        for doc in self._db["request_telemetry"].find({"test_run_id": test_run_id}).sort("request_start_ts", 1).skip(offset).limit(limit):
            doc["id"] = str(doc.pop("_id", ""))
            out.append(doc)
        return out


class OracleStore:
    """Oracle DB store. Use when oracledb is installed and configured."""

    def __init__(self):
        # Default connection string; override via env in production
        import os
        self._dsn = os.environ.get("ORACLE_DSN", "localhost:1521/XE")
        self._user = os.environ.get("ORACLE_USER", "perfsense")
        self._password = os.environ.get("ORACLE_PASSWORD", "perfsense")
        self._conn = oracledb.connect(user=self._user, password=self._password, dsn=self._dsn)

    def insert_script(self, script_name: str, script_type: str) -> dict:
        cur = self._conn.cursor()
        id_var = cur.var(oracledb.NUMBER)
        cur.execute(
            """
            INSERT INTO scripts (id, script_name, script_type, upload_time)
            VALUES (scripts_seq.NEXTVAL, :1, :2, SYSTIMESTAMP)
            RETURNING id INTO :id
            """,
            [script_name, script_type],
            {"id": id_var},
        )
        sid = id_var.getvalue(0)
        self._conn.commit()
        cur.close()
        return {
            "id": str(sid),
            "script_name": script_name,
            "script_type": script_type,
            "upload_time": datetime.now(timezone.utc),
        }

    def insert_transaction(
        self,
        script_id: str,
        transaction_name: str,
        request_url: str,
        http_method: str,
        headers: dict,
        payload: dict | None,
        execution_order: int,
        response: dict | None = None,
    ) -> dict:
        import json
        cur = self._conn.cursor()
        id_var = cur.var(oracledb.NUMBER)
        headers_json = json.dumps(headers or {})
        payload_json = json.dumps(payload) if payload is not None else None
        response_json = json.dumps(response) if response is not None else None
        try:
            cur.execute(
                """
                INSERT INTO transactions (id, script_id, transaction_name, request_url, http_method, headers, payload, execution_order, response)
                VALUES (transactions_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, :7, :8)
                RETURNING id INTO :id
                """,
                [script_id, transaction_name, request_url, http_method, headers_json, payload_json, execution_order, response_json],
                {"id": id_var},
            )
        except Exception:
            cur.execute(
                """
                INSERT INTO transactions (id, script_id, transaction_name, request_url, http_method, headers, payload, execution_order)
                VALUES (transactions_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, :7)
                RETURNING id INTO :id
                """,
                [script_id, transaction_name, request_url, http_method, headers_json, payload_json, execution_order],
                {"id": id_var},
            )
        tid = id_var.getvalue(0)
        self._conn.commit()
        cur.close()
        return {
            "id": str(tid),
            "script_id": script_id,
            "transaction_name": transaction_name,
            "request_url": request_url,
            "http_method": http_method,
            "headers": headers or {},
            "payload": payload,
            "execution_order": execution_order,
            "response": response,
        }

    def save_python_script(self, script_id: str, code: str) -> None:
        cur = self._conn.cursor()
        cur.execute(
            """
            MERGE INTO python_scripts p USING (SELECT :1 AS script_id FROM DUAL) s
            ON (p.script_id = s.script_id)
            WHEN MATCHED THEN UPDATE SET code = :2
            WHEN NOT MATCHED THEN INSERT (script_id, code) VALUES (:1, :2)
            """,
            [script_id, code],
        )
        self._conn.commit()
        cur.close()

    def get_all_scripts(self) -> list[dict]:
        cur = self._conn.cursor()
        cur.execute("SELECT id, script_name, script_type, upload_time FROM scripts ORDER BY upload_time DESC")
        rows = cur.fetchall()
        cur.close()
        return [
            {"id": str(r[0]), "script_name": r[1], "script_type": r[2], "upload_time": r[3]}
            for r in rows
        ]

    def get_script(self, script_id: str) -> dict | None:
        cur = self._conn.cursor()
        cur.execute(
            "SELECT id, script_name, script_type, upload_time FROM scripts WHERE id = :1",
            [script_id],
        )
        row = cur.fetchone()
        cur.close()
        if not row:
            return None
        return {"id": str(row[0]), "script_name": row[1], "script_type": row[2], "upload_time": row[3]}

    def get_transactions(self, script_id: str) -> list[dict]:
        import json
        cur = self._conn.cursor()
        has_response_col = True
        try:
            cur.execute(
                "SELECT id, script_id, transaction_name, request_url, http_method, headers, payload, execution_order, response FROM transactions WHERE script_id = :1 ORDER BY execution_order",
                [script_id],
            )
        except Exception:
            has_response_col = False
            cur.execute(
                "SELECT id, script_id, transaction_name, request_url, http_method, headers, payload, execution_order FROM transactions WHERE script_id = :1 ORDER BY execution_order",
                [script_id],
            )
        rows = cur.fetchall()
        cur.close()
        out = []
        for r in rows:
            headers = r[5]
            if isinstance(headers, str):
                try:
                    headers = json.loads(headers)
                except Exception:
                    headers = {}
            payload = r[6]
            if isinstance(payload, str) and payload:
                try:
                    payload = json.loads(payload)
                except Exception:
                    payload = {"raw": payload}
            response = r[8] if has_response_col and len(r) > 8 else None
            if isinstance(response, str) and response:
                try:
                    response = json.loads(response)
                except Exception:
                    response = None
            out.append({
                "id": str(r[0]),
                "script_id": str(r[1]),
                "transaction_name": r[2],
                "request_url": r[3],
                "http_method": r[4],
                "headers": headers or {},
                "payload": payload,
                "execution_order": r[7],
                "response": response,
            })
        return out

    def get_python_script(self, script_id: str) -> str | None:
        cur = self._conn.cursor()
        cur.execute("SELECT code FROM python_scripts WHERE script_id = :1", [script_id])
        row = cur.fetchone()
        cur.close()
        return row[0] if row else None

    def delete_script(self, script_id: str) -> bool:
        cur = self._conn.cursor()
        cur.execute("DELETE FROM transactions WHERE script_id = :1", [script_id])
        cur.execute("DELETE FROM python_scripts WHERE script_id = :1", [script_id])
        cur.execute("DELETE FROM scripts WHERE id = :1", [script_id])
        affected = cur.rowcount
        self._conn.commit()
        cur.close()
        return affected > 0

    def insert_scenario(self, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict:
        now = datetime.now(timezone.utc)
        cur = self._conn.cursor()
        id_var = cur.var(oracledb.NUMBER)
        cur.execute(
            "INSERT INTO scenarios (id, scenario_name, description, duration, ramp_up, ramp_down, scripts_json, created_at, updated_at) VALUES (scenarios_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, :7, :8) RETURNING id INTO :id",
            [scenario_name, description, duration, ramp_up, ramp_down, scripts_json, now, now], {"id": id_var},
        )
        sid = id_var.getvalue(0)
        self._conn.commit()
        cur.close()
        return {"id": str(sid), "scenario_name": scenario_name, "description": description, "duration": duration, "ramp_up": ramp_up, "ramp_down": ramp_down, "scripts_json": scripts_json, "created_at": now, "updated_at": now}

    def update_scenario(self, scenario_id: str, scenario_name: str, description: str, duration: str, ramp_up: str, ramp_down: str, scripts_json: str) -> dict | None:
        now = datetime.now(timezone.utc)
        cur = self._conn.cursor()
        cur.execute(
            "UPDATE scenarios SET scenario_name=:1, description=:2, duration=:3, ramp_up=:4, ramp_down=:5, scripts_json=:6, updated_at=:7 WHERE id=:8",
            [scenario_name, description, duration, ramp_up, ramp_down, scripts_json, now, scenario_id],
        )
        if cur.rowcount == 0:
            cur.close()
            return None
        self._conn.commit()
        cur.close()
        return self.get_scenario(scenario_id)

    def get_all_scenarios(self) -> list[dict]:
        cur = self._conn.cursor()
        cur.execute("SELECT id, scenario_name, description, duration, ramp_up, ramp_down, scripts_json, created_at, updated_at FROM scenarios ORDER BY updated_at DESC")
        rows = cur.fetchall()
        cur.close()
        return [{"id": str(r[0]), "scenario_name": r[1], "description": r[2], "duration": r[3], "ramp_up": r[4], "ramp_down": r[5], "scripts_json": r[6], "created_at": r[7], "updated_at": r[8]} for r in rows]

    def get_scenario(self, scenario_id: str) -> dict | None:
        cur = self._conn.cursor()
        cur.execute("SELECT id, scenario_name, description, duration, ramp_up, ramp_down, scripts_json, created_at, updated_at FROM scenarios WHERE id=:1", [scenario_id])
        r = cur.fetchone()
        cur.close()
        if not r:
            return None
        return {"id": str(r[0]), "scenario_name": r[1], "description": r[2], "duration": r[3], "ramp_up": r[4], "ramp_down": r[5], "scripts_json": r[6], "created_at": r[7], "updated_at": r[8]}

    def delete_scenario(self, scenario_id: str) -> bool:
        cur = self._conn.cursor()
        cur.execute("DELETE FROM scenarios WHERE id=:1", [scenario_id])
        affected = cur.rowcount
        self._conn.commit()
        cur.close()
        return affected > 0

    # ── Test Runs ──

    def insert_test_run(self, run_id, scenario_id, scenario_snapshot, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id="local") -> dict:
        now = datetime.now(timezone.utc)
        cur = self._conn.cursor()
        cur.execute(
            "INSERT INTO test_runs (id, scenario_id, scenario_snapshot, status, start_time, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id, created_at) VALUES (:1,:2,:3,'INITIALIZING',:4,:5,:6,:7,:8,:9,:10)",
            [run_id, scenario_id, scenario_snapshot, now, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, engine_node_id, now],
        )
        self._conn.commit()
        cur.close()
        return {"id": run_id, "status": "INITIALIZING", "start_time": now}

    def update_test_run(self, run_id, **kwargs) -> dict | None:
        if not kwargs:
            return self.get_test_run(run_id)
        sets = []
        vals = []
        idx = 1
        for k, v in kwargs.items():
            if v is not None:
                sets.append(f"{k}=:{idx}")
                vals.append(v)
                idx += 1
        vals.append(run_id)
        cur = self._conn.cursor()
        cur.execute(f"UPDATE test_runs SET {', '.join(sets)} WHERE id=:{idx}", vals)
        self._conn.commit()
        cur.close()
        return self.get_test_run(run_id)

    def get_test_run(self, run_id) -> dict | None:
        cur = self._conn.cursor()
        cur.execute("SELECT id, scenario_id, status, start_time, end_time, planned_duration_secs, ramp_up_secs, ramp_down_secs, total_users_target, total_users_spawned, engine_node_id, error_message, created_at FROM test_runs WHERE id=:1", [str(run_id)])
        r = cur.fetchone()
        cur.close()
        if not r:
            return None
        return {"id": r[0], "scenario_id": r[1], "status": r[2], "start_time": r[3], "end_time": r[4], "planned_duration_secs": r[5], "ramp_up_secs": r[6], "ramp_down_secs": r[7], "total_users_target": r[8], "total_users_spawned": r[9], "engine_node_id": r[10], "error_message": r[11], "created_at": r[12]}

    def get_all_test_runs(self) -> list[dict]:
        cur = self._conn.cursor()
        cur.execute("SELECT id, scenario_id, status, start_time, end_time, planned_duration_secs, total_users_target, total_users_spawned, engine_node_id, created_at FROM test_runs ORDER BY created_at DESC")
        rows = cur.fetchall()
        cur.close()
        return [{"id": r[0], "scenario_id": r[1], "status": r[2], "start_time": r[3], "end_time": r[4], "planned_duration_secs": r[5], "total_users_target": r[6], "total_users_spawned": r[7], "engine_node_id": r[8], "created_at": r[9]} for r in rows]

    def delete_test_run(self, run_id) -> None:
        cur = self._conn.cursor()
        cur.execute("DELETE FROM request_telemetry WHERE test_run_id=:1", [str(run_id)])
        cur.execute("DELETE FROM test_runs WHERE id=:1", [str(run_id)])
        self._conn.commit()
        cur.close()

    def insert_telemetry_batch(self, records: list[dict]) -> None:
        if not records:
            return
        cur = self._conn.cursor()
        sql = """INSERT INTO request_telemetry (test_run_id, script_id, virtual_user_id, iteration, iteration_id, sequence_number, request_start_ts, request_end_ts, response_time_ms, http_status_code, success, error_message, request_method, api_path, bytes_sent, bytes_received)
                 VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16)"""
        rows = [(r["test_run_id"], r["script_id"], r["virtual_user_id"], r["iteration"], r.get("iteration_id", ""), r.get("sequence_number", 0), r["request_start_ts"], r["request_end_ts"], r["response_time_ms"], r["http_status_code"], 1 if r["success"] else 0, r.get("error_message", ""), r["request_method"], r["api_path"], r.get("bytes_sent", 0), r.get("bytes_received", 0)) for r in records]
        cur.executemany(sql, rows)
        self._conn.commit()
        cur.close()

    def get_telemetry(self, test_run_id, limit=500, offset=0) -> list[dict]:
        cur = self._conn.cursor()
        cur.execute("SELECT test_run_id, script_id, virtual_user_id, iteration, iteration_id, sequence_number, request_start_ts, request_end_ts, response_time_ms, http_status_code, success, error_message, request_method, api_path, bytes_sent, bytes_received FROM request_telemetry WHERE test_run_id=:1 ORDER BY request_start_ts OFFSET :2 ROWS FETCH NEXT :3 ROWS ONLY", [test_run_id, offset, limit])
        rows = cur.fetchall()
        cur.close()
        return [{"test_run_id": r[0], "script_id": r[1], "virtual_user_id": r[2], "iteration": r[3], "iteration_id": r[4], "sequence_number": r[5], "request_start_ts": r[6], "request_end_ts": r[7], "response_time_ms": r[8], "http_status_code": r[9], "success": bool(r[10]), "error_message": r[11], "request_method": r[12], "api_path": r[13], "bytes_sent": r[14], "bytes_received": r[15]} for r in rows]

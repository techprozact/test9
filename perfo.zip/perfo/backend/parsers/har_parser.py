"""Parse HAR (HTTP Archive) JSON and extract API requests."""
import json
import re
from typing import Any

from backend.models.script_model import TransactionBase

# Static resource extensions to exclude (CSS, images, fonts, etc.)
_STATIC_EXTENSIONS = frozenset([
    ".css", ".js", ".map", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico",
    ".woff", ".woff2", ".ttf", ".eot", ".otf", ".cur", ".bmp", ".tiff", ".avif",
    ".mp4", ".webm", ".mp3", ".wav", ".ogg", ".m4a", ".pdf", ".zip", ".xml",
])
# Resource types from HAR (Chrome/DevTools) to exclude
_STATIC_RESOURCE_TYPES = frozenset([
    "stylesheet", "image", "imageset", "font", "media", "script", "manifest", "texttrack",
])
# Only include these when _resourceType is present (XHR/fetch = API-like)
_API_RESOURCE_TYPES = frozenset(["xhr", "fetch", "ping"])


def _should_include_har_entry(entry: dict, request: dict) -> bool:
    """
    Return True only for XHR/fetch or main API-like requests.
    Exclude CSS, images, fonts, media, and other static assets.
    """
    url = (request.get("url") or "")
    if not url:
        return False
    url_lower = url.lower().split("?")[0].split("#")[0]

    # Exclude by URL extension
    for ext in _STATIC_EXTENSIONS:
        if url_lower.endswith(ext) or ext + "?" in url_lower or ext + "#" in url_lower:
            return False

    # Chrome/DevTools HAR: _resourceType or resourceType
    resource_type = (entry.get("_resourceType") or entry.get("resourceType") or "").lower().strip()
    if resource_type:
        if resource_type in _STATIC_RESOURCE_TYPES:
            return False
        if resource_type in _API_RESOURCE_TYPES:
            return True
        # Unknown type (e.g. "other") - exclude to be safe
        return False

    # No resource type: include only if it looks like an API request
    path = url_lower
    if "://" in path:
        path = path.split("://", 1)[1]
    if "/" in path:
        path = "/" + path.split("/", 1)[1].split("?")[0]
    else:
        path = "/"
    api_like_path = bool(re.search(r"/(api|graphql|rest|v1|v2|v3|ajax|service|rpc)(/|$)", path))
    method = (request.get("method") or "GET").upper()
    has_body = bool(request.get("postData"))

    if api_like_path:
        return True
    if method in ("POST", "PUT", "PATCH", "DELETE") and has_body:
        return True
    headers_list = request.get("headers") or []
    accept = ""
    for h in headers_list:
        if isinstance(h, dict) and str(h.get("name", "")).lower() == "accept":
            accept = (h.get("value") or "").lower()
            break
    if "application/json" in accept:
        return True
    return False


def parse_har(content: str) -> list[TransactionBase]:
    """
    Parse HAR file and return list of transactions.
    Only includes XHR/fetch and main API requests; ignores CSS, images, fonts, etc.
    """
    transactions: list[TransactionBase] = []
    try:
        if not content or not content.strip():
            return transactions
        text = content.lstrip("\ufeff").strip()
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        return transactions

    entries = []
    if isinstance(data, dict):
        log = data.get("log")
        if isinstance(log, dict):
            entries = log.get("entries") or []
        elif isinstance(log, list):
            entries = log
        if not entries and "entries" in data:
            entries = data.get("entries") or []
    elif isinstance(data, list):
        entries = data

    if not isinstance(entries, list):
        return transactions

    order = 0
    for entry in entries:
        try:
            if not isinstance(entry, dict):
                continue
            request = entry.get("request")
            if not isinstance(request, dict):
                continue
            if not _should_include_har_entry(entry, request):
                continue
            url = request.get("url") or ""
            if not isinstance(url, str):
                url = str(url)
            method = (request.get("method") or "GET").upper()
            if not isinstance(method, str):
                method = "GET"
            headers = _parse_headers(request.get("headers"))
            payload = _parse_post_data(request.get("postData"))
            name = _request_name(entry, request, order)
            transactions.append(
                TransactionBase(
                    transaction_name=name,
                    request_url=url,
                    http_method=method[:20] if len(method) > 20 else method,
                    headers=headers,
                    payload=payload,
                    execution_order=order,
                )
            )
            order += 1
        except Exception:
            continue

    return transactions


def _parse_headers(headers_list: Any) -> dict[str, str]:
    if not isinstance(headers_list, list):
        return {}
    out: dict[str, str] = {}
    for h in headers_list:
        try:
            if not isinstance(h, dict):
                continue
            name = h.get("name")
            value = h.get("value")
            if name is None:
                continue
            name = str(name).strip()
            if not name or name.lower() in ("cookie",):
                continue
            out[name] = str(value).strip() if value is not None else ""
        except Exception:
            continue
    return out


def _parse_post_data(post_data: Any) -> dict[str, Any] | None:
    if not isinstance(post_data, dict):
        return None
    text = post_data.get("text")
    if text is None:
        return None
    if text == "":
        return None
    if isinstance(text, dict):
        return _ensure_serializable(text)
    try:
        if isinstance(text, str):
            parsed = json.loads(text)
            return _ensure_serializable(parsed) if isinstance(parsed, dict) else {"value": parsed}
        return {"raw": str(text)[:10000]}
    except (json.JSONDecodeError, TypeError, ValueError):
        return {"raw": str(text)[:10000]}


def _request_name(entry: dict, request: dict, order: int) -> str:
    """Prefer comment, then URL path, then index."""
    try:
        comment = entry.get("comment") or request.get("comment")
        if isinstance(comment, str) and comment.strip():
            return comment.strip()[:500]
        url = request.get("url") or ""
        if url:
            from urllib.parse import urlparse
            path = urlparse(str(url)).path or "/"
            name = path.strip("/") or f"Request_{order + 1}"
            return name[:500] if name else f"Request_{order + 1}"
    except Exception:
        pass
    return f"Request_{order + 1}"


def _ensure_serializable(obj: Any) -> dict[str, Any]:
    """Return a JSON-serializable copy of a dict (strip non-serializable types)."""
    if not isinstance(obj, dict):
        return {}
    out: dict[str, Any] = {}
    for k, v in obj.items():
        try:
            if v is None or isinstance(v, (str, int, float, bool)):
                out[str(k)] = v
            elif isinstance(v, dict):
                out[str(k)] = _ensure_serializable(v)
            elif isinstance(v, list):
                out[str(k)] = [
                    _ensure_serializable(x) if isinstance(x, dict) else (x if isinstance(x, (str, int, float, bool, type(None))) else str(x)[:2000])
                    for x in v[:100]
                ]
            else:
                out[str(k)] = str(v)[:2000]
        except Exception:
            out[str(k)] = "<non-serializable>"
    return out

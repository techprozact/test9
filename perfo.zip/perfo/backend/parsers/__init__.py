"""Parsers package — HAR only."""
from backend.parsers.har_parser import parse_har

__all__ = ["parse_har"]

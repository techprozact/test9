"""Virtual User — an async task that repeatedly executes a script flow with pacing and think time."""
from __future__ import annotations

import asyncio
import logging
import re
import uuid
from typing import Any

import aiohttp

from .script_runner import ScriptFlow, execute_step
from .telemetry import TelemetryBuffer

log = logging.getLogger("pt0.virtual_user")


def _parse_secs(val: str | int | float) -> float:
    """Parse a duration string like '5s', '2m', '1.5s' into seconds."""
    if isinstance(val, (int, float)):
        return float(val)
    m = re.match(r"^(\d+(?:\.\d+)?)\s*([smh]?)$", str(val or "0").strip(), re.I)
    if not m:
        return 0.0
    n = float(m.group(1))
    u = (m.group(2) or "s").lower()
    return n * 60 if u == "m" else n * 3600 if u == "h" else n


class VirtualUser:
    """Represents a single virtual user executing a script in a loop.

    Each iteration gets a unique iteration_id. Every request within that
    iteration receives an incremental sequence_number starting from 1.
    """

    def __init__(
        self,
        vu_id: str,
        test_run_id: str,
        flow: ScriptFlow,
        telemetry: TelemetryBuffer,
        stop_event: asyncio.Event,
        pacing_secs: float = 0.0,
        think_time_secs: float = 0.0,
        parameters: dict[str, str] | None = None,
    ):
        self.vu_id = vu_id
        self.test_run_id = test_run_id
        self.flow = flow
        self.telemetry = telemetry
        self._stop = stop_event
        self.pacing = pacing_secs
        self.think_time = think_time_secs
        self.parameters: dict[str, str] = parameters or {}

        self.iteration = 0
        self.total_requests = 0
        self.total_errors = 0
        self.crashed = False
        self.crash_error = ""

    async def run(self) -> None:
        """Main VU loop — execute script iterations until stop signal."""
        connector = aiohttp.TCPConnector(limit=1, ssl=False)
        try:
            async with aiohttp.ClientSession(
                connector=connector,
                cookie_jar=aiohttp.CookieJar(unsafe=True),
            ) as session:
                while not self._stop.is_set():
                    self.iteration += 1
                    iter_id = f"{self.vu_id}_iter{self.iteration}_{uuid.uuid4().hex[:8]}"
                    await self._run_iteration(session, iter_id)
                    if self.pacing > 0 and not self._stop.is_set():
                        try:
                            await asyncio.wait_for(self._stop.wait(), timeout=self.pacing)
                            break
                        except asyncio.TimeoutError:
                            pass
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.crashed = True
            self.crash_error = str(exc)[:500]
            log.error("VU %s crashed: %s", self.vu_id, exc)

    async def _run_iteration(self, session: aiohttp.ClientSession, iteration_id: str) -> None:
        """Execute all steps of the script flow once, assigning sequence numbers.

        A fresh per-iteration context dict is created from the VU's static parameters.
        Correlation extraction rules on each step update this dict in-place, so values
        extracted from earlier responses (e.g. access_token from a login call) are
        automatically substituted into all subsequent requests within the same iteration.

        The stop signal is intentionally NOT checked mid-iteration — once an iteration
        has started it always runs all steps to completion so that flows like
        login → add-to-cart → checkout → logout are never left half-finished.
        The stop check lives only in the outer run() loop, before a new iteration begins.
        """
        # Fresh context each iteration: static params + runtime-extracted values accumulated below
        context: dict[str, str] = dict(self.parameters)
        total_steps = len(self.flow.steps)
        for seq, step in enumerate(self.flow.steps, start=1):
            try:
                rec = await execute_step(
                    session, step,
                    self.test_run_id, self.flow.script_id,
                    self.vu_id, self.iteration,
                    iteration_id=iteration_id,
                    sequence_number=seq,
                    parameters=context,
                    script_name=self.flow.script_name,
                )
                self.telemetry.record(rec)
                self.total_requests += 1
                if not rec.success:
                    self.total_errors += 1
            except Exception as exc:
                self.total_errors += 1
                log.warning("VU %s step error: %s", self.vu_id, exc)

            # Apply think time between consecutive requests, not after the last one.
            # Pacing (configured separately) handles the gap between full iterations.
            # If the stop event fires during think time we cut it short but still
            # proceed to the next step — the iteration must always finish completely.
            is_last_step = (seq == total_steps)
            if not is_last_step and self.think_time > 0:
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=self.think_time)
                    # Stop fired before think time expired — skip remaining think time
                    # but continue the loop so all remaining steps still execute.
                except asyncio.TimeoutError:
                    pass


def create_virtual_users(
    test_run_id: str,
    flow: ScriptFlow,
    count: int,
    telemetry: TelemetryBuffer,
    stop_event: asyncio.Event,
    pacing: str | float = 0,
    think_time: str | float = 0,
    parameters_per_vu: list[dict[str, str]] | None = None,
) -> list[VirtualUser]:
    """Factory — create N VirtualUser instances for a given script.

    `parameters_per_vu` is an ordered list where index i contains the parameter
    key→value mapping for virtual user i.  If shorter than `count`, remaining
    VUs receive an empty dict (no substitution).
    """
    pacing_secs = _parse_secs(pacing)
    tt_secs = _parse_secs(think_time)
    users = []
    for i in range(count):
        vu_id = f"s{flow.script_id}_vu{i + 1}"
        vu_params = (parameters_per_vu[i] if parameters_per_vu and i < len(parameters_per_vu) else {})
        users.append(VirtualUser(
            vu_id=vu_id,
            test_run_id=test_run_id,
            flow=flow,
            telemetry=telemetry,
            stop_event=stop_event,
            pacing_secs=pacing_secs,
            think_time_secs=tt_secs,
            parameters=vu_params,
        ))
    return users

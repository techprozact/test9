"""PT0 Load Execution Engine — orchestrate concurrent script execution and capture raw telemetry."""

"""Error log writer — appends failed transaction records to per-run JSONL files.

Each failed HTTP request is written as a single JSON line to:
    backend/error_logs/{test_run_id}.jsonl
"""
from __future__ import annotations

import json
import os
from typing import Any

ERROR_LOGS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "error_logs")

_AUTH_KEYS = frozenset([
    "authorization", "x-api-key", "x-access-token", "x-auth-token",
    "api-key", "token", "auth-token", "x-token", "api_key",
])


def _extract_auth_headers(headers: dict[str, str]) -> dict[str, str]:
    result = {}
    for k, v in headers.items():
        kl = k.lower()
        if kl in _AUTH_KEYS or "auth" in kl or "token" in kl or "bearer" in kl:
            result[k] = v
    return result


def log_error(
    test_run_id: str,
    script_id: str,
    script_name: str,
    vu_id: str,
    iteration: int,
    timestamp: str,
    method: str,
    url: str,
    request_headers: dict[str, str],
    request_body: Any,
    response_code: int,
    response_body: str,
    error_message: str = "",
    response_time_ms: int = 0,
) -> None:
    """Append one error record. Silently swallows all exceptions — must never crash a VU."""
    try:
        os.makedirs(ERROR_LOGS_DIR, exist_ok=True)
        path = os.path.join(ERROR_LOGS_DIR, f"{test_run_id}.jsonl")

        if isinstance(request_body, (dict, list)):
            body_str = json.dumps(request_body)
        elif request_body is not None:
            body_str = str(request_body)
        else:
            body_str = ""

        record = {
            "test_run_id": test_run_id,
            "script_id": str(script_id),
            "script_name": script_name,
            "vu_id": vu_id,
            "iteration": iteration,
            "timestamp": str(timestamp),
            "method": method,
            "url": url,
            "request_headers": request_headers,
            "auth_headers": _extract_auth_headers(request_headers),
            "request_body": body_str,
            "response_code": response_code,
            "response_body": response_body,
            "error_message": error_message,
            "response_time_ms": response_time_ms,
        }
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
    except Exception:
        pass


def get_errors(
    test_run_id: str,
    script_id: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict:
    """Return paginated error records, optionally filtered by script_id."""
    path = os.path.join(ERROR_LOGS_DIR, f"{test_run_id}.jsonl")
    if not os.path.exists(path):
        return {"records": [], "total": 0}

    all_records: list[dict] = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    if script_id is not None and str(rec.get("script_id")) != str(script_id):
                        continue
                    all_records.append(rec)
                except Exception:
                    pass
    except Exception:
        pass

    total = len(all_records)
    return {"records": all_records[offset: offset + limit], "total": total}


def get_error_log_path(test_run_id: str, script_id: str | None = None) -> str | None:
    """Return path to raw JSONL for download. If script_id is set, writes a filtered temp file."""
    import tempfile

    full_path = os.path.join(ERROR_LOGS_DIR, f"{test_run_id}.jsonl")
    if not os.path.exists(full_path):
        return None

    if script_id is None:
        return full_path

    # Filter to a temp file for script-specific download
    filtered: list[str] = []
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    if str(rec.get("script_id")) == str(script_id):
                        filtered.append(line)
                except Exception:
                    pass
    except Exception:
        return None

    if not filtered:
        return None

    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".jsonl", delete=False, encoding="utf-8",
        prefix=f"errors_{test_run_id[:8]}_s{script_id}_",
    )
    tmp.write("\n".join(filtered) + "\n")
    tmp.close()
    return tmp.name

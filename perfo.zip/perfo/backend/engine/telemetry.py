"""Buffered telemetry writer — accumulates raw request records and flushes in batches.

Guarantees:
    - Batch-size flush: triggers when buffer reaches FLUSH_SIZE
    - Time-interval flush: periodic sweep every FLUSH_INTERVAL_SECS
    - Forced drain on stop(): flushes all remaining records with retry
    - Records are returned to the front of the buffer on DB write failure
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any

log = logging.getLogger("pt0.telemetry")

FLUSH_SIZE = 200
FLUSH_INTERVAL_SECS = 2.0
MAX_DRAIN_RETRIES = 3
DRAIN_RETRY_DELAY = 0.5


class TelemetryRecord:
    """Single HTTP request execution record with iteration tracking."""

    __slots__ = (
        "test_run_id", "script_id", "virtual_user_id", "iteration",
        "iteration_id", "sequence_number",
        "request_start_ts", "request_end_ts", "response_time_ms",
        "http_status_code", "success", "error_message",
        "request_method", "api_path", "bytes_sent", "bytes_received",
    )

    def __init__(
        self,
        test_run_id: str,
        script_id: str,
        virtual_user_id: str,
        iteration: int,
        request_start_ts: datetime,
        request_end_ts: datetime,
        response_time_ms: int,
        http_status_code: int,
        success: bool,
        request_method: str,
        api_path: str,
        error_message: str = "",
        bytes_sent: int = 0,
        bytes_received: int = 0,
        iteration_id: str = "",
        sequence_number: int = 0,
    ):
        self.test_run_id = test_run_id
        self.script_id = script_id
        self.virtual_user_id = virtual_user_id
        self.iteration = iteration
        self.iteration_id = iteration_id
        self.sequence_number = sequence_number
        self.request_start_ts = request_start_ts
        self.request_end_ts = request_end_ts
        self.response_time_ms = response_time_ms
        self.http_status_code = http_status_code
        self.success = success
        self.error_message = error_message
        self.request_method = request_method
        self.api_path = api_path
        self.bytes_sent = bytes_sent
        self.bytes_received = bytes_received

    def to_dict(self) -> dict[str, Any]:
        return {
            "test_run_id": self.test_run_id,
            "script_id": self.script_id,
            "virtual_user_id": self.virtual_user_id,
            "iteration": self.iteration,
            "iteration_id": self.iteration_id,
            "sequence_number": self.sequence_number,
            "request_start_ts": self.request_start_ts,
            "request_end_ts": self.request_end_ts,
            "response_time_ms": self.response_time_ms,
            "http_status_code": self.http_status_code,
            "success": self.success,
            "error_message": self.error_message,
            "request_method": self.request_method,
            "api_path": self.api_path,
            "bytes_sent": self.bytes_sent,
            "bytes_received": self.bytes_received,
        }


class TelemetryBuffer:
    """Async buffer that batch-inserts telemetry records to the DB store.

    Flush triggers:
        1. Size-based  — when buffer length >= FLUSH_SIZE
        2. Time-based  — periodic sweep every FLUSH_INTERVAL_SECS
        3. Forced drain — on stop(), retries up to MAX_DRAIN_RETRIES if DB fails

    On DB write failure the batch is prepended back to the buffer so nothing is lost.
    """

    def __init__(self, db_store: Any, flush_size: int = FLUSH_SIZE, flush_interval: float = FLUSH_INTERVAL_SECS):
        self._db = db_store
        self._buffer: list[TelemetryRecord] = []
        self._lock = asyncio.Lock()
        self._flush_task: asyncio.Task | None = None
        self._running = False
        self._flush_size = flush_size
        self._flush_interval = flush_interval
        self.total_flushed = 0
        self.total_lost = 0

    async def start(self) -> None:
        self._running = True
        self._flush_task = asyncio.create_task(self._periodic_flush())

    async def stop(self) -> None:
        """Stop the periodic flusher and drain all remaining records with retry."""
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        await self._drain()

    def record(self, rec: TelemetryRecord) -> None:
        """Append a record. Schedules an immediate flush if buffer is full."""
        self._buffer.append(rec)
        if len(self._buffer) >= self._flush_size:
            try:
                loop = asyncio.get_running_loop()
                loop.call_soon(lambda: asyncio.ensure_future(self._flush()))
            except RuntimeError:
                pass

    @property
    def pending(self) -> int:
        return len(self._buffer)

    async def force_flush(self) -> None:
        """Explicit flush callable from outside (e.g. scheduler tick)."""
        await self._flush()

    async def _periodic_flush(self) -> None:
        while self._running:
            await asyncio.sleep(self._flush_interval)
            await self._flush()

    async def _flush(self) -> None:
        async with self._lock:
            if not self._buffer:
                return
            batch = self._buffer[:]
            self._buffer.clear()
        if not batch:
            return
        try:
            dicts = [r.to_dict() for r in batch]
            await asyncio.get_event_loop().run_in_executor(
                None, self._db.insert_telemetry_batch, dicts
            )
            self.total_flushed += len(dicts)
        except Exception as exc:
            log.error("Telemetry flush failed (%d records): %s", len(batch), exc)
            async with self._lock:
                self._buffer = batch + self._buffer

    async def _drain(self) -> None:
        """Final drain with retries — ensures no data is silently dropped."""
        for attempt in range(1, MAX_DRAIN_RETRIES + 1):
            async with self._lock:
                if not self._buffer:
                    return
                batch = self._buffer[:]
                self._buffer.clear()
            try:
                dicts = [r.to_dict() for r in batch]
                await asyncio.get_event_loop().run_in_executor(
                    None, self._db.insert_telemetry_batch, dicts
                )
                self.total_flushed += len(dicts)
                log.info("Telemetry drain OK — flushed %d records (attempt %d)", len(dicts), attempt)
                return
            except Exception as exc:
                log.error("Telemetry drain attempt %d/%d failed (%d records): %s",
                          attempt, MAX_DRAIN_RETRIES, len(batch), exc)
                async with self._lock:
                    self._buffer = batch + self._buffer
                if attempt < MAX_DRAIN_RETRIES:
                    await asyncio.sleep(DRAIN_RETRY_DELAY)

        remaining = len(self._buffer)
        if remaining:
            self.total_lost += remaining
            log.error("Telemetry drain EXHAUSTED — %d records could not be persisted", remaining)

"""Execution Controller — lifecycle orchestrator with a central deterministic scheduler tick.

State machine:
    INITIALIZING → RAMPING_UP → STEADY → RAMPING_DOWN → COMPLETED
                         ↓ (any phase)
                        FAILED / ABORTED

The scheduler runs a fixed-interval tick (default 500 ms) that evaluates spawn
decisions, lifecycle transitions, elapsed timing, and telemetry flush triggers —
providing stable, deterministic concurrency behaviour independent of OS sleep jitter.
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any

from .script_runner import ScriptFlow, load_script_flow
from .telemetry import TelemetryBuffer
from .virtual_user import VirtualUser, create_virtual_users

log = logging.getLogger("pt0.controller")

# Valid lifecycle states
INITIALIZING = "INITIALIZING"
RAMPING_UP = "RAMPING_UP"
STEADY = "STEADY"
RAMPING_DOWN = "RAMPING_DOWN"
COMPLETED = "COMPLETED"
FAILED = "FAILED"
ABORTED = "ABORTED"
STOPPED = "STOPPED"   # user-initiated stop (replaces ABORTED for display)

DEFAULT_TICK_MS = 500


def _parse_secs(val: str | int | float) -> float:
    if isinstance(val, (int, float)):
        return float(val)
    m = re.match(r"^(\d+(?:\.\d+)?)\s*([smh]?)$", str(val or "0").strip(), re.I)
    if not m:
        return 0.0
    n = float(m.group(1))
    u = (m.group(2) or "s").lower()
    return n * 60 if u == "m" else n * 3600 if u == "h" else n


class ExecutionController:
    """Orchestrates a single test run with a central scheduler tick.

    The tick loop is the sole authority for:
        • Evaluating ramp-up spawn decisions
        • Transitioning between lifecycle phases
        • Evaluating ramp-down stop decisions
        • Updating the elapsed clock
        • Triggering periodic status persistence
    """

    def __init__(self, db_store: Any, config: dict, tick_ms: int = DEFAULT_TICK_MS):
        self.db = db_store
        self.config = config
        self.test_run_id = str(uuid.uuid4())
        self.engine_node_id = config.get("engine_node_id", "local")

        # Timing — duration_secs is the STEADY-STATE duration only.
        # Total test time = ramp_up_secs + duration_secs + ramp_down_secs.
        self.duration_secs = _parse_secs(config.get("duration", "5m"))
        self.ramp_up_secs = _parse_secs(config.get("ramp_up", "30s"))
        self.ramp_down_secs = _parse_secs(config.get("ramp_down", "15s"))
        self._total_secs = self.ramp_up_secs + self.duration_secs + self.ramp_down_secs
        self._steady_end_secs = self.ramp_up_secs + self.duration_secs
        self._tick_interval = tick_ms / 1000.0

        # State
        self.status = INITIALIZING
        self.start_time: datetime | None = None
        self.end_time: datetime | None = None
        self.elapsed = 0.0
        self.total_users_spawned = 0
        self.error_message = ""

        # Distinguish user-initiated stop from natural completion
        self._user_aborted = False

        # Internal
        self._stop_event = asyncio.Event()
        self._telemetry: TelemetryBuffer | None = None
        self._vu_tasks: list[asyncio.Task] = []
        self._vus: list[VirtualUser] = []
        self._flows: list[ScriptFlow] = []
        self._script_configs: list[dict] = config.get("scripts", [])

        # Scheduler ramp-up state
        self._all_vus: list[VirtualUser] = []
        self._spawn_index = 0
        self._t0 = 0.0  # monotonic start of execution

        # Status persistence throttle (avoid hammering DB every tick)
        self._last_persist_elapsed = 0.0

    # ── public status snapshot ──

    def snapshot(self) -> dict:
        """Return a JSON-serializable status snapshot for polling."""
        running_vus = sum(1 for t in self._vu_tasks if not t.done())
        total_requests = sum(vu.total_requests for vu in self._vus)
        total_errors = sum(vu.total_errors for vu in self._vus)
        vu_crashes = sum(1 for vu in self._vus if vu.crashed)

        return {
            "test_run_id": self.test_run_id,
            "status": self.status,
            "elapsed_secs": round(self.elapsed, 1),
            "duration_secs": self.duration_secs,          # steady-state seconds
            "total_secs": self._total_secs,               # ramp_up + steady + ramp_down
            "ramp_up_secs": self.ramp_up_secs,
            "ramp_down_secs": self.ramp_down_secs,
            "total_users_target": sum(int(s.get("users", 0)) for s in self._script_configs),
            "total_users_spawned": self.total_users_spawned,
            "running_vus": running_vus,
            "total_requests": total_requests,
            "total_errors": total_errors,
            "vu_crashes": vu_crashes,
            "engine_node_id": self.engine_node_id,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "error_message": self.error_message,
            "telemetry_pending": self._telemetry.pending if self._telemetry else 0,
            "telemetry_flushed": self._telemetry.total_flushed if self._telemetry else 0,
            "scripts": [
                {
                    "script_id": sc.get("script_id"),
                    "script_name": sc.get("script_name", ""),
                    "users": sc.get("users", 0),
                }
                for sc in self._script_configs
            ],
        }

    # ── abort ──

    def abort(self) -> None:
        """Signal all VUs to stop immediately (user-initiated)."""
        self._user_aborted = True
        self._stop_event.set()
        self.status = STOPPED
        self._persist_status(STOPPED)

    # ── main execution lifecycle ──

    async def run(self) -> None:
        """Full execution lifecycle — run as a background task."""
        try:
            await self._initialize()
            await self._scheduler_loop()
            # STOPPED only when user explicitly called abort(); natural completion = COMPLETED
            final = STOPPED if self._user_aborted else COMPLETED
            await self._finalize(final)
        except Exception as exc:
            self.error_message = str(exc)[:1000]
            log.error("Test run %s failed: %s", self.test_run_id, exc)
            await self._finalize(STOPPED)   # treat engine failures as "Stopped" for display

    # ── initialization ──

    async def _initialize(self) -> None:
        """Load scripts, create test_run record, prepare VU pool, start telemetry buffer."""
        self.status = INITIALIZING
        self.start_time = datetime.now(timezone.utc)

        total_target = sum(int(s.get("users", 0)) for s in self._script_configs)

        self.db.insert_test_run(
            run_id=self.test_run_id,
            scenario_id=str(self.config.get("scenario_id", "")),
            scenario_snapshot=json.dumps(self.config),
            planned_duration_secs=int(self.duration_secs),
            ramp_up_secs=int(self.ramp_up_secs),
            ramp_down_secs=int(self.ramp_down_secs),
            total_users_target=total_target,
            engine_node_id=self.engine_node_id,
        )

        for sc in self._script_configs:
            sid = str(sc.get("script_id", ""))
            if not sid:
                continue
            try:
                flow = load_script_flow(self.db, sid)
                self._flows.append(flow)
            except Exception as exc:
                log.warning("Failed to load script %s: %s", sid, exc)

        if not self._flows:
            raise RuntimeError("No valid scripts to execute")

        self._telemetry = TelemetryBuffer(self.db)
        await self._telemetry.start()

        # Pre-build the full VU pool (not yet started)
        for i, flow in enumerate(self._flows):
            sc = self._script_configs[i] if i < len(self._script_configs) else {}
            count = int(sc.get("users", 1))
            pacing = sc.get("pacing", "0s")
            think_time = sc.get("think_time", "0s")

            # Build per-VU parameter dicts from the scenario's parameters map.
            # parameters is stored as {param_name: [val_vu0, val_vu1, ...]}
            raw_params: dict = sc.get("parameters") or {}
            parameters_per_vu: list[dict[str, str]] = []
            for vu_idx in range(count):
                vu_params: dict[str, str] = {}
                for param_name, values in raw_params.items():
                    if isinstance(values, list) and vu_idx < len(values):
                        vu_params[param_name] = str(values[vu_idx])
                    elif isinstance(values, str):
                        vu_params[param_name] = values  # single value shared by all VUs
                parameters_per_vu.append(vu_params)

            vus = create_virtual_users(
                test_run_id=self.test_run_id,
                flow=flow,
                count=count,
                telemetry=self._telemetry,
                stop_event=self._stop_event,
                pacing=pacing,
                think_time=think_time,
                parameters_per_vu=parameters_per_vu if raw_params else None,
            )
            self._all_vus.extend(vus)

        if not self._all_vus:
            raise RuntimeError("No virtual users to spawn")

        self._persist_status(INITIALIZING)
        log.info("Test %s initialized — %d scripts, %d target VUs, tick=%.0fms",
                 self.test_run_id, len(self._flows), total_target, self._tick_interval * 1000)

    # ── central scheduler tick loop ──

    async def _scheduler_loop(self) -> None:
        """Deterministic tick loop that drives the entire execution lifecycle."""
        self._t0 = time.monotonic()
        self.status = RAMPING_UP
        self._persist_status(RAMPING_UP)
        log.info("Test %s entering RAMPING_UP", self.test_run_id)

        # Phase boundaries (all relative to _t0):
        #   [0, ramp_up_secs)            → RAMPING_UP
        #   [ramp_up_secs, _steady_end)  → STEADY
        #   [_steady_end, _total_secs)   → RAMPING_DOWN  (signal VUs to finish iteration)
        #   [_total_secs, ...)           → exit → COMPLETED

        while True:
            # Check for user-initiated abort first
            if self._stop_event.is_set() and self._user_aborted:
                break

            tick_start = time.monotonic()
            self.elapsed = tick_start - self._t0

            # ── Natural end: total time reached ──
            if self.elapsed >= self._total_secs:
                break

            # ── Determine current phase ──
            prev_status = self.status

            if self.elapsed < self.ramp_up_secs:
                self.status = RAMPING_UP
                self._tick_ramp_up()
            elif self.elapsed < self._steady_end_secs:
                if prev_status == RAMPING_UP:
                    self._spawn_remaining()
                self.status = STEADY
            else:
                # Ramp-down: tell VUs to stop taking new iterations but let them finish
                if prev_status != RAMPING_DOWN:
                    self._stop_event.set()   # signals VUs to stop looping
                self.status = RAMPING_DOWN

            # Persist status on phase transition
            if self.status != prev_status:
                self._persist_status(self.status)
                log.info("Test %s → %s at %.1fs", self.test_run_id, self.status, self.elapsed)

            # Periodic DB status update (~every 2 seconds)
            if self.elapsed - self._last_persist_elapsed >= 2.0:
                self._last_persist_elapsed = self.elapsed
                self._persist_users_spawned()

            # Sleep until next tick (compensate for tick processing time)
            tick_elapsed = time.monotonic() - tick_start
            sleep_for = max(0.0, self._tick_interval - tick_elapsed)
            if sleep_for > 0:
                # During ramp-down, VU stop_event is already set; just sleep the tick
                if self._user_aborted:
                    # User abort — exit immediately without sleeping
                    break
                try:
                    if self.status == RAMPING_DOWN:
                        # VUs are stopping; just sleep the tick, don't wait on stop_event
                        await asyncio.sleep(sleep_for)
                    else:
                        await asyncio.wait_for(self._stop_event.wait(), timeout=sleep_for)
                        if self._user_aborted:
                            break
                        # stop_event fired because ramp-down started on a previous tick
                        # re-enter the loop so we switch to RAMPING_DOWN status
                except asyncio.TimeoutError:
                    pass

        # Ensure stop_event is always set before draining, so VUs exit their loops
        self._stop_event.set()

        # After scheduler exits — wait for VUs to finish current iteration
        await self._drain_vus()

    def _tick_ramp_up(self) -> None:
        """Evaluate how many VUs should be running by now and spawn the deficit."""
        total = len(self._all_vus)
        ramp_secs = max(0.01, self.ramp_up_secs)
        target_spawned = min(total, math.ceil((self.elapsed / ramp_secs) * total))

        while self._spawn_index < target_spawned:
            vu = self._all_vus[self._spawn_index]
            self._vus.append(vu)
            task = asyncio.create_task(vu.run())
            self._vu_tasks.append(task)
            self.total_users_spawned += 1
            self._spawn_index += 1

    def _spawn_remaining(self) -> None:
        """Ensure every VU is spawned when transitioning out of ramp-up."""
        while self._spawn_index < len(self._all_vus):
            vu = self._all_vus[self._spawn_index]
            self._vus.append(vu)
            task = asyncio.create_task(vu.run())
            self._vu_tasks.append(task)
            self.total_users_spawned += 1
            self._spawn_index += 1

    async def _drain_vus(self) -> None:
        """Wait for all VU tasks to finish their last in-progress iteration.

        Because VUs now always run every step to completion (no mid-iteration
        abort), the drain window must be wide enough to cover the worst-case
        remaining iteration time: all remaining steps × (response_time +
        think_time).  120 s is a comfortable ceiling for any realistic flow.
        """
        if not self._vu_tasks:
            return
        timeout = max(self.ramp_down_secs + 120, 120.0)
        done, pending = await asyncio.wait(self._vu_tasks, timeout=timeout)
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        log.info("Test %s VU drain complete — %d done, %d cancelled",
                 self.test_run_id, len(done), len(pending))

    # ── finalization ──

    async def _finalize(self, final_status: str) -> None:
        """Force-flush telemetry, persist final status."""
        self.status = final_status
        self.end_time = datetime.now(timezone.utc)
        self.elapsed = time.monotonic() - self._t0 if self._t0 else 0.0

        if self._telemetry:
            await self._telemetry.stop()

        self.db.update_test_run(
            self.test_run_id,
            status=final_status,
            end_time=self.end_time,
            total_users_spawned=self.total_users_spawned,
            error_message=self.error_message or None,
        )

        total_req = sum(vu.total_requests for vu in self._vus)
        total_err = sum(vu.total_errors for vu in self._vus)
        flushed = self._telemetry.total_flushed if self._telemetry else 0
        lost = self._telemetry.total_lost if self._telemetry else 0

        log.info(
            "Test %s finalized — status=%s, spawned=%d, requests=%d, errors=%d, "
            "telemetry_flushed=%d, telemetry_lost=%d",
            self.test_run_id, final_status, self.total_users_spawned,
            total_req, total_err, flushed, lost,
        )

    # ── DB persistence helpers ──

    def _persist_status(self, status: str) -> None:
        try:
            self.db.update_test_run(self.test_run_id, status=status)
        except Exception:
            pass

    def _persist_users_spawned(self) -> None:
        try:
            self.db.update_test_run(self.test_run_id, total_users_spawned=self.total_users_spawned)
        except Exception:
            pass


# ── Global registry of active controllers (keyed by test_run_id) ──

_active_runs: dict[str, ExecutionController] = {}


def get_active_controller(test_run_id: str) -> ExecutionController | None:
    return _active_runs.get(test_run_id)


def register_controller(ctrl: ExecutionController) -> None:
    _active_runs[ctrl.test_run_id] = ctrl


def unregister_controller(test_run_id: str) -> None:
    _active_runs.pop(test_run_id, None)


async def run_execution(db_store: Any, config: dict) -> str:
    """Top-level entry point: create controller, register it, launch as background task, return test_run_id."""
    ctrl = ExecutionController(db_store, config)
    register_controller(ctrl)

    async def _wrapper():
        try:
            await ctrl.run()
        finally:
            unregister_controller(ctrl.test_run_id)

    asyncio.create_task(_wrapper())
    return ctrl.test_run_id

"""Script flow loader and HTTP executor — loads transactions from DB and replays them via aiohttp."""
from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

import aiohttp

from .telemetry import TelemetryRecord
from .error_logger import log_error
from backend.perfzy.execution_engine import ExtractionDef, extract_values

log = logging.getLogger("pt0.script_runner")


@dataclass
class RequestStep:
    """Single HTTP request derived from a stored transaction."""
    execution_order: int
    method: str
    url: str
    headers: dict[str, str]
    payload: Any
    payload_kwarg: str  # "json" | "data" | ""
    extractions: list[dict] = field(default_factory=list)  # correlation rules to apply after response


@dataclass
class ScriptFlow:
    """A loaded script ready for execution — ordered list of HTTP requests."""
    script_id: str
    script_name: str
    steps: list[RequestStep] = field(default_factory=list)


def load_script_flow(db_store: Any, script_id: str) -> ScriptFlow:
    """Load a script's transactions from the DB and build a ScriptFlow."""
    script = db_store.get_script(script_id)
    if not script:
        raise ValueError(f"Script {script_id} not found")
    transactions = db_store.get_transactions(script_id)
    if not transactions:
        raise ValueError(f"Script {script_id} has no transactions")

    steps: list[RequestStep] = []
    for tx in sorted(transactions, key=lambda t: t.get("execution_order", 0)):
        method = (tx.get("http_method") or "GET").upper()
        url = tx.get("request_url", "")
        headers_raw = tx.get("headers") or {}
        if isinstance(headers_raw, str):
            try:
                headers_raw = json.loads(headers_raw)
            except Exception:
                headers_raw = {}

        payload = tx.get("payload")
        if isinstance(payload, str) and payload:
            try:
                payload = json.loads(payload)
            except Exception:
                pass

        payload_kwarg = ""
        if payload is not None:
            ct = ""
            for k, v in headers_raw.items():
                if k.lower().strip() == "content-type":
                    ct = v.lower()
                    break
            if "json" in ct or (isinstance(payload, dict) and not ct):
                payload_kwarg = "json"
            else:
                payload_kwarg = "data"

        skip = frozenset([
            "host", "content-length", "accept-encoding", "connection",
            "upgrade-insecure-requests", "cookie", "set-cookie",
        ])
        clean_h: dict[str, str] = {}
        for k, v in headers_raw.items():
            if k.lower().strip() in skip:
                continue
            if k.lower().startswith("sec-"):
                continue
            clean_h[k] = str(v) if not isinstance(v, str) else v

        # Load correlation extraction rules stored when the script was created
        stored_response = tx.get("response") or {}
        if isinstance(stored_response, str):
            try:
                stored_response = json.loads(stored_response)
            except Exception:
                stored_response = {}
        extractions = stored_response.get("_extractions", []) if isinstance(stored_response, dict) else []

        steps.append(RequestStep(
            execution_order=tx.get("execution_order", 0),
            method=method,
            url=url,
            headers=clean_h,
            payload=payload,
            payload_kwarg=payload_kwarg,
            extractions=extractions,
        ))

    return ScriptFlow(
        script_id=str(script_id),
        script_name=script.get("script_name", ""),
        steps=steps,
    )


def _derive_api_path(url: str) -> str:
    """Extract the path component from a URL."""
    try:
        return urlparse(url).path or "/"
    except Exception:
        return "/"


def _substitute_params(text: str, parameters: dict[str, str]) -> str:
    """Replace {{param_name}} placeholders in a string with per-VU values."""
    if not text or not parameters:
        return text
    for name, value in parameters.items():
        text = text.replace(f"{{{{{name}}}}}", str(value))
    return text


def _substitute_in_payload(payload: Any, parameters: dict[str, str]) -> Any:
    """Recursively replace {{param_name}} placeholders throughout a payload.

    Handles str, dict, list, and passes through all other types unchanged.
    This is required because load_script_flow parses JSON payloads into dicts,
    so the top-level isinstance(payload, str) check in execute_step is insufficient.
    """
    if not parameters or payload is None:
        return payload
    if isinstance(payload, str):
        return _substitute_params(payload, parameters)
    if isinstance(payload, dict):
        return {k: _substitute_in_payload(v, parameters) for k, v in payload.items()}
    if isinstance(payload, list):
        return [_substitute_in_payload(item, parameters) for item in payload]
    return payload


async def execute_step(
    session: aiohttp.ClientSession,
    step: RequestStep,
    test_run_id: str,
    script_id: str,
    vu_id: str,
    iteration: int,
    iteration_id: str = "",
    sequence_number: int = 0,
    parameters: dict[str, str] | None = None,
    script_name: str = "",
) -> TelemetryRecord:
    """Execute a single HTTP request and return a TelemetryRecord.

    If `parameters` is provided, any {{param_name}} placeholders in the URL,
    headers, and payload are replaced with the per-VU parameter values before
    the request is sent.
    """
    # `params` is used both for substitution and as an accumulator for runtime-extracted
    # values (e.g. access_token).  Use the caller's dict directly (not a copy) so that
    # values extracted from this step's response are visible to subsequent steps.
    params = parameters if parameters is not None else {}
    url     = _substitute_params(step.url, params)
    headers = {k: _substitute_params(v, params) for k, v in step.headers.items()}
    # Use recursive helper so dict/list payloads (parsed JSON) are fully substituted
    payload = _substitute_in_payload(step.payload, params)

    api_path = _derive_api_path(url)
    start_ts = datetime.now(timezone.utc)
    t0 = time.monotonic()

    status_code = 0
    success = False
    error_msg = ""
    bytes_sent = 0
    bytes_received = 0
    response_body_str = ""

    try:
        kwargs: dict[str, Any] = {
            "headers": headers,
            "timeout": aiohttp.ClientTimeout(total=30),
            "allow_redirects": True,
            "ssl": False,
        }
        if payload is not None and step.payload_kwarg:
            kwargs[step.payload_kwarg] = payload

        if payload:
            try:
                bytes_sent = len(json.dumps(payload).encode())
            except Exception:
                bytes_sent = 0

        async with session.request(step.method, url, **kwargs) as resp:
            body = await resp.read()
            status_code = resp.status
            bytes_received = len(body)
            success = 200 <= status_code < 400

            # Decode body when needed for error logging or correlation extraction
            if not success or step.extractions:
                try:
                    response_body_str = body.decode("utf-8", errors="replace")[:10000]
                except Exception:
                    response_body_str = ""

            # Apply correlation extraction rules and update params in-place so
            # subsequent steps in the same iteration can use the extracted values
            if step.extractions and response_body_str:
                resp_headers = dict(resp.headers)
                rules = [
                    ExtractionDef(
                        name=e.get("name", ""),
                        source=e.get("source", "json_path"),
                        expression=e.get("expression", ""),
                    )
                    for e in step.extractions
                    if e.get("name") and e.get("expression")
                ]
                if rules:
                    extracted = extract_values(response_body_str, resp_headers, status_code, rules)
                    params.update(extracted)

    except asyncio.TimeoutError:
        error_msg = "Request timed out (30s)"
    except aiohttp.ClientError as exc:
        error_msg = str(exc)[:500]
    except Exception as exc:
        error_msg = f"Unexpected: {exc}"[:500]

    t1 = time.monotonic()
    end_ts = datetime.now(timezone.utc)
    response_time_ms = max(1, round((t1 - t0) * 1000))

    # Log failed requests (non-2xx or network errors) to per-run error file
    if not success:
        log_error(
            test_run_id=test_run_id,
            script_id=script_id,
            script_name=script_name,
            vu_id=vu_id,
            iteration=iteration,
            timestamp=start_ts.isoformat(),
            method=step.method,
            url=url,
            request_headers=headers,
            request_body=payload,
            response_code=status_code,
            response_body=response_body_str,
            error_message=error_msg,
            response_time_ms=response_time_ms,
        )

    return TelemetryRecord(
        test_run_id=test_run_id,
        script_id=script_id,
        virtual_user_id=vu_id,
        iteration=iteration,
        iteration_id=iteration_id,
        sequence_number=sequence_number,
        request_start_ts=start_ts,
        request_end_ts=end_ts,
        response_time_ms=response_time_ms,
        http_status_code=status_code,
        success=success,
        error_message=error_msg,
        request_method=step.method,
        api_path=api_path,
        bytes_sent=bytes_sent,
        bytes_received=bytes_received,
    )

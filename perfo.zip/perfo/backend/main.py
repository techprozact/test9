"""FastAPI application for perfSense."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.api.upload_api import router as upload_router
from backend.api.perfzy_api import router as perfzy_router
from backend.api.scenario_api import router as scenario_router
from backend.api.execution_api import router as execution_router
from backend.api.delay_api import router as delay_router
from backend.db.db_connection import get_db_store


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Create a single shared DB store at startup; all requests use it."""
    app.state.db = get_db_store()
    yield


app = FastAPI(
    title="perfSense API",
    description="Local API performance testing platform",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload_router)
app.include_router(perfzy_router)
app.include_router(scenario_router)
app.include_router(execution_router)
app.include_router(delay_router)  # temporary — engine validation only


@app.get("/")
async def root():
    return {"service": "perfSense Script Parser", "status": "ok"}


@app.get("/health")
async def health():
    return {"status": "healthy"}

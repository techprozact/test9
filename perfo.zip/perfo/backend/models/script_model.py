"""Script and related Pydantic models for API."""
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class ScriptBase(BaseModel):
    """Base script schema."""
    script_name: str
    script_type: str


class ScriptCreate(ScriptBase):
    """Schema for creating a script record."""
    pass


class ScriptResponse(ScriptBase):
    """Schema for script in API response."""
    id: str
    upload_time: datetime

    class Config:
        from_attributes = True


class TransactionBase(BaseModel):
    """Base transaction/API request schema."""
    transaction_name: str
    request_url: str
    http_method: str
    headers: dict = Field(default_factory=dict)
    payload: Optional[dict] = None
    execution_order: int
    response: Optional[dict] = None


class TransactionCreate(TransactionBase):
    """Schema for creating a transaction record."""
    script_id: str


class TransactionResponse(TransactionBase):
    """Schema for transaction in API response."""
    id: str
    script_id: str

    class Config:
        from_attributes = True

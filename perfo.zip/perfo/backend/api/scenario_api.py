"""Scenario CRUD API for Load Designer."""
import json
from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from backend.db.db_connection import get_db_store

router = APIRouter(prefix="/scenarios", tags=["scenarios"])


def _get_db(request: Request):
    return get_db_store()


def _serialize_dt(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _serialize_dt(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_serialize_dt(v) for v in obj]
    return obj


class ScenarioBody(BaseModel):
    scenario_name: str
    description: str = ""
    duration: str = "5m"
    ramp_up: str = "30s"
    ramp_down: str = "15s"
    scripts: list = []


@router.post("")
async def create_scenario(body: ScenarioBody, request: Request) -> dict:
    db = _get_db(request)
    scripts_json = json.dumps(body.scripts)
    rec = db.insert_scenario(body.scenario_name, body.description, body.duration, body.ramp_up, body.ramp_down, scripts_json)
    return _serialize_dt(rec)


@router.get("")
async def list_scenarios(request: Request) -> list[dict]:
    db = _get_db(request)
    scenarios = db.get_all_scenarios()
    return [_serialize_dt(s) for s in scenarios]


@router.get("/{scenario_id}")
async def get_scenario(request: Request, scenario_id: str) -> dict:
    db = _get_db(request)
    rec = db.get_scenario(scenario_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return _serialize_dt(rec)


@router.put("/{scenario_id}")
async def update_scenario(request: Request, scenario_id: str, body: ScenarioBody) -> dict:
    db = _get_db(request)
    scripts_json = json.dumps(body.scripts)
    rec = db.update_scenario(scenario_id, body.scenario_name, body.description, body.duration, body.ramp_up, body.ramp_down, scripts_json)
    if not rec:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return _serialize_dt(rec)


@router.delete("/{scenario_id}")
async def delete_scenario(request: Request, scenario_id: str) -> dict:
    db = _get_db(request)
    deleted = db.delete_scenario(scenario_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return {"ok": True}

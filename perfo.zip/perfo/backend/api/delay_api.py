"""Deterministic delay endpoint — engine validation only.

GET /delay/{seconds}
  - Sleeps for the requested duration (float, max 10 s) using async sleep
    so the FastAPI event loop is never blocked.
  - Returns a fixed JSON response.
  - Intended to let the load execution engine drive controlled, predictable
    load so that analytics calculations (TPS, percentiles, VU counts) can be
    validated scientifically.
  - Does NOT write telemetry itself; response timing is measured externally
    by the execution engine.

Remove this file once engine validation is complete.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Request

log = logging.getLogger("pt0.delay")

MAX_DELAY_SECS = 10.0

router = APIRouter(prefix="/delay", tags=["validation"])


@router.get("/{seconds}")
async def delay_response(seconds: float, request: Request) -> dict:
    """Sleep for *seconds* then return a deterministic JSON response.

    Args:
        seconds: Delay duration in seconds (float, 0 < x ≤ 10).

    Returns:
        JSON with status, echoed delay value, and a fixed message.

    Raises:
        HTTP 400 if delay is out of range.
    """
    if seconds <= 0 or seconds > MAX_DELAY_SECS:
        raise HTTPException(
            status_code=400,
            detail=f"delay must be > 0 and ≤ {MAX_DELAY_SECS} seconds",
        )

    client_ip = request.client.host if request.client else "unknown"
    invoked_at = datetime.now(timezone.utc).isoformat()
    log.info(
        "delay invoked  ts=%s  delay=%.3fs  client=%s",
        invoked_at, seconds, client_ip,
    )

    await asyncio.sleep(seconds)

    return {
        "status": "ok",
        "delay_seconds": seconds,
        "message": "deterministic delay response",
    }

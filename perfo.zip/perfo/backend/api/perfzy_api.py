"""Perfzy API — execute requests and generate scripts from Perfzy workflows."""
from __future__ import annotations

import asyncio
import sys
from functools import partial
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from backend.db.db_connection import get_db_store
from backend.perfzy.execution_engine import execute_request, ExecutionResult
from backend.perfzy.script_generator import generate_perfzy_script

router = APIRouter(prefix="/perfzy", tags=["perfzy"])


def _apply_param_substitutions(path: str, params: list) -> str:
    """Replace literal parameter values in a URL path/query with {{custom_name}} placeholders.
    Used when storing transaction URLs so the execution engine can substitute per-VU values.
    """
    import re as _re
    if not path or not params:
        return path
    q_idx = path.find("?")
    path_part = path[:q_idx] if q_idx >= 0 else path
    query_part = path[q_idx:] if q_idx >= 0 else ""
    for p in params:
        p_dict = p.model_dump() if hasattr(p, "model_dump") else p
        custom_name = _re.sub(r"[^a-zA-Z0-9_]", "_", (p_dict.get("custom_name") or p_dict.get("key") or "").strip())
        value = str(p_dict.get("value") or "")
        source = p_dict.get("source", "")
        if not value or not custom_name:
            continue
        if source == "path":
            segments = path_part.split("/")
            segments = [f"{{{{{custom_name}}}}}" if seg == value else seg for seg in segments]
            path_part = "/".join(segments)
        elif source == "query":
            key = str(p_dict.get("key", ""))
            if key:
                query_part = _re.sub(
                    r"([?&]" + _re.escape(key) + r"=)" + _re.escape(value) + r"(?=&|$)",
                    r"\g<1>" + "{{" + custom_name + "}}",
                    query_part,
                )
    return path_part + query_part

DEBUG = True


def _debug(msg: str, **kwargs) -> None:
    if DEBUG:
        print(f"[perfSense:perfzy] {msg}", kwargs if kwargs else "", file=sys.stderr, flush=True)


# ── Request models ────────────────────────────────────────────────────────

class ExecuteBody(BaseModel):
    method: str = "GET"
    url: str
    headers: dict[str, str] = Field(default_factory=dict)
    payload: Any = None
    payload_type: str = "none"
    auth_type: str = "none"
    auth_value: dict = Field(default_factory=dict)
    variables: dict[str, str] = Field(default_factory=dict)
    extractions: list[dict] = Field(default_factory=list)


class RequestDef(BaseModel):
    name: str = "Unnamed"
    method: str = "GET"
    path: str = ""
    headers: dict[str, str] = Field(default_factory=dict)
    payload: Any = None
    payload_type: str = "none"
    auth_type: str = "none"
    auth_value: dict = Field(default_factory=dict)
    extractions: list[dict] = Field(default_factory=list)
    request_parameters: list["ParameterDef"] = Field(default_factory=list)


class ParameterDef(BaseModel):
    key: str = ""
    custom_name: str = ""
    value: str = ""
    source: str = "manual"


class CreateScriptBody(BaseModel):
    script_name: str
    base_url: str = ""
    requests: list[RequestDef]
    global_variables: dict[str, str] = Field(default_factory=dict)
    parameters: list[ParameterDef] = Field(default_factory=list)
    think_time: float = 0.0


# ── Endpoints ─────────────────────────────────────────────────────────────

@router.post("/execute")
async def perfzy_execute(body: ExecuteBody):
    """Execute a single request with variable substitution and return response + extractions.

    execute_request() uses the synchronous `requests` library.  Running it
    directly in an async handler would block the uvicorn event loop, starving
    all other coroutines (including /delay/* endpoints) for the duration of the
    HTTP call.  We offload it to a thread-pool executor so the event loop stays
    free.
    """
    _debug("execute", url=body.url, method=body.method)
    loop = asyncio.get_event_loop()
    result: ExecutionResult = await loop.run_in_executor(
        None,
        partial(
            execute_request,
            method=body.method,
            url=body.url,
            headers=body.headers,
            payload=body.payload,
            payload_type=body.payload_type,
            auth_type=body.auth_type,
            auth_value=body.auth_value,
            variables=body.variables,
            extractions=body.extractions,
        ),
    )

    if result.error and result.status_code == 0:
        return {
            "error": result.error,
            "status_code": 0,
            "headers": {},
            "body": "",
            "elapsed_ms": 0,
            "extracted_values": {},
            "suggested_extractions": [],
            "sent_url": result.sent_url,
            "sent_method": result.sent_method,
            "sent_headers": result.sent_headers,
            "sent_payload": result.sent_payload,
        }

    return {
        "status_code": result.status_code,
        "headers": result.headers,
        "body": result.body,
        "elapsed_ms": result.elapsed_ms,
        "extracted_values": result.extracted_values,
        "suggested_extractions": result.suggested_extractions,
        "error": result.error,
        "sent_url": result.sent_url,
        "sent_method": result.sent_method,
        "sent_headers": result.sent_headers,
        "sent_payload": result.sent_payload,
    }


@router.post("/create-script")
async def perfzy_create_script(body: CreateScriptBody, request: Request):
    """Generate a Python performance script from Perfzy workflow and save to DB.

    Also persists each request as a transaction row so the load execution engine
    (load_script_flow) can replay them without needing to parse the Python script.
    """
    _debug("create-script", name=body.script_name, count=len(body.requests))

    if not body.requests:
        raise HTTPException(status_code=400, detail="At least one request is required")

    req_defs = [r.model_dump() for r in body.requests]
    param_defs = [p.model_dump() for p in (body.parameters or [])]
    script_content = generate_perfzy_script(
        script_name=body.script_name,
        base_url=body.base_url,
        requests_def=req_defs,
        global_variables=body.global_variables,
        parameters=param_defs,
        think_time=body.think_time,
    )

    db = get_db_store()
    script_record = db.insert_script(body.script_name, "perfzy")
    script_id = script_record["id"]
    db.save_python_script(script_id, script_content)

    # Persist each request as a transaction so load_script_flow() can replay them.
    # Apply per-request parameter substitutions so the execution engine can substitute
    # per-VU values at runtime using {{param_name}} placeholders in the stored URL.
    base = (body.base_url or "").rstrip("/")
    for order, req in enumerate(body.requests, start=1):
        path = req.path if req.path.startswith("/") else f"/{req.path}"
        # Substitute confirmed parameters into the path before storing
        parameterized_path = _apply_param_substitutions(path, req.request_parameters or [])
        full_url = f"{base}{parameterized_path}" if base else parameterized_path

        # Only store payload when it is actually present to avoid storing None
        payload = req.payload if req.payload_type not in ("none", "") else None

        # Persist extraction rules so the load engine can correlate runtime values
        # (e.g. access_token) across requests within the same VU iteration.
        valid_extractions = [
            e for e in (req.extractions or []) if e.get("name") and e.get("expression")
        ]
        response_meta = {"_extractions": valid_extractions} if valid_extractions else None

        db.insert_transaction(
            script_id=script_id,
            transaction_name=req.name or f"Request_{order}",
            request_url=full_url,  # may contain {{param_name}} placeholders
            http_method=(req.method or "GET").upper(),
            headers=req.headers or {},
            payload=payload,
            execution_order=order,
            response=response_meta,
        )

    _debug("script saved", script_id=script_id, transactions=len(body.requests))

    return {
        "script_id": script_id,
        "script_content": script_content,
    }

"""Load Execution API — start, monitor, stop test runs and query raw telemetry."""
from __future__ import annotations

import math
from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

from backend.db.db_connection import get_db_store
from backend.engine.controller import (
    get_active_controller,
    run_execution,
)
from backend.engine.error_logger import get_errors, get_error_log_path

router = APIRouter(prefix="/executions", tags=["executions"])


def _get_db(request: Request):
    return get_db_store()


def _serialize(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _serialize(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_serialize(v) for v in obj]
    return obj


# ── Request models ──

class ScriptConfig(BaseModel):
    script_id: str
    script_name: str = ""
    users: int = 1
    pacing: str = "0s"
    think_time: str = "0s"
    parameters: dict = {}


class ExecutionRequest(BaseModel):
    scenario_id: str = ""
    scripts: list[ScriptConfig] = []
    duration: str = "5m"
    ramp_up: str = "30s"
    ramp_down: str = "15s"
    engine_node_id: str = "local"


# ── Endpoints ──

@router.post("")
async def start_execution(body: ExecutionRequest, request: Request) -> dict:
    """Start a new load test execution. Returns test_run_id immediately."""
    db = _get_db(request)
    config = {
        "scenario_id": body.scenario_id,
        "scripts": [s.model_dump() for s in body.scripts],
        "duration": body.duration,
        "ramp_up": body.ramp_up,
        "ramp_down": body.ramp_down,
        "engine_node_id": body.engine_node_id,
    }
    if not body.scripts:
        raise HTTPException(status_code=400, detail="At least one script is required")

    test_run_id = await run_execution(db, config)
    return {"test_run_id": test_run_id, "status": "INITIALIZING"}


@router.get("")
async def list_executions(request: Request) -> list[dict]:
    """List all test runs (most recent first)."""
    db = _get_db(request)
    runs = db.get_all_test_runs()
    return [_serialize(r) for r in runs]


@router.get("/{test_run_id}")
async def get_execution(request: Request, test_run_id: str) -> dict:
    """Get test run status — prefers live controller snapshot when running."""
    ctrl = get_active_controller(test_run_id)
    if ctrl:
        return _serialize(ctrl.snapshot())
    db = _get_db(request)
    rec = db.get_test_run(test_run_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Test run not found")
    return _serialize(rec)


@router.post("/{test_run_id}/stop")
async def stop_execution(request: Request, test_run_id: str) -> dict:
    """Abort a running test. Gracefully stops all VUs."""
    ctrl = get_active_controller(test_run_id)
    if not ctrl:
        db = _get_db(request)
        rec = db.get_test_run(test_run_id)
        if not rec:
            raise HTTPException(status_code=404, detail="Test run not found")
        return {"ok": True, "status": rec.get("status", "UNKNOWN"), "message": "Test already finished"}
    ctrl.abort()
    return {"ok": True, "status": "ABORTED", "test_run_id": test_run_id}


@router.get("/{test_run_id}/summary")
async def get_execution_summary(request: Request, test_run_id: str) -> dict:
    """Compute aggregate stats from telemetry for a test run."""
    db = _get_db(request)
    rec = db.get_test_run(test_run_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Test run not found")
    records = db.get_telemetry(test_run_id, limit=1000000, offset=0)
    total = len(records)
    if total == 0:
        return {"total_requests": 0, "total_errors": 0, "avg_rt": 0, "tph": 0, "ux_variance": 0, "error_pct": 0.0, "p50": 0, "p95": 0}
    errors = 0
    rt_sum = 0
    rts = []
    for r in records:
        rt = r.get("response_time_ms", 0) or 0
        rts.append(rt)
        rt_sum += rt
        if r.get("success") in (False, 0) or (r.get("http_status_code", 0) or 0) >= 500:
            errors += 1
    avg_rt = round(rt_sum / total)
    rts.sort()
    def _pct(p):
        return rts[max(0, math.ceil(p / 100 * len(rts)) - 1)]
    p50, p95 = _pct(50), _pct(95)
    dur = rec.get("planned_duration_secs") or 0
    tph = round(total / max(1, dur) * 3600)
    return {
        "total_requests": total, "total_errors": errors, "avg_rt": avg_rt,
        "tph": tph, "ux_variance": p95 - p50, "error_pct": round(errors / total * 100, 2),
        "p50": p50, "p95": p95,
    }


@router.get("/{test_run_id}/telemetry")
async def get_telemetry(request: Request, test_run_id: str, limit: int = 500, offset: int = 0) -> list[dict]:
    """Query raw request telemetry for a test run (paginated)."""
    db = _get_db(request)
    records = db.get_telemetry(test_run_id, limit=limit, offset=offset)
    return [_serialize(r) for r in records]


@router.get("/{test_run_id}/errors")
async def get_execution_errors(
    request: Request,
    test_run_id: str,
    script_id: str = None,
    limit: int = 20,
    offset: int = 0,
) -> dict:
    """Return paginated failed transaction records for a test run."""
    return get_errors(test_run_id, script_id=script_id, limit=limit, offset=offset)


@router.get("/{test_run_id}/errors/download")
async def download_execution_errors(
    request: Request,
    test_run_id: str,
    script_id: str = None,
) -> FileResponse:
    """Download the full error log JSONL file for a test run (optionally filtered by script)."""
    path = get_error_log_path(test_run_id, script_id=script_id)
    if not path:
        raise HTTPException(status_code=404, detail="No error log found for this test run")
    filename = f"errors_{test_run_id[:8]}"
    if script_id:
        filename += f"_script{script_id}"
    filename += ".jsonl"
    return FileResponse(
        path=path,
        media_type="application/x-ndjson",
        filename=filename,
    )



@router.delete("/{test_run_id}")
async def delete_execution(request: Request, test_run_id: str) -> dict:
    """Delete a test run and its telemetry."""
    db = _get_db(request)
    rec = db.get_test_run(test_run_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Test run not found")
    db.delete_test_run(test_run_id)
    return {"ok": True, "test_run_id": test_run_id}

"""Upload script and list scripts / transactions / generated Python script."""
import json
import os
import re
import sys
from typing import Any

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse, PlainTextResponse, Response

from backend.db.db_connection import get_db_store
from backend.services.script_parser_service import parse_upload
from backend.models.script_model import ScriptResponse, TransactionResponse

router = APIRouter(prefix="", tags=["script-parser"])

DEBUG = True  # set to False to reduce logs

_replay_sessions: dict[str, Any] = {}


def _debug(msg: str, **kwargs) -> None:
    if DEBUG:
        print(f"[perfSense] {msg}", kwargs if kwargs else "", file=sys.stderr, flush=True)


def _get_db(request: Request):
    """Always use get_db_store() so DATABASE_URL is respected on every request (fixes 404 when using MySQL)."""
    return get_db_store()


def _ensure_json_serializable(obj):
    """Recursively ensure dict/list values are JSON-serializable (for API response)."""
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    if hasattr(obj, "__str__") and not isinstance(obj, (dict, list)):
        return str(obj)
    if isinstance(obj, dict):
        return {str(k): _ensure_json_serializable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_ensure_json_serializable(v) for v in obj]
    return str(obj)


@router.post("/upload-script")
async def upload_script(request: Request, file: UploadFile = File(...)) -> dict:
    """
    Upload a HAR file (.har).
    Parses, stores, and generates Python script from the captured traffic.
    """
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Empty file")
    db = _get_db(request)
    _debug("upload_script: store=" + type(db).__name__)
    try:
        script, transactions, python_code, summary = parse_upload(
            content, file.filename or "unknown", db
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    script_dict = script.model_dump(mode="json")
    script_dict["id"] = str(script_dict.get("id", script.id))
    _debug("upload_script: returning script_id=" + str(script_dict["id"]))
    out = {
        "script": script_dict,
        "transactions": [t.model_dump(mode="json") for t in transactions],
    }
    if summary:
        out["har_summary"] = summary
    return out


@router.get("/debug")
async def debug_info(request: Request) -> dict:
    """Return which store is used and if DATABASE_URL is set. Use to verify which backend is hit."""
    db = _get_db(request)
    return {
        "store": type(db).__name__,
        "database_url_set": bool(os.environ.get("DATABASE_URL", "").strip()),
        "message": "If store is not MySQLStore but you set DATABASE_URL, another process may be on port 8000.",
    }


@router.get("/scripts")
async def list_scripts(request: Request) -> list[dict]:
    """List all uploaded scripts."""
    db = _get_db(request)
    scripts = db.get_all_scripts()
    out = []
    for s in scripts:
        upload_time = s.get("upload_time")
        if hasattr(upload_time, "isoformat"):
            upload_time = upload_time.isoformat()
        sid = str(s.get("id", ""))
        has_correlated_script = bool(db.get_python_script(f"{sid}_correlated")) if sid else False
        correlated_params = None
        if sid:
            persisted_report = db.get_python_script(f"{sid}_correlated_report")
            if persisted_report:
                try:
                    correlated_params = int((json.loads(persisted_report) or {}).get("correlated_params", 0))
                except Exception:
                    correlated_params = None
        out.append({
            "id": sid,
            "script_name": s.get("script_name", ""),
            "script_type": s.get("script_type", ""),
            "upload_time": upload_time,
            "has_correlated_script": has_correlated_script,
            "correlated_params": correlated_params,
        })
    return out


@router.delete("/scripts/{script_id}")
async def delete_script(request: Request, script_id: str):
    """Delete a script and all its associated data."""
    db = _get_db(request)
    # Also delete correlated script artifacts stored as pseudo-scripts
    for suffix in ("_correlated", "_correlated_report"):
        try:
            db.delete_script(f"{script_id}{suffix}")
        except Exception:
            pass
    deleted = db.delete_script(script_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Script not found")
    return {"ok": True}


@router.get("/scripts/{script_id}/transactions")
async def get_script_transactions(request: Request, script_id: str) -> list[dict]:
    """Return parsed API transactions for a script. Always returns 200 with a list (possibly empty)."""
    sid = script_id.strip() if script_id else ""
    _debug("get_script_transactions: script_id=" + repr(script_id))
    if not script_id or not sid:
        raise HTTPException(status_code=404, detail="Script not found")
    try:
        db = _get_db(request)
        _debug("get_script_transactions: store=" + type(db).__name__)
        script = db.get_script(sid)
        _debug("get_script_transactions: get_script found=" + str(script is not None))
        if not script:
            try:
                all_scripts = db.get_all_scripts()
                known_ids = [str(s.get("id", "")) for s in all_scripts]
            except Exception:
                known_ids = []
            _debug("get_script_transactions: 404 - store=" + type(db).__name__ + " known_ids=" + str(known_ids))
            return JSONResponse(
                status_code=404,
                content={
                    "detail": "Script not found",
                    "debug": {
                        "store": type(db).__name__,
                        "database_url_set": bool(os.environ.get("DATABASE_URL", "").strip()),
                        "requested_script_id": sid,
                        "known_script_ids_in_this_store": known_ids,
                        "tip": "If store is not MySQLStore or known_script_ids is empty, a different backend may be on port 8000. Stop all backends and start only one with: export DATABASE_URL=... ; uvicorn ...",
                    },
                },
            )
        transactions = db.get_transactions(sid)
        out = []
        for t in transactions:
            try:
                out.append({
                    "id": str(t.get("id", "")),
                    "script_id": str(t.get("script_id", "")),
                    "transaction_name": str(t.get("transaction_name", "")),
                    "request_url": str(t.get("request_url", "")),
                    "http_method": str(t.get("http_method", "GET")),
                    "headers": _ensure_json_serializable(t.get("headers") or {}),
                    "payload": _ensure_json_serializable(t.get("payload")) if t.get("payload") is not None else None,
                    "execution_order": int(t.get("execution_order", 0)),
                })
            except (TypeError, ValueError, KeyError):
                continue
        return out
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load transactions: {str(e)}")


@router.get("/scripts/{script_id}/python-script", response_class=PlainTextResponse)
async def get_python_script(request: Request, script_id: str) -> str:
    """Return generated Python script as plain text (for in-memory use)."""
    db = _get_db(request)
    script = db.get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    code = db.get_python_script(script_id)
    if not code:
        raise HTTPException(status_code=404, detail="Generated script not found")
    return code


@router.get("/scripts/{script_id}/parameters")
async def get_script_parameters(request: Request, script_id: str) -> list[dict]:
    """Extract configurable parameters from a Perfzy-generated Python script."""
    db = _get_db(request)
    script = db.get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    if (script.get("script_type") or "").lower() != "perfzy":
        return []
    code = db.get_python_script(script_id)
    if not code:
        return []
    params = []
    in_params_block = False
    param_re = re.compile(r'^(\w+)\s*=\s*"([^"]*)"\s*#\s*source:\s*(\w+)')
    for line in code.splitlines():
        if "# === Parameters ===" in line:
            in_params_block = True
            continue
        if in_params_block:
            if line.startswith("def ") or line.startswith("# ==="):
                break
            m = param_re.match(line.strip())
            if m:
                params.append({"name": m.group(1), "default_value": m.group(2), "source": m.group(3)})
    return params


@router.get("/scripts/{script_id}/download-script")
async def download_script(request: Request, script_id: str) -> Response:
    """Download generated Python script as script.py (executable)."""
    db = _get_db(request)
    script = db.get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    code = db.get_python_script(script_id)
    if not code:
        raise HTTPException(status_code=404, detail="Generated script not found")
    name = (script.get("script_name") or "script").rsplit(".", 1)[0]
    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in name)[:50] or "script"
    filename = f"{safe_name}.py"
    return Response(
        content=code,
        media_type="text/x-python",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/scripts/{script_id}/correlate")
async def correlate_script(request: Request, script_id: str) -> dict:
    """Run the correlation engine on a script's transactions and return the correlated script."""
    from backend.correlation_engine.orchestrator import run_correlation

    db = _get_db(request)
    script = db.get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    transactions = db.get_transactions(script_id)
    if not transactions:
        raise HTTPException(status_code=400, detail="No transactions found for this script. Record a flow first.")

    try:
        correlated_script, result = run_correlation(transactions)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Correlation engine error: {str(e)}")

    db.save_python_script(f"{script_id}_correlated", correlated_script)
    db.save_python_script(
        f"{script_id}_correlated_report",
        json.dumps({"correlated_params": result.correlated_param_count}),
    )

    return {
        "script": correlated_script,
        "report": {
            "request_count": result.request_count,
            "correlated_params": result.correlated_param_count,
            "extraction_rules": len(result.extraction_rules),
            "uncorrelated_candidates": len(result.uncorrelated_candidates),
            "user_params": len(result.user_params),
            "edges": [
                {
                    "param": e.param_name,
                    "param_type": e.param_type.value,
                    "source_request": e.source_request_index,
                    "target_request": e.target_request_index,
                    "type": e.extraction_rule.source_type.value,
                    "json_path": e.extraction_rule.json_path or None,
                    "source_key": e.extraction_rule.source_key_name or None,
                    "sample_value": (e.param_value[:80] + "…") if len(e.param_value) > 80 else e.param_value,
                    "response_hash": e.extraction_rule.response_hash or None,
                    "occurrences": e.extraction_rule.occurrence_count,
                    "confidence": e.extraction_rule.confidence_score,
                    "confidence_breakdown": e.extraction_rule.confidence_breakdown,
                }
                for e in result.edges[:50]
            ],
        },
    }


@router.get("/scripts/{script_id}/download-correlated-script")
async def download_correlated_script(request: Request, script_id: str) -> Response:
    """Download the correlated Python script."""
    db = _get_db(request)
    script = db.get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    code = db.get_python_script(f"{script_id}_correlated")
    if not code:
        raise HTTPException(status_code=404, detail="Correlated script not found. Run correlation first.")
    name = (script.get("script_name") or "script").rsplit(".", 1)[0]
    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in name)[:50] or "script"
    filename = f"{safe_name}_correlated.py"
    return Response(
        content=code,
        media_type="text/x-python",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---------------------------------------------------------------------------
# Script Replay Validator
# ---------------------------------------------------------------------------

@router.post("/scripts/{script_id}/replay/start")
async def replay_start(request: Request, script_id: str) -> dict:
    """Start a replay session for a script. Returns the transaction/API tree and session info."""
    from backend.correlation_engine.traverse_engine import build_request_records
    from backend.correlation_engine.dependency_graph import build_dependency_graph
    from backend.correlation_engine.replay_executor import ReplaySession, step_to_dict

    db = _get_db(request)
    script = db.get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    transactions = db.get_transactions(script_id)
    if not transactions:
        raise HTTPException(status_code=400, detail="No transactions found for this script.")

    records = build_request_records(transactions)
    if not records:
        raise HTTPException(status_code=400, detail="Could not build request records.")

    try:
        edges, rules, _ = build_dependency_graph(records)
    except Exception:
        edges, rules = [], []

    session = ReplaySession(
        script_id=script_id,
        records=records,
        edges=edges,
        rules=rules,
    )
    _replay_sessions[script_id] = session

    tree = _build_transaction_tree(session)
    return {
        "script_id": script_id,
        "total_requests": len(records),
        "current_index": 0,
        "tree": tree,
        "steps": [step_to_dict(s) for s in session.steps],
    }


@router.post("/scripts/{script_id}/replay/next")
async def replay_next(request: Request, script_id: str) -> dict:
    """Execute the next request in the replay session."""
    from backend.correlation_engine.replay_executor import execute_step, step_to_dict

    session = _replay_sessions.get(script_id)
    if session is None:
        raise HTTPException(status_code=400, detail="No active replay session. Call /replay/start first.")

    if session.current_index >= len(session.records):
        return {
            "done": True,
            "current_index": session.current_index,
            "step": None,
            "steps": [step_to_dict(s) for s in session.steps],
            "summary": _build_summary(session),
        }

    step = execute_step(session)

    return {
        "done": session.current_index >= len(session.records),
        "current_index": session.current_index,
        "step": step_to_dict(step),
        "steps": [step_to_dict(s) for s in session.steps],
    }


@router.post("/scripts/{script_id}/replay/stop")
async def replay_stop(request: Request, script_id: str) -> dict:
    """Stop and clean up a replay session."""
    from backend.correlation_engine.replay_executor import step_to_dict

    session = _replay_sessions.pop(script_id, None)
    if session is None:
        return {"ok": True, "message": "No active session"}

    summary = _build_summary(session)
    return {"ok": True, "summary": summary}


def _build_transaction_tree(session) -> list[dict]:
    """Build a tree of transactions with their child API requests."""
    from collections import OrderedDict
    groups: OrderedDict[str, list[dict]] = OrderedDict()
    for step in session.steps:
        name = step.transaction_name or "Unassigned"
        if name not in groups:
            groups[name] = []
        groups[name].append({
            "request_index": step.request_index,
            "method": step.method,
            "url": step.url,
            "status": step.status,
        })
    tree = []
    for tx_name, apis in groups.items():
        tree.append({"transaction_name": tx_name, "apis": apis})
    return tree


def _build_summary(session) -> dict:
    passed = sum(1 for s in session.steps if s.status == "passed")
    failed = sum(1 for s in session.steps if s.status == "failed")
    pending = sum(1 for s in session.steps if s.status == "pending")
    total_retries = sum(s.retries for s in session.steps)
    total_repairs = sum(len(s.repaired_rules) for s in session.steps)
    return {
        "total": len(session.steps),
        "passed": passed,
        "failed": failed,
        "pending": pending,
        "total_retries": total_retries,
        "total_repairs": total_repairs,
    }

"""
Universal HAR → performance script pipeline.
No domain-specific rules. Reduces 500–1000 HAR requests to 10–20 APIs grouped into transactions.
"""
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from urllib.parse import urlparse, parse_qs

from backend.models.script_model import TransactionBase


# ---------------------------------------------------------------------------
# RequestEntry (parsed URL components stored once)
# ---------------------------------------------------------------------------

@dataclass
class RequestEntry:
    """Single HAR request with response metadata for pipeline processing."""
    url: str
    scheme: str
    host: str
    path: str
    query_params: dict[str, list[str]]
    method: str
    headers: dict[str, str]
    payload: dict[str, Any] | None
    content_type: str
    status: int
    timestamp: str = ""
    path_params: dict[str, str] = field(default_factory=dict)
    response_size: int = 0
    request_body_size: int = 0
    response_text: str = ""
    response_headers: dict[str, str] = field(default_factory=dict)
    category: str = ""


# ---------------------------------------------------------------------------
# Request categories for grouped review
# ---------------------------------------------------------------------------

CAT_BUSINESS_API = "business_api"
CAT_HTML_NAVIGATION = "html_navigation"
CAT_STATIC_ASSET = "static_asset"
CAT_TELEMETRY = "telemetry"
CAT_CDN_INFRA = "cdn_infrastructure"
CAT_THIRD_PARTY = "third_party"
CAT_SECURITY = "security"
CAT_POLLING = "polling"

_DEFAULT_INCLUDED_CATEGORIES = frozenset([CAT_BUSINESS_API, CAT_HTML_NAVIGATION])

_STATIC_ASSET_EXTENSIONS = frozenset([
    ".css", ".js", ".png", ".jpg", ".jpeg", ".webp", ".svg", ".ico",
    ".gif", ".bmp", ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".mp4", ".webm", ".mp3", ".wav", ".map", ".avif", ".cur",
])


def _is_static_asset(entry: RequestEntry) -> bool:
    """True when the request is unambiguously a static asset (by extension or content-type).
    Evaluated BEFORE business-API scoring so .css/.js never leak into BUSINESS_API.
    """
    path_lower = (entry.path or "").lower().split("?")[0].split("#")[0]
    if any(path_lower.endswith(ext) for ext in _STATIC_ASSET_EXTENSIONS):
        return True
    ct = (entry.content_type or "").lower().split(";")[0].strip()
    if ct in ("text/css", "text/javascript", "application/javascript", "application/x-javascript"):
        return True
    if ct.startswith(("image/", "font/", "video/", "audio/")):
        return True
    return False


def _is_hard_cdn_infrastructure_request(entry: RequestEntry) -> bool:
    """Recorder-only hard exclusion for Cloudflare infrastructure paths."""
    path = (entry.path or "").lower()
    return path.startswith("/cdn-cgi/")


def classify_entry(
    entry: RequestEntry,
    primary_domain: str = "",
    is_third_party: bool = False,
    is_polling_dup: bool = False,
    business_score: int = 0,
) -> str:
    """Assign a single category to *entry*.

    Hard categories (third-party, static assets) always win.
    Soft negative signals (CDN, telemetry, security, polling) are overridden
    when the business score is high enough — matching the existing scoring
    pipeline where these signals are penalties, not hard exclusions.
    """
    if is_third_party:
        return CAT_THIRD_PARTY

    if _is_static_asset(entry):
        return CAT_STATIC_ASSET

    # Hard exception: Cloudflare infrastructure endpoints like /cdn-cgi/rum
    # must never be promoted into business APIs.
    if _is_hard_cdn_infrastructure_request(entry):
        return CAT_CDN_INFRA

    # If the scoring pipeline considers this a business API, trust that
    # verdict — the score already incorporates CDN/telemetry/security/polling
    # as negative penalties, and the request earned enough positive signals
    # to overcome them.
    if business_score >= _BUSINESS_API_THRESHOLD:
        ct = (entry.content_type or "").lower().split(";")[0].strip()
        if ct == "text/html" and (entry.method or "GET").upper() == "GET":
            return CAT_HTML_NAVIGATION
        return CAT_BUSINESS_API

    # Below threshold — apply soft negative categories
    if is_cdn_infrastructure_request(entry):
        return CAT_CDN_INFRA

    if is_telemetry_request(entry):
        return CAT_TELEMETRY

    if is_security_infrastructure_request(entry):
        return CAT_SECURITY

    if is_polling_dup:
        return CAT_POLLING

    ct = (entry.content_type or "").lower().split(";")[0].strip()
    if ct == "text/html" and (entry.method or "GET").upper() == "GET":
        return CAT_HTML_NAVIGATION

    return CAT_BUSINESS_API


def classify_all_entries(
    entries: list[RequestEntry],
    primary_domain: str = "",
    polling_keys: set[str] | None = None,
    transaction_windows: list[tuple[float, float]] | None = None,
    nav_event_times: list[float] | None = None,
) -> None:
    """Classify every entry in-place, setting ``entry.category``.

    Third-party detection uses *primary_domain* + ``_host_matches_root``
    (defined later in this module) so subdomains are correctly kept.
    """
    if polling_keys is None:
        polling_keys = _detect_polling_keys(entries)
    seen_polling: dict[str, bool] = {}

    for e in entries:
        host = (e.host or "").lower()
        is_tp = bool(primary_domain) and not _host_matches_root(host, primary_domain)

        path_key = (e.method or "GET").upper() + " " + (e.path or "/").lower()
        is_dup = False
        if path_key in polling_keys:
            if seen_polling.get(path_key):
                is_dup = True
            else:
                seen_polling[path_key] = True

        score = business_api_score(
            e,
            primary_domain=primary_domain,
            transaction_windows=transaction_windows,
            polling_keys=polling_keys,
            is_polling_duplicate=is_dup,
            nav_event_times=nav_event_times,
        )
        e.category = classify_entry(
            e,
            primary_domain=primary_domain,
            is_third_party=is_tp,
            is_polling_dup=is_dup,
            business_score=score,
        )


def _request_identity(e: RequestEntry) -> tuple:
    """Key that uniquely identifies a request for counting/dedup purposes.
    Two requests are identical only when method, full URL, query params, and
    payload all match.  Different path-parameter values (e.g. /add_to_cart/1
    vs /add_to_cart/2) produce different keys."""
    import json as _json
    return (
        (e.method or "GET").upper(),
        (e.url or "").split("?")[0],
        tuple(sorted((k, tuple(v)) for k, v in (e.query_params or {}).items())),
        _json.dumps(e.payload, sort_keys=True) if e.payload else "",
    )


def build_group_summary(entries: list[RequestEntry]) -> dict[str, dict]:
    """Build the grouped summary dict from classified entries.

    Counts *distinct* APIs per category so that repeated identical requests
    (same method + full URL + query + payload) count once, while different
    path-parameter values count separately.
    """
    seen: dict[str, set] = {}
    for e in entries:
        cat = e.category or CAT_BUSINESS_API
        seen.setdefault(cat, set()).add(_request_identity(e))

    summary: dict[str, dict] = {}
    for cat in (CAT_BUSINESS_API, CAT_HTML_NAVIGATION, CAT_STATIC_ASSET,
                CAT_TELEMETRY, CAT_CDN_INFRA, CAT_THIRD_PARTY,
                CAT_SECURITY, CAT_POLLING):
        distinct = len(seen.get(cat, set()))
        if distinct > 0:
            summary[cat] = {
                "count": distinct,
                "default_selected": cat in _DEFAULT_INCLUDED_CATEGORIES,
            }
    return summary


def dedup_consecutive_identical(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Remove consecutive duplicate requests that are truly identical.
    Keeps distinct APIs like /add_to_cart/1 and /add_to_cart/2."""
    if not entries:
        return entries
    out: list[RequestEntry] = [entries[0]]
    for e in entries[1:]:
        if _request_identity(e) != _request_identity(out[-1]):
            out.append(e)
    return out


def filter_entries_by_categories(
    entries: list[RequestEntry],
    include_categories: list[str],
) -> list[RequestEntry]:
    """Return only entries whose category is in *include_categories*."""
    allowed = frozenset(include_categories)
    return [e for e in entries if e.category in allowed]


# ---------------------------------------------------------------------------
# 1. Ignore browser protocol requests (OPTIONS, HEAD)
# ---------------------------------------------------------------------------

def remove_browser_protocol_requests(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Remove OPTIONS (CORS preflight) and HEAD (metadata checks, not real transactions)."""
    return [e for e in entries if (e.method or "GET").upper() not in ("OPTIONS", "HEAD")]


# ---------------------------------------------------------------------------
# 2. Browser pseudo and transport headers (strip before script gen)
# ---------------------------------------------------------------------------

_HEADERS_TO_REMOVE = frozenset([
    "sec-fetch-site", "sec-fetch-mode", "sec-fetch-dest", "priority",
    "rtt", "downlink", "device-memory", "viewport-width",
])
_HEADERS_TO_REMOVE_PREFIX = (":", "sec-ch-")


def _strip_browser_headers(headers: dict[str, str]) -> dict[str, str]:
    """Keep only useful headers: accept, content-type, authorization, cookie, user-agent, x-*."""
    if not headers:
        return {}
    out: dict[str, str] = {}
    for name, value in headers.items():
        key_lower = name.lower().strip()
        if key_lower.startswith(_HEADERS_TO_REMOVE_PREFIX[0]):
            continue
        if key_lower in _HEADERS_TO_REMOVE:
            continue
        if any(key_lower.startswith(p) for p in _HEADERS_TO_REMOVE_PREFIX[1:]):
            continue
        if key_lower in ("accept", "content-type", "authorization", "cookie", "user-agent"):
            out[name] = value
        elif key_lower.startswith("x-"):
            out[name] = value
    return out


# ---------------------------------------------------------------------------
# 3. Static resources (content-type + file extensions)
# ---------------------------------------------------------------------------

_STATIC_EXTENSIONS = frozenset([
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".css", ".js",
    ".ttf", ".woff", ".woff2", ".eot", ".otf",
    ".ico", ".mp4", ".webm", ".map", ".avif", ".bmp", ".cur",
])

# Do NOT include "text/html" here: document navigation requests (product pages, search, checkout)
# have content-type text/html and must be preserved. Only remove HTML when clearly embedded static
# (e.g. .html file with static path); that is handled by URL suffix below.
_STATIC_CONTENT_TYPES = frozenset([
    "text/css", "text/javascript", "application/javascript", "application/x-javascript",
])


def _content_type_base(ct: str) -> str:
    if not ct:
        return ""
    return ct.split(";")[0].strip().lower()


def _is_static_content_type(ct: str) -> bool:
    """True if content-type is a static asset type. Excludes text/html so document navigations are kept."""
    base = _content_type_base(ct)
    if not base:
        return False
    if base in _STATIC_CONTENT_TYPES:
        return True
    if base.startswith("image/") or base.startswith("font/"):
        return True
    if base.startswith("video/") or base.startswith("audio/"):
        return True
    return False


def _is_embedded_static_html(entry: RequestEntry) -> bool:
    """True if this looks like a static HTML asset (e.g. /static/error.html), not a document navigation."""
    ct = _content_type_base(entry.content_type or "")
    if ct != "text/html":
        return False
    path_lower = (entry.path or "").lower().split("?")[0].split("#")[0]
    return path_lower.endswith(".html")


def remove_static_resources(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Drop requests that are static assets by URL suffix or response content type.
    Document navigation requests (text/html, e.g. /dp/<ASIN>, search, checkout) are preserved.
    Only remove HTML when clearly a static file (e.g. path ends with .html)."""
    out: list[RequestEntry] = []
    for e in entries:
        path_lower = (e.path or "").lower()
        if any(path_lower.endswith(ext) or ext + "?" in path_lower or ext + "#" in path_lower for ext in _STATIC_EXTENSIONS):
            continue
        if _is_static_content_type(e.content_type or ""):
            continue
        if _is_embedded_static_html(e):
            continue
        out.append(e)
    return out


# ---------------------------------------------------------------------------
# Remove very small GET responses (heartbeat / UI signals / feature flags)
# ---------------------------------------------------------------------------

_MIN_MEANINGFUL_RESPONSE_BYTES = 50


def remove_small_non_json_get_responses(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Remove GET requests with response < 50 bytes and not JSON (often heartbeat, UI signals, feature flags)."""
    out: list[RequestEntry] = []
    for e in entries:
        if (e.method or "GET").upper() != "GET":
            out.append(e)
            continue
        if (e.response_size or 0) >= _MIN_MEANINGFUL_RESPONSE_BYTES:
            out.append(e)
            continue
        ct = _content_type_base(e.content_type or "")
        if "application/json" in ct:
            out.append(e)
            continue
        # GET, small response, not JSON → skip
    return out


# ---------------------------------------------------------------------------
# 4. Telemetry detection (URL, host, payload, behavioral)
# ---------------------------------------------------------------------------

_TELEMETRY_URL_KEYWORDS_RE = re.compile(
    r"\b(analytics|tracking|telemetry|beacon|pixel|heartbeat)\b", re.I,
)

_TELEMETRY_PATH_PATTERNS = frozenset([
    "analytics", "tracking", "telemetry", "metrics", "metric", "collect",
    "beacon", "pixel", "monitor", "monitoring", "logging", "consent",
    "experiment", "featureflag", "events", "event", "log", "logs",
])

# Host substrings for monitoring infrastructure
_TELEMETRY_HOST_PATTERNS = frozenset([
    "metrics", "telemetry", "analytics", "monitor", "logging", "collector",
    "tracking", "beacon", "pixel", "heartbeat",
])

# Payload keys that indicate telemetry/monitoring pipelines
_PAYLOAD_TELEMETRY_KEYS = frozenset([
    "events", "metrics", "counters", "logs", "telemetry", "heartbeat",
    "producerid", "schemaid", "messageid",
])

# Client-side telemetry: path substrings
_TELEMETRY_PATH_CLIENT = ("/oe/", "/batch/", "/metrics")

# Request/response body substrings (cel, csm, metrics = client telemetry APIs)
_TELEMETRY_BODY_MARKERS = ("cel", "csm", "metrics")


def _payload_has_telemetry_signals(payload: Any, depth: int = 0) -> bool:
    """True if payload contains telemetry-like keys (events, metrics, etc.)."""
    if depth > 5:
        return False
    if payload is None:
        return False
    if isinstance(payload, dict):
        for k, v in payload.items():
            if str(k).lower() in _PAYLOAD_TELEMETRY_KEYS:
                return True
            if _payload_has_telemetry_signals(v, depth + 1):
                return True
    elif isinstance(payload, list):
        for item in payload[:20]:
            if _payload_has_telemetry_signals(item, depth + 1):
                return True
    return False


def _payload_has_nested_events(payload: Any, depth: int = 0) -> bool:
    """True if payload has nested structure typical of event collectors."""
    if depth > 4:
        return False
    if payload is None:
        return False
    if isinstance(payload, dict):
        keys_lower = [str(k).lower() for k in payload.keys()]
        if "events" in keys_lower or "event" in keys_lower:
            return True
        for v in payload.values():
            if _payload_has_nested_events(v, depth + 1):
                return True
    elif isinstance(payload, list):
        for item in payload[:10]:
            if isinstance(item, dict) and ("event" in str(item).lower() or "name" in str(item).lower()):
                return True
            if _payload_has_nested_events(item, depth + 1):
                return True
    return False


def _is_behavioral_telemetry(entry: RequestEntry) -> bool:
    """POST with nested event-like payload and tiny response = telemetry collector."""
    if (entry.method or "").upper() != "POST":
        return False
    if (entry.response_size or 0) >= 200:
        return False
    return _payload_has_nested_events(entry.payload)


def _path_contains_telemetry(path: str) -> bool:
    """True if path contains /events/, /log/, /metrics/, etc."""
    path_lower = (path or "").lower().strip("/")
    segments = path_lower.split("/")
    return any(seg in _TELEMETRY_PATH_PATTERNS for seg in segments)


def _host_contains_telemetry(host: str) -> bool:
    """True if host suggests monitoring infrastructure."""
    host_lower = (host or "").lower()
    return any(p in host_lower for p in _TELEMETRY_HOST_PATTERNS)


def _body_contains_telemetry_markers(text: str) -> bool:
    """True if request/response body contains client telemetry markers (cel, csm, metrics)."""
    if not text or not isinstance(text, str):
        return False
    t = text.lower()
    return any(m in t for m in _TELEMETRY_BODY_MARKERS)


def is_telemetry_request(entry: RequestEntry) -> bool:
    """True if request should be classified as telemetry and removed.

    Uses segment-based matching for paths (not raw substring) to avoid
    false positives like 'log' matching 'login' or 'ads' matching 'uploads'.
    """
    host_lower = (entry.host or "").lower()
    path_lower = (entry.path or "").lower()
    if _path_contains_telemetry(path_lower):
        return True
    for seg in _TELEMETRY_PATH_CLIENT:
        if seg in path_lower:
            return True
    if _host_contains_telemetry(host_lower):
        return True
    if _TELEMETRY_URL_KEYWORDS_RE.search(entry.url or ""):
        return True
    if _payload_has_telemetry_signals(entry.payload):
        return True
    if _body_contains_telemetry_markers(json.dumps(entry.payload) if entry.payload else ""):
        return True
    if _body_contains_telemetry_markers(entry.response_text or ""):
        return True
    if _is_behavioral_telemetry(entry):
        return True
    return False


def remove_telemetry_requests(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Remove requests that match URL, host, payload, or behavioral telemetry patterns.
    Login requests are immune — never removed by telemetry detection.
    """
    return [e for e in entries if is_login_request(e) or not is_telemetry_request(e)]


# ---------------------------------------------------------------------------
# Step 3a — Cloudflare RUM / CDN infrastructure endpoints
# ---------------------------------------------------------------------------
# /cdn-cgi/* paths are Cloudflare infrastructure (Real User Monitoring, trace, etc.)
# They exist on the primary domain but are never business APIs.

_CDN_INFRA_PATH_PREFIXES = ("/cdn-cgi/", "/cdn-cgi", "/akamai/", "/cloudflare/")

_CDN_INFRA_EXACT_SEGMENTS = frozenset([
    "rum", "beacon", "telemetry", "collect", "pixel.gif",
])


def is_cdn_infrastructure_request(entry: RequestEntry) -> bool:
    path = (entry.path or "").lower()
    if any(path.startswith(p) for p in _CDN_INFRA_PATH_PREFIXES):
        return True
    segments = path.strip("/").split("/")
    return any(seg in _CDN_INFRA_EXACT_SEGMENTS for seg in segments)


def remove_cdn_infrastructure_requests(entries: list[RequestEntry]) -> tuple[list[RequestEntry], int]:
    """Remove Cloudflare /cdn-cgi/* endpoints (RUM, trace, etc.). Returns (kept, removed_count)."""
    kept: list[RequestEntry] = []
    removed = 0
    for e in entries:
        if is_cdn_infrastructure_request(e):
            print(f"[Pipeline] Removed Cloudflare RUM endpoint: {e.path}")
            removed += 1
        else:
            kept.append(e)
    return kept, removed


# ---------------------------------------------------------------------------
# Step 3b — Bot-protection and security verification (before business API detection)
# ---------------------------------------------------------------------------
# Generic filtering for AWS WAF, Cloudflare, Akamai, PerimeterX, Datadome, etc.
# These are infrastructure requests, not business APIs.

_SECURITY_HOST_SUBSTRINGS = frozenset([
    "token", "waf", "captcha", "bot", "challenge", "security",
])

_SECURITY_PATH_SUBSTRINGS = frozenset([
    "verify", "challenge", "inputs", "captcha", "bot", "validate",
])


def is_security_infrastructure_request(entry: RequestEntry) -> bool:
    """
    True if this request is bot-protection or security verification infrastructure.
    Examples: *.token.awswaf.com, captcha.*, /mp_verify, /inputs, /challenge.
    """
    host = (entry.host or "").lower()
    path = (entry.path or "").lower()
    for sub in _SECURITY_HOST_SUBSTRINGS:
        if sub in host:
            return True
    for sub in _SECURITY_PATH_SUBSTRINGS:
        if sub in path:
            return True
    return False


def remove_security_infrastructure_requests(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Remove WAF, captcha, bot challenge, and security verification endpoints.
    Login requests are immune — never removed by security infrastructure detection.
    """
    return [e for e in entries if is_login_request(e) or not is_security_infrastructure_request(e)]


# ---------------------------------------------------------------------------
# Step 4 — Primary domain detection + third-party domain filtering
# ---------------------------------------------------------------------------
# The primary domain is extracted from the user-provided URL (not guessed from
# HAR frequency, which fails when third-party requests outnumber the real site).
# Only requests to the primary domain or its subdomains are kept.

_MULTI_PART_TLDS = frozenset([
    "co.uk", "com.au", "co.in", "co.nz", "com.br", "co.jp", "com.mx",
    "co.za", "com.sg", "co.kr", "org.uk", "net.au", "ac.uk", "gov.uk",
])

# Domains containing any of these substrings are always third-party noise
_THIRD_PARTY_DOMAIN_KEYWORDS = frozenset([
    "google", "doubleclick", "googlesyndication", "googletagmanager",
    "googleadservices", "googleapis", "gstatic", "googleanalytics",
    "google-analytics", "googleoptimize", "googlesource",
    "facebook", "fbcdn", "fbsbx", "instagram",
    "analytics", "segment", "mixpanel", "amplitude",
    "datadog", "sentry", "newrelic", "rollbar", "bugsnag", "logrocket",
    "hotjar", "mouseflow", "fullstory", "crazyegg", "inspectlet",
    "cloudflareinsights", "fundingchoicesmessages",
    "adsense", "adroll", "criteo", "taboola", "outbrain",
    "chartbeat", "parsely", "quantserve", "scorecardresearch",
    "omniture", "omtrdc", "demdex", "adobedtm",
    "optimizely", "launchdarkly", "split.io",
    "intercom", "drift", "zendesk", "freshchat", "tawk",
    "branch.io", "appsflyer", "adjust", "kochava",
    "twitter", "linkedin", "pinterest", "tiktok", "snapchat",
    "youtube", "vimeo",
])


def _root_domain(host: str) -> str:
    """Extract root domain, e.g. api.amazon.in → amazon.in, www.amazon.co.uk → amazon.co.uk."""
    if not host:
        return ""
    parts = host.lower().strip().split(".")
    if len(parts) <= 2:
        return host.lower()
    suffix = ".".join(parts[-2:])
    if suffix in _MULTI_PART_TLDS and len(parts) >= 3:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def detect_primary_domain(user_url: str) -> str:
    """Extract the primary root domain from the URL the user provided to the recorder.

    Example: https://automationexercise.com/products → automationexercise.com
    """
    if not user_url:
        return ""
    parsed = urlparse(user_url)
    host = (parsed.netloc or parsed.path.split("/")[0] or "").lower().strip()
    if ":" in host:
        host = host.split(":")[0]
    return _root_domain(host)


def _extract_main_host(entries: list[RequestEntry]) -> str:
    """Fallback: derive main host from the first non-third-party request."""
    if not entries:
        return ""
    for e in entries:
        h = (e.host or "").lower().strip()
        if h and not _is_known_third_party(h):
            return h
    return (entries[0].host or "").lower()


def _is_known_third_party(host: str) -> bool:
    """True if host contains a known third-party domain keyword."""
    h = host.lower()
    return any(kw in h for kw in _THIRD_PARTY_DOMAIN_KEYWORDS)


def _host_matches_root(host: str, root: str) -> bool:
    """True if host is the root domain or any subdomain of it.

    Automatically allows all subdomains:
      root = automationexercise.com
      matches: automationexercise.com, api.automationexercise.com,
               services.automationexercise.com, gateway.automationexercise.com
    """
    if not root:
        return True
    host = (host or "").lower()
    if host == root:
        return True
    if host.endswith("." + root):
        return True
    return False


def _discover_allowed_domains(entries: list[RequestEntry], root: str) -> frozenset[str]:
    """Discover all domains that share the same root domain.

    This handles real-world setups where APIs come from sibling subdomains:
      frontend.example.com, api.example.com, services.example.com, gateway.example.com
    All are legitimate because they share root domain 'example.com'.
    """
    if not root:
        return frozenset()
    allowed = set()
    for e in entries:
        h = (e.host or "").lower().strip()
        if _host_matches_root(h, root):
            allowed.add(h)
    return frozenset(allowed)


def remove_third_party_domains(
    entries: list[RequestEntry],
    primary_domain: str = "",
    main_host: str | None = None,
) -> tuple[list[RequestEntry], int]:
    """Keep only requests whose host shares the same root domain as the primary.

    Automatically allows ALL subdomains:
      primary_domain = automationexercise.com
      keeps: automationexercise.com, api.automationexercise.com, cdn.automationexercise.com
      removes: google.com, facebook.com, analytics.example.net

    Returns (kept_entries, removed_count).
    """
    root = primary_domain or ""
    if not root and main_host:
        root = _root_domain(main_host)
    if not root:
        root = _root_domain(_extract_main_host(entries))

    before = len(entries)
    if root:
        allowed = _discover_allowed_domains(entries, root)
        entries = [e for e in entries if _host_matches_root((e.host or "").lower(), root)]
        if allowed:
            print(f"[Pipeline] Primary domain: {root} — allowed hosts: {sorted(allowed)}")
    else:
        entries = [e for e in entries if not _is_known_third_party(e.host or "")]

    return entries, before - len(entries)


# ---------------------------------------------------------------------------
# 7. Behavior-based business API scoring
# ---------------------------------------------------------------------------
# Each request receives a score based on behavioral signals rather than URL
# keywords.  Requests scoring >= _BUSINESS_API_THRESHOLD are classified as
# business APIs.  Login requests are always immune regardless of score.

_BUSINESS_API_THRESHOLD = 40

_TEMPORAL_PROXIMITY_MS = 500
_MIN_MEANINGFUL_RESPONSE_SIZE = 500

_BUSINESS_CONTENT_TYPES = frozenset([
    "text/html", "application/json", "text/plain", "application/xml",
    "application/x-www-form-urlencoded", "multipart/form-data",
    "text/xml", "application/soap+xml",
])

_BINARY_RESPONSE_PREFIXES = ("image/", "font/", "video/", "audio/")
_BINARY_RESPONSE_TYPES = frozenset([
    "application/octet-stream", "application/pdf", "application/zip",
    "application/gzip", "application/wasm",
    "application/font-woff", "application/font-woff2",
])


def _is_binary_response_type(ct: str) -> bool:
    if not ct:
        return False
    return ct.startswith(_BINARY_RESPONSE_PREFIXES) or ct in _BINARY_RESPONSE_TYPES


def _detect_polling_keys(entries: list[RequestEntry]) -> set[str]:
    """Identify method+path combinations that fire >= 5 times within any 60-second window."""
    if not entries:
        return set()
    path_key_to_times: dict[str, list[float]] = {}
    for e in entries:
        key = (e.method or "GET").upper() + " " + (e.path or "/").lower()
        path_key_to_times.setdefault(key, []).append(_parse_har_time(e.timestamp))
    polling: set[str] = set()
    for key, times in path_key_to_times.items():
        times.sort()
        for t in times:
            count = sum(1 for s in times if 0 <= (s - t) <= _POLLING_WINDOW_SECONDS)
            if count >= _POLLING_MIN_COUNT:
                polling.add(key)
                break
    return polling


def business_api_score(
    entry: RequestEntry,
    primary_domain: str = "",
    transaction_windows: list[tuple[float, float]] | None = None,
    polling_keys: set[str] | None = None,
    is_polling_duplicate: bool = False,
    nav_event_times: list[float] | None = None,
) -> int:
    """Compute a behavior-based score for whether *entry* is a business API.

    Positive signals (the request looks like a real user-facing API):
        +20  same domain as the primary application
        +20  response content-type is a business type (HTML, JSON, XML, text)
        +20  request falls within a user transaction time window
        +15  request carries parameters (query, path, or body)
        +10  mutating method (POST / PUT / PATCH / DELETE)
        +10  temporal proximity — within ±500 ms of a navigation event
         +8  GET that is not a static asset
         +5  response body size > 500 bytes (meaningful payload)

    Negative signals (infrastructure / noise):
        -40  matches telemetry patterns
        -40  matches CDN infrastructure paths
        -40  response is a binary type (image, font, video)
        -30  detected as background polling (duplicate instance)
        -30  matches security-infrastructure patterns (WAF, captcha)
    """
    score = 0
    method = (entry.method or "GET").upper()
    ct = _content_type_base(entry.content_type or "")
    host = (entry.host or "").lower()

    # --- positive signals ---
    if primary_domain and _host_matches_root(host, primary_domain):
        score += 20

    if ct in _BUSINESS_CONTENT_TYPES:
        score += 20

    if transaction_windows:
        t = _parse_har_time(entry.timestamp)
        for start, end in transaction_windows:
            if start <= t <= end:
                score += 20
                break

    has_params = bool(entry.query_params) or bool(entry.path_params) or bool(entry.payload)
    if has_params:
        score += 15

    if method in ("POST", "PUT", "PATCH", "DELETE"):
        score += 10
    elif method == "GET" and not _is_static_content_type(ct) and not _is_binary_response_type(ct):
        score += 8

    # Temporal proximity: user actions trigger backend calls in bursts
    if nav_event_times:
        t = _parse_har_time(entry.timestamp)
        proximity_s = _TEMPORAL_PROXIMITY_MS / 1000.0
        for nt in nav_event_times:
            if abs(t - nt) <= proximity_s:
                score += 10
                break

    # Response size: business APIs return meaningful payloads
    if (entry.response_size or 0) > _MIN_MEANINGFUL_RESPONSE_SIZE:
        score += 5

    # --- negative signals ---
    if is_telemetry_request(entry):
        score -= 40

    if is_cdn_infrastructure_request(entry):
        score -= 40

    if _is_binary_response_type(ct):
        score -= 40

    if is_polling_duplicate:
        score -= 30

    if is_security_infrastructure_request(entry):
        score -= 30

    return score


def business_api_confidence(entry: RequestEntry) -> int:
    """Legacy convenience wrapper — returns the behavior score."""
    return business_api_score(entry)


def is_business_api(entry: RequestEntry, **kwargs) -> bool:
    """True when the entry's behavior score meets the business-API threshold."""
    return business_api_score(entry, **kwargs) >= _BUSINESS_API_THRESHOLD


_CLUSTER_ADJACENCY_BOOST = 5
_CLUSTER_NEIGHBOR_THRESHOLD = 60


def score_and_filter_entries(
    entries: list[RequestEntry],
    primary_domain: str = "",
    transaction_windows: list[tuple[float, float]] | None = None,
    nav_event_times: list[float] | None = None,
) -> tuple[list[RequestEntry], dict[str, int]]:
    """Score every entry and keep those that qualify as business APIs.

    Two-pass scoring:
      Pass 1 — compute individual behavior scores for each entry.
      Pass 2 — apply cluster adjacency boost: if either chronological
               neighbor scored >= 60, add +5.  APIs often appear in
               bursts (e.g. GET /product, GET /inventory, GET /reviews);
               a weaker request surrounded by strong ones is likely real.

    Returns (kept_entries, breakdown) where *breakdown* maps rejection
    reasons to counts for the pipeline report.
    """
    polling_keys = _detect_polling_keys(entries)

    # --- Pass 1: compute individual scores ---
    n = len(entries)
    scores: list[int] = [0] * n
    is_login: list[bool] = [False] * n
    is_dup_flags: list[bool] = [False] * n
    seen_polling: dict[str, bool] = {}

    for i, e in enumerate(entries):
        if is_login_request(e):
            is_login[i] = True
            continue

        path_key = (e.method or "GET").upper() + " " + (e.path or "/").lower()
        is_dup = False
        if path_key in polling_keys:
            if seen_polling.get(path_key):
                is_dup = True
            else:
                seen_polling[path_key] = True
        is_dup_flags[i] = is_dup

        scores[i] = business_api_score(
            e,
            primary_domain=primary_domain,
            transaction_windows=transaction_windows,
            polling_keys=polling_keys,
            is_polling_duplicate=is_dup,
            nav_event_times=nav_event_times,
        )

    # --- Pass 2: cluster adjacency boost ---
    for i in range(n):
        if is_login[i] or scores[i] >= _BUSINESS_API_THRESHOLD:
            continue
        prev_strong = i > 0 and scores[i - 1] >= _CLUSTER_NEIGHBOR_THRESHOLD
        next_strong = i < n - 1 and scores[i + 1] >= _CLUSTER_NEIGHBOR_THRESHOLD
        if prev_strong or next_strong:
            scores[i] += _CLUSTER_ADJACENCY_BOOST

    # --- Filter ---
    kept: list[RequestEntry] = []
    breakdown: dict[str, int] = {
        "static_resources_removed": 0,
        "cdn_infrastructure_removed": 0,
        "telemetry_requests_removed": 0,
        "security_infrastructure_removed": 0,
        "polling_requests_removed": 0,
        "low_score_removed": 0,
    }

    for i, e in enumerate(entries):
        if is_login[i]:
            kept.append(e)
            continue

        if scores[i] >= _BUSINESS_API_THRESHOLD:
            kept.append(e)
        else:
            ct = _content_type_base(e.content_type or "")
            if _is_binary_response_type(ct) or _is_static_content_type(ct):
                breakdown["static_resources_removed"] += 1
            elif is_cdn_infrastructure_request(e):
                breakdown["cdn_infrastructure_removed"] += 1
            elif is_telemetry_request(e):
                breakdown["telemetry_requests_removed"] += 1
            elif is_security_infrastructure_request(e):
                breakdown["security_infrastructure_removed"] += 1
            elif is_dup_flags[i]:
                breakdown["polling_requests_removed"] += 1
            else:
                breakdown["low_score_removed"] += 1

    return kept, breakdown


# ---------------------------------------------------------------------------
# Login request detection — immune to telemetry and business filters
# ---------------------------------------------------------------------------

_LOGIN_PATH_KEYWORDS = frozenset([
    "login", "signin", "sign-in", "sign_in", "authenticate", "auth", "session",
])

_LOGIN_BODY_FIELDS = frozenset([
    "username", "email", "password", "passwd", "user", "login",
    "credential", "credentials",
])

_LOGIN_BODY_FIELDS_RE = re.compile(
    r"\b(username|email|password|passwd|credential|credentials)\b", re.I,
)


def is_login_request(entry: RequestEntry) -> bool:
    """True if this is a login/authentication POST that must always be preserved.

    Checks both path keywords AND payload fields (including form-urlencoded raw bodies).
    Login requests are immune to telemetry, business API, and behavioral filters.
    """
    if (entry.method or "").upper() != "POST":
        return False
    path_lower = (entry.path or "").lower()
    segments = path_lower.strip("/").split("/")
    if any(seg in _LOGIN_PATH_KEYWORDS for seg in segments):
        return True
    if entry.payload and isinstance(entry.payload, dict):
        keys_lower = {str(k).lower() for k in entry.payload.keys()}
        if keys_lower & _LOGIN_BODY_FIELDS:
            return True
        raw = str(entry.payload.get("raw", ""))
        if raw and _LOGIN_BODY_FIELDS_RE.search(raw):
            return True
    return False


def _log_detected_logins(entries: list[RequestEntry]) -> None:
    """Log detected login requests once (called from pipeline runner)."""
    for e in entries:
        if is_login_request(e):
            print(f"[Pipeline] Detected login POST request: {e.path}")


def _is_login_page_get(entry: RequestEntry) -> bool:
    """True if request is a GET to a login page (the HTML form, not the submission)."""
    if (entry.method or "").upper() != "GET":
        return False
    path_lower = (entry.path or "").lower()
    segments = path_lower.strip("/").split("/")
    return any(seg in _LOGIN_PATH_KEYWORDS for seg in segments)


def prioritize_login_posts(entries: list[RequestEntry]) -> list[RequestEntry]:
    """When both a login page GET and a login POST exist,
    remove the GET (the page load) and keep only the POST (the actual authentication).
    """
    login_posts = [e for e in entries if is_login_request(e)]
    if not login_posts:
        return entries
    login_gets = {id(e) for e in entries if _is_login_page_get(e)}
    if not login_gets:
        return entries
    removed = 0
    out = []
    for e in entries:
        if id(e) in login_gets:
            print(f"[Pipeline] Replaced GET {e.path} with POST {e.path}")
            removed += 1
        else:
            out.append(e)
    return out


def _first_value(v: list[str] | str | Any) -> str:
    if isinstance(v, list):
        return v[0] if v else ""
    return str(v) if v else ""


def _duplicate_key(entry: RequestEntry) -> str:
    method = (entry.method or "GET").upper()
    path = (entry.path or "/").lower() or "/"
    q = entry.query_params or {}
    parts = sorted(f"{k}={_first_value(q[k])}" for k in sorted(q.keys()))
    query_part = "&".join(parts)
    return f"{method} {path}" + ("?" + query_part if query_part else "")


def _parse_har_time(ts: str) -> float:
    """Parse HAR startedDateTime to Unix timestamp."""
    if not ts:
        return 0.0
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.timestamp()
    except Exception:
        return 0.0


# ---------------------------------------------------------------------------
# 5. Repeated polling (method + path >5 in 60s window → keep one)
# ---------------------------------------------------------------------------

_POLLING_WINDOW_SECONDS = 60
_POLLING_MIN_COUNT = 5


def remove_polling_requests(entries: list[RequestEntry]) -> list[RequestEntry]:
    """If same method+path appears >5 times within 60s, keep only the first (behavior-based)."""
    if not entries:
        return entries
    sorted_entries = sorted(entries, key=lambda x: (_parse_har_time(x.timestamp), x.url))
    path_key_to_list: dict[str, list[RequestEntry]] = {}
    for e in sorted_entries:
        key = (e.method or "GET").upper() + " " + (e.path or "/").lower()
        path_key_to_list.setdefault(key, []).append(e)
    polling_keys: set[str] = set()
    for key, group in path_key_to_list.items():
        times = [_parse_har_time(e.timestamp) for e in group]
        for t in times:
            count = sum(1 for s in times if 0 <= (s - t) <= _POLLING_WINDOW_SECONDS)
            if count >= _POLLING_MIN_COUNT:
                polling_keys.add(key)
                break
    seen_polling: dict[str, bool] = {}
    out: list[RequestEntry] = []
    for e in sorted_entries:
        key = (e.method or "GET").upper() + " " + (e.path or "/").lower()
        if key in polling_keys:
            if not seen_polling.get(key):
                seen_polling[key] = True
                out.append(e)
        else:
            out.append(e)
    out.sort(key=lambda x: (_parse_har_time(x.timestamp), x.url))
    return out


# ---------------------------------------------------------------------------
# 6. Collapse typing/suggestion APIs (same path, same query keys, diff values → keep last)
# ---------------------------------------------------------------------------

def _base_path_key(entry: RequestEntry) -> str:
    return (entry.method or "GET").upper() + " " + (entry.path or "/").lower()


def collapse_typing_suggestions(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Group by method+path; if multiple have same query keys (e.g. ?q=), keep only the final request."""
    if not entries:
        return entries
    sorted_entries = sorted(entries, key=lambda x: (_parse_har_time(x.timestamp), x.url))
    by_base: dict[str, list[RequestEntry]] = {}
    for e in sorted_entries:
        by_base.setdefault(_base_path_key(e), []).append(e)
    out: list[RequestEntry] = []
    for key, group in by_base.items():
        if len(group) <= 1:
            out.extend(group)
            continue
        query_keys_sets = [frozenset((e.query_params or {}).keys()) for e in group]
        if len(set(query_keys_sets)) > 1:
            out.extend(group)
            continue
        out.append(group[-1])
    out.sort(key=lambda x: (_parse_har_time(x.timestamp), x.url))
    return out


# ---------------------------------------------------------------------------
# 8. Detect user transactions (rolling time window: gap > TRANSACTION_GAP = new transaction)
# ---------------------------------------------------------------------------
# Ordering is strictly by request timeline. Each transaction's order is determined
# by the timestamp of its first request (start_timestamp).

TRANSACTION_GAP_SECONDS = 3.0


def _sort_entries_by_timestamp(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Return entries sorted by HAR timestamp (and url for stability). Downstream must respect this order."""
    return sorted(entries, key=lambda e: (_parse_har_time(e.timestamp), e.url or ""))


def group_by_time_gap(entries: list[RequestEntry]) -> list[list[RequestEntry]]:
    """
    Group requests by rolling time window: if gap > TRANSACTION_GAP, start new transaction
    only when the next request is not a background request (cart, recommendations, etc.).
    Background requests stay in the current transaction until a navigation event.
    """
    if not entries:
        return []
    sorted_entries = _sort_entries_by_timestamp(entries)
    groups: list[list[RequestEntry]] = []
    current: list[RequestEntry] = [sorted_entries[0]]
    prev_t = _parse_har_time(sorted_entries[0].timestamp)
    for e in sorted_entries[1:]:
        t = _parse_har_time(e.timestamp)
        gap = t - prev_t
        if gap > TRANSACTION_GAP_SECONDS and not is_background_request(e):
            groups.append(current)
            current = [e]
        else:
            current.append(e)
        prev_t = t
    if current:
        groups.append(current)
    return groups


def _transaction_start_timestamp(group: list[RequestEntry]) -> float:
    """Timestamp of the first request in the group (for ordering)."""
    if not group:
        return 0.0
    return min(_parse_har_time(e.timestamp) for e in group)


def sort_groups_by_start_timestamp(groups: list[list[RequestEntry]]) -> list[list[RequestEntry]]:
    """Order transactions by the timestamp of their first request (user flow chronology)."""
    if not groups:
        return []
    with_start = [(_transaction_start_timestamp(g), g) for g in groups]
    return [g for _, g in sorted(with_start, key=lambda x: x[0])]


# ---------------------------------------------------------------------------
# 8b. Group by navigation events (CDP Page.frameNavigated / Page.loadEventFired)
# ---------------------------------------------------------------------------

def group_by_navigation_timestamps(
    entries: list[RequestEntry],
    navigation_timestamps: list[str],
) -> list[list[RequestEntry]]:
    """
    Group requests by navigation boundaries. Each segment is [nav[i], nav[i+1]).
    Requests before first nav go in segment 0; after last nav go in last segment.
    Reflects real user navigation: homepage → search → product.
    """
    if not entries:
        return []
    sorted_entries = _sort_entries_by_timestamp(entries)
    nav_times = [_parse_har_time(ts) for ts in (navigation_timestamps or [])]
    nav_times.sort()
    segments: list[list[RequestEntry]] = []
    for e in sorted_entries:
        t = _parse_har_time(e.timestamp)
        seg_idx = 0
        for i, nt in enumerate(nav_times):
            if t >= nt:
                seg_idx = i + 1
            else:
                break
        while len(segments) <= seg_idx:
            segments.append([])
        segments[seg_idx].append(e)
    return [g for g in segments if g]


# ---------------------------------------------------------------------------
# 8c. Background requests (do not start a new transaction on time gap)
# ---------------------------------------------------------------------------

_BACKGROUND_PATH_SUBSTRINGS = frozenset([
    "cart", "recommendations", "notifications", "widgets",
])


def is_background_request(entry: RequestEntry) -> bool:
    """True if request is background (cart, recommendations, etc.); keep in current transaction."""
    path_lower = (entry.path or "").lower()
    return any(sub in path_lower for sub in _BACKGROUND_PATH_SUBSTRINGS)


# ---------------------------------------------------------------------------
# Extract path parameters (numeric, long alphanumeric, UUID)
# ---------------------------------------------------------------------------

_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
_NUMERIC_ID_RE = re.compile(r"^[0-9]+$")
_LONG_ALPHANUMERIC_RE = re.compile(r"^[a-zA-Z0-9_-]{8,}$")


def _singularize(segment: str) -> str:
    """Simple singular form for param name: products → product."""
    s = segment.lower()
    if s.endswith("ies") and len(s) > 3:
        return s[:-3] + "y"
    if s.endswith("es") and len(s) > 2:
        return s[:-2]
    if s.endswith("s") and len(s) > 1:
        return s[:-1]
    return s


def _extract_path_params(entry: RequestEntry) -> dict[str, str]:
    """Detect path params: numeric ids, long alphanumeric (8+), UUID. Name by previous segment (e.g. product_id)."""
    params: dict[str, str] = {}
    path = entry.path or "/"
    segments = [s for s in path.split("/") if s]
    for i, seg in enumerate(segments):
        if _NUMERIC_ID_RE.match(seg):
            prev = segments[i - 1] if i > 0 else "id"
            name = _singularize(prev) + "_id"
            params[name] = seg
        elif _LONG_ALPHANUMERIC_RE.match(seg):
            prev = segments[i - 1] if i > 0 else "id"
            name = _singularize(prev) + "_id"
            params[name] = seg
        elif _UUID_RE.match(seg):
            prev = segments[i - 1] if i > 0 else "id"
            name = _singularize(prev) + "_id"
            params[name] = seg
    return params


def extract_parameters(entries: list[RequestEntry]) -> list[RequestEntry]:
    """Attach path params to each entry (query/body already on request)."""
    for e in entries:
        e.path_params = _extract_path_params(e)
    return entries


# ---------------------------------------------------------------------------
# Step 1 — Load HAR file
# ---------------------------------------------------------------------------

def _parse_headers(headers_list: Any) -> dict[str, str]:
    if not isinstance(headers_list, list):
        return {}
    out: dict[str, str] = {}
    for h in headers_list:
        try:
            if not isinstance(h, dict):
                continue
            name = h.get("name")
            value = h.get("value")
            if name is None:
                continue
            name = str(name).strip()
            if not name:
                continue
            out[name] = str(value).strip() if value is not None else ""
        except Exception:
            continue
    return out


def _parse_post_data(post_data: Any) -> dict[str, Any] | None:
    if not isinstance(post_data, dict):
        return None
    text = post_data.get("text")
    if text is None or text == "":
        return None
    if isinstance(text, dict):
        return text
    try:
        if isinstance(text, str):
            parsed = json.loads(text)
            return parsed if isinstance(parsed, dict) else {"value": parsed}
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return {"raw": str(text)[:10000]}


def _response_content_type(entry: dict) -> str:
    response = entry.get("response") or {}
    headers_list = response.get("headers") or []
    for h in headers_list:
        if isinstance(h, dict) and str(h.get("name", "")).lower() == "content-type":
            return str(h.get("value") or "")
    return ""


def load_har_entries(content: str) -> list[RequestEntry]:
    """Parse HAR JSON and return list of RequestEntry (Step 1)."""
    entries: list[RequestEntry] = []
    try:
        text = (content or "").lstrip("\ufeff").strip()
        if not text:
            return entries
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        return entries

    har_entries: list[dict] = []
    if isinstance(data, dict):
        log = data.get("log")
        if isinstance(log, dict):
            har_entries = log.get("entries") or []
        elif isinstance(log, list):
            har_entries = log
        if not har_entries and "entries" in data:
            har_entries = data.get("entries") or []
    elif isinstance(data, list):
        har_entries = data

    if not isinstance(har_entries, list):
        return entries

    for entry in har_entries:
        try:
            if not isinstance(entry, dict):
                continue
            request = entry.get("request")
            if not isinstance(request, dict):
                continue
            url = request.get("url") or ""
            if not url:
                continue
            url = str(url)
            if url.startswith(("data:", "blob:", "javascript:", "about:", "chrome-extension:")):
                continue
            parsed = urlparse(url)
            scheme = (parsed.scheme or "https").lower()
            host = (parsed.netloc or "").lower()
            path = (parsed.path or "/").strip() or "/"
            query_params = parse_qs(parsed.query, keep_blank_values=True)

            method = (request.get("method") or "GET").upper()
            raw_headers = _parse_headers(request.get("headers"))
            headers = _strip_browser_headers(raw_headers)
            payload = _parse_post_data(request.get("postData"))
            request_body_size = 0
            if payload:
                try:
                    request_body_size = len(json.dumps(payload))
                except Exception:
                    request_body_size = 0

            response = entry.get("response") or {}
            status = int(response.get("status") or 0)
            content_type = _response_content_type(entry)
            content = response.get("content") or {}
            size = int(content.get("size") or 0)
            response_text = content.get("text")
            if response_text is not None and not isinstance(response_text, str):
                response_text = str(response_text)
            response_text = response_text or ""
            resp_headers = _parse_headers(response.get("headers"))
            started = str(entry.get("startedDateTime") or "")

            entries.append(
                RequestEntry(
                    url=url,
                    scheme=scheme,
                    host=host,
                    path=path,
                    query_params=query_params,
                    method=method,
                    headers=headers,
                    payload=payload,
                    content_type=content_type,
                    status=status,
                    timestamp=started,
                    response_size=size,
                    request_body_size=request_body_size,
                    response_text=response_text,
                    response_headers=resp_headers,
                )
            )
        except Exception:
            continue
    return entries


# ---------------------------------------------------------------------------
# Transaction naming (universal heuristics from path)
# ---------------------------------------------------------------------------

def _transaction_name_from_path(path: str, index: int) -> str:
    """
    Name from URL heuristics (applied after ordering).
    search → transaction_search; product or dp → transaction_product; else transaction_<index>.
    """
    path_lower = (path or "/").lower()
    if "search" in path_lower:
        return "transaction_search"
    if "product" in path_lower or "/dp/" in path_lower:
        return "transaction_product"
    return f"transaction_{index + 1}"


# ---------------------------------------------------------------------------
# Validation: ensure no telemetry/OPTIONS/HEAD/static/polling remain in final set
# ---------------------------------------------------------------------------

def _is_still_noise(entry: RequestEntry) -> bool:
    """True if entry should be excluded from final script (validation).
    Uses the behavior-based score: anything below threshold is noise.
    Login requests are never noise.
    """
    if is_login_request(entry):
        return False
    if (entry.method or "GET").upper() in ("OPTIONS", "HEAD"):
        return True
    return business_api_score(entry) < _BUSINESS_API_THRESHOLD


def validate_and_filter_groups(groups: list[list[RequestEntry]]) -> tuple[list[list[RequestEntry]], int]:
    """Remove any remaining noise from groups. Returns (filtered_groups, excluded_count)."""
    excluded = 0
    out: list[list[RequestEntry]] = []
    for group in groups:
        kept = [e for e in group if not _is_still_noise(e)]
        excluded += len(group) - len(kept)
        if kept:
            out.append(kept)
    return out, excluded


# ---------------------------------------------------------------------------
# Convert RequestEntry to TransactionBase (for script generator)
# ---------------------------------------------------------------------------

def request_entry_to_transaction_base(entry: RequestEntry, transaction_name: str, execution_order: int = 0) -> TransactionBase:
    """Convert a single RequestEntry to TransactionBase, preserving response data for correlation."""
    resp: dict | None = None
    if entry.status or entry.response_text or entry.content_type:
        resp = {
            "status": entry.status,
            "headers": entry.response_headers or {},
            "content_type": entry.content_type or "",
            "body": entry.response_text or "",
            "size": entry.response_size,
        }
    return TransactionBase(
        transaction_name=transaction_name,
        request_url=entry.url,
        http_method=(entry.method or "GET")[:20],
        headers=entry.headers or {},
        payload=entry.payload,
        execution_order=execution_order,
        response=resp,
    )


def build_user_transaction_groups_from_recording(
    recording: dict[str, Any],
    flat_entries: list[RequestEntry],
) -> tuple[list[list[TransactionBase]], list[str]]:
    """
    When user provided transaction names in the recorder, assign each flat_entry to a segment by
    time window: requests before first transaction → Initial_Load, during each transaction → that
    transaction name, after last transaction → After_Last. This produces a script that clearly
    separates APIs before/during/after each transaction (e.g. product click requests appear in After_Last).
    """
    user_txs = [t for t in recording.get("transactions", []) if (t.get("name") or "").strip()]
    if not user_txs:
        return [], []

    # Time window per user transaction: prefer explicit start_timestamp/end_timestamp
    # (set by start_transaction_cdp / stop_transaction_cdp) over request-derived timestamps.
    tx_windows: list[tuple[float, float]] = []
    for t in user_txs:
        start_ts_str = (t.get("start_timestamp") or "").strip()
        end_ts_str = (t.get("end_timestamp") or "").strip()
        if start_ts_str:
            start_f = _parse_har_time(start_ts_str)
            end_f = _parse_har_time(end_ts_str) if end_ts_str else start_f + 300.0
            tx_windows.append((start_f, end_f))
        else:
            timestamps = [_parse_har_time((req.get("timestamp") or "").strip())
                          for req in t.get("requests", []) if (req.get("timestamp") or "").strip()]
            if timestamps:
                tx_windows.append((min(timestamps), max(timestamps)))
            else:
                tx_windows.append((0.0, 0.0))

    # flat_entries are already sorted by timestamp from pipeline; ensure order
    sorted_entries = sorted(flat_entries, key=lambda e: (_parse_har_time(e.timestamp), e.url or ""))

    # Segment index: -1 = before first tx, 0..n-1 = during tx_i, n = after last tx
    segment_names = ["Initial_Load"] + [(t.get("name") or "").strip() for t in user_txs] + ["After_Last"]

    def segment_for_entry(e: RequestEntry) -> int:
        t = _parse_har_time(e.timestamp)
        if not tx_windows:
            return 0  # Initial_Load
        if t < tx_windows[0][0]:
            return -1  # before first → Initial_Load (index 0 in segment_names)
        for i, (start, end) in enumerate(tx_windows):
            if start <= t <= end:
                return i  # during tx_i
            if i + 1 < len(tx_windows) and end < t < tx_windows[i + 1][0]:
                return len(tx_windows)  # between tx_i and tx_i+1 → After_Last
        return len(tx_windows)  # after last tx → After_Last

    for i, t in enumerate(user_txs):
        w = tx_windows[i] if i < len(tx_windows) else (0.0, 0.0)
        print(f"[Pipeline] Transaction '{(t.get('name') or '')}': window=({w[0]:.0f}, {w[1]:.0f}), requests_in_recording={len(t.get('requests', []))}")
    print(f"[Pipeline] flat_entries to assign: {len(sorted_entries)}")

    # Build groups: [Initial_Load, Tx0, Tx1, ..., After_Last]; segment index -1 maps to group 0, 0..n-1 to 1..n, n to n+1
    num_groups = len(user_txs) + 2
    groups: list[list[TransactionBase]] = [[] for _ in range(num_groups)]
    for e in sorted_entries:
        seg = segment_for_entry(e)
        if seg == -1:
            gidx = 0
            name = "Initial_Load"
        elif seg < len(user_txs):
            gidx = seg + 1
            name = (user_txs[seg].get("name") or "").strip()
        else:
            gidx = num_groups - 1
            name = "After_Last"
        # Use a per-group index for now; the caller (recorder_api.py) reassigns
        # globally sequential execution_order after flattening all groups.
        groups[gidx].append(request_entry_to_transaction_base(e, name, len(groups[gidx])))

    for i, name in enumerate(segment_names):
        print(f"[Pipeline] Segment '{name}': {len(groups[i])} entries assigned")

    names = segment_names
    # Keep all groups (including empty) so script has consistent sections; script generator handles empty
    return groups, names


def entries_to_transaction_groups(groups: list[list[RequestEntry]]) -> tuple[list[list[TransactionBase]], list[str]]:
    """Convert pipeline groups to (list of request groups, list of transaction names). Used for HAR upload with auto-naming."""
    tx_groups: list[list[TransactionBase]] = []
    names: list[str] = []
    global_order = 0  # cross-group sequential counter so ORDER BY execution_order is correct
    for i, group in enumerate(groups):
        if not group:
            continue
        name = _transaction_name_from_path(group[0].path, i)
        func_name = re.sub(r"[^a-zA-Z0-9_]", "_", name).strip("_") or f"transaction_{i + 1}"
        names.append(func_name)
        txs = []
        for e in group:
            txs.append(request_entry_to_transaction_base(e, func_name, global_order))
            global_order += 1
        tx_groups.append(txs)
    return tx_groups, names


# ---------------------------------------------------------------------------
# Pipeline result and runner
# ---------------------------------------------------------------------------

@dataclass
class HarPipelineResult:
    """Result of universal HAR pipeline: transaction groups + intelligence report."""
    transaction_groups: list[list[TransactionBase]]
    transaction_names: list[str]
    base_url: str
    report: dict[str, int]
    flat_entries: list[RequestEntry] = field(default_factory=list)  # filtered entries (score >= threshold) for script gen
    all_entries: list[RequestEntry] = field(default_factory=list)   # full pre-filter dataset for correlation engine
    group_summary: dict = field(default_factory=dict)               # category → {count, default_selected}


def run_smart_har_pipeline(
    content: str,
    navigation_timestamps: list[str] | None = None,
    group_transactions: bool = True,
    primary_domain: str = "",
) -> HarPipelineResult:
    """
    Run universal HAR pipeline. Returns transaction groups and intelligence report.

    Classification uses a behavior-based scoring system instead of URL keywords.
    Each request is scored on domain affinity, response type, method, parameters,
    transaction context, temporal proximity, response size, and negative signals
    (telemetry, CDN, binary, polling).
    Requests scoring >= 40 are kept as business APIs.  Login requests are immune.
    The full pre-filter dataset is preserved in all_entries for the correlation engine.

    primary_domain: root domain from the user-provided URL (e.g. "automationexercise.com").
        When provided, same-domain requests receive a +20 score bonus.
    """
    entries = load_har_entries(content)
    total_har = len(entries)

    # Stage 1: Hard pre-filters (unambiguously not business APIs)
    entries = remove_browser_protocol_requests(entries)

    # Snapshot BEFORE third-party removal — classification needs the full set
    full_entries_for_classification = list(entries)

    entries, third_party_removed = remove_third_party_domains(entries, primary_domain=primary_domain)

    _log_detected_logins(entries)

    # Extract path parameters before scoring so the +15 param signal is available
    entries = extract_parameters(entries)

    # Build transaction windows from navigation timestamps (for the +20 in-transaction signal)
    tx_windows: list[tuple[float, float]] | None = None
    nav_event_times: list[float] | None = None
    if navigation_timestamps:
        nav_times = sorted(_parse_har_time(ts) for ts in navigation_timestamps if ts)
        if nav_times:
            nav_event_times = nav_times
            tx_windows = []
            for i in range(len(nav_times)):
                start = nav_times[i]
                end = nav_times[i + 1] if i + 1 < len(nav_times) else start + 300.0
                tx_windows.append((start, end))

    # Stage 2: Behavior-based scoring (replaces static, CDN, telemetry,
    #          security, business-keyword, and polling filters with a unified score)
    entries, score_breakdown = score_and_filter_entries(
        entries,
        primary_domain=primary_domain,
        transaction_windows=tx_windows,
        nav_event_times=nav_event_times,
    )
    business_apis_detected = len(entries)

    # Stage 3: Post-scoring deduplication
    typing_before = len(entries)
    entries = collapse_typing_suggestions(entries)
    typing_collapsed = typing_before - len(entries)

    entries = _sort_entries_by_timestamp(entries)

    static_removed = score_breakdown.get("static_resources_removed", 0)
    cdn_infra_removed = score_breakdown.get("cdn_infrastructure_removed", 0)
    telemetry_removed = score_breakdown.get("telemetry_requests_removed", 0)
    security_removed = score_breakdown.get("security_infrastructure_removed", 0)
    polling_removed = score_breakdown.get("polling_requests_removed", 0)
    low_score_removed = score_breakdown.get("low_score_removed", 0)

    print(
        f"[Pipeline] HAR={total_har} → 3rd-party={third_party_removed} "
        f"static={static_removed} cdn={cdn_infra_removed} telemetry={telemetry_removed} "
        f"security={security_removed} polling={polling_removed} low-score={low_score_removed} "
        f"typing={typing_collapsed} → business={business_apis_detected}"
    )

    # Classify every entry (including third-party) for the grouped review UI.
    # Also extract parameters on the full set so classify_all_entries can
    # compute business_api_score with the +15 parameter signal.
    full_entries_for_classification = extract_parameters(full_entries_for_classification)
    classify_all_entries(
        full_entries_for_classification,
        primary_domain=primary_domain,
        transaction_windows=tx_windows,
        nav_event_times=nav_event_times,
    )
    group_summary = build_group_summary(full_entries_for_classification)

    if not group_transactions:
        report = {
            "total_har_requests": total_har,
            "third_party_removed": third_party_removed,
            "static_resources_removed": static_removed,
            "cdn_infrastructure_removed": cdn_infra_removed,
            "telemetry_requests_removed": telemetry_removed,
            "security_infrastructure_removed": security_removed,
            "polling_requests_removed": polling_removed,
            "typing_suggestion_requests_collapsed": typing_collapsed,
            "low_score_removed": low_score_removed,
            "business_apis_detected": business_apis_detected,
            "transactions_detected": 0,
            "validation_excluded": 0,
            "transaction_summary": [],
        }
        base_url = ""
        if entries:
            e0 = entries[0]
            base_url = f"{e0.scheme or 'https'}://{e0.host or ''}"
        return HarPipelineResult(
            transaction_groups=[],
            transaction_names=[],
            base_url=base_url,
            report=report,
            flat_entries=entries,
            all_entries=full_entries_for_classification,
            group_summary=group_summary,
        )

    if navigation_timestamps:
        groups = group_by_navigation_timestamps(entries, navigation_timestamps)
    else:
        groups = group_by_time_gap(entries)
    groups, validation_excluded = validate_and_filter_groups(groups)
    groups = sort_groups_by_start_timestamp(groups)
    transactions_detected = len(groups)

    tx_groups, tx_names = entries_to_transaction_groups(groups)

    base_url = ""
    if entries:
        e0 = entries[0]
        base_url = f"{e0.scheme or 'https'}://{e0.host or ''}"

    t0 = min(_parse_har_time(e.timestamp) for e in entries) if entries else 0.0
    transaction_summary = []
    for g in groups:
        start_s = round(_transaction_start_timestamp(g) - t0, 2)
        end_s = round(max(_parse_har_time(e.timestamp) for e in g) - t0, 2) if g else start_s
        transaction_summary.append({"name": "", "start_s": start_s, "end_s": end_s, "requests": len(g)})
    for i, name in enumerate(tx_names):
        if i < len(transaction_summary):
            transaction_summary[i]["name"] = name

    report = {
        "total_har_requests": total_har,
        "third_party_removed": third_party_removed,
        "static_resources_removed": static_removed,
        "cdn_infrastructure_removed": cdn_infra_removed,
        "telemetry_requests_removed": telemetry_removed,
        "security_infrastructure_removed": security_removed,
        "polling_requests_removed": polling_removed,
        "typing_suggestion_requests_collapsed": typing_collapsed,
        "low_score_removed": low_score_removed,
        "business_apis_detected": business_apis_detected,
        "transactions_detected": transactions_detected,
        "validation_excluded": validation_excluded,
        "transaction_summary": transaction_summary,
    }
    return HarPipelineResult(
        transaction_groups=tx_groups,
        transaction_names=tx_names,
        base_url=base_url,
        report=report,
        flat_entries=[],
        all_entries=full_entries_for_classification,
        group_summary=group_summary,
    )

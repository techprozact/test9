"""Orchestrate script type detection, parsing, storage and Python script generation."""
from datetime import datetime, timezone
from typing import Any

from backend.models.script_model import ScriptResponse, TransactionBase, TransactionResponse
from backend.utils.script_type_detector import detect_script_type
from backend.parsers import parse_har
from backend.utils.python_script_generator import generate_python_script
from backend.har.smart_pipeline import run_smart_har_pipeline


def parse_upload(
    content: bytes,
    filename: str,
    db_store: Any,
) -> tuple[ScriptResponse, list[TransactionResponse], str, dict]:
    """
    Detect type, parse, store in DB, generate Python script.
    Returns (script_response, list of transaction_responses, generated_python_script, summary_dict).
    For HAR: uses SMART pipeline and summary has total_har_requests, after_filtering, business_apis_detected.
    """
    script_type = detect_script_type(filename, content)
    if script_type == "unknown":
        raise ValueError(f"Unsupported or unknown script type for file: {filename}. Only .har files are accepted.")

    summary: dict = {}
    transaction_groups: list[list[TransactionBase]] | None = None
    transaction_names: list[str] | None = None
    transactions_flat: list[TransactionBase] = []
    base_url: str | None = None

    pipeline_result = run_smart_har_pipeline(content.decode("utf-8", errors="ignore"))
    transaction_groups = pipeline_result.transaction_groups
    transaction_names = pipeline_result.transaction_names
    summary = pipeline_result.report
    base_url = pipeline_result.base_url or None
    transactions_flat = [t for group in transaction_groups for t in group]

    script_name = filename.split("/")[-1].split("\\")[-1]

    script_record = db_store.insert_script(
        script_name=script_name,
        script_type=script_type,
    )
    script_id = script_record["id"]

    transaction_records: list[TransactionResponse] = []
    for order, t in enumerate(transactions_flat):
        rec = db_store.insert_transaction(
            script_id=script_id,
            transaction_name=t.transaction_name,
            request_url=t.request_url,
            http_method=t.http_method,
            headers=t.headers,
            payload=t.payload,
            execution_order=order,
            response=t.response if hasattr(t, "response") else None,
        )
        transaction_records.append(
            TransactionResponse(
                id=rec["id"],
                script_id=script_id,
                transaction_name=rec["transaction_name"],
                request_url=rec["request_url"],
                http_method=rec["http_method"],
                headers=rec.get("headers") or {},
                payload=rec.get("payload"),
                execution_order=rec["execution_order"],
                response=rec.get("response"),
            )
        )

    python_code = generate_python_script(
        transactions_flat,
        business_only=False,
        base_url=base_url,
        summary=summary if summary else None,
        transaction_groups=transaction_groups,
        transaction_names=transaction_names,
    )
    db_store.save_python_script(script_id, python_code)

    upload_time = script_record.get("upload_time")
    if isinstance(upload_time, datetime):
        pass
    elif isinstance(upload_time, str):
        upload_time = datetime.fromisoformat(upload_time.replace("Z", "+00:00"))
    else:
        upload_time = datetime.now(timezone.utc)

    script_response = ScriptResponse(
        id=script_id,
        script_name=script_record["script_name"],
        script_type=script_record["script_type"],
        upload_time=upload_time,
    )
    return script_response, transaction_records, python_code, summary

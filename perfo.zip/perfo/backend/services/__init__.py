from backend.services.script_parser_service import parse_upload

__all__ = ["parse_upload"]

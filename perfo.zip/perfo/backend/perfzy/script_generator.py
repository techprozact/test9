"""Perfzy Script Generator — produce clean Python performance scripts from Perfzy workflows."""
from __future__ import annotations

import json
import re
from typing import Any


def _sanitize_func_name(name: str) -> str:
    """Convert a human-readable name into a valid Python function name."""
    clean = re.sub(r"[^a-zA-Z0-9_]+", "_", name.strip())
    clean = clean.strip("_")
    if not clean or clean[0].isdigit():
        clean = "step_" + clean
    return clean


def _escape(s: str) -> str:
    """Escape a string for safe Python string literal embedding."""
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")


_VAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")


def _apply_param_substitutions(path: str, params: list[dict]) -> str:
    """Replace literal parameter values in a URL path/query with {{custom_name}} placeholders.

    Only replaces exact path segments (for source='path') or query values (for source='query')
    to avoid partial string collisions.
    """
    if not path or not params:
        return path

    q_idx = path.find("?")
    path_part = path[:q_idx] if q_idx >= 0 else path
    query_part = path[q_idx:] if q_idx >= 0 else ""

    for p in params:
        custom_name = re.sub(r"[^a-zA-Z0-9_]", "_", (p.get("custom_name") or p.get("key") or "").strip())
        value = str(p.get("value") or "")
        source = p.get("source", "")
        if not value or not custom_name:
            continue

        if source == "path":
            # Replace exact path segment only (e.g. /delay/1 → /delay/{{user_1}})
            segments = path_part.split("/")
            segments = [f"{{{{{custom_name}}}}}" if seg == value else seg for seg in segments]
            path_part = "/".join(segments)

        elif source == "query":
            # Replace value of a specific query key (e.g. ?limit=10 → ?limit={{user_limit}})
            key = str(p.get("key", ""))
            if key:
                query_part = re.sub(
                    r"([?&]" + re.escape(key) + r"=)" + re.escape(value) + r"(?=&|$)",
                    r"\g<1>" + "{{" + custom_name + "}}",
                    query_part,
                )

    return path_part + query_part


def _has_vars(text: str) -> bool:
    return bool(_VAR_PATTERN.search(text)) if text else False


def _var_fstring(text: str) -> str:
    """Convert {{var}} to Python f-string {var}."""
    return _VAR_PATTERN.sub(r"{\1}", text)


def _repr_value(value: Any) -> str:
    """Return a Python repr suitable for script emission."""
    if isinstance(value, str):
        if _has_vars(value):
            return 'f"' + _escape(_var_fstring(value)) + '"'
        return '"' + _escape(value) + '"'
    if isinstance(value, dict):
        return _dict_repr(value)
    if isinstance(value, bool):
        return "True" if value else "False"
    if value is None:
        return "None"
    return repr(value)


def _dict_repr(d: dict, indent: int = 4) -> str:
    """Pretty-print a dict as Python source with {{var}} -> f-string support."""
    if not d:
        return "{}"
    pad = " " * indent
    lines = ["{"]
    for k, v in d.items():
        key_repr = _repr_value(k)
        val_repr = _repr_value(v)
        lines.append(f"{pad}{key_repr}: {val_repr},")
    lines.append("}")
    return "\n".join(lines)


def _payload_block(payload: Any, payload_type: str, indent: str = "    ") -> tuple[str, str]:
    """Return (payload_code, kwarg) for a request payload.

    payload_code is a multi-line string assignable to ``payload = ...``.
    kwarg is one of: 'json', 'data', 'files', or '' (empty → no payload).

    payload_type values:
        'json'       → session.post(..., json=payload)
        'urlencoded' → session.post(..., data=payload)   # requests auto-encodes dict
        'form'       → session.post(..., files=payload)  # multipart/form-data
        anything else that has data → 'data'
    """
    if payload is None or payload_type == "none":
        return "", ""

    if isinstance(payload, str):
        payload = payload.strip()
        if not payload:
            return "", ""
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, ValueError):
            if _has_vars(payload):
                return f'f"{_escape(_var_fstring(payload))}"', "data"
            return f'"{_escape(payload)}"', "data"

    if not payload:  # empty dict/list after parsing
        return "", ""

    if payload_type == "json":
        return _dict_repr(payload), "json"

    if payload_type == "urlencoded":
        # requests sends a dict as application/x-www-form-urlencoded when kwarg is 'data'
        return _dict_repr(payload), "data"

    if payload_type == "form":
        # multipart/form-data: requests expects files={'field': (None, 'value')} for text fields
        # Build a files dict so Content-Type is correctly multipart
        if isinstance(payload, dict):
            pad = "    "
            lines = ["{"]
            for k, v in payload.items():
                key_repr = _repr_value(k)
                val_repr = _repr_value(v)
                lines.append(f"{pad}{key_repr}: (None, {val_repr}),")
            lines.append("}")
            return "\n".join(lines), "files"
        return _dict_repr(payload), "data"

    # fallback
    return _dict_repr(payload), "data"


def generate_perfzy_script(
    script_name: str,
    base_url: str,
    requests_def: list[dict],
    global_variables: dict[str, str] | None = None,
    parameters: list[dict] | None = None,
    think_time: float = 0.0,
) -> str:
    """Generate a complete Python script from Perfzy workflow definition.

    Parameters
    ----------
    script_name : str
        Human-readable name used in the docstring.
    base_url : str
        Default base URL for all requests (can contain {{var}}).
    requests_def : list[dict]
        Each dict: {name, method, path, headers, payload, payload_type, auth_type, auth_value, extractions}
    global_variables : dict
        Global key-value pairs to declare at the top.
    parameters : list[dict]
        Finalized parameters with keys: key, custom_name, value, source.
        These are declared at the top of the script as configurable inputs.
    think_time : float
        Seconds to sleep between consecutive requests. 0 = no delay.
    """
    global_variables = global_variables or {}
    parameters = parameters or []
    lines: list[str] = []

    lines.append('#!/usr/bin/env python3')
    lines.append(f'"""Generated by perfSense Perfzy — {_escape(script_name)}. Requires: pip install requests"""')
    lines.append("import requests")
    lines.append("import re")
    lines.append("import json")
    lines.append("import time")
    lines.append("")

    if _has_vars(base_url):
        lines.append(f'BASE_URL = f"{_escape(_var_fstring(base_url))}"')
    else:
        lines.append(f'BASE_URL = "{_escape(base_url)}"')
    lines.append("session = requests.Session()")
    lines.append("")

    # Emit script-level parameters (configurable inputs for load execution)
    lines.append("# === Parameters ===")
    lines.append("# These values are configurable inputs for load execution.")
    # think_time is always emitted so it can be overridden for standalone runs
    think_time_val = think_time if isinstance(think_time, (int, float)) and think_time >= 0 else 0.0
    lines.append(f"think_time = {think_time_val}  # seconds to sleep between consecutive requests")
    if parameters:
        for p in parameters:
            custom_name = re.sub(r"[^a-zA-Z0-9_]", "_", (p.get("custom_name") or p.get("key") or "param").strip())
            value = _escape(str(p.get("value") or ""))
            source = p.get("source", "manual")
            lines.append(f'{custom_name} = "{value}"  # source: {source}')
    lines.append("")

    if global_variables:
        for k, v in global_variables.items():
            lines.append(f'{k} = "{_escape(str(v))}"')
        lines.append("")

    func_names: list[str] = []
    extraction_vars: set[str] = set()

    for req in requests_def:
        name = req.get("name", "Unnamed")
        func_name = _sanitize_func_name(name)

        # handle duplicate names
        original = func_name
        counter = 1
        while func_name in func_names:
            counter += 1
            func_name = f"{original}_{counter}"
        func_names.append(func_name)

        method = (req.get("method") or "GET").upper()
        path = req.get("path", "")
        headers = req.get("headers") or {}
        payload = req.get("payload")
        payload_type = req.get("payload_type", "none")
        auth_type = req.get("auth_type", "none")
        auth_value = req.get("auth_value") or {}
        extractions = req.get("extractions") or []

        # Apply per-request parameter substitutions to the path
        req_params = req.get("request_parameters") or []
        path = _apply_param_substitutions(path, req_params)

        # build function
        lines.append(f"def {func_name}():")
        # nonlocal for extractions from other functions
        needed_nonlocals = set()
        for ext in extractions:
            ext_name = ext.get("name", "")
            if ext_name:
                needed_nonlocals.add(ext_name)

        # check if path uses variables (either original {{var}} or newly substituted params)
        if _has_vars(path):
            lines.append(f'    url = BASE_URL + f"{_escape(_var_fstring(path))}"')
        else:
            lines.append(f'    url = BASE_URL + "{_escape(path)}"')

        # auth injection into headers (only if not already present — frontend may have pre-injected)
        auth_header_present = any(k.lower() == "authorization" for k in headers)
        if auth_type == "bearer" and not auth_header_present:
            token = auth_value.get("token", "")
            if token and _has_vars(token):
                headers["Authorization"] = f"Bearer {_var_fstring(token)}"
            elif token:
                headers["Authorization"] = f"Bearer {token}"
        elif auth_type == "basic" and not auth_header_present:
            import base64
            username = auth_value.get("username", "")
            password = auth_value.get("password", "")
            if _has_vars(username) or _has_vars(password):
                lines.append(f'    import base64')
                lines.append(f'    _cred = base64.b64encode(f"{_escape(_var_fstring(username))}:{_escape(_var_fstring(password))}".encode()).decode()')
                headers["Authorization"] = "Basic {{_cred}}"
            else:
                encoded = base64.b64encode(f"{username}:{password}".encode()).decode()
                headers["Authorization"] = f"Basic {encoded}"
        elif auth_type == "apikey":
            key = auth_value.get("key", "")
            value = auth_value.get("value", "")
            location = auth_value.get("location", "header")
            if location == "header" and key and key not in headers:
                headers[key] = value

        # headers
        if headers:
            h_repr = _dict_repr(headers, indent=8)
            lines.append(f"    headers = {h_repr}")
        else:
            lines.append("    headers = {}")

        # payload
        p_code, kwarg = _payload_block(payload, payload_type, "    ")
        if p_code:
            lines.append(f"    payload = {p_code}")

        # request call
        # For multipart form-data (kwarg='files'), suppress Content-Type header so
        # requests can set the multipart boundary automatically.
        if kwarg == "files" and any(k.lower() == "content-type" for k in headers):
            lines.append("    # Content-Type removed: requests sets multipart boundary automatically")
            lines.append("    _h = {k: v for k, v in headers.items() if k.lower() != 'content-type'}")
            call_parts = ["session." + method.lower() + "(url, headers=_h", "files=payload)"]
        else:
            call_parts = [f"session.{method.lower()}(url, headers=headers"]
            if p_code and kwarg:
                call_parts.append(f"{kwarg}=payload")
            call_parts.append(")")
        lines.append(f'    response = {", ".join(call_parts)}')

        # extractions
        for ext in extractions:
            ext_name = ext.get("name", "")
            ext_source = ext.get("source", "")
            ext_expr = ext.get("expression", "")
            if not ext_name or not ext_expr:
                continue
            extraction_vars.add(ext_name)
            if ext_source == "json_path":
                keys = ext_expr.lstrip("$.").split(".")
                chain = "".join(f'["{_escape(k)}"]' for k in keys)
                lines.append(f"    global {ext_name}")
                lines.append(f"    {ext_name} = response.json(){chain}")
            elif ext_source == "header":
                lines.append(f"    global {ext_name}")
                lines.append(f'    {ext_name} = response.headers.get("{_escape(ext_expr)}", "")')
            elif ext_source == "regex":
                lines.append(f"    global {ext_name}")
                lines.append(f'    _m = re.search(r\'{ext_expr}\', response.text)')
                lines.append(f"    {ext_name} = _m.group(1) if _m else \"\"")
            elif ext_source == "boundary":
                parts = ext_expr.split(";;")
                lb = rb = ""
                for p in parts:
                    p = p.strip()
                    if p.startswith("LB="):
                        lb = p[3:]
                    elif p.startswith("RB="):
                        rb = p[3:]
                lines.append(f"    global {ext_name}")
                lines.append(f'    _lb = "{_escape(lb)}"')
                lines.append(f'    _rb = "{_escape(rb)}"')
                lines.append(f"    _start = response.text.find(_lb)")
                lines.append(f"    if _start >= 0:")
                lines.append(f"        _start += len(_lb)")
                lines.append(f"        _end = response.text.find(_rb, _start)")
                lines.append(f"        {ext_name} = response.text[_start:_end] if _end >= 0 else \"\"")
                lines.append(f"    else:")
                lines.append(f'        {ext_name} = ""')

        lines.append("    return response")
        lines.append("")

    # main function
    lines.append("def main():")
    if not func_names:
        lines.append("    pass")
    else:
        for i, fn in enumerate(func_names):
            lines.append(f"    {fn}()")
            # Sleep between consecutive requests (not after the last one)
            if i < len(func_names) - 1:
                lines.append("    if think_time > 0:")
                lines.append("        time.sleep(think_time)")
    lines.append("")
    lines.append("")
    lines.append('if __name__ == "__main__":')
    lines.append("    main()")
    lines.append("")

    return "\n".join(lines)

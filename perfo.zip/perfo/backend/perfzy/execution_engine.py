"""Perfzy Execution Engine — run requests with variable substitution and extraction.

Handles {{variable}} replacement, auth injection, response extraction (JSON path,
header, regex, boundary), and auto-suggestion of extractable dynamic values.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlencode

import requests as http_requests


# ---------------------------------------------------------------------------
# Variable substitution
# ---------------------------------------------------------------------------

_VAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")


def substitute(text: str, variables: dict[str, str]) -> str:
    """Replace {{variable_name}} tokens with values from *variables*."""
    if not text:
        return text
    def _replacer(m: re.Match) -> str:
        name = m.group(1)
        return variables.get(name, m.group(0))
    return _VAR_PATTERN.sub(_replacer, text)


def substitute_dict(obj: Any, variables: dict[str, str]) -> Any:
    """Recursively substitute {{var}} in dicts, lists, and strings."""
    if isinstance(obj, str):
        return substitute(obj, variables)
    if isinstance(obj, dict):
        return {substitute(k, variables): substitute_dict(v, variables) for k, v in obj.items()}
    if isinstance(obj, list):
        return [substitute_dict(item, variables) for item in obj]
    return obj


# ---------------------------------------------------------------------------
# Auth injection
# ---------------------------------------------------------------------------

def apply_auth(headers: dict[str, str], auth_type: str, auth_value: dict) -> dict[str, str]:
    """Inject auth headers based on type."""
    if not auth_type or auth_type == "none":
        return headers
    if auth_type == "bearer":
        token = auth_value.get("token", "")
        if token:
            headers["Authorization"] = f"Bearer {token}"
    elif auth_type == "basic":
        import base64
        username = auth_value.get("username", "")
        password = auth_value.get("password", "")
        encoded = base64.b64encode(f"{username}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {encoded}"
    elif auth_type == "apikey":
        key = auth_value.get("key", "")
        value = auth_value.get("value", "")
        location = auth_value.get("location", "header")
        if location == "header" and key:
            headers[key] = value
    return headers


# ---------------------------------------------------------------------------
# Extraction rules
# ---------------------------------------------------------------------------

@dataclass
class ExtractionDef:
    name: str
    source: str          # json_path | header | regex | boundary
    expression: str


def extract_values(
    body: str,
    headers: dict[str, str],
    status_code: int,
    rules: list[ExtractionDef],
) -> dict[str, str]:
    """Run extraction rules against a response. Returns name -> extracted_value."""
    results: dict[str, str] = {}
    for rule in rules:
        if not rule.name or not rule.expression:
            continue
        value = _extract_single(body, headers, rule)
        if value is not None:
            results[rule.name] = value
    return results


def _extract_single(body: str, headers: dict[str, str], rule: ExtractionDef) -> str | None:
    if rule.source == "json_path":
        return _extract_json_path(body, rule.expression)
    if rule.source == "header":
        return _extract_header(headers, rule.expression)
    if rule.source == "regex":
        return _extract_regex(body, rule.expression)
    if rule.source == "boundary":
        return _extract_boundary(body, rule.expression)
    return None


def _extract_json_path(body: str, path: str) -> str | None:
    """Extract value from JSON body using dot-path (e.g. $.data.token or data.token)."""
    try:
        data = json.loads(body)
    except (json.JSONDecodeError, TypeError, ValueError):
        return None
    keys = path.lstrip("$.").split(".")
    obj: Any = data
    for key in keys:
        m = re.match(r"(\w+)\[(\d+)\]", key)
        if m:
            obj = obj[m.group(1)][int(m.group(2))]
        elif isinstance(obj, dict):
            obj = obj.get(key)
        else:
            return None
        if obj is None:
            return None
    return str(obj) if obj is not None else None


def _extract_header(headers: dict[str, str], header_name: str) -> str | None:
    for k, v in headers.items():
        if k.lower() == header_name.lower():
            return v
    return None


def _extract_regex(body: str, pattern: str) -> str | None:
    m = re.search(pattern, body)
    if m:
        return m.group(1) if m.groups() else m.group(0)
    return None


def _extract_boundary(body: str, expression: str) -> str | None:
    """Boundary format: LB=<left>;;RB=<right>"""
    parts = expression.split(";;")
    lb = rb = ""
    for p in parts:
        p = p.strip()
        if p.startswith("LB="):
            lb = p[3:]
        elif p.startswith("RB="):
            rb = p[3:]
    if not lb or not rb:
        return None
    start = body.find(lb)
    if start < 0:
        return None
    start += len(lb)
    end = body.find(rb, start)
    if end < 0:
        return None
    return body[start:end]


# ---------------------------------------------------------------------------
# Smart extraction suggestions
# ---------------------------------------------------------------------------

# Exact key matches — highest confidence correlation candidates
_EXACT_CORRELATION_KEYS = frozenset([
    # Auth / session
    "token", "access_token", "auth_token", "refresh_token", "id_token",
    "csrf", "csrftoken", "csrfmiddlewaretoken", "csrf_token", "_csrf",
    "xsrf", "xsrf_token", "_xsrf",
    "session", "sessionid", "session_id", "sid",
    "nonce", "authenticity_token", "api_key", "apikey",
    # Generic identifiers
    "id", "_id", "uid", "uuid", "guid",
    # Common entity IDs (snake_case variants)
    "order_id", "orderid", "order_number", "order_no",
    "user_id", "userid", "user_number",
    "customer_id", "customerid", "customer_number",
    "account_id", "accountid",
    "cart_id", "cartid",
    "product_id", "productid",
    "item_id", "itemid",
    "transaction_id", "transactionid", "txn_id",
    "booking_id", "bookingid",
    "reservation_id", "invoice_id", "invoiceid",
    "ref_id", "refid", "reference_id",
    "sequence_id", "seq_id", "session_token",
    # Short reference keys
    "code", "ref", "reference", "number", "no", "num", "seq", "sequence", "key",
])

# Fragments that indicate auth/session tokens in key names
_AUTH_FRAGMENTS = frozenset(("token", "csrf", "session", "nonce", "auth", "secret"))

# snake_case suffixes that indicate an identifier (applied to key.lower())
_SNAKE_ID_SUFFIXES = (
    "_id", "_no", "_num", "_number", "_code", "_ref", "_key",
    "_seq", "_token", "_uuid", "_guid", "_hash",
)

# camelCase / PascalCase suffixes that indicate an identifier (case-sensitive)
_CAMEL_ID_SUFFIXES = (
    "Id", "No", "Num", "Number", "Code", "Ref", "Key",
    "Seq", "Token", "Uuid", "Guid", "Hash", "ID",
)

_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I
)
_LONG_TOKEN_RE = re.compile(r"^[A-Za-z0-9+/=_\-\.]{20,}$")


def _key_interest_score(key: str) -> int:
    """Return a priority score for how likely a key holds a dynamic/correlation value.
    Returns 0 if the key is not interesting at all."""
    key_lower = key.lower()

    if key_lower in _EXACT_CORRELATION_KEYS:
        return 10

    if any(frag in key_lower for frag in _AUTH_FRAGMENTS):
        return 8

    if any(key_lower.endswith(s) for s in _SNAKE_ID_SUFFIXES):
        return 7

    if any(key.endswith(s) for s in _CAMEL_ID_SUFFIXES):
        return 7

    if key_lower.startswith("id_") or key_lower.startswith("_id"):
        return 6

    # Key ends with "id" preceded by at least one other character (e.g. "productid")
    # but not words like "valid" or "invalid"
    if (re.search(r"[a-z]{2}id$", key_lower)
            and not key_lower.endswith("valid")
            and not key_lower.endswith("qrid")):
        return 5

    return 0


def _value_score(value: Any) -> int:
    """Score how likely a value is a dynamic correlation target. 0 = skip."""
    if isinstance(value, bool):  # bool is a subclass of int — must check first
        return 0
    if isinstance(value, int):
        return 8 if value != 0 else 2
    if isinstance(value, float):
        # Floats that are whole numbers could be IDs; skip prices etc.
        if value == int(value) and value > 0:
            return 4
        return 0
    if isinstance(value, str):
        if not value:
            return 0
        if _UUID_RE.match(value):
            return 10
        if _LONG_TOKEN_RE.match(value) and len(value) >= 20:
            return 9
        if len(value) >= 4:
            return 5
        return 2
    return 0


def _scan_json(obj: Any, path: str, candidates: list[dict], depth: int = 0) -> None:
    """Recursively collect correlation candidates without deduplication."""
    if depth > 6 or not isinstance(obj, dict):
        return
    for key, value in obj.items():
        current_path = f"{path}.{key}"
        k_score = _key_interest_score(key)
        v_score = _value_score(value)

        if k_score > 0 and v_score > 0:
            depth_bonus = max(0, (6 - depth) * 2)
            candidates.append({
                "name": key,
                "source": "json_path",
                "expression": current_path,
                "preview": str(value) if not isinstance(value, str) else value,
                "_score": k_score + v_score + depth_bonus,
            })

        if isinstance(value, dict):
            _scan_json(value, current_path, candidates, depth + 1)
        elif isinstance(value, list):
            for i, item in enumerate(value[:3]):
                if isinstance(item, dict):
                    _scan_json(item, f"{current_path}[{i}]", candidates, depth + 1)


def suggest_extractions(body: str, headers: dict[str, str]) -> list[dict]:
    """Scan response for dynamic-looking values and return up to 10 ranked suggestions."""
    candidates: list[dict] = []

    try:
        data = json.loads(body)
        if isinstance(data, dict):
            _scan_json(data, "$", candidates)
        elif isinstance(data, list):
            # Root-level arrays (e.g. cart items, search results)
            for i, item in enumerate(data[:3]):
                if isinstance(item, dict):
                    _scan_json(item, f"$[{i}]", candidates)
    except (json.JSONDecodeError, TypeError, ValueError):
        pass

    # Sort by score descending, then deduplicate by key name (keep highest-scored path)
    candidates.sort(key=lambda c: c["_score"], reverse=True)
    seen_names: set[str] = set()
    suggestions: list[dict] = []
    for c in candidates:
        name_lower = c["name"].lower()
        if name_lower not in seen_names:
            seen_names.add(name_lower)
            c.pop("_score")
            suggestions.append(c)
            if len(suggestions) >= 10:
                break

    # Append header-based suggestions up to the remaining capacity
    for hdr_name, hdr_value in headers.items():
        if len(suggestions) >= 10:
            break
        name_lower = hdr_name.lower()
        if name_lower in ("set-cookie", "cookie", "content-type", "content-length",
                          "date", "server", "connection", "transfer-encoding"):
            continue
        if any(frag in name_lower for frag in _AUTH_FRAGMENTS):
            if hdr_value and len(hdr_value) >= 6 and name_lower not in seen_names:
                seen_names.add(name_lower)
                suggestions.append({
                    "name": hdr_name.lower().replace("-", "_"),
                    "source": "header",
                    "expression": hdr_name,
                    "preview": hdr_value,
                })

    return suggestions


# ---------------------------------------------------------------------------
# Request execution
# ---------------------------------------------------------------------------

@dataclass
class ExecutionResult:
    status_code: int = 0
    headers: dict[str, str] = field(default_factory=dict)
    body: str = ""
    elapsed_ms: float = 0
    extracted_values: dict[str, str] = field(default_factory=dict)
    suggested_extractions: list[dict] = field(default_factory=list)
    error: str = ""
    sent_url: str = ""
    sent_method: str = ""
    sent_headers: dict[str, str] = field(default_factory=dict)
    sent_payload: Any = None


def execute_request(
    method: str,
    url: str,
    headers: dict[str, str] | None = None,
    payload: Any = None,
    payload_type: str = "none",
    auth_type: str = "none",
    auth_value: dict | None = None,
    variables: dict[str, str] | None = None,
    extractions: list[dict] | None = None,
    session: http_requests.Session | None = None,
) -> ExecutionResult:
    """Execute a single HTTP request with variable substitution and extraction."""
    variables = variables or {}
    headers = dict(headers or {})
    auth_value = substitute_dict(auth_value or {}, variables)

    resolved_url = substitute(url, variables)
    headers = substitute_dict(headers, variables)
    headers = apply_auth(headers, auth_type or "none", auth_value)

    resolved_payload: Any = None
    kwarg = ""
    if payload is not None and payload_type != "none":
        if payload_type == "json":
            if isinstance(payload, str):
                try:
                    resolved_payload = json.loads(substitute(payload, variables))
                except (json.JSONDecodeError, TypeError):
                    resolved_payload = substitute(payload, variables)
            else:
                resolved_payload = substitute_dict(payload, variables)
            kwarg = "json"
        elif payload_type == "urlencoded":
            if isinstance(payload, str):
                try:
                    resolved_payload = json.loads(substitute(payload, variables))
                except (json.JSONDecodeError, TypeError):
                    resolved_payload = substitute(payload, variables)
            else:
                resolved_payload = substitute_dict(payload, variables)
            kwarg = "data"
        elif payload_type == "form":
            if isinstance(payload, dict):
                resolved_payload = substitute_dict(payload, variables)
            elif isinstance(payload, str):
                try:
                    resolved_payload = json.loads(substitute(payload, variables))
                except (json.JSONDecodeError, TypeError):
                    resolved_payload = substitute(payload, variables)
            kwarg = "data"
        else:
            if isinstance(payload, str):
                resolved_payload = substitute(payload, variables)
            else:
                resolved_payload = substitute_dict(payload, variables)
            kwarg = "data"

    result = ExecutionResult(
        sent_url=resolved_url,
        sent_method=method.upper(),
        sent_headers=dict(headers),
        sent_payload=resolved_payload,
    )

    if session is None:
        session = http_requests.Session()

    try:
        kwargs: dict[str, Any] = {
            "headers": headers,
            "timeout": 30,
            "allow_redirects": True,
        }
        if resolved_payload is not None and kwarg:
            kwargs[kwarg] = resolved_payload

        start = time.perf_counter()
        resp = session.request(method.upper(), resolved_url, **kwargs)
        elapsed = (time.perf_counter() - start) * 1000

        # Capture actual wire-level request info (including default headers).
        try:
            result.sent_method = resp.request.method or method.upper()
            result.sent_url = resp.request.url or resolved_url
            result.sent_headers = dict(resp.request.headers or {})
        except Exception:
            # Fall back to what we constructed if anything goes wrong.
            result.sent_method = method.upper()
            result.sent_url = resolved_url
            result.sent_headers = dict(headers)

        result.status_code = resp.status_code
        result.headers = dict(resp.headers)
        result.body = resp.text[:500_000]
        result.elapsed_ms = round(elapsed, 1)

    except Exception as e:
        result.error = str(e)
        return result

    extraction_defs = [
        ExtractionDef(name=r.get("name", ""), source=r.get("source", ""), expression=r.get("expression", ""))
        for r in (extractions or [])
        if r.get("name") and r.get("expression")
    ]

    result.extracted_values = extract_values(
        result.body, result.headers, result.status_code, extraction_defs
    )
    result.suggested_extractions = suggest_extractions(result.body, result.headers)

    return result

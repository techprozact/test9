"""Traverse Engine — scan every request in order and extract parameters from URL, query, headers, body."""
from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import parse_qs, urlparse

from .models import Parameter, ParamLocation, RequestRecord


def build_request_records(transactions: list[dict]) -> list[RequestRecord]:
    """Convert raw DB transaction dicts into normalised RequestRecord objects."""
    records: list[RequestRecord] = []
    for i, t in enumerate(transactions):
        url = t.get("request_url", "")
        parsed = urlparse(url)
        qp = parse_qs(parsed.query, keep_blank_values=True)
        headers = t.get("headers") or {}
        if isinstance(headers, str):
            try:
                headers = json.loads(headers)
            except Exception:
                headers = {}
        payload = t.get("payload")
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except Exception:
                pass
        resp = t.get("response") or {}
        records.append(RequestRecord(
            index=i,
            transaction_name=t.get("transaction_name", f"request_{i}"),
            method=(t.get("http_method") or "GET").upper(),
            url=url,
            headers={str(k): str(v) for k, v in headers.items()},
            query_params=qp,
            payload=payload,
            response_status=resp.get("status", 0) if isinstance(resp, dict) else 0,
            response_headers=resp.get("headers", {}) if isinstance(resp, dict) else {},
            response_body=resp.get("body", "") if isinstance(resp, dict) else "",
            response_content_type=resp.get("content_type", "") if isinstance(resp, dict) else "",
        ))
    return records


def extract_parameters(record: RequestRecord) -> list[Parameter]:
    """Extract all parameter values from a single request."""
    params: list[Parameter] = []

    parsed = urlparse(record.url)
    path_segments = [s for s in (parsed.path or "/").split("/") if s]
    for seg in path_segments:
        if _looks_like_dynamic_segment(seg):
            params.append(Parameter(
                value=seg,
                request_index=record.index,
                location=ParamLocation.URL_PATH,
                key_name=seg,
                full_path=f"url.path/{seg}",
            ))

    for key, values in record.query_params.items():
        for v in values:
            if v:
                params.append(Parameter(
                    value=v,
                    request_index=record.index,
                    location=ParamLocation.QUERY,
                    key_name=key,
                    full_path=f"query.{key}",
                ))

    for hdr_name, hdr_value in record.headers.items():
        lower = hdr_name.lower()
        if lower in _SKIP_HEADERS:
            continue
        if lower == "cookie":
            continue
        if hdr_value and len(hdr_value) > 5:
            params.append(Parameter(
                value=hdr_value,
                request_index=record.index,
                location=ParamLocation.HEADER,
                key_name=hdr_name,
                full_path=f"header.{hdr_name}",
            ))

    if record.payload:
        body_params = _extract_from_dict(record.payload, record.index, "body")
        params.extend(body_params)

    return params


def extract_all_parameters(records: list[RequestRecord]) -> list[Parameter]:
    """Extract parameters from every request in order."""
    all_params: list[Parameter] = []
    for rec in records:
        all_params.extend(extract_parameters(rec))
    return all_params


_SKIP_HEADERS = frozenset([
    "accept", "accept-encoding", "accept-language", "connection",
    "host", "origin", "referer", "user-agent", "content-type",
    "content-length", "cache-control", "pragma",
    "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site",
    "upgrade-insecure-requests",
])

_DYNAMIC_SEGMENT_RE = re.compile(
    r"^[0-9a-fA-F]{8,}$"
    r"|^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-"
    r"|^\d{6,}$"
    r"|^[A-Za-z0-9_-]{8,}$"
)


def _looks_like_dynamic_segment(seg: str) -> bool:
    if len(seg) < 6:
        return False
    if seg.startswith(("api", "v1", "v2", "v3", "www", "static", "assets", "images")):
        return False
    return bool(_DYNAMIC_SEGMENT_RE.match(seg))


def _parse_cookie_params(cookie_str: str, request_index: int) -> list[Parameter]:
    params: list[Parameter] = []
    for part in cookie_str.split(";"):
        part = part.strip()
        if "=" not in part:
            continue
        name, _, value = part.partition("=")
        name = name.strip()
        value = value.strip()
        if value and len(value) > 5:
            params.append(Parameter(
                value=value,
                request_index=request_index,
                location=ParamLocation.COOKIE,
                key_name=name,
                full_path=f"cookie.{name}",
            ))
    return params


def _extract_from_dict(obj: Any, request_index: int, prefix: str) -> list[Parameter]:
    """Recursively extract key-value pairs from a dict/list payload."""
    params: list[Parameter] = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            path = f"{prefix}.{k}"
            if isinstance(v, str) and v:
                params.append(Parameter(
                    value=v,
                    request_index=request_index,
                    location=ParamLocation.BODY,
                    key_name=k,
                    full_path=path,
                ))
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                params.append(Parameter(
                    value=str(v),
                    request_index=request_index,
                    location=ParamLocation.BODY,
                    key_name=k,
                    full_path=path,
                ))
            elif isinstance(v, (dict, list)):
                params.extend(_extract_from_dict(v, request_index, path))
    elif isinstance(obj, list):
        for i, item in enumerate(obj[:50]):
            params.extend(_extract_from_dict(item, request_index, f"{prefix}[{i}]"))
    return params

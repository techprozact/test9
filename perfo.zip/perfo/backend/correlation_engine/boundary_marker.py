"""Boundary Marker — locate where a dynamic value originates in earlier responses.

For JSON responses: extract the JSON path.
For HTML/text responses: detect hidden input fields (CSRF tokens, etc.) first,
  then fall back to generic left/right boundary detection.

Every returned ExtractionRule carries rich debugging context:
  source_key_name, sample_value, occurrence_count, response_hash, response_content_type, source_url
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from .models import ExtractionRule, ParameterType, RequestRecord, SourceType


_LB_CONTEXT_CHARS = 40
_RB_CONTEXT_CHARS = 40

# ---------------------------------------------------------------------------
# HTML hidden-input field extraction
# ---------------------------------------------------------------------------

_HIDDEN_INPUT_RE = re.compile(
    r"<input\b[^>]*?\btype\s*=\s*[\"']hidden[\"'][^>]*?/?>",
    re.IGNORECASE | re.DOTALL,
)
_META_CSRF_RE = re.compile(
    r"<meta\b[^>]*?\bname\s*=\s*[\"']([^\"']*(?:csrf|token|nonce|xsrf)[^\"']*)[\"'][^>]*?/?>",
    re.IGNORECASE | re.DOTALL,
)
_ATTR_VALUE_RE = re.compile(r"""\bvalue\s*=\s*(["'])(.*?)\1""", re.IGNORECASE)
_ATTR_NAME_RE = re.compile(r"""\bname\s*=\s*(["'])(.*?)\1""", re.IGNORECASE)
_ATTR_CONTENT_RE = re.compile(r"""\bcontent\s*=\s*(["'])(.*?)\1""", re.IGNORECASE)

_CSRF_NAME_KEYWORDS = frozenset(["csrf", "token", "auth", "nonce", "xsrf"])


def find_extraction_source(
    value: str,
    earlier_records: list[RequestRecord],
    param_name: str,
) -> ExtractionRule | None:
    """Search earlier responses (newest first) for the origin of *value*.

    Returns the best ExtractionRule or None if the value cannot be found.
    Priority: headers → JSON path → HTML hidden inputs → generic boundary.
    """
    for record in reversed(earlier_records):
        rule = _search_response_headers(value, record, param_name)
        if rule:
            return _enrich_rule(rule, value, record)

        body = record.response_body or ""
        if not body or value not in body:
            continue

        ct = (record.response_content_type or "").lower()

        if "json" in ct:
            rule = _search_json_body(value, body, record.index, param_name)
            if rule:
                return _enrich_rule(rule, value, record)

        if "html" in ct or "text" in ct:
            rule = _search_html_hidden_fields(value, body, record.index, param_name)
            if rule:
                return _enrich_rule(rule, value, record)

        rule = _extract_boundary(value, body, record.index, param_name)
        if rule:
            return _enrich_rule(rule, value, record)

    return None


def _enrich_rule(
    rule: ExtractionRule,
    value: str,
    record: RequestRecord,
) -> ExtractionRule:
    """Attach debugging / audit context to a rule."""
    body = record.response_body or ""
    rule.sample_value = value[:200]
    rule.occurrence_count = body.count(value)
    rule.response_hash = hashlib.sha256(body.encode("utf-8", errors="replace")).hexdigest()[:16]
    rule.response_content_type = record.response_content_type or ""
    rule.source_url = record.url
    return rule


def _search_response_headers(
    value: str, record: RequestRecord, param_name: str,
) -> ExtractionRule | None:
    for hdr_name, hdr_value in record.response_headers.items():
        if hdr_name.lower() in ("set-cookie", "cookie"):
            continue
        if value in str(hdr_value):
            return ExtractionRule(
                param_name=param_name,
                param_type=ParameterType.CORRELATION,
                source_request_index=record.index,
                source_type=SourceType.HEADER,
                header_name=hdr_name,
                source_key_name=hdr_name,
            )
    return None


def _search_json_body(
    value: str, body: str, source_index: int, param_name: str,
) -> ExtractionRule | None:
    try:
        data = json.loads(body)
    except (json.JSONDecodeError, TypeError, ValueError):
        return None

    paths = _find_json_paths(data, value, "$")
    if not paths:
        return None

    best = min(paths, key=len)
    source_key = best.rsplit(".", 1)[-1] if "." in best else best.lstrip("$.")
    source_key = re.sub(r"\[\d+\]", "", source_key)

    return ExtractionRule(
        param_name=param_name,
        param_type=ParameterType.CORRELATION,
        source_request_index=source_index,
        source_type=SourceType.JSON_PATH,
        json_path=best,
        source_key_name=source_key,
    )


def _find_json_paths(obj: Any, target: str, current_path: str) -> list[str]:
    """Recursively find all JSON paths that lead to *target*."""
    paths: list[str] = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            child_path = f"{current_path}.{k}"
            if isinstance(v, str) and v == target:
                paths.append(child_path)
            elif isinstance(v, (int, float)) and str(v) == target:
                paths.append(child_path)
            elif isinstance(v, (dict, list)):
                paths.extend(_find_json_paths(v, target, child_path))
    elif isinstance(obj, list):
        for i, item in enumerate(obj[:100]):
            child_path = f"{current_path}[{i}]"
            if isinstance(item, str) and item == target:
                paths.append(child_path)
            elif isinstance(item, (int, float)) and str(item) == target:
                paths.append(child_path)
            elif isinstance(item, (dict, list)):
                paths.extend(_find_json_paths(item, target, child_path))
    return paths


def _search_html_hidden_fields(
    value: str, body: str, source_index: int, param_name: str,
) -> ExtractionRule | None:
    """Search for *value* inside HTML hidden input fields and CSRF meta tags.

    Produces precise left/right boundaries like:
      LB: name="csrfmiddlewaretoken" value="
      RB: "
    """
    rule = _search_hidden_inputs(value, body, source_index, param_name)
    if rule:
        return rule
    return _search_meta_csrf_tags(value, body, source_index, param_name)


def _search_hidden_inputs(
    value: str, body: str, source_index: int, param_name: str,
) -> ExtractionRule | None:
    for tag_match in _HIDDEN_INPUT_RE.finditer(body):
        tag_text = tag_match.group()

        val_m = _ATTR_VALUE_RE.search(tag_text)
        if not val_m or val_m.group(2) != value:
            continue

        name_m = _ATTR_NAME_RE.search(tag_text)
        field_name = name_m.group(2) if name_m else ""
        quote = val_m.group(1)

        value_prefix = f"value={quote}"
        value_content_start = val_m.start() + len(value_prefix)

        if name_m and name_m.start() < val_m.start():
            lb = tag_text[name_m.start():value_content_start]
        else:
            lb = value_prefix
        rb = quote

        lb_pos = tag_match.start() + (val_m.start() - len(lb) + len(value_prefix))
        if body[lb_pos:lb_pos + len(lb)] != lb:
            lb = value_prefix

        regex = re.escape(lb) + r"(.+?)" + re.escape(rb)

        return ExtractionRule(
            param_name=param_name,
            param_type=ParameterType.CORRELATION,
            source_request_index=source_index,
            source_type=SourceType.HTML_HIDDEN,
            left_boundary=lb,
            right_boundary=rb,
            regex_pattern=regex,
            source_key_name=field_name or "hidden_input",
        )
    return None


def _search_meta_csrf_tags(
    value: str, body: str, source_index: int, param_name: str,
) -> ExtractionRule | None:
    """Search <meta name="csrf-token" content="VALUE"> patterns."""
    for tag_match in _META_CSRF_RE.finditer(body):
        tag_text = tag_match.group()
        content_m = _ATTR_CONTENT_RE.search(tag_text)
        if not content_m or content_m.group(2) != value:
            continue

        meta_name = tag_match.group(1)
        quote = content_m.group(1)

        content_prefix = f"content={quote}"
        content_start = content_m.start() + len(content_prefix)

        name_m = _ATTR_NAME_RE.search(tag_text)
        if name_m and name_m.start() < content_m.start():
            lb = tag_text[name_m.start():content_start]
        else:
            lb = content_prefix
        rb = quote

        regex = re.escape(lb) + r"(.+?)" + re.escape(rb)

        return ExtractionRule(
            param_name=param_name,
            param_type=ParameterType.CORRELATION,
            source_request_index=source_index,
            source_type=SourceType.HTML_HIDDEN,
            left_boundary=lb,
            right_boundary=rb,
            regex_pattern=regex,
            source_key_name=meta_name or "csrf_meta",
        )
    return None


def _extract_boundary(
    value: str, body: str, source_index: int, param_name: str,
) -> ExtractionRule | None:
    """Find left and right boundaries around the first occurrence of *value* in *body*."""
    idx = body.find(value)
    if idx < 0:
        return None

    lb_start = max(0, idx - _LB_CONTEXT_CHARS)
    lb_raw = body[lb_start:idx]
    lb = _trim_boundary(lb_raw, is_left=True)

    rb_end = min(len(body), idx + len(value) + _RB_CONTEXT_CHARS)
    rb_raw = body[idx + len(value):rb_end]
    rb = _trim_boundary(rb_raw, is_left=False)

    if not lb and not rb:
        return None
    if len(lb) < 3 or len(rb) < 3:
        return None

    regex = ""
    if lb and rb:
        regex = re.escape(lb) + r"(.+?)" + re.escape(rb)

    return ExtractionRule(
        param_name=param_name,
        param_type=ParameterType.CORRELATION,
        source_request_index=source_index,
        source_type=SourceType.BOUNDARY,
        left_boundary=lb,
        right_boundary=rb,
        regex_pattern=regex,
        source_key_name="boundary",
    )


def _trim_boundary(raw: str, is_left: bool) -> str:
    """Trim a raw boundary to a clean, unique anchor string."""
    text = raw.strip()
    if not text:
        return ""
    if is_left:
        for delim in ('"', "'", ">", "=", ":", ",", ";", "\n"):
            pos = text.rfind(delim)
            if pos >= 0:
                text = text[pos:]
                break
    else:
        for delim in ('"', "'", "<", ",", ";", "&", "\n"):
            pos = text.find(delim)
            if pos >= 0:
                text = text[: pos + 1]
                break
    return text[:60]

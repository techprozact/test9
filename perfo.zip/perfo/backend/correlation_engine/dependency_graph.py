"""Dependency Graph — build correlation relationships between requests.

For every correlated parameter, creates an edge:
    source_request  --[param]--> target_request

Uses ParamNameRegistry for readable variable names (product_id, auth_token, etc.)
and tags every artefact with ParameterType.CORRELATION so future phases can
distinguish them from USER parameters.
"""
from __future__ import annotations

from .models import (
    DependencyEdge,
    ExtractionRule,
    Parameter,
    ParameterType,
    ParameterUsage,
    ParamLocation,
    RequestRecord,
)
from .boundary_marker import find_extraction_source
from .candidate_detector import detect_candidates, find_usages, value_reused_in_later_requests
from .confidence import compute_confidence
from .param_namer import ParamNameRegistry
from .traverse_engine import extract_all_parameters


def build_dependency_graph(
    records: list[RequestRecord],
) -> tuple[list[DependencyEdge], list[ExtractionRule], list[Parameter]]:
    """Run full correlation analysis and return (edges, rules, uncorrelated_candidates).

    Flow (mirrors a performance engineer's workflow):
    1. Extract all parameters from every request
    2. Detect candidates: params whose values appear in an earlier response
    3. For each candidate, find the extraction rule (JSON path or LB/RB) from the source response
    4. Assign a readable variable name via ParamNameRegistry
    5. Find all downstream usages of that value
    6. Build dependency edges: source_response -> target_requests
    """
    all_params = extract_all_parameters(records)
    candidates = detect_candidates(all_params, records)

    namer = ParamNameRegistry()
    edges: list[DependencyEdge] = []
    rules: list[ExtractionRule] = []
    uncorrelated: list[Parameter] = []
    seen_values: set[str] = set()

    for candidate in candidates:
        val = candidate.value
        if val in seen_values:
            continue
        seen_values.add(val)

        earlier = [r for r in records if r.index < candidate.request_index]
        if not earlier:
            uncorrelated.append(candidate)
            continue

        placeholder = "pending"
        rule = find_extraction_source(val, earlier, placeholder)

        if not rule:
            uncorrelated.append(candidate)
            continue

        downstream_usages = find_usages(val, all_params, rule.source_request_index)

        # Layer 1 — parameter-level check: the extracted value must be reused
        # in at least one later request in a valid location (URL path, query,
        # body, or non-cookie header).
        _VALID_REUSE_LOCATIONS = {ParamLocation.BODY, ParamLocation.QUERY,
                                  ParamLocation.URL_PATH, ParamLocation.HEADER}
        all_reuse = downstream_usages + [candidate]
        valid_reuse = [
            u for u in all_reuse
            if u.location in _VALID_REUSE_LOCATIONS
            and u.request_index > rule.source_request_index
        ]
        if not valid_reuse:
            uncorrelated.append(candidate)
            continue

        # Layer 2 — raw text scan: confirm the value literally appears in a
        # later request's URL, query, body, or non-cookie headers.  Catches
        # cases where parameter extraction missed an embedded occurrence.
        if not value_reused_in_later_requests(val, records, rule.source_request_index):
            uncorrelated.append(candidate)
            continue

        all_usage_params = downstream_usages + [candidate]

        param_name = namer.assign(candidate, rule, usages=all_usage_params)
        rule.param_name = param_name
        rule.param_type = ParameterType.CORRELATION

        target_indices = {candidate.request_index}
        param_usages: list[ParameterUsage] = []

        for u in downstream_usages:
            target_indices.add(u.request_index)
            param_usages.append(ParameterUsage(
                param_value=u.value,
                request_index=u.request_index,
                location=u.location,
                key_name=u.key_name,
                full_path=u.full_path,
                param_type=ParameterType.CORRELATION,
            ))

        if not param_usages:
            param_usages.append(ParameterUsage(
                param_value=candidate.value,
                request_index=candidate.request_index,
                location=candidate.location,
                key_name=candidate.key_name,
                full_path=candidate.full_path,
                param_type=ParameterType.CORRELATION,
            ))
            target_indices.add(candidate.request_index)

        score, breakdown = compute_confidence(rule, candidate, param_usages)
        rule.confidence_score = score
        rule.confidence_breakdown = breakdown
        rules.append(rule)

        for target_idx in sorted(target_indices):
            edges.append(DependencyEdge(
                param_name=param_name,
                param_value=val,
                param_type=ParameterType.CORRELATION,
                source_request_index=rule.source_request_index,
                target_request_index=target_idx,
                extraction_rule=rule,
                usages=[u for u in param_usages if u.request_index == target_idx],
            ))

    return edges, rules, uncorrelated

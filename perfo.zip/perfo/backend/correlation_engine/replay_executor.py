"""Replay Executor — execute recorded requests live, compare responses, repair broken correlations.

Architecture:
  Script → Request Executor → Response Comparator → Correlation Repair Engine → Retry Controller → Result

Each component is a pure function or small stateful class so the validator can
later power self-healing scripts.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse, urlencode, parse_qs

import requests as http_requests

from .models import (
    DependencyEdge,
    ExtractionRule,
    ParameterType,
    ParamLocation,
    RequestRecord,
    SourceType,
)
from .boundary_marker import find_extraction_source
from .replay_validator import extract_value


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class StepResult:
    """Outcome of executing one request in the replay."""
    request_index: int
    transaction_name: str
    method: str
    url: str
    request_headers: dict[str, str] = field(default_factory=dict)
    request_payload: Any = None
    status: str = "pending"   # pending | running | passed | failed
    replay_status_code: int = 0
    recorded_status_code: int = 0
    response_headers: dict[str, str] = field(default_factory=dict)
    response_body: str = ""
    error: str = ""
    retries: int = 0
    repaired_rules: list[dict] = field(default_factory=list)


@dataclass
class ReplaySession:
    """Stateful replay session that tracks execution progress."""
    script_id: str
    records: list[RequestRecord]
    edges: list[DependencyEdge]
    rules: list[ExtractionRule]
    steps: list[StepResult] = field(default_factory=list)
    current_index: int = 0
    extracted_values: dict[str, str] = field(default_factory=dict)
    http_session: Any = None
    base_url: str = ""

    def __post_init__(self):
        if self.http_session is None:
            self.http_session = http_requests.Session()
        if not self.base_url and self.records:
            parsed = urlparse(self.records[0].url)
            self.base_url = f"{parsed.scheme}://{parsed.netloc}"
        self._build_steps()
        self._build_lookup()

    def _build_steps(self):
        self.steps = []
        for rec in self.records:
            self.steps.append(StepResult(
                request_index=rec.index,
                transaction_name=rec.transaction_name,
                method=rec.method,
                url=rec.url,
                recorded_status_code=rec.response_status,
            ))

    def _build_lookup(self):
        self._extractions_by_source: dict[int, list[DependencyEdge]] = {}
        self._substitutions_by_target: dict[int, list[DependencyEdge]] = {}
        for edge in self.edges:
            src = edge.extraction_rule.source_request_index
            self._extractions_by_source.setdefault(src, []).append(edge)
            self._substitutions_by_target.setdefault(edge.target_request_index, []).append(edge)


# ---------------------------------------------------------------------------
# Request Executor
# ---------------------------------------------------------------------------

_COOKIE_HEADERS = frozenset(["cookie", "set-cookie", "set-cookie2"])
_SKIP_HEADERS = frozenset([
    "host", "content-length", "accept-encoding", "connection",
    "upgrade-insecure-requests", "priority", "pragma", "cache-control", "dnt",
])


def _clean_replay_headers(headers: dict[str, str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for k, v in headers.items():
        key = k.lower().strip()
        if key in _COOKIE_HEADERS or "cookie" in key:
            continue
        if key in _SKIP_HEADERS:
            continue
        if key.startswith("sec-fetch-") or key.startswith("sec-ch-"):
            continue
        out[k] = v
    return out


def _detect_content_type(headers: dict[str, str]) -> str:
    for k, v in (headers or {}).items():
        if k.lower().strip() == "content-type":
            return v.lower().split(";")[0].strip()
    return ""


def _is_raw_wrapper(payload: Any) -> bool:
    return (
        isinstance(payload, dict)
        and "raw" in payload
        and len(payload) == 1
        and isinstance(payload["raw"], str)
    )


def _parse_form_urlencoded(raw: str) -> dict[str, str]:
    from urllib.parse import unquote_plus
    result: dict[str, str] = {}
    for pair in raw.split("&"):
        if "=" in pair:
            key, _, value = pair.partition("=")
            result[unquote_plus(key)] = unquote_plus(value)
        elif pair.strip():
            result[pair.strip()] = ""
    return result


def _normalize_payload(payload: Any, headers: dict[str, str]) -> tuple[Any, str]:
    """Resolve the DB payload into the same format the correlated script uses.

    Handles the {"raw": "key=val&key2=val2"} wrapper that the CDP recorder stores.
    Returns (resolved_payload, kwarg) where kwarg is 'json', 'data', or ''.
    """
    if payload is None:
        return None, ""

    ct = _detect_content_type(headers)
    raw_str = payload.get("raw", "") if _is_raw_wrapper(payload) else None

    if ct == "application/json":
        if raw_str is not None:
            try:
                parsed = json.loads(raw_str)
                return parsed if isinstance(parsed, dict) else {"value": parsed}, "json"
            except (json.JSONDecodeError, TypeError, ValueError):
                return raw_str, "data"
        return payload, "json"

    if ct in ("application/x-www-form-urlencoded", "multipart/form-data"):
        if raw_str is not None:
            parsed = _parse_form_urlencoded(raw_str)
            if parsed:
                return parsed, "data"
            return raw_str, "data"
        clean = {k: v for k, v in payload.items() if k != "raw"} if isinstance(payload, dict) else payload
        return (clean or payload), "data"

    if ct == "text/plain":
        return (raw_str if raw_str is not None else payload), "data"

    if raw_str is not None:
        try:
            parsed = json.loads(raw_str)
            if isinstance(parsed, dict):
                return parsed, "json"
        except (json.JSONDecodeError, TypeError, ValueError):
            pass
        if "=" in raw_str and "&" in raw_str:
            parsed = _parse_form_urlencoded(raw_str)
            if parsed:
                return parsed, "data"
        return raw_str, "data"

    return payload, "json"


def _apply_substitutions(
    record: RequestRecord,
    subs: list[DependencyEdge],
    extracted: dict[str, str],
) -> tuple[str, dict[str, str], Any, str]:
    """Apply correlation substitutions to URL, headers, and payload.

    Returns (url, headers, normalized_payload, kwarg).
    The payload is normalized first (raw wrappers parsed into proper dicts)
    so substitutions operate on individual field values, not raw strings.

    Two substitution passes:
    1. Edge-based: apply each formal correlation edge
    2. Proactive: for payload dict keys that match a name in `extracted` but
       weren't covered by an edge, replace with the live value — this handles
       CSRF tokens extracted by the proactive scanner without a formal edge.
    """
    url = record.url
    headers = dict(record.headers)
    payload, kwarg = _normalize_payload(record.payload, headers)

    edge_param_names: set[str] = set()
    for edge in subs:
        var_value = extracted.get(edge.param_name)
        if var_value is None:
            continue
        recorded_value = edge.param_value
        edge_param_names.add(edge.param_name)

        for usage in edge.usages:
            if usage.location in (ParamLocation.URL_PATH, ParamLocation.QUERY):
                url = url.replace(recorded_value, var_value)
            elif usage.location == ParamLocation.HEADER:
                for hk in list(headers.keys()):
                    if recorded_value in headers[hk]:
                        headers[hk] = headers[hk].replace(recorded_value, var_value)
            elif usage.location == ParamLocation.BODY and payload is not None:
                payload = _replace_in_payload(payload, recorded_value, var_value)

    if isinstance(payload, dict):
        payload = _proactive_payload_substitution(payload, extracted, edge_param_names)

    return url, headers, payload, kwarg


def _proactive_payload_substitution(
    payload: dict, extracted: dict[str, str], already_handled: set[str],
) -> dict:
    """Replace payload values whose keys match an extracted parameter name.

    Only applies to keys NOT already handled by a formal edge. This catches
    CSRF tokens and similar fields that were proactively extracted but have
    no correlation edge.
    """
    result = {}
    for key, value in payload.items():
        if key in extracted and key not in already_handled:
            result[key] = extracted[key]
        elif isinstance(value, dict):
            result[key] = _proactive_payload_substitution(value, extracted, already_handled)
        else:
            result[key] = value
    return result


def _replace_in_payload(payload: Any, old: str, new: str) -> Any:
    if isinstance(payload, dict):
        return {k: _replace_in_payload(v, old, new) for k, v in payload.items()}
    if isinstance(payload, list):
        return [_replace_in_payload(item, old, new) for item in payload]
    if isinstance(payload, str) and old in payload:
        return payload.replace(old, new)
    return payload


def _ensure_referer_origin(
    headers: dict[str, str], url: str, previous_url: str,
) -> dict[str, str]:
    """Add Referer and Origin if missing — required by Django/Rails CSRF checks."""
    lower_keys = {k.lower() for k in headers}

    if "referer" not in lower_keys and previous_url:
        headers["Referer"] = previous_url

    if "origin" not in lower_keys:
        parsed = urlparse(url)
        if parsed.scheme and parsed.netloc:
            headers["Origin"] = f"{parsed.scheme}://{parsed.netloc}"

    return headers


def execute_request(
    session: http_requests.Session,
    record: RequestRecord,
    subs: list[DependencyEdge],
    extracted: dict[str, str],
    previous_url: str = "",
) -> tuple[int, dict[str, str], str]:
    """Execute a single HTTP request. Returns (status_code, response_headers, response_body)."""
    url, headers, payload, kwarg = _apply_substitutions(record, subs, extracted)
    clean_headers = _clean_replay_headers(headers)

    method = record.method.upper()
    if method in ("POST", "PUT", "PATCH", "DELETE"):
        clean_headers = _ensure_referer_origin(clean_headers, url, previous_url)

    kwargs: dict[str, Any] = {"headers": clean_headers, "timeout": 30, "allow_redirects": True}

    if payload is not None and method in ("POST", "PUT", "PATCH", "DELETE") and kwarg:
        kwargs[kwarg] = payload

    resp = session.request(method, url, **kwargs)
    resp_headers = dict(resp.headers)
    body = resp.text[:500_000]
    return resp.status_code, resp_headers, body


# ---------------------------------------------------------------------------
# Response Comparator
# ---------------------------------------------------------------------------

_BODY_FAILURE_PATTERNS = [
    "login to your account", "log in to your account", "please log in",
    "please sign in", "sign in to continue", "login to continue",
    "<title>login</title>", "<title>sign in</title>",
    "access denied", "unauthorized", "forbidden",
    "session expired", "session has expired", "session timed out",
    "invalid token", "token expired", "token has expired",
    "csrf token", "csrf verification failed",
    "not authenticated", "authentication required",
    '"error":', '"status":"error"', '"status":"fail"',
    "your session has ended", "you have been logged out",
]

_RESPONSE_SHRINK_RATIO = 0.25


def compare_response(
    recorded_status: int,
    replay_status: int,
    replay_body: str,
    recorded_body: str = "",
) -> bool:
    """Return True if the replay response is considered successful.

    Three validation layers:
    1) Status code — replay must match recorded (soft: 2xx/3xx still pass)
    2) Response length — if replay body shrank to <25% of recorded, likely failure
    3) Key text — failure patterns in replay body that weren't in recorded body
    """
    expected_success = recorded_status and 200 <= recorded_status < 300

    if recorded_status and replay_status != recorded_status:
        if not (200 <= replay_status < 400):
            return False

    replay_lower = replay_body[:10_000].lower() if replay_body else ""
    recorded_lower = recorded_body[:10_000].lower() if recorded_body else ""

    if expected_success:
        for pattern in _BODY_FAILURE_PATTERNS:
            if pattern in replay_lower and pattern not in recorded_lower:
                return False

    if recorded_body and replay_body and expected_success:
        recorded_len = len(recorded_body)
        replay_len = len(replay_body)
        if recorded_len > 500 and replay_len < recorded_len * _RESPONSE_SHRINK_RATIO:
            return False

    return True


# ---------------------------------------------------------------------------
# Parameter Extraction (runs after EVERY response, before comparison)
# ---------------------------------------------------------------------------

_HIDDEN_INPUT_RE = re.compile(
    r"<input\b[^>]*?\btype\s*=\s*[\"']hidden[\"'][^>]*?/?>",
    re.IGNORECASE | re.DOTALL,
)
_META_CSRF_RE = re.compile(
    r"<meta\b[^>]*?\bname\s*=\s*[\"']([^\"']*(?:csrf|token|nonce|xsrf)[^\"']*)[\"'][^>]*?/?>",
    re.IGNORECASE | re.DOTALL,
)
_ATTR_VALUE_RE = re.compile(r"""\bvalue\s*=\s*(["'])(.*?)\1""", re.IGNORECASE)
_ATTR_NAME_RE = re.compile(r"""\bname\s*=\s*(["'])(.*?)\1""", re.IGNORECASE)
_ATTR_CONTENT_RE = re.compile(r"""\bcontent\s*=\s*(["'])(.*?)\1""", re.IGNORECASE)

_DYNAMIC_FIELD_KEYWORDS = frozenset([
    "csrf", "csrftoken", "csrfmiddlewaretoken", "csrf_token", "_csrf",
    "xsrf", "xsrf_token", "_xsrf",
    "token", "auth_token", "authenticity_token", "access_token",
    "nonce", "__requestverificationtoken",
    "session", "sessionid", "session_id",
])

_DYNAMIC_NAME_FRAGMENTS = ("csrf", "token", "nonce", "xsrf", "auth")


def _build_live_record(
    record: RequestRecord,
    status_code: int,
    resp_headers: dict[str, str],
    resp_body: str,
) -> RequestRecord:
    return RequestRecord(
        index=record.index,
        transaction_name=record.transaction_name,
        method=record.method,
        url=record.url,
        headers=record.headers,
        query_params=record.query_params,
        payload=record.payload,
        response_status=status_code,
        response_headers=resp_headers,
        response_body=resp_body,
        response_content_type=resp_headers.get(
            "content-type", resp_headers.get("Content-Type", "")
        ),
    )


def _extract_from_response(
    session_obj: ReplaySession,
    record: RequestRecord,
    live_rec: RequestRecord,
) -> None:
    """Extract parameters from a response IMMEDIATELY after execution.

    Two extraction passes:
    1. Edge-based: use pre-computed correlation edges for this source request
    2. Proactive: scan for CSRF/token/auth hidden inputs, meta tags, and JSON
       fields by name — catches tokens the correlation engine may not have edged
    """
    for edge in session_obj._extractions_by_source.get(record.index, []):
        value = extract_value(edge.extraction_rule, live_rec)
        if value:
            session_obj.extracted_values[edge.param_name] = value

    _proactive_extract(session_obj, live_rec)


def _proactive_extract(session_obj: ReplaySession, live_rec: RequestRecord) -> None:
    """Scan the response for dynamic tokens by field name, independent of edges."""
    body = live_rec.response_body or ""
    if not body:
        return

    ct = (live_rec.response_content_type or "").lower()

    if "html" in ct or "text" in ct or "<" in body[:500]:
        _extract_html_tokens(session_obj, body)

    if "json" in ct or body.lstrip()[:1] in ("{", "["):
        _extract_json_tokens(session_obj, body)

    for hdr_name, hdr_value in live_rec.response_headers.items():
        name_lower = hdr_name.lower()
        if name_lower in ("set-cookie", "cookie"):
            continue
        if any(frag in name_lower for frag in _DYNAMIC_NAME_FRAGMENTS):
            if hdr_value and len(hdr_value) >= 8:
                session_obj.extracted_values[hdr_name] = hdr_value


def _extract_html_tokens(session_obj: ReplaySession, body: str) -> None:
    for tag_match in _HIDDEN_INPUT_RE.finditer(body):
        tag = tag_match.group()
        name_m = _ATTR_NAME_RE.search(tag)
        val_m = _ATTR_VALUE_RE.search(tag)
        if not name_m or not val_m:
            continue
        field_name = name_m.group(2)
        field_value = val_m.group(2)
        if not field_value or len(field_value) < 4:
            continue
        name_lower = field_name.lower()
        if name_lower in _DYNAMIC_FIELD_KEYWORDS or any(
            frag in name_lower for frag in _DYNAMIC_NAME_FRAGMENTS
        ):
            session_obj.extracted_values[field_name] = field_value

    for tag_match in _META_CSRF_RE.finditer(body):
        tag = tag_match.group()
        meta_name = tag_match.group(1)
        content_m = _ATTR_CONTENT_RE.search(tag)
        if content_m and content_m.group(2) and len(content_m.group(2)) >= 4:
            session_obj.extracted_values[meta_name] = content_m.group(2)


def _extract_json_tokens(session_obj: ReplaySession, body: str) -> None:
    try:
        data = json.loads(body)
    except (json.JSONDecodeError, TypeError, ValueError):
        return
    if isinstance(data, dict):
        _scan_json_dict(session_obj, data)


def _scan_json_dict(session_obj: ReplaySession, obj: Any, depth: int = 0) -> None:
    if depth > 5 or not isinstance(obj, dict):
        return
    for key, value in obj.items():
        key_lower = key.lower()
        if key_lower in _DYNAMIC_FIELD_KEYWORDS or any(
            frag in key_lower for frag in _DYNAMIC_NAME_FRAGMENTS
        ):
            if isinstance(value, str) and len(value) >= 4:
                session_obj.extracted_values[key] = value
        if isinstance(value, dict):
            _scan_json_dict(session_obj, value, depth + 1)
        elif isinstance(value, list):
            for item in value[:20]:
                if isinstance(item, dict):
                    _scan_json_dict(session_obj, item, depth + 1)


# ---------------------------------------------------------------------------
# Correlation Repair Engine
# ---------------------------------------------------------------------------

def attempt_repair(
    record: RequestRecord,
    replay_body: str,
    replay_status: int,
    previous_records: list[RequestRecord],
    previous_responses: list[tuple[str, dict[str, str]]],
    subs: list[DependencyEdge],
    extracted: dict[str, str],
    all_rules: list[ExtractionRule],
) -> list[DependencyEdge]:
    """Try to repair ALL broken correlations for a failed request in one pass.

    Strategy:
    1. Build live response records once.
    2. For each correlated parameter:
       a. Try to find the recorded value in live responses.
       b. If not found, try the currently extracted value.
       c. If still not found, search by parameter NAME (csrf, token, etc.)
          in hidden inputs, meta tags, JSON fields of live responses.
       d. Extract the fresh value and update the extracted dict.
    3. Return all repaired edges so the retry uses ALL new values.
    """
    live_records = _build_live_records(previous_records, previous_responses)
    if not live_records:
        return []

    live_by_idx = {r.index: r for r in live_records}
    repaired: list[DependencyEdge] = []

    for edge in subs:
        recorded_value = edge.param_value
        current_value = extracted.get(edge.param_name, recorded_value)

        new_rule = find_extraction_source(
            recorded_value, live_records, edge.param_name
        )

        if new_rule is None and current_value != recorded_value:
            new_rule = find_extraction_source(
                current_value, live_records, edge.param_name
            )

        if new_rule is not None:
            source_rec = live_by_idx.get(new_rule.source_request_index)
            new_value = extract_value(new_rule, source_rec) if source_rec else None
            if new_value:
                edge.extraction_rule = new_rule
                extracted[edge.param_name] = new_value
                repaired.append(edge)
                continue

        name_value = _search_by_param_name(edge.param_name, live_records)
        if name_value:
            extracted[edge.param_name] = name_value
            repaired.append(edge)

    return repaired


def _search_by_param_name(param_name: str, live_records: list[RequestRecord]) -> str | None:
    """Fallback: search for a value by parameter name in live responses (newest first).

    Looks for the param_name as a hidden input name, meta tag name, or JSON key.
    """
    name_lower = param_name.lower()
    for record in reversed(live_records):
        body = record.response_body or ""
        if not body:
            continue

        for tag_match in _HIDDEN_INPUT_RE.finditer(body):
            tag = tag_match.group()
            name_m = _ATTR_NAME_RE.search(tag)
            val_m = _ATTR_VALUE_RE.search(tag)
            if name_m and val_m:
                if name_m.group(2).lower() == name_lower:
                    val = val_m.group(2)
                    if val and len(val) >= 4:
                        return val

        for tag_match in _META_CSRF_RE.finditer(body):
            meta_name = tag_match.group(1)
            if meta_name.lower() == name_lower:
                content_m = _ATTR_CONTENT_RE.search(tag_match.group())
                if content_m and content_m.group(2) and len(content_m.group(2)) >= 4:
                    return content_m.group(2)

        ct = (record.response_content_type or "").lower()
        if "json" in ct or body.lstrip()[:1] in ("{", "["):
            try:
                data = json.loads(body)
            except (json.JSONDecodeError, TypeError, ValueError):
                continue
            if isinstance(data, dict):
                val = _find_json_key(data, name_lower)
                if val:
                    return val

    return None


def _find_json_key(obj: Any, target_key: str, depth: int = 0) -> str | None:
    if depth > 5 or not isinstance(obj, dict):
        return None
    for key, value in obj.items():
        if key.lower() == target_key and isinstance(value, str) and len(value) >= 4:
            return value
        if isinstance(value, dict):
            found = _find_json_key(value, target_key, depth + 1)
            if found:
                return found
        elif isinstance(value, list):
            for item in value[:20]:
                if isinstance(item, dict):
                    found = _find_json_key(item, target_key, depth + 1)
                    if found:
                        return found
    return None


def _build_live_records(
    original_records: list[RequestRecord],
    live_responses: list[tuple[str, dict[str, str]]],
) -> list[RequestRecord]:
    """Build RequestRecord objects with live response bodies for repair search."""
    live: list[RequestRecord] = []
    for i, rec in enumerate(original_records):
        if i < len(live_responses):
            body, hdrs = live_responses[i]
            ct = hdrs.get("content-type", hdrs.get("Content-Type", ""))
            live.append(RequestRecord(
                index=rec.index,
                transaction_name=rec.transaction_name,
                method=rec.method,
                url=rec.url,
                headers=rec.headers,
                query_params=rec.query_params,
                payload=rec.payload,
                response_status=rec.response_status,
                response_headers=hdrs,
                response_body=body,
                response_content_type=ct,
            ))
        else:
            live.append(rec)
    return live


# ---------------------------------------------------------------------------
# Retry Controller
# ---------------------------------------------------------------------------

MAX_RETRIES = 3


def execute_step(session_obj: ReplaySession) -> StepResult:
    """Execute the next step in the replay session.

    Pipeline: execute → store response → extract parameters → compare →
    repair only if extraction failed → retry → next request with substitutions.
    """
    if session_obj.current_index >= len(session_obj.records):
        return StepResult(
            request_index=-1,
            transaction_name="",
            method="",
            url="",
            status="failed",
            error="No more requests to execute",
        )

    idx = session_obj.current_index
    record = session_obj.records[idx]
    step = session_obj.steps[idx]
    subs = session_obj._substitutions_by_target.get(record.index, [])

    previous_url = session_obj.steps[idx - 1].url if idx > 0 else ""

    step.status = "running"

    url, headers, payload, _kwarg = _apply_substitutions(record, subs, session_obj.extracted_values)
    step.url = url
    display_headers = _clean_replay_headers(headers)
    if record.method.upper() in ("POST", "PUT", "PATCH", "DELETE"):
        display_headers = _ensure_referer_origin(display_headers, url, previous_url)
    step.request_headers = display_headers
    step.request_payload = payload

    try:
        status_code, resp_headers, resp_body = execute_request(
            session_obj.http_session, record, subs, session_obj.extracted_values,
            previous_url=previous_url,
        )
    except Exception as e:
        step.status = "failed"
        step.error = str(e)
        session_obj.current_index += 1
        return step

    step.replay_status_code = status_code
    step.response_headers = resp_headers
    step.response_body = resp_body[:100_000]

    # --- Extract parameters IMMEDIATELY after every response ---
    live_rec = _build_live_record(record, status_code, resp_headers, resp_body)
    _extract_from_response(session_obj, record, live_rec)

    recorded_body = record.response_body or ""
    passed = compare_response(record.response_status, status_code, resp_body, recorded_body)

    if not passed:
        previous_records = session_obj.records[:idx]
        previous_responses = [
            (s.response_body, s.response_headers) for s in session_obj.steps[:idx]
            if s.response_body
        ]

        for retry in range(1, MAX_RETRIES + 1):
            step.retries = retry
            repaired = attempt_repair(
                record, resp_body, status_code,
                previous_records, previous_responses,
                subs, session_obj.extracted_values,
                session_obj.rules,
            )

            if not repaired:
                break

            step.repaired_rules = [
                {"param": e.param_name, "new_source": e.extraction_rule.source_type.value}
                for e in repaired
            ]

            try:
                url, headers, payload, _kwarg = _apply_substitutions(
                    record, subs, session_obj.extracted_values
                )
                step.url = url
                display_headers = _clean_replay_headers(headers)
                if record.method.upper() in ("POST", "PUT", "PATCH", "DELETE"):
                    display_headers = _ensure_referer_origin(display_headers, url, previous_url)
                step.request_headers = display_headers
                step.request_payload = payload

                status_code, resp_headers, resp_body = execute_request(
                    session_obj.http_session, record, subs, session_obj.extracted_values,
                    previous_url=previous_url,
                )
                step.replay_status_code = status_code
                step.response_headers = resp_headers
                step.response_body = resp_body[:100_000]
            except Exception as e:
                step.error = str(e)
                continue

            live_rec = _build_live_record(record, status_code, resp_headers, resp_body)
            _extract_from_response(session_obj, record, live_rec)

            if compare_response(record.response_status, status_code, resp_body, recorded_body):
                passed = True
                break

    step.status = "passed" if passed else "failed"
    if not passed and not step.error:
        step.error = f"Expected status {record.response_status}, got {status_code}"

    session_obj.current_index += 1
    return step


def step_to_dict(step: StepResult) -> dict:
    """Serialize a StepResult for the API response."""
    payload_serializable = step.request_payload
    if payload_serializable is not None:
        try:
            json.dumps(payload_serializable)
        except (TypeError, ValueError):
            payload_serializable = str(payload_serializable)

    return {
        "request_index": step.request_index,
        "transaction_name": step.transaction_name,
        "method": step.method,
        "url": step.url,
        "request_headers": step.request_headers,
        "request_payload": payload_serializable,
        "status": step.status,
        "replay_status_code": step.replay_status_code,
        "recorded_status_code": step.recorded_status_code,
        "response_headers": dict(step.response_headers) if step.response_headers else {},
        "response_body": step.response_body[:50_000],
        "error": step.error,
        "retries": step.retries,
        "repaired_rules": step.repaired_rules,
    }

"""Smart Parameter Namer — derive readable variable names from context, not raw values.

Instead of:   PROD_99281, eyJhbGciOiJ..., USR_7849302
Produces:     product_id,  auth_token,    user_id

Strategy (in priority order):
  1. Source JSON key  — the key in the source response (e.g. $.data.token → "token")
  2. Target key hint  — the key name where the value is consumed (e.g. Authorization → "auth_token")
  3. Value pattern    — regex-based heuristic on the value itself (JWT → "auth_token", UUID → "session_id")
  4. Fallback         — generic "param_N"

All names are de-duplicated with numeric suffixes if a collision occurs.
"""
from __future__ import annotations

import re

from .models import ExtractionRule, Parameter, ParamLocation, ParameterType, SourceType


_JSON_KEY_RENAMES: dict[str, str] = {
    "access_token": "auth_token",
    "accessToken": "auth_token",
    "id_token": "id_token",
    "idToken": "id_token",
    "refresh_token": "refresh_token",
    "refreshToken": "refresh_token",
    "csrf": "csrf_token",
    "csrfToken": "csrf_token",
    "xsrf": "xsrf_token",
}

_TARGET_KEY_RENAMES: dict[str, str] = {
    "authorization": "auth_token",
    "x-csrf-token": "csrf_token",
    "x-xsrf-token": "xsrf_token",
    "x-request-id": "request_id",
    "x-correlation-id": "correlation_id",
}

_VALUE_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"^eyJ[A-Za-z0-9_-]+\."), "auth_token"),
    (re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I), "session_id"),
    (re.compile(r"^[0-9a-f]{24,}$", re.I), "object_id"),
    (re.compile(r"^SESS[A-Za-z0-9]{10,}$"), "session_id"),
    (re.compile(r"^sid[_-]?[A-Za-z0-9]{8,}$", re.I), "session_id"),
    (re.compile(r"^tok[_-]?[A-Za-z0-9]{8,}$", re.I), "auth_token"),
    (re.compile(r"^[A-Z]{2,6}[_-]\d{4,}$"), "entity_id"),
]

_SEMANTIC_KEYWORDS: dict[str, str] = {
    "token": "token",
    "session": "session_id",
    "product": "product_id",
    "item": "item_id",
    "cart": "cart_id",
    "order": "order_id",
    "user": "user_id",
    "account": "account_id",
    "customer": "customer_id",
    "transaction": "transaction_id",
    "payment": "payment_id",
    "invoice": "invoice_id",
    "address": "address_id",
    "category": "category_id",
    "merchant": "merchant_id",
    "offer": "offer_id",
    "coupon": "coupon_id",
    "search": "search_id",
    "request": "request_id",
    "trace": "trace_id",
    "nonce": "nonce",
    "key": "api_key",
    "secret": "secret_key",
    "csrf": "csrf_token",
    "xsrf": "xsrf_token",
    "asin": "product_id",
}

_GENERIC_KEYS = frozenset(["id", "ID", "Id", "value", "val", "data", "key", "code", "name", "ref"])

_RESERVED_NAMES = frozenset([
    "session", "requests", "json", "re", "url", "headers", "payload",
    "response", "print", "main", "self", "True", "False", "None",
    "id", "type", "list", "dict", "str", "int", "float", "bool",
])


def _looks_like_raw_value(key: str) -> bool:
    """Return True if the key looks like a raw value (e.g. PROD_99281) not a field name."""
    if len(key) < 3:
        return True
    if re.match(r"^[A-Z]{2,6}[_-]\d{3,}$", key):
        return True
    if re.match(r"^[0-9a-fA-F-]{20,}$", key):
        return True
    return False


class ParamNameRegistry:
    """Tracks assigned names and prevents duplicates."""

    def __init__(self) -> None:
        self._used: dict[str, int] = {}

    def assign(
        self,
        candidate: Parameter,
        rule: ExtractionRule | None = None,
        usages: list[Parameter] | None = None,
    ) -> str:
        """Derive the best variable name for this parameter + rule + downstream usages."""
        raw = self._derive_raw_name(candidate, rule, usages)
        clean = self._sanitize(raw)
        unique = self._deduplicate(clean)
        return unique

    def _derive_raw_name(
        self,
        candidate: Parameter,
        rule: ExtractionRule | None,
        usages: list[Parameter] | None,
    ) -> str:
        # Priority 1: source JSON key (from extraction rule)
        if rule and rule.source_type == SourceType.JSON_PATH and rule.json_path:
            json_key = rule.json_path.rsplit(".", 1)[-1]
            json_key = re.sub(r"\[\d+\]", "", json_key)
            if json_key in _JSON_KEY_RENAMES:
                return _JSON_KEY_RENAMES[json_key]
            semantic = self._semantic_from_key(json_key)
            if semantic:
                return semantic
            if json_key and len(json_key) > 2:
                return self._to_snake(json_key)
            if json_key in _GENERIC_KEYS:
                better = self._name_from_usages(usages) or self._name_from_json_parent(rule.json_path)
                if better:
                    return better

        if rule and rule.source_key_name:
            semantic = self._semantic_from_key(rule.source_key_name)
            if semantic:
                return semantic

        # Priority 2: target key hints (from candidate + all downstream usages)
        best_target = self._name_from_usages(usages) if usages else None
        if not best_target:
            best_target = self._name_from_target_key(candidate)
        if best_target:
            return best_target

        # Priority 3: value-pattern heuristic
        for pattern, name in _VALUE_PATTERNS:
            if pattern.search(candidate.value):
                return name

        return "param"

    def _name_from_target_key(self, param: Parameter) -> str:
        """Try to derive a name from the target request key where the value is consumed."""
        target_key = param.key_name.lower()
        if target_key in _TARGET_KEY_RENAMES:
            return _TARGET_KEY_RENAMES[target_key]
        semantic = self._semantic_from_key(target_key)
        if semantic:
            return semantic
        if param.key_name and len(param.key_name) > 2 and not _looks_like_raw_value(param.key_name):
            return self._to_snake(param.key_name)
        return ""

    def _name_from_usages(self, usages: list[Parameter] | None) -> str:
        """Scan all usages for the most descriptive key name (prefer body/query keys)."""
        if not usages:
            return ""
        priority = [ParamLocation.BODY, ParamLocation.QUERY, ParamLocation.HEADER]
        for loc in priority:
            for u in usages:
                if u.location == loc and u.key_name and not _looks_like_raw_value(u.key_name):
                    semantic = self._semantic_from_key(u.key_name)
                    if semantic:
                        return semantic
                    if len(u.key_name) > 2:
                        return self._to_snake(u.key_name)
        return ""

    def _name_from_json_parent(self, json_path: str) -> str:
        """When the leaf key is generic ('id'), use the parent key for context.

        $.results[0].id  →  'results_id'
        $.data.item.id   →  'item_id'
        """
        parts = json_path.lstrip("$.").split(".")
        parts = [re.sub(r"\[\d+\]", "", p) for p in parts if p]
        if len(parts) < 2:
            return ""
        parent = parts[-2]
        leaf = parts[-1]
        if parent and leaf:
            combo = f"{parent}_{leaf}"
            semantic = self._semantic_from_key(combo)
            return semantic or self._to_snake(combo)
        return ""

    def _semantic_from_key(self, key: str) -> str:
        """Check if the key contains a known semantic keyword."""
        lower = key.lower().replace("-", "_")
        if lower in _SEMANTIC_KEYWORDS:
            return _SEMANTIC_KEYWORDS[lower]
        for kw, name in _SEMANTIC_KEYWORDS.items():
            if kw in lower:
                return name
        return ""

    def _to_snake(self, name: str) -> str:
        """Convert camelCase/PascalCase/kebab-case to snake_case."""
        s = name.replace("-", "_").replace(".", "_")
        s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
        s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s)
        return s.lower()

    def _sanitize(self, raw: str) -> str:
        s = re.sub(r"[^a-zA-Z0-9_]", "_", raw)
        s = re.sub(r"_+", "_", s).strip("_")
        if not s:
            s = "param"
        if s[0].isdigit():
            s = "p_" + s
        if s in _RESERVED_NAMES:
            s = "c_" + s
        return s[:40]

    def _deduplicate(self, name: str) -> str:
        if name not in self._used:
            self._used[name] = 1
            return name
        self._used[name] += 1
        unique = f"{name}_{self._used[name]}"
        while unique in self._used:
            self._used[name] += 1
            unique = f"{name}_{self._used[name]}"
        self._used[unique] = 1
        return unique

"""Confidence Scorer — assign a 0-100 confidence score to each extraction rule.

Five factors, each weighted 0-20 (normalized total = 100):

  1. Uniqueness     (0-20) — fewer occurrences in the response = higher confidence
                             that we're extracting the right instance.
  2. Key match      (0-20) — source JSON key semantically matches the target usage key
                             (e.g. source="token", target="Authorization" → high match).
  3. Position       (0-20) — JSON path extraction > header extraction > boundary.
                             Shallower JSON depth is more stable across API versions.
  4. Entropy        (0-20) — higher Shannon entropy = more likely a dynamic value
                             (tokens, UUIDs) vs. a static enum that happens to repeat.
  5. Dependency     (0-20) — more downstream usages = higher correlation importance.
                             A token feeding 5 requests is far more critical than a
                             value used once.

The final score = sum of all five factors, clamped to [0, 100].
"""
from __future__ import annotations

import math
import re
from collections import Counter

from .models import ExtractionRule, Parameter, ParameterUsage, SourceType

_W_UNIQUENESS = 20.0
_W_KEY_MATCH = 20.0
_W_POSITION = 20.0
_W_ENTROPY = 20.0
_W_DEPENDENCY = 20.0


_CSRF_NAME_KEYWORDS = frozenset(["csrf", "token", "auth", "nonce", "xsrf"])


def compute_confidence(
    rule: ExtractionRule,
    candidate: Parameter,
    usages: list[ParameterUsage],
) -> tuple[float, dict[str, float]]:
    """Return (score, breakdown_dict) for a given extraction rule."""
    s_uniq = _score_uniqueness(rule)
    s_key = _score_key_match(rule, candidate, usages)
    s_pos = _score_position(rule)
    s_ent = _score_entropy(rule.sample_value)
    s_dep = _score_dependency(usages)
    s_csrf = _score_csrf_name_boost(rule, candidate)

    total = round(s_uniq + s_key + s_pos + s_ent + s_dep + s_csrf, 1)
    total = max(0.0, min(100.0, total))

    breakdown = {
        "uniqueness": round(s_uniq, 1),
        "key_match": round(s_key, 1),
        "position": round(s_pos, 1),
        "entropy": round(s_ent, 1),
        "dependency": round(s_dep, 1),
        "csrf_boost": round(s_csrf, 1),
    }
    return total, breakdown


def _score_uniqueness(rule: ExtractionRule) -> float:
    """Fewer occurrences in the response body → higher score."""
    count = max(rule.occurrence_count, 1)
    if count == 1:
        return _W_UNIQUENESS
    if count == 2:
        return _W_UNIQUENESS * 0.7
    if count <= 5:
        return _W_UNIQUENESS * 0.4
    return _W_UNIQUENESS * 0.1


def _score_key_match(
    rule: ExtractionRule,
    candidate: Parameter,
    usages: list[ParameterUsage],
) -> float:
    """Source key semantically matches target key → high confidence this is the right value."""
    src_key = _normalise(rule.source_key_name)
    if not src_key:
        return _W_KEY_MATCH * 0.3

    target_keys: set[str] = set()
    target_keys.add(_normalise(candidate.key_name))
    for u in usages:
        target_keys.add(_normalise(u.key_name))
    target_keys.discard("")

    if not target_keys:
        return _W_KEY_MATCH * 0.3

    best = 0.0
    for tk in target_keys:
        sim = _key_similarity(src_key, tk)
        if sim > best:
            best = sim

    return _W_KEY_MATCH * best


def _score_position(rule: ExtractionRule) -> float:
    """Extraction method reliability.

    Strong sources (high confidence):
      JSON path  — structured, stable across runs
      HTML hidden inputs — precise anchoring via name/value attributes
      Response headers (non-cookie) — exact key-based extraction

    Weak sources (low confidence):
      Generic LB/RB boundary — fragile, breaks when surrounding text changes
    """
    if rule.source_type == SourceType.JSON_PATH:
        depth = rule.json_path.count(".") if rule.json_path else 1
        depth_penalty = min(depth - 1, 4) * 0.05
        return _W_POSITION * max(0.6, 1.0 - depth_penalty)
    if rule.source_type == SourceType.HEADER:
        return _W_POSITION * 0.9
    if rule.source_type == SourceType.HTML_HIDDEN:
        has_both = bool(rule.left_boundary and rule.right_boundary)
        return _W_POSITION * (0.9 if has_both else 0.6)
    if rule.source_type == SourceType.BOUNDARY:
        has_both = bool(rule.left_boundary and rule.right_boundary)
        lb = rule.left_boundary or ""
        rb = rule.right_boundary or ""
        if has_both and lb in ('"', "'") and rb in ('"', "'"):
            return _W_POSITION * 0.15
        return _W_POSITION * (0.35 if has_both else 0.15)
    return _W_POSITION * 0.1


def _score_entropy(value: str) -> float:
    """Higher Shannon entropy → more likely to be a genuinely dynamic value."""
    if not value:
        return 0.0
    ent = _shannon_entropy(value)
    if ent >= 4.5:
        return _W_ENTROPY
    if ent >= 3.5:
        return _W_ENTROPY * 0.8
    if ent >= 2.5:
        return _W_ENTROPY * 0.5
    if ent >= 1.5:
        return _W_ENTROPY * 0.3
    return _W_ENTROPY * 0.1


def _score_dependency(usages: list[ParameterUsage]) -> float:
    """More downstream requests consuming this value → higher importance."""
    unique_requests = len({u.request_index for u in usages})
    if unique_requests >= 5:
        return _W_DEPENDENCY
    if unique_requests >= 3:
        return _W_DEPENDENCY * 0.8
    if unique_requests == 2:
        return _W_DEPENDENCY * 0.5
    if unique_requests == 1:
        return _W_DEPENDENCY * 0.2
    return 0.0


def _score_csrf_name_boost(rule: ExtractionRule, candidate: Parameter) -> float:
    """Bonus for parameters whose names signal security tokens (csrf, token, auth, nonce)."""
    names_to_check = [
        _normalise(rule.param_name),
        _normalise(rule.source_key_name),
        _normalise(candidate.key_name),
    ]
    for name in names_to_check:
        if any(kw in name for kw in _CSRF_NAME_KEYWORDS):
            return 10.0
    return 0.0


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq = Counter(s)
    length = len(s)
    return -sum((c / length) * math.log2(c / length) for c in freq.values())


def _normalise(key: str) -> str:
    """Normalise a key name for comparison: lowercase, strip separators."""
    return re.sub(r"[^a-z0-9]", "", key.lower())


def _key_similarity(src: str, target: str) -> float:
    """Compute similarity between normalised source and target key names.

    Returns 0.0-1.0 where:
      1.0 = exact match
      0.8 = one contains the other
      0.6 = share a semantic root (token/auth, id/identifier)
      0.3 = default (no relation detected)
    """
    if src == target:
        return 1.0
    if src in target or target in src:
        return 0.8

    for group in _SEMANTIC_GROUPS:
        if any(kw in src for kw in group) and any(kw in target for kw in group):
            return 0.6

    return 0.3


_SEMANTIC_GROUPS: list[tuple[str, ...]] = [
    ("token", "auth", "bearer", "jwt", "access"),
    ("session", "sid", "sess"),
    ("id", "identifier", "ref", "key"),
    ("user", "usr", "account", "customer"),
    ("product", "item", "asin", "sku"),
    ("cart", "basket"),
    ("order", "purchase", "invoice"),
    ("csrf", "xsrf", "nonce"),
    ("page", "offset", "cursor", "next"),
]

"""Data models for the correlation engine."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ParamLocation(str, Enum):
    URL_PATH = "url_path"
    QUERY = "query"
    HEADER = "header"
    BODY = "body"
    COOKIE = "cookie"


class SourceType(str, Enum):
    JSON_PATH = "json_path"
    BOUNDARY = "boundary"
    HEADER = "header"
    COOKIE = "cookie"
    HTML_HIDDEN = "html_hidden"


class ParameterType(str, Enum):
    """Distinguishes how a parameter is handled in the final script.

    CORRELATION — value is extracted from a prior response and injected automatically.
                  The user never needs to touch these; the engine handles them.
    USER        — value must be supplied or configured by the user at runtime
                  (e.g. username, password, search keyword).  Implemented in later phases
                  but the slot is reserved now so scripts can represent both cleanly.
    """
    CORRELATION = "correlation"
    USER = "user"


@dataclass
class Parameter:
    """A single parameter value found in a request."""
    value: str
    request_index: int
    location: ParamLocation
    key_name: str
    full_path: str = ""
    param_type: ParameterType = ParameterType.CORRELATION


@dataclass
class ParameterUsage:
    """Where a dynamic parameter is consumed (in a later request)."""
    param_value: str
    request_index: int
    location: ParamLocation
    key_name: str
    full_path: str = ""
    param_type: ParameterType = ParameterType.CORRELATION


@dataclass
class ExtractionRule:
    """How to extract a dynamic value from an earlier response.

    Stores rich context so rules can be debugged / audited when the response
    format changes between recordings.
    """
    param_name: str
    param_type: ParameterType
    source_request_index: int
    source_type: SourceType

    # --- extraction instructions (only the relevant fields are populated) ---
    json_path: str = ""
    left_boundary: str = ""
    right_boundary: str = ""
    header_name: str = ""
    regex_pattern: str = ""

    # --- debugging / audit context ---
    source_key_name: str = ""
    sample_value: str = ""
    occurrence_count: int = 1
    response_hash: str = ""
    response_content_type: str = ""
    source_url: str = ""

    # --- confidence scoring ---
    confidence_score: float = 0.0
    confidence_breakdown: dict[str, float] = field(default_factory=dict)


@dataclass
class DependencyEdge:
    """A correlation link: value produced by source, consumed by target."""
    param_name: str
    param_value: str
    param_type: ParameterType
    source_request_index: int
    target_request_index: int
    extraction_rule: ExtractionRule
    usages: list[ParameterUsage] = field(default_factory=list)


@dataclass
class CorrelationResult:
    """Full output of the correlation engine."""
    edges: list[DependencyEdge]
    extraction_rules: list[ExtractionRule]
    request_count: int
    correlated_param_count: int
    uncorrelated_candidates: list[Parameter] = field(default_factory=list)
    user_params: list[Parameter] = field(default_factory=list)


@dataclass
class RequestRecord:
    """Normalised request+response pair used internally by the engine."""
    index: int
    transaction_name: str
    method: str
    url: str
    headers: dict[str, str]
    query_params: dict[str, list[str]]
    payload: Any
    response_status: int = 0
    response_headers: dict[str, str] = field(default_factory=dict)
    response_body: str = ""
    response_content_type: str = ""

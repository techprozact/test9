"""Candidate Detector — identify dynamic parameter values that originate from earlier responses.

Mimics how a performance engineer performs correlation:
  For each parameter in request N (N > 0), check if the value appears
  in any response body/headers of requests 0..N-1.  If found, that parameter
  is dynamic and needs an extraction rule.
"""
from __future__ import annotations

import re

from .models import Parameter, ParamLocation, RequestRecord


_ANALYTICS_COOKIE_PATTERNS = re.compile(
    r"^(_ga|_gid|_gat|_fbp|_fbc|__utm|__gads|_hjid|_hjSession|ajs_)",
    re.IGNORECASE,
)

_STATIC_VALUE_PATTERNS = frozenset([
    "true", "false", "null", "none", "undefined",
    "en_in", "en_us", "en_gb", "inr", "usd", "eur",
    "desktop", "mobile", "tablet",
    "xmlhttprequest", "application/json",
])

_BEARER_RE = re.compile(r"^Bearer\s+(.+)$", re.IGNORECASE)


def detect_candidates(
    all_params: list[Parameter],
    records: list[RequestRecord],
    min_value_length: int = 6,
) -> list[Parameter]:
    """Return parameters whose values appear in an earlier response (reverse-lookup).

    For each parameter extracted from request N, we search response bodies and
    headers of requests 0..N-1 for the raw value or a stripped variant (e.g.
    removing 'Bearer ' prefix).  Matches indicate the value is dynamic.
    """
    response_corpus: dict[int, str] = {}
    for r in records:
        corpus = r.response_body or ""
        for hk, hv in r.response_headers.items():
            if hk.lower() in ("set-cookie", "cookie"):
                continue
            corpus += " " + str(hv)
        response_corpus[r.index] = corpus

    candidates: list[Parameter] = []
    seen: set[tuple[str, int]] = set()

    for p in all_params:
        key = (p.value, p.request_index)
        if key in seen:
            continue
        seen.add(key)

        if p.request_index == 0:
            continue

        if p.location == ParamLocation.COOKIE:
            continue

        if not _passes_basic_filters(p, min_value_length):
            continue

        search_values = _get_search_variants(p)
        found = False
        for val in search_values:
            for earlier_idx in range(p.request_index):
                corpus = response_corpus.get(earlier_idx, "")
                if val in corpus:
                    found = True
                    if val != p.value:
                        candidates.append(Parameter(
                            value=val,
                            request_index=p.request_index,
                            location=p.location,
                            key_name=p.key_name,
                            full_path=p.full_path,
                        ))
                    else:
                        candidates.append(p)
                    break
            if found:
                break

    candidates = _deduplicate_candidates(candidates)
    return candidates


def _passes_basic_filters(param: Parameter, min_length: int) -> bool:
    val = param.value
    if len(val) < min_length:
        return False
    if val.lower() in _STATIC_VALUE_PATTERNS:
        return False
    if _ANALYTICS_COOKIE_PATTERNS.match(param.key_name):
        return False
    if val.isdigit() and len(val) < 8:
        return False
    return True


def _get_search_variants(param: Parameter) -> list[str]:
    """Return the raw value plus any stripped variants (e.g. without 'Bearer ' prefix)."""
    variants = [param.value]
    m = _BEARER_RE.match(param.value)
    if m:
        variants.append(m.group(1))
    if param.value.startswith("token="):
        variants.append(param.value[6:])
    return variants


def _deduplicate_candidates(candidates: list[Parameter]) -> list[Parameter]:
    """Keep only the first occurrence of each unique value."""
    seen: set[str] = set()
    out: list[Parameter] = []
    for c in candidates:
        if c.value not in seen:
            seen.add(c.value)
            out.append(c)
    return out


def find_usages(value: str, all_params: list[Parameter], source_request_index: int) -> list[Parameter]:
    """Find all places where a candidate value is used in requests AFTER the source.
    Cookie-location usages are excluded — requests.Session() manages cookies."""
    usages: list[Parameter] = []
    for p in all_params:
        if p.request_index <= source_request_index:
            continue
        if p.location == ParamLocation.COOKIE:
            continue
        if p.value == value:
            usages.append(p)
        elif value in p.value:
            usages.append(Parameter(
                value=value,
                request_index=p.request_index,
                location=p.location,
                key_name=p.key_name,
                full_path=p.full_path,
            ))
    return usages


def value_reused_in_later_requests(
    value: str,
    records: list[RequestRecord],
    source_request_index: int,
) -> bool:
    """Raw text scan: confirm *value* literally appears in a later request's
    URL, query parameters, body, or non-cookie headers.

    This is a stronger validation than parameter-based checks because it
    catches values embedded inside compound strings (e.g. Bearer tokens,
    path segments, concatenated query values).
    """
    import json as _json

    for r in records:
        if r.index <= source_request_index:
            continue

        if value in (r.url or ""):
            return True

        for qvals in (r.query_params or {}).values():
            for qv in qvals:
                if value in qv:
                    return True

        for hk, hv in (r.headers or {}).items():
            if hk.lower() in ("cookie", "set-cookie"):
                continue
            if value in str(hv):
                return True

        if r.payload:
            try:
                payload_text = _json.dumps(r.payload)
            except (TypeError, ValueError):
                payload_text = str(r.payload)
            if value in payload_text:
                return True

    return False

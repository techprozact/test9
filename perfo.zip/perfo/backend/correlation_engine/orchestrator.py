"""Orchestrator — run the full correlation pipeline on a script's transactions."""
from __future__ import annotations

from .models import CorrelationResult, RequestRecord
from .traverse_engine import build_request_records
from .dependency_graph import build_dependency_graph
from .replay_validator import dry_run_validate
from .script_generator import generate_correlated_script


def run_correlation(transactions: list[dict]) -> tuple[str, CorrelationResult]:
    """Run the full correlation pipeline.

    Args:
        transactions: list of transaction dicts from DB (with response data if available).

    Returns:
        (correlated_script, correlation_result)
    """
    records = build_request_records(transactions)
    if not records:
        return "", CorrelationResult(
            edges=[], extraction_rules=[], request_count=0,
            correlated_param_count=0, uncorrelated_candidates=[],
        )

    edges, rules, uncorrelated = build_dependency_graph(records)

    validation = dry_run_validate(records, edges, rules)

    result = CorrelationResult(
        edges=edges,
        extraction_rules=rules,
        request_count=len(records),
        correlated_param_count=len(rules),
        uncorrelated_candidates=uncorrelated,
    )

    script = generate_correlated_script(records, result)
    return script, result

"""Phase-2 Correlation Engine — detect dynamic parameters, build extraction rules, generate correlated scripts."""

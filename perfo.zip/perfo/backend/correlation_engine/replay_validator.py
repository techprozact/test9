"""Replay Validator — execute requests sequentially, extract dynamic values using rules, substitute into later requests.

This validates that the correlation rules actually work at replay time.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from .models import DependencyEdge, ExtractionRule, RequestRecord, SourceType


@dataclass
class ReplayResult:
    """Outcome of replaying the correlated script."""
    success: bool
    total_requests: int
    passed_requests: int
    failed_requests: int
    extracted_values: dict[str, str] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)


def dry_run_validate(
    records: list[RequestRecord],
    edges: list[DependencyEdge],
    rules: list[ExtractionRule],
) -> ReplayResult:
    """Validate extraction rules against the recorded responses (no live HTTP calls).

    For each rule, attempt to extract the expected value from the source response.
    Then verify it matches the value used in the target request.
    """
    extracted: dict[str, str] = {}
    errors: list[str] = []
    passed = 0
    failed = 0

    records_by_index = {r.index: r for r in records}

    for rule in rules:
        source = records_by_index.get(rule.source_request_index)
        if not source:
            errors.append(f"{rule.param_name}: source request {rule.source_request_index} not found")
            failed += 1
            continue

        value = extract_value(rule, source)
        if value is None:
            errors.append(f"{rule.param_name}: extraction failed from request {rule.source_request_index}")
            failed += 1
            continue

        extracted[rule.param_name] = value
        passed += 1

    return ReplayResult(
        success=failed == 0,
        total_requests=len(records),
        passed_requests=passed,
        failed_requests=failed,
        extracted_values=extracted,
        errors=errors,
    )


def extract_value(rule: ExtractionRule, source: RequestRecord) -> str | None:
    """Apply an extraction rule to a response and return the extracted value."""
    if rule.source_type == SourceType.JSON_PATH:
        return _extract_json_path(source.response_body, rule.json_path)
    elif rule.source_type == SourceType.HEADER:
        return source.response_headers.get(rule.header_name)
    elif rule.source_type == SourceType.BOUNDARY:
        return _extract_boundary(source.response_body, rule)
    return None


def _extract_json_path(body: str, json_path: str) -> str | None:
    """Extract a value by JSON path like $.data.token."""
    if not body or not json_path:
        return None
    try:
        data = json.loads(body)
    except (json.JSONDecodeError, TypeError, ValueError):
        return None

    parts = _parse_json_path(json_path)
    current: Any = data
    for part in parts:
        if isinstance(current, dict):
            if part in current:
                current = current[part]
            else:
                return None
        elif isinstance(current, list):
            try:
                idx = int(part)
                current = current[idx]
            except (ValueError, IndexError):
                return None
        else:
            return None

    if isinstance(current, str):
        return current
    if isinstance(current, (int, float)):
        return str(current)
    return None


def _parse_json_path(path: str) -> list[str]:
    """Parse $.foo.bar[0].baz into ['foo', 'bar', '0', 'baz']."""
    path = path.lstrip("$").lstrip(".")
    parts: list[str] = []
    for segment in re.split(r"\.|(?=\[)", path):
        if not segment:
            continue
        m = re.match(r"\[(\d+)\]", segment)
        if m:
            parts.append(m.group(1))
        else:
            parts.append(segment)
    return parts


def _extract_boundary(body: str, rule: ExtractionRule) -> str | None:
    if rule.regex_pattern:
        m = re.search(rule.regex_pattern, body)
        if m:
            return m.group(1)

    if rule.left_boundary and rule.right_boundary:
        lb_pos = body.find(rule.left_boundary)
        if lb_pos < 0:
            return None
        start = lb_pos + len(rule.left_boundary)
        rb_pos = body.find(rule.right_boundary, start)
        if rb_pos < 0:
            return None
        return body[start:rb_pos]

    return None

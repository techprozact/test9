#!/bin/bash
# Stop all processes using port 8000 and any uvicorn backend.main processes.
# Usage: ./scripts/stop-backends.sh

set -e

echo "Checking what is using port 8000..."
PIDS=$(lsof -t -i :8000 2>/dev/null || true)
if [ -n "$PIDS" ]; then
  echo "Killing process(es) on port 8000: $PIDS"
  echo "$PIDS" | xargs kill 2>/dev/null || echo "$PIDS" | xargs kill -9 2>/dev/null || true
  sleep 1
  echo "Done."
else
  echo "No process found on port 8000."
fi

echo "Stopping any uvicorn backend.main processes..."
pkill -f "uvicorn backend.main" 2>/dev/null && echo "Stopped uvicorn backend(s)." || echo "No uvicorn backend process found."
sleep 1

echo "Port 8000 status:"
lsof -i :8000 2>/dev/null || echo "Port 8000 is free."

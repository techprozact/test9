# Stop All perfSense Backends

## 1. Find what is using port 8000

```bash
lsof -i :8000
```

Example output:
```
COMMAND   PID   USER   FD   TYPE  DEVICE  SIZE/OFF  NODE  NAME
python    12345  you   3u   IPv4  ...     0t0      TCP  *:8000 (LISTEN)
```

The **PID** (e.g. `12345`) is the process to kill.

## 2. Kill the process on port 8000

```bash
# Replace 12345 with the PID from lsof
kill 12345
```

Or in one line (kills whatever is listening on 8000):

```bash
kill $(lsof -t -i :8000)
```

If it doesn’t exit, force kill:

```bash
kill -9 $(lsof -t -i :8000)
```

## 3. Find all uvicorn / backend Python processes

```bash
ps aux | grep uvicorn
ps aux | grep "backend.main"
```

Kill by PID, or kill all uvicorn processes (use with care):

```bash
pkill -f "uvicorn backend.main"
# or force
pkill -9 -f "uvicorn backend.main"
```

## 4. One-shot: free port 8000 and start a single backend

From the **perfSense** project root:

```bash
# Stop whatever is on 8000
lsof -t -i :8000 | xargs -r kill 2>/dev/null || true
# Optional: stop any uvicorn backend
pkill -f "uvicorn backend.main" 2>/dev/null || true
sleep 1

# Start one backend with MySQL
export DATABASE_URL="mysql+pymysql://root:xrbn2614@localhost:3306/xrbn_db"
PYTHONPATH=. uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

On macOS, `xargs -r` is not supported; use:

```bash
lsof -t -i :8000 | xargs kill 2>/dev/null; true
```

# perfSense — Comprehensive Application Documentation

> **Purpose of this document:** Complete technical reference for developers (including AI systems like Devin) to understand, extend, or port the perfSense application without prior context.

---

## Table of Contents

1. [Application Overview](#1-application-overview)
2. [Core Modules Explanation](#2-core-modules-explanation)
3. [Architecture Flow](#3-architecture-flow)
4. [Folder & File Structure](#4-folder--file-structure)
5. [Key Features](#5-key-features)
6. [Data Structures](#6-data-structures)
7. [Dependencies](#7-dependencies)
8. [Database Layer Analysis](#8-database-layer-analysis)
9. [Oracle Migration](#9-oracle-migration)
10. [How to Run](#10-how-to-run)
11. [Removed Modules](#11-removed-modules)

---

## 1. Application Overview

**perfSense** (also referred to as **PT0** internally) is a full-stack, locally-hosted API performance testing platform. It allows engineers to write, manage, execute, and analyse load tests entirely in their browser — no external cloud service, no k6/JMeter required.

### What It Does

| Capability | Description |
|---|---|
| **Script Builder (Perfzy)** | Build HTTP workflows visually: define requests, add auth, set variables, run single requests, extract dynamic values, and generate a ready-to-run Python script |
| **HAR Upload** | Upload a HAR file exported from the browser; the smart pipeline parses and groups requests into transactions, runs auto-correlation, and generates a Python script |
| **Load Designer** | Compose test scenarios: attach multiple scripts, configure VUser counts, pacing, think time, duration, ramp-up, and ramp-down curves |
| **Quick Test** | Run a scenario immediately from the browser; watch live real-time metrics (response time, TPS, hits/sec, error rate, VU count) as the test executes |
| **Perfora Guardian** | In-browser, real-time intelligence engine that monitors performance signals and raises lifecycle-based alerts (not spam notifications) during a live test |
| **Test Results** | Replay and explore all historical test telemetry with the same graphs as the live view; view Perfora Guardian post-test recommendations |
| **Dashboard** | Summary view: script/scenario/run counts, top slow APIs across all runs, recent run history, and headline Perfora finding for the last test |

### Primary Use Cases

- Private-environment load testing (no SaaS dependency — data never leaves the machine)
- Rapid API regression checks: build a script, run 5 minutes, check results
- Identifying slow endpoints across multiple services with a single scenario
- Post-test root-cause analysis via Perfora recommendations

---

## 2. Core Modules Explanation

### 2.1 Backend — `backend/`

#### `main.py`
**FastAPI application entry point.** Registers all routers, configures CORS (allows `localhost:3000` and `localhost:5173`), and sets up the shared DB store singleton via the `lifespan` context manager. All routers are mounted here.

#### `backend/api/perfzy_api.py`
**Perfzy script builder API.** Two endpoints:
- `POST /perfzy/execute` — executes a single HTTP request from the browser (proxied through the Python backend so CORS restrictions on the target API are bypassed). Offloads the synchronous `requests` call to a thread-pool executor to keep the uvicorn event loop free.
- `POST /perfzy/create-script` — takes a full Perfzy workflow definition (list of requests with auth, headers, payload, and extraction rules), generates a Python script, saves the script + each request as a transaction row in the DB, and returns the generated code.

#### `backend/api/execution_api.py`
**Load test lifecycle API.** Manages test runs end-to-end:
- `POST /executions` — starts a new test run; returns `test_run_id` immediately (non-blocking)
- `GET /executions` — lists all historical runs
- `GET /executions/{id}` — live snapshot when running (from in-memory controller), DB record when completed
- `POST /executions/{id}/stop` — graceful abort
- `GET /executions/{id}/summary` — aggregate KPIs (avg RT, p50, p95, error %, TPH)
- `GET /executions/{id}/telemetry` — paginated raw telemetry records
- `GET /executions/{id}/errors` — paginated failed-request logs
- `GET /executions/{id}/errors/download` — JSONL file download
- `DELETE /executions/{id}` — delete run + telemetry

#### `backend/api/scenario_api.py`
**Scenario CRUD.** Standard REST endpoints for creating, reading, updating, and deleting named test scenarios. Scenarios hold a JSON snapshot of script configs (users, pacing, think time, parameters).

#### `backend/api/upload_api.py`
**HAR file upload and script management API.** Accepts `.har` files, parses them via the smart pipeline, stores scripts and transactions in the DB, and exposes endpoints for script CRUD, transaction listing, Python script download, and auto-correlation.

#### `backend/engine/controller.py`
**Execution Controller — the heart of the load engine.** A state machine with phases: `INITIALIZING → RAMPING_UP → STEADY → RAMPING_DOWN → COMPLETED` (or `STOPPED` / `FAILED`). Runs a central deterministic 500 ms scheduler tick that:
1. Evaluates how many VUs should be alive at the current elapsed time
2. Spawns new VU tasks to meet the ramp-up target
3. Transitions between lifecycle phases
4. Triggers periodic DB status persistence

The global `_active_runs` dict maps `test_run_id → ExecutionController`, allowing the API layer to query live state during execution.

#### `backend/engine/virtual_user.py`
**Virtual User.** Each VU is an `asyncio` task using a shared `aiohttp.ClientSession`. It loops over script iterations until the `stop_event` is set. Each iteration runs every step to completion (no mid-iteration abort) to preserve logical flows like `login → cart → checkout → logout`. Think time is applied between steps; pacing is applied between full iterations.

#### `backend/engine/script_runner.py`
**Script flow loader and HTTP step executor.** `load_script_flow()` reads transaction rows from the DB and converts them into a `ScriptFlow` (ordered list of `RequestStep` objects). `execute_step()` fires the HTTP request via `aiohttp`, applies `{{param_name}}` substitution, runs correlation extraction rules (updating the per-iteration `context` dict in-place), logs failures to the error logger, and returns a `TelemetryRecord`.

#### `backend/engine/telemetry.py`
**Async telemetry buffer.** Accumulates `TelemetryRecord` objects in memory and batch-flushes to the DB store either on size threshold (200 records) or periodic interval (every 2 seconds). On test stop, it performs a forced drain with up to 3 retries to ensure no data is silently dropped.

#### `backend/engine/error_logger.py`
**Per-run error log writer.** Appends failed HTTP requests as JSONL lines to `backend/error_logs/{test_run_id}.jsonl`. Also provides paginated read and filtered download helpers. Auth headers are extracted and stored separately in each record for debugging.

#### `backend/perfzy/execution_engine.py`
**Single-request HTTP executor for Perfzy script builder.** Handles `{{variable}}` substitution across URLs, headers, and payloads. Supports four auth types (`bearer`, `basic`, `apikey`, `none`). Implements four extraction strategies (`json_path`, `header`, `regex`, `boundary`). The `suggest_extractions()` function scans JSON responses and returns up to 10 ranked correlation candidates using a scoring system based on key names and value patterns (UUIDs, tokens, IDs).

#### `backend/perfzy/script_generator.py`
**Python script code generator.** Takes a Perfzy workflow definition and emits a complete, runnable Python script using the `requests` library. Handles f-string generation for `{{variable}}` placeholders, per-request parameter substitutions in paths/queries, all payload types (JSON, urlencoded, multipart/form), and all extraction strategies as inline Python code. Emits a `main()` function that chains all steps with configurable think time.

#### `backend/db/db_connection.py`
**Database abstraction layer.** Auto-selects the best available backend at startup:
1. MySQL (via `DATABASE_URL` environment variable + `pymysql`)
2. Oracle (via `oracledb` + environment variables)
3. MongoDB (via `pymongo`, auto-detected at `localhost:27017`)
4. FileStore (JSON file at `backend/db/perfsense_data.json`) — **default for local dev**
5. InMemoryStore — last resort, data lost on restart

All five backends implement an identical interface (same method signatures), so the rest of the application is completely storage-agnostic.

#### `backend/services/script_parser_service.py`
**HAR upload orchestrator.** Coordinates HAR parsing via the smart pipeline, transaction extraction, and Python script generation. Used by the upload API.

#### `backend/correlation_engine/`
**Auto-correlation engine** (used for uploaded HAR scripts). Detects dynamic values in request/response pairs, suggests extraction rules, builds a dependency graph, and generates a correlated version of the script.

#### `backend/parsers/har_parser.py`
**HAR parser.** Parses browser HAR exports into a list of `TransactionBase` objects.

#### `backend/har/smart_pipeline.py`
**HAR ingestion pipeline.** Classifies, deduplicates, and groups HAR entries into logical transactions. Returns a structured `HarPipelineResult` containing transaction groups, base URL, and a summary report.

---

### 2.2 Frontend — `frontend/src/`

#### `main.jsx` / `App.jsx`
App entry point. Sets up React Router routes for all pages. All app pages live under `/app/*` (authenticated area). Landing page is at `/`.

#### `api.js`
**Frontend API client.** Single file containing all `fetch()` wrappers for every backend endpoint. Uses `API_BASE = 'http://localhost:8000'`. All functions are named exports. The base URL must be changed here when deploying to a different host/port.

#### `analytics/metricsEngine.js`
**Real-time metrics computation engine.** Ingests raw telemetry records from the backend polling loop and computes:
- Rolling window (default 5 s) metrics: avg response time, TPS, error %, VU count
- Cumulative stats: total requests, errors, overall avg RT
- Percentiles (p50, p90, p95, p99) using a bucketed histogram estimator (O(n) instead of O(n log n))
- EMA-smoothed graph series for stability
- Per-API and per-transaction breakdown stats
- Time-series data for all graph types

#### `analytics/useAnalytics.js`
**React hook** that bridges `metricsEngine.js` and `PerforaGuardian` with React state. Polls the backend telemetry endpoint, feeds records into the engine, exposes `chartData`, `apiStats`, `txStats`, `guardianAlerts`, `guardianRiskScore`, and `guardianSubtleHint` as reactive state.

#### `analytics/perforaGuardian.js`
**Perfora Guardian — live test intelligence engine.** Evaluates 10+ deterministic rules against rolling metrics every review cycle (60–90 s, 45 s for critical alerts). Maintains a lifecycle per alert (`NEW → OBSERVING → STABLE → RECURRING → RESOLVED`). Features: multi-interval confirmation, hysteresis (separate entry/exit thresholds), noise floors, adaptive review intervals, confidence escalation/downgrade, severity evolution, incident dominance grouping, retroactive reconciliation of fragmented alerts, composite system risk score (0–100), and subtle hint toasts for meaningful state changes.

#### `analytics/perforaPostAnalysis.js`
**Post-test analysis.** Runs once on completed test data to generate 8+ categories of findings (response time quality, error rates, throughput, capacity, tail latency, etc.) and an overall test verdict. Results are shown in the "Perfora Guardian" panel on the Test Results page and Dashboard.

#### `analytics/replayEngine.js`
**Historical telemetry replay.** Takes raw telemetry records from a completed test and computes the same graph data as the live engine, enabling the Test Results page to show identical charts to the Quick Test live view.

#### `analytics/pathNormalizer.js`
**URL path normalizer.** Replaces dynamic path segments (numeric IDs, UUIDs, tokens) with template placeholders (e.g. `/users/123` → `/users/{{user_id}}`) so per-API stats are aggregated correctly across VUs.

#### `pages/PerfzyPage.jsx`
**Perfzy script builder UI.** Multi-step workflow: define base URL → add requests → configure auth/headers/payload → execute request → review response → add extraction rules → generate script. Integrates with `perfzyExecute` and `perfzyCreateScript` API calls.

#### `pages/UploadPage.jsx`
**HAR upload UI.** Simple file picker that accepts `.har` files and calls the `POST /upload-script` endpoint. Displays the parsed transaction count and a link to view the generated script.

#### `pages/LoadDesignerPage.jsx`
**Load scenario designer UI.** CRUD interface for scenarios. Select scripts, assign VUser counts, configure timing. Saves to `/scenarios` API.

#### `pages/QuickTestPage.jsx`
**Live load test page.** Picks a scenario, starts a test, and displays live metrics via `useAnalytics` hook. Shows Perfora Guardian button/risk indicator above the Stop button. Renders the same `PerformanceTable` component as Test Results.

#### `pages/TestResultsPage.jsx`
**Historical test results page.** Lists all runs; click a run to replay it. Shows the same graphs, expanded tables, Perfora post-analysis panel, and error logs modal.

#### `pages/DashboardPage.jsx`
**Dashboard.** Aggregates data from scripts, scenarios, and executions APIs to show summary stats, recent runs, quick actions, and a headline Perfora finding card for the last test.

#### `components/PerformanceTable.jsx`
**Expandable graph + table component.** Used in both Quick Test and Test Results. Shows metric cards (small mode) that expand into a full graph with an individual-API/transaction table below it, with checkboxes controlling line visibility (LoadRunner-style).

#### `components/ErrorLogsModal.jsx`
**Error log viewer.** Paginated modal showing failed HTTP requests with full request/response details.

#### `context/ThemeContext.jsx`
**Dark/light theme provider.**

---

## 3. Architecture Flow

### 3.1 Perfzy Script Creation Flow

```
User defines request in PerfzyPage
    │
    ├─ POST /perfzy/execute  →  backend executes HTTP request via thread pool
    │       │
    │       └─ execution_engine.py: substitute variables → apply auth → fire request
    │               → extract values → suggest correlations
    │               → return: status, headers, body, elapsed_ms, extractions, suggestions
    │
    │  (User reviews response, confirms extractions, adds more requests)
    │
    └─ POST /perfzy/create-script  →  script_generator.py emits Python code
            │
            └─ DB: insert_script("perfzy") + save_python_script(code)
                    + insert_transaction() for each request
                    (transaction rows include extraction rules in response._extractions)
```

### 3.2 HAR Upload Flow

```
User uploads .har file in UploadPage
    │
    └─ POST /upload-script  →  script_parser_service.parse_upload()
            │
            ├─ detect_script_type() → "har"
            ├─ run_smart_har_pipeline() → HarPipelineResult
            │       - classify + deduplicate HAR entries
            │       - group into logical transactions
            │       - detect base URL
            │       - return summary report
            │
            ├─ DB: insert_script("har") + insert_transaction() for each entry
            └─ generate_python_script() → save to DB
```

### 3.3 Load Test Execution Flow

```
User picks scenario in QuickTestPage / LoadDesignerPage
    │
    └─ POST /executions  {scenario_id, scripts[], duration, ramp_up, ramp_down}
            │
            └─ controller.py: create ExecutionController → register in _active_runs
                    │
                    └─ asyncio.create_task(_wrapper) — background task, API returns test_run_id immediately
                            │
                    ┌───────┴──────────────────────────────────────────────┐
                    │         ExecutionController._initialize()             │
                    │  - DB: insert_test_run()                              │
                    │  - Load scripts: load_script_flow() for each script   │
                    │  - Create VU pool: create_virtual_users()             │
                    │  - Start TelemetryBuffer (async periodic flusher)     │
                    └───────┬──────────────────────────────────────────────┘
                            │
                    ┌───────┴──────────────────────────────────────────────┐
                    │         Scheduler tick loop (500ms)                   │
                    │  RAMPING_UP:                                           │
                    │    compute target_spawned = ceil(elapsed/ramp * total)│
                    │    spawn VU tasks up to target                        │
                    │  STEADY: all VUs running                              │
                    │  RAMPING_DOWN: set stop_event → VUs finish iteration  │
                    └───────┬──────────────────────────────────────────────┘
                            │
                    Each VirtualUser.run():
                    ┌───────┴──────────────────────────────────────────────┐
                    │  while not stop_event:                                │
                    │    context = copy(vu_parameters)                      │
                    │    for step in flow.steps:                            │
                    │      execute_step(session, step, context)             │
                    │        → substitute {{params}} in URL/headers/payload │
                    │        → aiohttp.request()                            │
                    │        → if not success: error_logger.log_error()     │
                    │        → run extraction rules → update context{}      │
                    │        → TelemetryBuffer.record(TelemetryRecord)      │
                    │      if not last_step: await asyncio.sleep(think_time)│
                    │    await asyncio.sleep(pacing)                        │
                    └───────┬──────────────────────────────────────────────┘
                            │
                    TelemetryBuffer flush (every 200 records or 2s):
                        DB.insert_telemetry_batch(records[])
                            │
                    On stop: finalize() → DB.update_test_run(COMPLETED/STOPPED)
                             unregister_controller(test_run_id)
```

### 3.4 Live Metrics Flow (Frontend)

```
QuickTestPage mounts → useAnalytics hook starts
    │
    └─ Poll every 5s: GET /executions/{id}/telemetry?offset=N
            │
            └─ metricsEngine.ingestInterval(newRecords):
                    - Add to rolling window
                    - Compute avg RT, TPS, error%, active VUs
                    - Update bucketed histogram → p50/p90/p95/p99
                    - EMA smooth graph series
                    - Update per-API and per-transaction rolling stats
                    │
                    └─ PerforaGuardian.evaluate(metrics):
                            - Check 10+ rules against rolling window + cumulative data
                            - Create/update/resolve alert lifecycle objects
                            - Emit subtle hint if meaningful state change
                            │
                            └─ React state updates → re-render charts + cards
```

### 3.5 Test Results / Historical Replay Flow

```
User clicks run in TestResultsPage
    │
    └─ GET /executions/{id}/telemetry  (full dataset, paginated + merged)
            │
            └─ replayEngine.replayTelemetry(records):
                    - Group records by 5s buckets
                    - Compute same metrics as live engine
                    - Return chartData, apiStats, txStats
                    │
                    └─ perforaPostAnalysis.analyzeTestResults(apiStats, summary):
                            - Evaluate 8+ finding categories
                            - computeVerdict() → overall health badge
                            - Return findings[] for the Perfora panel
```

---

## 4. Folder & File Structure

```
perfSense/
├── README.md                          # Quick-start guide
├── application_info.md                # This document
├── oracle_schema.sql                  # Oracle DDL (see Section 9)
│
├── backend/                           # Python FastAPI backend
│   ├── main.py                        # App entry: router registration, lifespan
│   ├── requirements.txt               # Python dependencies
│   │
│   ├── api/                           # HTTP route handlers
│   │   ├── perfzy_api.py              # Perfzy execute + create-script endpoints
│   │   ├── execution_api.py           # Load test lifecycle endpoints
│   │   ├── scenario_api.py            # Scenario CRUD
│   │   ├── upload_api.py              # HAR file upload + script management endpoints
│   │   └── delay_api.py               # Temp delay endpoints (engine validation)
│   │
│   ├── engine/                        # Load execution engine
│   │   ├── controller.py              # ExecutionController state machine + scheduler
│   │   ├── virtual_user.py            # VirtualUser async task + factory
│   │   ├── script_runner.py           # ScriptFlow loader + execute_step()
│   │   ├── telemetry.py               # TelemetryBuffer + TelemetryRecord
│   │   └── error_logger.py            # Per-run JSONL error log writer/reader
│   │
│   ├── perfzy/                        # Perfzy script builder core
│   │   ├── execution_engine.py        # Single-request executor + extraction + suggestions
│   │   └── script_generator.py        # Python code generator
│   │
│   ├── db/                            # Database abstraction layer
│   │   ├── db_connection.py           # FileStore/InMemory/MySQL/Oracle/MongoDB stores
│   │   └── migrations/
│   │       ├── run_mysql_migration.py # Create MySQL tables
│   │       └── run_mysql_alter_payload.py  # Add response column migration
│   │
│   ├── correlation_engine/            # Auto-correlation for uploaded HAR scripts
│   │   ├── orchestrator.py            # Pipeline coordinator
│   │   ├── candidate_detector.py      # Detect dynamic values
│   │   ├── dependency_graph.py        # Build extraction dependency graph
│   │   ├── script_generator.py        # Generate correlated script
│   │   ├── models.py                  # Data models
│   │   ├── confidence.py              # Confidence scoring
│   │   ├── boundary_marker.py         # Boundary extraction helper
│   │   ├── param_namer.py             # Name extracted parameters
│   │   ├── traverse_engine.py         # HAR/transaction traversal
│   │   ├── replay_executor.py         # Replay requests for validation
│   │   └── replay_validator.py        # Validate replayed responses
│   │
│   ├── parsers/                       # Script file format parsers
│   │   └── har_parser.py              # HAR (browser export)
│   │
│   ├── har/
│   │   └── smart_pipeline.py          # HAR ingestion pipeline
│   │
│   ├── models/                        # Pydantic/data models
│   │   ├── script_model.py
│   │   └── transaction_model.py
│   │
│   ├── services/
│   │   └── script_parser_service.py   # HAR parsing orchestration service
│   │
│   ├── utils/
│   │   ├── python_script_generator.py # Generic Python script generation utilities
│   │   └── script_type_detector.py    # Detect file type (HAR only)
│   │
│   ├── error_logs/                    # Auto-created; per-run JSONL error files
│
├── frontend/                          # React/Vite SPA
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx                   # React entry point
│       ├── App.jsx                    # Router + route definitions
│       ├── api.js                     # All fetch() wrappers (API_BASE = localhost:8000)
│       ├── index.css                  # Global styles
│       │
│       ├── analytics/                 # Frontend analytics pipeline
│       │   ├── metricsEngine.js       # Real-time metrics computation
│       │   ├── useAnalytics.js        # React hook: polls + processes telemetry
│       │   ├── perforaGuardian.js     # Live test intelligence + alert lifecycle
│       │   ├── perforaPostAnalysis.js # Post-test findings + verdict
│       │   ├── replayEngine.js        # Historical telemetry replay
│       │   └── pathNormalizer.js      # URL path parameterization
│       │
│       ├── pages/                     # Page components
│       │   ├── DashboardPage.jsx      # /app — summary + recent runs
│       │   ├── PerfzyPage.jsx         # /app/perfzy — script builder
│       │   ├── UploadPage.jsx         # /app/upload — HAR file upload
│       │   ├── LoadDesignerPage.jsx   # /app/load-designer — scenario designer
│       │   ├── QuickTestPage.jsx      # /app/quick-test — live test runner
│       │   ├── TestResultsPage.jsx    # /app/test-results — historical results
│       │   ├── ScriptListPage.jsx     # /app/scripts — script list/manage
│       │   ├── ScriptPreviewPage.jsx  # /app/scripts/:id — script detail
│       │   └── landing/               # Public landing page (/)
│       │
│       ├── components/                # Shared UI components
│       │   ├── Layout.jsx             # App shell: sidebar + nav + theme toggle
│       │   ├── PerformanceTable.jsx   # Expandable metric card + graph + API table
│       │   ├── ErrorLogsModal.jsx     # Paginated error log viewer
│       │   └── ScriptValidatorModal.jsx # Script replay validation UI
│       │
│       └── context/
│           ├── ThemeContext.jsx        # Dark/light theme provider
│           └── LayoutContext.jsx       # Sidebar state provider
│
└── data/
    └── browsers/                      # (unused — Playwright removed)
```

---

## 5. Key Features

### 5.1 Variable Substitution (`{{variable_name}}`)

Placeholders of the form `{{name}}` are used throughout scripts and are substituted at runtime.

**In Perfzy (single-request mode):**
- `substitute(text, variables)` replaces all `{{name}}` tokens in a string
- `substitute_dict(obj, variables)` recursively handles nested dicts/lists

**In the load engine (VU iteration mode):**
- `_substitute_params(text, parameters)` in `script_runner.py`
- Per-VU parameter dicts are built from the scenario's `parameters` map
- Values extracted from a previous step (e.g. `access_token` from a login response) are accumulated in the per-iteration `context` dict and available for all subsequent steps

**In the code generator:**
- `{{var}}` becomes an f-string `{var}` in the emitted Python code
- The generator detects whether a string contains vars and wraps it in `f"..."` accordingly

### 5.2 Authentication Handling

Supported auth types:

| Type | How Applied |
|---|---|
| `bearer` | Adds `Authorization: Bearer {token}` header |
| `basic` | Base64-encodes `username:password`, adds `Authorization: Basic {encoded}` |
| `apikey` | Adds a custom header `{key}: {value}` (header location only) |
| `none` | No auth header added |

Auth is applied after variable substitution, so `{{auth_token}}` can be used as the bearer token value.

### 5.3 Extraction Logic

Four extraction strategies, specified per-request in the `extractions` list:

| Source | Expression Format | Example |
|---|---|---|
| `json_path` | Dot-path from `$` | `$.data.access_token` or `data.user.id` |
| `header` | Header name (case-insensitive) | `X-Auth-Token` |
| `regex` | Python regex with optional capture group | `"token":"([^"]+)"` |
| `boundary` | `LB=<left_boundary>;;RB=<right_boundary>` | `LB="token":";;RB="` |

Extracted values are stored by name (e.g. `access_token`) and injected into `{{access_token}}` placeholders in subsequent requests within the same VU iteration.

### 5.4 Auto-Correlation Suggestions

`suggest_extractions()` in `execution_engine.py` scans a JSON response body and returns up to 10 ranked extraction candidates. Scoring algorithm:

- **Key score** (0–10): based on exact matches (e.g. `id`, `token`, `session`), auth fragments, snake_case ID suffixes (`_id`, `_token`, `_uuid`), camelCase suffixes (`Id`, `Token`, `Uuid`)
- **Value score** (0–10): UUID format = 10, long token (≥20 chars) = 9, integer ≠ 0 = 8, string ≥ 4 chars = 5
- Final score = key_score + value_score + depth_bonus (shallower = higher)
- Deduplicated by key name (highest-scored path wins)

Header-based suggestions are appended for auth-related headers (containing `token`, `auth`, `session`, etc.)

### 5.5 Script Generation

`generate_perfzy_script()` emits a complete Python file with:
- `BASE_URL` constant
- `session = requests.Session()` shared across all functions
- Parameters section with all configurable inputs
- One function per request step, named from the request name (sanitized to valid Python identifier)
- `main()` function chaining all steps with `time.sleep(think_time)` between them
- `if __name__ == "__main__": main()` block

The generated script is both runnable standalone (`python script.py`) and directly executable by the load engine (via the transaction rows in the DB — the Python file is for download/reference only).

### 5.6 Perfora Guardian Rules

10 built-in rules evaluated each review cycle:

| Rule Code | Trigger Condition | Severity |
|---|---|---|
| `LATENCY_GROWTH` | Avg RT increasing with positive slope over rolling window | WARNING |
| `HIGH_ERROR_RATE` | Cumulative error rate ≥ 5% (entry), < 2% (exit) | CRITICAL |
| `ERROR_BURST` | Rolling error spike ≥ 15% AND cumulative < 0.5% | WARNING |
| `TPS_STALL` | TPS drops significantly below peak despite stable VUs | WARNING |
| `CAPACITY_KNEE` | p95 diverging sharply from p50 (tail latency explosion) | CRITICAL |
| `HIGH_TX_ERROR` | Single transaction error rate ≥ 30% + traffic weight ≥ 10% | CRITICAL |
| `ERROR_TREND` | Cumulative error rate rising ≥ 1% over recent intervals | WARNING |
| `INSTABILITY` | High coefficient of variation in response times | INFO |
| `LOW_LOAD` | VUs well below target during steady state | INFO |
| `P95_SPIKE` | p95 latency exceeds absolute threshold | WARNING |

**Alert lifecycle states:** `NEW → OBSERVING → STABLE → RECURRING → RESOLVED`

**Confidence levels:** `LOW → MEDIUM → HIGH` (escalates over review cycles, downgrades on improvement)

**Incident dominance:** When `HIGH_TX_ERROR` is active for an endpoint, global error alerts (`HIGH_ERROR_RATE`, `ERROR_TREND`) are suppressed and converted to impact notes on the primary alert card.

---

## 6. Data Structures

### 6.1 `TelemetryRecord` (backend)

```python
TelemetryRecord:
    test_run_id:        str   # UUID of the test run
    script_id:          str   # ID of the script being executed
    virtual_user_id:    str   # e.g. "s1_vu3" (script 1, VU 3)
    iteration:          int   # which iteration of the VU loop
    iteration_id:       str   # unique per-iteration UUID-based ID
    sequence_number:    int   # position of this request within the iteration
    request_start_ts:   datetime
    request_end_ts:     datetime
    response_time_ms:   int
    http_status_code:   int
    success:            bool  # True if 2xx/3xx
    error_message:      str
    request_method:     str   # GET, POST, etc.
    api_path:           str   # normalized URL path
    bytes_sent:         int
    bytes_received:     int
```

### 6.2 `ExecutionResult` (Perfzy single-request)

```python
ExecutionResult:
    status_code:           int
    headers:               dict[str, str]
    body:                  str        # truncated at 500,000 chars
    elapsed_ms:            float
    extracted_values:      dict[str, str]   # name → extracted value
    suggested_extractions: list[dict]       # ranked correlation candidates
    error:                 str
    sent_url:              str        # final URL after variable substitution
    sent_method:           str
    sent_headers:          dict[str, str]
    sent_payload:          Any
```

### 6.3 `ExtractionDef`

```python
ExtractionDef:
    name:       str   # variable name to store extracted value
    source:     str   # "json_path" | "header" | "regex" | "boundary"
    expression: str   # path/header name/pattern/boundary expression
```

### 6.4 `ScriptFlow` / `RequestStep`

```python
ScriptFlow:
    script_id:   str
    script_name: str
    steps:       list[RequestStep]

RequestStep:
    execution_order: int
    method:          str
    url:             str          # may contain {{param_name}} placeholders
    headers:         dict[str, str]
    payload:         Any          # parsed JSON dict, form dict, or raw string
    payload_kwarg:   str          # "json" | "data" | ""
    extractions:     list[dict]   # correlation rules persisted from script creation
```

### 6.5 Guardian Alert Object (frontend, perforaGuardian.js)

```javascript
{
  id:                 string,   // unique alert ID
  ruleCode:           string,   // e.g. "HIGH_TX_ERROR"
  severity:           string,   // "critical" | "warning" | "info"
  firstDetectedAt:    number,   // epoch ms
  lastObservedAt:     number,
  state:              string,   // "NEW" | "OBSERVING" | "STABLE" | "RECURRING" | "RESOLVED"
  statusMessage:      string,   // human-readable narrative
  recurrenceCount:    number,
  confidenceLevel:    string,   // "LOW" | "MEDIUM" | "HIGH"
  activeDurationSecs: number,
  stableDurationSecs: number,
  isPrimary:          boolean,  // true = root-cause incident
  impactNotes:        string[], // secondary signals absorbed into this alert
  fastReviewCyclesRemaining: number,
}
```

### 6.6 API Input/Output Formats

**POST /executions request:**
```json
{
  "scenario_id": "uuid",
  "scripts": [
    {
      "script_id": "1",
      "script_name": "Login Flow",
      "users": 10,
      "pacing": "2s",
      "think_time": "500ms",
      "parameters": { "username": ["user1","user2",...] }
    }
  ],
  "duration": "5m",
  "ramp_up": "30s",
  "ramp_down": "15s"
}
```

**GET /executions/{id}/summary response:**
```json
{
  "total_requests": 12450,
  "total_errors": 62,
  "avg_rt": 187,
  "tph": 8964,
  "ux_variance": 340,
  "error_pct": 0.5,
  "p50": 145,
  "p95": 485
}
```

**POST /perfzy/execute request:**
```json
{
  "method": "POST",
  "url": "https://api.example.com/auth/login",
  "headers": { "Content-Type": "application/json" },
  "payload": { "username": "{{username}}", "password": "{{password}}" },
  "payload_type": "json",
  "auth_type": "none",
  "variables": { "username": "testuser", "password": "secret" },
  "extractions": [
    { "name": "access_token", "source": "json_path", "expression": "$.data.token" }
  ]
}
```

---

## 7. Dependencies

### 7.1 Backend Python Dependencies

See `backend/requirements.txt`. Cleaned and annotated version:

```text
# Web framework
fastapi>=0.104.0
uvicorn[standard]>=0.24.0
python-multipart>=0.0.6   # required for file upload (multipart/form-data)
pydantic>=2.0.0

# HTTP clients
aiohttp>=3.9.0            # used by virtual user engine (async, high concurrency)
requests>=2.31.0          # used by Perfzy single-request executor (sync, thread pool)

# Database drivers (install only what you need)
pymysql>=1.1.0            # MySQL support (recommended for production)
pymongo>=4.5.0            # MongoDB support (optional)
# oracledb is not in requirements — install manually: pip install oracledb

# Script parsing utilities
regex>=2023.0.0
```

### 7.2 Frontend JavaScript Dependencies

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "react-router-dom": "^6.20.0",   // routing
  "recharts": "^3.8.0",            // live and historical charts
  "lucide-react": "^0.577.0",      // icons
  "motion": "^12.36.0",            // animations (framer-motion)
  "tw-animate-css": "^1.4.0"       // Tailwind animation utilities
}
```

Dev dependencies: `vite`, `@vitejs/plugin-react`, `tailwindcss`, `@tailwindcss/vite`

---

## 8. Database Layer Analysis

### 8.1 Overview

All database access is routed through the store abstraction in `db_connection.py`. Five backend implementations share an identical interface. The active backend is selected at startup based on available drivers and environment variables.

**Priority order:**
1. MySQL (if `DATABASE_URL` env var is set and `pymysql` is installed)
2. Oracle (if `oracledb` is installed and `ORACLE_DSN`/`ORACLE_USER`/`ORACLE_PASSWORD` are set)
3. MongoDB (if `pymongo` is installed and MongoDB is reachable at `localhost:27017`)
4. FileStore (default — JSON file at `backend/db/perfsense_data.json`)
5. InMemoryStore (last resort — data lost on process restart)

### 8.2 Tables / Collections

#### `scripts`
Stores metadata for each performance script.

| Column | Type | Description |
|---|---|---|
| `id` | INT AUTO_INCREMENT / PK | Unique script identifier |
| `script_name` | VARCHAR(500) | Human-readable name |
| `script_type` | VARCHAR(50) | `"perfzy"` / `"har"` |
| `upload_time` | DATETIME(6) | When the script was created |

#### `transactions`
Each row is one HTTP request step within a script, ordered by `execution_order`.

| Column | Type | Description |
|---|---|---|
| `id` | INT AUTO_INCREMENT / PK | Unique transaction ID |
| `script_id` | VARCHAR(50) | FK → scripts.id |
| `transaction_name` | VARCHAR(500) | Step name (e.g. "Login", "Add to Cart") |
| `request_url` | VARCHAR(4000) | Full URL (may contain `{{param}}` placeholders) |
| `http_method` | VARCHAR(20) | GET / POST / PUT / DELETE / PATCH |
| `headers` | LONGTEXT | JSON-serialized headers dict |
| `payload` | LONGTEXT | JSON-serialized request body (null if GET) |
| `execution_order` | INT | 1-based position within the script |
| `response` | LONGTEXT | JSON object containing `_extractions` rules (set at script creation) |

#### `python_scripts`
Stores the generated Python source code for each script.

| Column | Type | Description |
|---|---|---|
| `script_id` | VARCHAR(50) / PK | FK → scripts.id |
| `code` | LONGTEXT | Complete Python script content |

#### `scenarios`
Named test scenario configurations.

| Column | Type | Description |
|---|---|---|
| `id` | VARCHAR(36) / UUID / PK | Scenario UUID |
| `scenario_name` | VARCHAR(500) | Display name |
| `description` | TEXT | Optional description |
| `duration` | VARCHAR(50) | Steady-state duration (e.g. `"5m"`, `"300s"`) |
| `ramp_up` | VARCHAR(50) | Ramp-up time (e.g. `"30s"`) |
| `ramp_down` | VARCHAR(50) | Ramp-down time (e.g. `"15s"`) |
| `scripts_json` | LONGTEXT | JSON array of script config objects |
| `created_at` | DATETIME(6) | |
| `updated_at` | DATETIME(6) | |

#### `test_runs`
One row per load test execution.

| Column | Type | Description |
|---|---|---|
| `id` | VARCHAR(36) / UUID / PK | Test run UUID |
| `scenario_id` | VARCHAR(50) | FK → scenarios.id (may be empty for ad-hoc runs) |
| `scenario_snapshot` | LONGTEXT | JSON snapshot of config at execution time |
| `status` | VARCHAR(30) | `INITIALIZING / RAMPING_UP / STEADY / RAMPING_DOWN / COMPLETED / STOPPED / FAILED` |
| `start_time` | DATETIME(6) | Wall-clock start |
| `end_time` | DATETIME(6) | Wall-clock end (null if still running) |
| `planned_duration_secs` | INT | Steady-state seconds only |
| `ramp_up_secs` | INT | |
| `ramp_down_secs` | INT | |
| `total_users_target` | INT | Sum of all script VUser counts |
| `total_users_spawned` | INT | Updated every 2 seconds during ramp-up |
| `engine_node_id` | VARCHAR(100) | `"local"` (future: distributed nodes) |
| `error_message` | TEXT | Failure reason if status = FAILED |
| `created_at` | DATETIME(6) | |

#### `request_telemetry`
One row per HTTP request executed by any VU during a test. High-volume table.

| Column | Type | Description |
|---|---|---|
| `id` | BIGINT AUTO_INCREMENT / PK | |
| `test_run_id` | VARCHAR(36) | FK → test_runs.id |
| `script_id` | VARCHAR(50) | Which script this request belongs to |
| `virtual_user_id` | VARCHAR(100) | e.g. `"s1_vu3"` |
| `iteration` | INT | VU loop iteration number |
| `iteration_id` | VARCHAR(80) | Unique per-iteration ID for flow tracing |
| `sequence_number` | INT | 1-based position within the iteration |
| `request_start_ts` | DATETIME(6) | When request was sent |
| `request_end_ts` | DATETIME(6) | When response was received |
| `response_time_ms` | INT | End-to-end latency in milliseconds |
| `http_status_code` | INT | HTTP response status |
| `success` | TINYINT(1) | 1 = 2xx/3xx, 0 = error |
| `error_message` | TEXT | Network/timeout error message |
| `request_method` | VARCHAR(10) | HTTP method |
| `api_path` | VARCHAR(2000) | URL path (normalized by `pathNormalizer`) |
| `bytes_sent` | INT | |
| `bytes_received` | INT | |

**Indexes on `request_telemetry`:**
- `idx_telemetry_run (test_run_id)` — primary access pattern
- `idx_telemetry_run_script (test_run_id, script_id)` — per-script filtering
- `idx_telemetry_ts (test_run_id, request_start_ts)` — time-ordered queries
- `idx_telemetry_iteration (test_run_id, iteration_id)` — iteration tracing

### 8.3 Relationships

```
scripts (1) ──< transactions (many)
scripts (1) ──  python_scripts (1:1)
scenarios (1) ──< test_runs (many)  [loose FK — not enforced in DB]
test_runs (1) ──< request_telemetry (many)
test_runs (1) ──  error_logs/{id}.jsonl  [filesystem, not in DB]
```

---

## 9. Oracle Migration

See the companion file `oracle_schema.sql` in the project root. It contains Oracle-compatible DDL for all five tables with appropriate data types, sequences, triggers for auto-increment, and indexes.

---

## 10. How to Run

### Prerequisites

| Requirement | Version |
|---|---|
| Python | 3.10+ |
| Node.js | 18+ |
| npm | 9+ |
| (Optional) MySQL | 8.0+ |

---

### Setting Up on a New Machine

> **Note:** The `venv/` and `frontend/node_modules/` directories are not included in the repository. You must recreate them on any new machine before starting the app. Follow all steps below in order.

#### Step 1: Navigate to the Project Root

```bash
cd /path/to/perfo
```

All subsequent commands must be run from this root directory.

#### Step 2: Create Python Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate       # macOS / Linux
# venv\Scripts\activate        # Windows
```

#### Step 3: Install Python Dependencies

```bash
pip install -r backend/requirements.txt
```

#### Step 4: Install Frontend Dependencies

```bash
cd frontend
npm install
cd ..
```

#### Step 5: Start the Backend

Open a terminal in the project root and run:

```bash
source venv/bin/activate       # if not already activated
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

Backend is now running at `http://localhost:8000`
- API docs: `http://localhost:8000/docs`
- Health check: `http://localhost:8000/health`

#### Step 6: Start the Frontend

Open a **second terminal** in the project root and run:

```bash
cd frontend
npm run dev
```

Frontend runs at **`http://localhost:3000`** (configured via `vite.config.js`).

#### Step 7: Open the Application

Navigate to **`http://localhost:3000`** in your browser. This is the main entry point.

**First-time workflow:**
1. Go to **API Studio** → build an API script via Perfzy
2. — OR — Go to **Upload HAR** → upload a `.har` file exported from your browser DevTools
3. Go to **Load Designer** → create a load scenario referencing your script
4. Go to **Quick Test** → select the scenario → click **Start Test**
5. Watch live metrics in real time
6. After test completes → go to **Test Results** → view replay and Perfora analysis

---

### (Optional) Configure MySQL for Persistent Storage

By default, data is stored in `backend/db/perfsense_data.json` (FileStore — no setup required). To use MySQL instead:

```bash
export DATABASE_URL="mysql+pymysql://root:yourpassword@localhost:3306/perfsense_db"

# Run migration once to create all tables:
PYTHONPATH=. python -m backend.db.migrations.run_mysql_migration
```

Then restart the backend — it will automatically detect and use MySQL.

---

### Environment Variables Reference

| Variable | Default | Description |
|---|---|---|
| `DATABASE_URL` | (none) | MySQL connection string: `mysql+pymysql://user:pass@host:port/db` |
| `ORACLE_DSN` | `localhost:1521/XE` | Oracle connection DSN |
| `ORACLE_USER` | `perfsense` | Oracle username |
| `ORACLE_PASSWORD` | `perfsense` | Oracle password |
| `PYTHONPATH` | (none) | Must include project root so `backend.*` imports resolve |

---

### Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'backend'` | Set `PYTHONPATH=.` or run from project root |
| `Address already in use` on port 8000 | Run `lsof -ti :8000 \| xargs kill -9` then restart backend |
| `Address already in use` on port 3000 | Run `lsof -ti :3000 \| xargs kill -9` then restart frontend |
| `Script not found` on execution | Ensure MySQL migration has been run, or use FileStore (default) |
| Frontend can't reach backend | Check CORS config in `main.py`; verify backend is on port 8000 |
| `npm install` fails | Ensure Node.js 18+ is installed: `node --version` |
| `pip install` fails | Ensure Python 3.10+ and venv is activated: `python3 --version` |

---

## 11. Removed Modules

The following modules were removed in the enterprise-safe simplification pass. They are **not present** in the codebase.

### 11.1 Browser Flow Recorder

**Removed files:**
- `backend/recorder/` (entire directory: `cdp_recorder.py`, `proxy_recorder.py`)
- `backend/api/recorder_api.py`
- `frontend/src/pages/RecordPage.jsx`
- All recorder-related API functions removed from `frontend/src/api.js`
- "Flow Recorder" nav item removed from sidebar

**Reason:** Required `mitmproxy`, `websockets`, and headless Chrome DevTools Protocol — external tooling with enterprise security and compliance concerns.

### 11.2 JMeter and LoadRunner Script Parsers

**Removed files:**
- `backend/parsers/jmeter_parser.py`
- `backend/parsers/loadrunner_parser.py`

**What remains:** HAR parsing only (`backend/parsers/har_parser.py`). The upload endpoint (`POST /upload-script`) now exclusively accepts `.har` files.

**Reason:** JMeter `.jmx` XML parsing required `lxml`/`xmltodict`. LoadRunner `.c`/`.txt` parsing was heuristic-based and not needed for the core HAR-driven workflow. Removing these simplifies the parser surface area.

### 11.3 PDF Report Generator

**Removed files:**
- `backend/engine/report_generator.py`

**Removed endpoint:**
- `GET /executions/{id}/report` (PDF download)

**Frontend changes:**
- "Download Results" (PDF) button removed from `TestResultsPage.jsx`

**Reason:** Required Playwright + headless Chromium (~300 MB binary). Unacceptable dependency weight for an enterprise-internal tool. Test result data is still fully available via the interactive replay UI and the error log download (`GET /executions/{id}/errors/download`).

### 11.4 Removed Python Dependencies

| Package | Was Used For |
|---|---|
| `playwright` | PDF report generation |
| `mitmproxy` | Proxy-based browser recorder |
| `websockets` | Recorder WebSocket signaling |
| `lxml` | JMeter `.jmx` XML parsing |
| `xmltodict` | JMeter `.jmx` XML parsing |

-- =============================================================================
-- perfSense / PT0 — Oracle Database Schema
-- =============================================================================
-- Compatible with: Oracle 12c+ (12.2+), Oracle 18c, Oracle 19c, Oracle 21c
--
-- Usage:
--   sqlplus perfsense/perfsense@localhost:1521/XE @oracle_schema.sql
--
-- Notes:
--   1. All sequences + triggers implement AUTO_INCREMENT behaviour (pre-12c style).
--      On Oracle 12c+ you may use IDENTITY columns instead — see comments.
--   2. LONGTEXT (MySQL) → CLOB (Oracle)
--   3. VARCHAR(4000) is the maximum for Oracle VARCHAR2; longer values use CLOB.
--   4. DATETIME(6) → TIMESTAMP(6) WITH TIME ZONE
--   5. TINYINT(1) boolean → NUMBER(1,0) CHECK IN (0,1)
--   6. UUIDs are stored as VARCHAR2(36); generation is handled by the application.
--   7. Run this file exactly once on a fresh schema.  Re-running is safe because
--      all statements use CREATE ... IF NOT EXISTS equivalents via EXECUTE IMMEDIATE
--      inside the anonymous blocks.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Utility: helper procedure to ignore "table/sequence/trigger already exists"
-- errors so the script can be safely re-run.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE drop_if_exists(p_name VARCHAR2, p_type VARCHAR2)
AS
BEGIN
    IF p_type = 'TABLE' THEN
        EXECUTE IMMEDIATE 'DROP TABLE ' || p_name || ' CASCADE CONSTRAINTS PURGE';
    ELSIF p_type = 'SEQUENCE' THEN
        EXECUTE IMMEDIATE 'DROP SEQUENCE ' || p_name;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE IN (-942, -2289) THEN NULL; -- table/sequence does not exist
        ELSE RAISE;
        END IF;
END;
/


-- =============================================================================
-- TABLE: scripts
-- Stores metadata for each performance script (Perfzy, HAR, JMeter, LoadRunner).
-- =============================================================================
BEGIN drop_if_exists('scripts', 'TABLE'); END;
/
BEGIN drop_if_exists('seq_scripts_id', 'SEQUENCE'); END;
/

CREATE TABLE scripts (
    id              NUMBER(10,0)     NOT NULL,
    script_name     VARCHAR2(500)    NOT NULL,
    script_type     VARCHAR2(50)     NOT NULL,   -- 'perfzy' | 'har' | 'jmeter' | 'loadrunner'
    upload_time     TIMESTAMP(6) WITH TIME ZONE
                        DEFAULT SYSTIMESTAMP      NOT NULL,
    CONSTRAINT pk_scripts PRIMARY KEY (id)
);

-- Oracle 12c+ alternative (comment out the trigger below if using this):
-- id NUMBER(10,0) GENERATED ALWAYS AS IDENTITY,

CREATE SEQUENCE seq_scripts_id START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

CREATE OR REPLACE TRIGGER trg_scripts_id
BEFORE INSERT ON scripts
FOR EACH ROW
BEGIN
    IF :NEW.id IS NULL THEN
        :NEW.id := seq_scripts_id.NEXTVAL;
    END IF;
END;
/

CREATE INDEX idx_scripts_upload_time ON scripts (upload_time);
CREATE INDEX idx_scripts_type        ON scripts (script_type);


-- =============================================================================
-- TABLE: transactions
-- Each row is one ordered HTTP request step within a script.
-- High cardinality: a single script may have dozens of transactions.
-- =============================================================================
BEGIN drop_if_exists('transactions', 'TABLE'); END;
/
BEGIN drop_if_exists('seq_transactions_id', 'SEQUENCE'); END;
/

CREATE TABLE transactions (
    id                  NUMBER(10,0)    NOT NULL,
    script_id           VARCHAR2(50)    NOT NULL,   -- FK → scripts.id (loose)
    transaction_name    VARCHAR2(500)   NOT NULL,
    request_url         VARCHAR2(4000)  NOT NULL,   -- may contain {{param}} placeholders
    http_method         VARCHAR2(20)    NOT NULL,   -- GET | POST | PUT | DELETE | PATCH
    headers             CLOB,                        -- JSON dict of request headers
    payload             CLOB,                        -- JSON-serialized request body
    execution_order     NUMBER(6,0)     NOT NULL,   -- 1-based position within the script
    response            CLOB,                        -- JSON with _extractions[] rules
    CONSTRAINT pk_transactions PRIMARY KEY (id)
);

CREATE SEQUENCE seq_transactions_id START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

CREATE OR REPLACE TRIGGER trg_transactions_id
BEFORE INSERT ON transactions
FOR EACH ROW
BEGIN
    IF :NEW.id IS NULL THEN
        :NEW.id := seq_transactions_id.NEXTVAL;
    END IF;
END;
/

-- Indexes for access patterns used by load_script_flow()
CREATE INDEX idx_tx_script_id    ON transactions (script_id);
CREATE INDEX idx_tx_script_order ON transactions (script_id, execution_order);

-- Optional: add CLOB check constraint to enforce JSON format (Oracle 21c+)
-- ALTER TABLE transactions ADD CONSTRAINT chk_tx_headers  CHECK (headers  IS JSON);
-- ALTER TABLE transactions ADD CONSTRAINT chk_tx_payload  CHECK (payload  IS JSON);
-- ALTER TABLE transactions ADD CONSTRAINT chk_tx_response CHECK (response IS JSON);


-- =============================================================================
-- TABLE: python_scripts
-- Stores generated Python source code (one row per script).
-- =============================================================================
BEGIN drop_if_exists('python_scripts', 'TABLE'); END;
/

CREATE TABLE python_scripts (
    script_id   VARCHAR2(50)    NOT NULL,   -- PK + FK → scripts.id (loose)
    code        CLOB            NOT NULL,   -- complete Python script content
    CONSTRAINT pk_python_scripts PRIMARY KEY (script_id)
);


-- =============================================================================
-- TABLE: scenarios
-- Named test scenario configurations (Load Designer output).
-- =============================================================================
BEGIN drop_if_exists('scenarios', 'TABLE'); END;
/

CREATE TABLE scenarios (
    id              VARCHAR2(36)    NOT NULL,   -- UUID generated by application
    scenario_name   VARCHAR2(500)   NOT NULL,
    description     CLOB,
    duration        VARCHAR2(50)    DEFAULT '5m'    NOT NULL,   -- e.g. '5m', '300s'
    ramp_up         VARCHAR2(50)    DEFAULT '30s'   NOT NULL,
    ramp_down       VARCHAR2(50)    DEFAULT '15s'   NOT NULL,
    scripts_json    CLOB,                                        -- JSON array of script configs
    created_at      TIMESTAMP(6) WITH TIME ZONE
                        DEFAULT SYSTIMESTAMP        NOT NULL,
    updated_at      TIMESTAMP(6) WITH TIME ZONE
                        DEFAULT SYSTIMESTAMP        NOT NULL,
    CONSTRAINT pk_scenarios PRIMARY KEY (id)
);

CREATE INDEX idx_scenarios_created ON scenarios (created_at);

-- Trigger to keep updated_at current
CREATE OR REPLACE TRIGGER trg_scenarios_upd
BEFORE UPDATE ON scenarios
FOR EACH ROW
BEGIN
    :NEW.updated_at := SYSTIMESTAMP;
END;
/


-- =============================================================================
-- TABLE: test_runs
-- One row per load test execution; status column tracks lifecycle phases.
-- =============================================================================
BEGIN drop_if_exists('test_runs', 'TABLE'); END;
/

CREATE TABLE test_runs (
    id                      VARCHAR2(36)    NOT NULL,   -- UUID from ExecutionController
    scenario_id             VARCHAR2(50),               -- FK → scenarios.id (loose, may be empty)
    scenario_snapshot       CLOB,                        -- JSON config snapshot at execution time
    status                  VARCHAR2(30)    NOT NULL,   -- see valid values below
    start_time              TIMESTAMP(6) WITH TIME ZONE,
    end_time                TIMESTAMP(6) WITH TIME ZONE,
    planned_duration_secs   NUMBER(8,0)     DEFAULT 0,  -- steady-state duration only
    ramp_up_secs            NUMBER(6,0)     DEFAULT 0,
    ramp_down_secs          NUMBER(6,0)     DEFAULT 0,
    total_users_target      NUMBER(6,0)     DEFAULT 0,
    total_users_spawned     NUMBER(6,0)     DEFAULT 0,
    engine_node_id          VARCHAR2(100)   DEFAULT 'local',
    error_message           CLOB,
    created_at              TIMESTAMP(6) WITH TIME ZONE
                                DEFAULT SYSTIMESTAMP    NOT NULL,
    CONSTRAINT pk_test_runs PRIMARY KEY (id),
    CONSTRAINT chk_run_status CHECK (
        status IN (
            'INITIALIZING', 'RAMPING_UP', 'STEADY',
            'RAMPING_DOWN', 'COMPLETED', 'STOPPED', 'FAILED', 'ABORTED'
        )
    )
);

CREATE INDEX idx_run_scenario    ON test_runs (scenario_id);
CREATE INDEX idx_run_status      ON test_runs (status);
CREATE INDEX idx_run_created     ON test_runs (created_at DESC);
CREATE INDEX idx_run_start_time  ON test_runs (start_time DESC);


-- =============================================================================
-- TABLE: request_telemetry
-- High-volume table: one row per HTTP request executed by any VU.
-- A 5-minute test with 50 VUs × 1 req/s × 10 steps ≈ 150,000 rows.
-- =============================================================================
BEGIN drop_if_exists('request_telemetry', 'TABLE'); END;
/
BEGIN drop_if_exists('seq_telemetry_id', 'SEQUENCE'); END;
/

CREATE TABLE request_telemetry (
    id                  NUMBER(19,0)    NOT NULL,
    test_run_id         VARCHAR2(36)    NOT NULL,   -- FK → test_runs.id
    script_id           VARCHAR2(50)    NOT NULL,
    virtual_user_id     VARCHAR2(100)   NOT NULL,   -- e.g. 's1_vu3'
    iteration           NUMBER(10,0)    NOT NULL,
    iteration_id        VARCHAR2(80),               -- unique per-iteration UUID-based ID
    sequence_number     NUMBER(6,0)     DEFAULT 0,  -- 1-based position within iteration
    request_start_ts    TIMESTAMP(6) WITH TIME ZONE NOT NULL,
    request_end_ts      TIMESTAMP(6) WITH TIME ZONE NOT NULL,
    response_time_ms    NUMBER(10,0)    NOT NULL,   -- end-to-end latency in ms
    http_status_code    NUMBER(6,0)     DEFAULT 0,
    success             NUMBER(1,0)     DEFAULT 0   NOT NULL, -- 0=fail, 1=success
    error_message       VARCHAR2(500),
    request_method      VARCHAR2(10),               -- GET | POST | PUT | DELETE | PATCH
    api_path            VARCHAR2(2000),              -- normalized URL path
    bytes_sent          NUMBER(12,0)    DEFAULT 0,
    bytes_received      NUMBER(12,0)    DEFAULT 0,
    CONSTRAINT pk_request_telemetry     PRIMARY KEY (id),
    CONSTRAINT chk_telemetry_success    CHECK (success IN (0, 1)),
    CONSTRAINT chk_telemetry_rt_pos     CHECK (response_time_ms >= 0)
);

CREATE SEQUENCE seq_telemetry_id START WITH 1 INCREMENT BY 1 CACHE 100 NOCYCLE;

CREATE OR REPLACE TRIGGER trg_telemetry_id
BEFORE INSERT ON request_telemetry
FOR EACH ROW
BEGIN
    IF :NEW.id IS NULL THEN
        :NEW.id := seq_telemetry_id.NEXTVAL;
    END IF;
END;
/

-- Primary access pattern: all telemetry for a run
CREATE INDEX idx_tel_run          ON request_telemetry (test_run_id);

-- Per-script filtering (for script-level analytics)
CREATE INDEX idx_tel_run_script   ON request_telemetry (test_run_id, script_id);

-- Time-ordered queries (graph series computation)
CREATE INDEX idx_tel_ts           ON request_telemetry (test_run_id, request_start_ts);

-- Iteration tracing (full flow replay)
CREATE INDEX idx_tel_iteration    ON request_telemetry (test_run_id, iteration_id);

-- Path-based grouping (per-API stats)
CREATE INDEX idx_tel_path         ON request_telemetry (test_run_id, api_path);

-- Success/failure filtering
CREATE INDEX idx_tel_success      ON request_telemetry (test_run_id, success);


-- =============================================================================
-- Oracle Application User Setup (run as SYSDBA if creating a fresh user)
-- =============================================================================
-- The lines below are commented out — uncomment and run as DBA if needed.
--
-- CREATE USER perfsense IDENTIFIED BY perfsense_password
--     DEFAULT TABLESPACE USERS
--     TEMPORARY TABLESPACE TEMP
--     QUOTA UNLIMITED ON USERS;
--
-- GRANT CREATE SESSION TO perfsense;
-- GRANT CREATE TABLE TO perfsense;
-- GRANT CREATE SEQUENCE TO perfsense;
-- GRANT CREATE TRIGGER TO perfsense;
-- GRANT CREATE PROCEDURE TO perfsense;
-- GRANT CREATE VIEW TO perfsense;
--


-- =============================================================================
-- Verification query — run after DDL to confirm all objects exist
-- =============================================================================
SELECT
    object_name,
    object_type,
    status
FROM
    user_objects
WHERE
    object_type IN ('TABLE', 'SEQUENCE', 'TRIGGER', 'INDEX')
ORDER BY
    object_type, object_name;


-- =============================================================================
-- Summary of created objects
-- =============================================================================
-- Tables (5):
--   scripts, transactions, python_scripts, scenarios, test_runs, request_telemetry
--
-- Sequences (3):
--   seq_scripts_id, seq_transactions_id, seq_telemetry_id
--
-- Triggers (4):
--   trg_scripts_id, trg_transactions_id, trg_scenarios_upd, trg_telemetry_id
--
-- Indexes (12):
--   idx_scripts_upload_time, idx_scripts_type
--   idx_tx_script_id, idx_tx_script_order
--   idx_scenarios_created
--   idx_run_scenario, idx_run_status, idx_run_created, idx_run_start_time
--   idx_tel_run, idx_tel_run_script, idx_tel_ts, idx_tel_iteration,
--   idx_tel_path, idx_tel_success
-- =============================================================================

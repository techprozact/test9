import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 3000,
    proxy: {
      '/upload-script': 'http://localhost:8000',
      // Only proxy actual API calls under /scripts/<id>/... (not the bare /scripts page)
      '/scripts/': 'http://localhost:8000',
    },
  },
})

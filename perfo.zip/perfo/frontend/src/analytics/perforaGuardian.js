/**
 * Perfora Guardian — Local Runtime Intelligence Engine  (v6)
 *
 * ISSUE-CENTRIC LIFECYCLE MODEL
 * ─────────────────────────────
 * Each rule produces exactly ONE living alert object that evolves through:
 *
 *   NEW → OBSERVING → STABLE → RECURRING → OBSERVING → STABLE → RESOLVED
 *
 * After RESOLVED, a fresh NEW lifecycle is created if the rule fires again.
 *
 * Refinements in v5:
 *   1. Adaptive review interval — phase-aware (60s ramp / 90s steady)
 *   2. Confidence escalation — LOW → MEDIUM → HIGH across review cycles
 *   3. Severity evolution — alert severity updates dynamically without new alert
 *   4. RESOLVED vs REOPEN — RESOLVED triggers NEW (not RECURRING)
 *   5. Correlation suppression — dominance pairs suppress redundant alerts
 *   6. Duration precision — activeDurationSecs / stableDurationSecs only in review
 *
 * Refinements in v6:
 *   7. Confidence downgrade — severity drop or near-exit threshold reduces confidence
 *   8. Signal-strength-aware suppression — suppressor must be ≥ child severity + not LOW confidence
 *   9. Fast-review window — CRITICAL alerts get 3 review cycles at 45 s, then revert
 *  10. Composite risk score — severity weight × confidence multiplier + duration factor
 *
 * Callbacks:
 *   onAlertChange(alerts[])            – fired whenever any alert changes
 *   onToast(alert)                     – fired ONLY for NEW creation + RECURRING transition
 *   onSubtleHint({ direction, label }) – fired when substantial improvement/degradation
 *                                        is detected (risk-tier cross, RESOLVED, STABLE,
 *                                        or critical severity escalation). Has a 90-second
 *                                        per-direction cooldown to stay non-spammy.
 */

// ── Noise floors ──────────────────────────────────────────────────────────
const NOISE = {
  MIN_RT_MS:               20,
  MIN_RT_FOR_GROWTH:       50,
  MIN_TPS_FOR_DROP:         3,
  MIN_VU_FOR_CAPACITY:     10,
  MIN_CUMULATIVE_REQS:     30,
  MIN_REQUESTS_FOR_TX_ERR: 10,
}

// ── Per-rule metadata ─────────────────────────────────────────────────────
const RULE_META = {
  LATENCY_SPIKE:     { severity: 'critical', confirm: 2, exitConfirm: 1, risk: 35 },
  LATENCY_GROWTH:    { severity: 'warning',  confirm: 2, exitConfirm: 2, risk: 15 },
  TAIL_LATENCY:      { severity: 'warning',  confirm: 2, exitConfirm: 2, risk: 10 },
  HIGH_P95:          { severity: 'warning',  confirm: 2, exitConfirm: 2, risk: 15 },
  SUSTAINED_HIGH_RT: { severity: 'warning',  confirm: 1, exitConfirm: 2, risk: 20 },
  CAPACITY_KNEE:     { severity: 'warning',  confirm: 2, exitConfirm: 2, risk: 25 },
  TPS_DROP:          { severity: 'warning',  confirm: 2, exitConfirm: 2, risk: 15 },
  TPS_STALL:         { severity: 'critical', confirm: 1, exitConfirm: 1, risk: 45 },
  ERROR_BURST:       { severity: 'critical', confirm: 1, exitConfirm: 1, risk: 30 },
  HIGH_ERROR_RATE:   { severity: 'critical', confirm: 2, exitConfirm: 2, risk: 40 },
  HIGH_TX_ERROR:     { severity: 'warning',  confirm: 2, exitConfirm: 2, risk: 20 },
  ERROR_TREND:       { severity: 'critical', confirm: 1, exitConfirm: 2, risk: 35 },
  INSTABILITY:       { severity: 'warning',  confirm: 3, exitConfirm: 3, risk: 10 },
  LOW_LOAD:          { severity: 'info',     confirm: 3, exitConfirm: 2, risk: 0  },
}

// ── Correlation suppression map ───────────────────────────────────────────
// { child: [parentRules] } — child is suppressed when ANY parent rule is active
const CORRELATION_SUPPRESS = {
  LATENCY_GROWTH: ['CAPACITY_KNEE'],
  ERROR_BURST:    ['HIGH_ERROR_RATE'],
  LOW_LOAD:       ['TPS_STALL'],
  INSTABILITY:    ['TPS_STALL'],
}

const RULE_KEYS = Object.keys(RULE_META)
const SEV_RANK  = { critical: 3, warning: 2, info: 1 }

// Inactive duration thresholds
const RESOLVE_AFTER_MS       = 600_000  // 10 minutes → RESOLVED
const STABLE_REVIEW_THRESHOLD = 2        // consecutive inactive review cycles → STABLE

// Confidence escalation thresholds (in review cycles while active)
const CONF_MEDIUM_AFTER = 1   // 1st review cycle active  → MEDIUM
const CONF_HIGH_AFTER   = 3   // 3rd review cycle active  → HIGH

// ── Math helpers ───────────────────────────────────────────────────────────
function _pct(a, b)   { return (!a || a <= 0) ? 0 : ((b - a) / a) * 100 }
function _mean(arr)   { return arr.length ? arr.reduce((s, v) => s + v, 0) / arr.length : 0 }
function _stddev(arr) {
  if (arr.length < 2) return 0
  const m = _mean(arr)
  return Math.sqrt(arr.reduce((s, v) => s + (v - m) ** 2, 0) / arr.length)
}
function _fmtMins(secs) {
  const m = Math.max(1, Math.round(secs / 60))
  return `${m} min${m !== 1 ? 's' : ''}`
}
function _confLabel(level) {
  return level === 'HIGH' ? 'HIGH' : level === 'MEDIUM' ? 'MEDIUM' : 'LOW'
}

// ── Fresh rule-engine state ────────────────────────────────────────────────
function _freshRuleState() {
  const o = k => Object.fromEntries(RULE_KEYS.map(r => [r, k]))
  return {
    ruleActive:   o(false),
    confirmCount: o(0),
    exitCount:    o(0),
    ruleBaseline: o(null),
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export class PerforaGuardian {
  /**
   * @param {{ windowSize?, onAlertChange?, onToast?, onSubtleHint? }} opts
   *   onAlertChange(alerts[])            – fired on any alert change
   *   onToast(alert)                     – fired only for NEW creation + RECURRING transition
   *   onSubtleHint({ direction, label }) – fired for substantial improvement / degradation
   */
  constructor({ windowSize = 5, onAlertChange, onToast, onSubtleHint } = {}) {
    this.windowSize          = windowSize
    this._onAlertChange      = onAlertChange  || null
    this._onToast            = onToast        || null
    this._onSubtleHint       = onSubtleHint   || null

    this._buffer             = []
    this._alerts             = {}      // ruleCode → alert object
    this._domRank            = 0
    this._active             = false
    this._startMs            = 0
    this._lastReviewMs       = 0
    this._latestMetric       = null    // v6: snapshot of most recent metric (used in review)
    this._computedRiskScore  = 0       // v6: updated only during review cycle
    this._prevRiskTier       = -1      // -1 = unset; 0=Low 1=Moderate 2=High 3=Critical
    this._hintCooldownEnd    = { degradation: 0, improvement: 0 }

    this._stableReviewCount  = {}
    this._inactiveStartMs    = {}

    Object.assign(this, _freshRuleState())
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  start() {
    this._active             = true
    this._buffer             = []
    this._alerts             = {}
    this._domRank            = 0
    this._startMs            = Date.now()
    this._lastReviewMs       = Date.now()
    this._latestMetric       = null
    this._computedRiskScore  = 0
    this._prevRiskTier       = -1
    this._hintCooldownEnd    = { degradation: 0, improvement: 0 }
    this._stableReviewCount  = {}
    this._inactiveStartMs    = {}
    Object.assign(this, _freshRuleState())
  }

  stop()  { this._active = false }

  reset() {
    this._active             = false
    this._buffer             = []
    this._alerts             = {}
    this._domRank            = 0
    this._latestMetric       = null
    this._computedRiskScore  = 0
    this._prevRiskTier       = -1
    this._hintCooldownEnd    = { degradation: 0, improvement: 0 }
    this._stableReviewCount  = {}
    this._inactiveStartMs    = {}
    Object.assign(this, _freshRuleState())
  }

  get active()    { return this._active }
  get alerts()    { return Object.values(this._alerts) }

  /**
   * 0–100 system risk score — updated only during review cycle (v6).
   * Computation: Σ (severityBase × confidenceMultiplier + durationBonus) clamped to 100.
   * Risk levels: 0–20 Low · 21–50 Moderate · 51–80 High · 81–100 Critical
   */
  get riskScore() { return this._computedRiskScore ?? 0 }

  _updateRiskScore() {
    const CONF_MULT = { HIGH: 1.4, MEDIUM: 1.0, LOW: 0.6 }
    const SEV_BASE  = { critical: 30, warning: 15, info: 5 }
    let score = 0
    for (const alert of Object.values(this._alerts)) {
      if (alert.state !== 'NEW' && alert.state !== 'OBSERVING' && alert.state !== 'RECURRING') continue
      const base    = SEV_BASE[alert.severity] ?? 5
      const mult    = CONF_MULT[alert.confidenceLevel] ?? 1.0
      let contrib   = base * mult
      if ((alert.activeDurationSecs ?? 0) > 900)     contrib += 10
      else if ((alert.activeDurationSecs ?? 0) > 300) contrib += 5
      score += contrib
    }
    this._computedRiskScore = Math.min(100, Math.round(score))

    // Emit subtle hint when composite risk crosses a tier boundary.
    // Tier 0=Low(0-20) · 1=Moderate(21-50) · 2=High(51-80) · 3=Critical(81-100).
    const TIER_LABELS = ['Low', 'Moderate', 'High', 'Critical']
    const newTier = this._getRiskTier(this._computedRiskScore)
    if (this._prevRiskTier !== -1 && newTier !== this._prevRiskTier) {
      if (newTier > this._prevRiskTier) {
        this._emitSubtleHint('degradation',
          `Performance degradation observed. Check Perfora updates.`)
      } else {
        this._emitSubtleHint('improvement',
          `Performance improvement observed. Check Perfora updates.`)
      }
    }
    this._prevRiskTier = newTier
  }

  // Returns 0-3 risk tier for a 0-100 score.
  _getRiskTier(score) {
    if (score <= 20) return 0
    if (score <= 50) return 1
    if (score <= 80) return 2
    return 3
  }

  // Emits a subtle hint in the given direction with a 90-second per-direction cooldown.
  // Hints are only fired for genuinely substantial transitions; routine steady-state
  // updates produce no output.
  _emitSubtleHint(direction, label) {
    const now = Date.now()
    const HINT_COOLDOWN_MS = 90_000
    if (now < (this._hintCooldownEnd[direction] ?? 0)) return
    this._hintCooldownEnd[direction] = now + HINT_COOLDOWN_MS
    this._onSubtleHint?.({ direction, label })
  }

  // ── Adaptive review interval (v6) ─────────────────────────────────────────
  // · Active CRITICAL alert with fastReviewCyclesRemaining > 0  → 45 s
  // · First 10 min (ramp / early phase)                         → 60 s
  // · Steady state (after 10 min)                               → 90 s

  _computeReviewInterval() {
    const elapsedMs    = Date.now() - this._startMs
    const hasFastWindow = Object.values(this._alerts).some(a =>
      (a.fastReviewCyclesRemaining ?? 0) > 0 &&
      (a.state === 'NEW' || a.state === 'OBSERVING' || a.state === 'RECURRING')
    )
    if (hasFastWindow)       return 45_000
    if (elapsedMs < 600_000) return 60_000
    return 90_000
  }

  // ── Public ingest ──────────────────────────────────────────────────────────

  ingestInterval(metric) {
    if (!this._active) return
    this._latestMetric = metric    // snapshot for review cycle conditions (v6)
    this._buffer.push(metric)
    if (this._buffer.length > this.windowSize) this._buffer.shift()

    if (this._buffer.length >= 3) this._evaluate()

    // Run review if enough time has elapsed (interval is computed adaptively)
    const now = Date.now()
    if (now - this._lastReviewMs >= this._computeReviewInterval()) {
      this._lastReviewMs = now
      this._review()
    }
  }

  // ── Rule Engine ────────────────────────────────────────────────────────────

  _evaluate() {
    const data    = this._buffer
    const n       = data.length
    const latest  = data[n - 1]
    const prev    = data[n - 2]
    const elapsed = Math.round((Date.now() - this._startMs) / 1000)

    const avgRts = data.map(x => x.avg_rt)
    const tpss   = data.map(x => x.tps)
    const errs   = data.map(x => x.error_rate)

    // Recompute severity dominance from currently active rules
    this._domRank = 0
    for (const [rule, active] of Object.entries(this.ruleActive)) {
      if (active) {
        const r = SEV_RANK[RULE_META[rule]?.severity ?? 'info'] ?? 1
        if (r > this._domRank) this._domRank = r
      }
    }

    const rtΔ           = (latest.avg_rt > NOISE.MIN_RT_MS && prev.avg_rt > NOISE.MIN_RT_MS)
                            ? _pct(prev.avg_rt, latest.avg_rt) : 0
    const tpsΔ          = _pct(prev.tps, latest.tps)
    const cumErrPct     = latest.cum_error_rate ?? latest.error_rate
    const hasEnoughReqs = (latest.total_requests ?? 0) >= NOISE.MIN_CUMULATIVE_REQS

    // ── L1a · Latency spike ──────────────────────────────────────────────────
    this._check({
      rule: 'LATENCY_SPIKE', elapsed,
      entry: rtΔ > 60,
      exit:  rtΔ < 20,
      message: `Response time spiked ${Math.round(rtΔ)}% in one interval ` +
        `(${Math.round(prev.avg_rt)} → ${Math.round(latest.avg_rt)} ms). ` +
        `Possible downstream saturation or cascading timeout.`,
    })

    // ── L1b · Latency growth (suppressed when CAPACITY_KNEE active) ──────────
    this._check({
      rule: 'LATENCY_GROWTH', elapsed,
      entry: rtΔ > 25 && rtΔ <= 60 && latest.avg_rt > NOISE.MIN_RT_FOR_GROWTH
             && !this.ruleActive.LATENCY_SPIKE,
      exit:  rtΔ < 10,
      message: `Avg response time rising rapidly (+${Math.round(rtΔ)}% vs previous interval, ` +
        `now ${Math.round(latest.avg_rt)} ms). System approaching saturation.`,
    })

    // ── L2 · Tail latency ────────────────────────────────────────────────────
    const tailRatio = latest.avg_rt > 0 ? latest.p95 / latest.avg_rt : 0
    this._check({
      rule: 'TAIL_LATENCY', elapsed,
      entry: latest.avg_rt > NOISE.MIN_RT_MS && latest.p95 > 400 && tailRatio > 2.5,
      exit:  tailRatio < 2.0,
      message: `P95 (${Math.round(latest.p95)} ms) is ${tailRatio.toFixed(1)}× the mean RT ` +
        `(${Math.round(latest.avg_rt)} ms). High tail indicates lock contention or slow DB queries.`,
    })

    // ── L3 · P95 absolute threshold ──────────────────────────────────────────
    this._check({
      rule: 'HIGH_P95', elapsed,
      entry: latest.p95 >= 2000,
      exit:  latest.p95 < 1500,
      message: `P95 latency exceeded 2 s (${Math.round(latest.p95)} ms). ` +
        `End users experiencing consistently slow responses.`,
    })

    // ── L4 · Sustained high RT ───────────────────────────────────────────────
    if (n >= 5) {
      const recentRts = avgRts.slice(-4)
      this._check({
        rule: 'SUSTAINED_HIGH_RT', elapsed,
        entry: recentRts.every(v => v > 800),
        exit:  _mean(recentRts.slice(-2)) < 600,
        message: `Response time above 800 ms for the last 4 intervals ` +
          `(avg ${Math.round(_mean(recentRts))} ms). Degradation is sustained, not transient.`,
      })
    }

    // ── T1 · Capacity knee ───────────────────────────────────────────────────
    if (n >= 3 && latest.vus >= NOISE.MIN_VU_FOR_CAPACITY && latest.tps > NOISE.MIN_TPS_FOR_DROP) {
      const tpsΔ3    = _pct(data[n - 3].tps, latest.tps)
      const rtΔ3     = _pct(data[n - 3].avg_rt, latest.avg_rt)
      const vuGrowth = latest.vus > data[n - 3].vus
      this._check({
        rule: 'CAPACITY_KNEE', elapsed,
        entry: vuGrowth && tpsΔ3 < 5 && rtΔ3 > 20 && latest.avg_rt > NOISE.MIN_RT_MS,
        exit:  tpsΔ3 > 5 || rtΔ3 < 10,
        message: `Throughput plateaued (+${Math.round(tpsΔ3)}%) while latency climbed ` +
          `${Math.round(rtΔ3)}% as VUs increased. System may be at capacity ceiling.`,
      })
    }

    // ── T2 · TPS drop ────────────────────────────────────────────────────────
    const tpsDropBaseline = this.ruleBaseline.TPS_DROP ?? prev.tps
    this._check({
      rule: 'TPS_DROP', elapsed,
      entry: prev.tps > NOISE.MIN_TPS_FOR_DROP && tpsΔ < -20,
      exit:  latest.tps >= tpsDropBaseline * 0.80,
      baseline: prev.tps,
      message: `Throughput dropped ${Math.round(Math.abs(tpsΔ))}% in one interval ` +
        `(${prev.tps.toFixed(1)} → ${latest.tps.toFixed(1)} TPS). ` +
        `Possible overload, connection-pool exhaustion, or throttling.`,
    })

    // ── T3 · TPS stall ───────────────────────────────────────────────────────
    if (n >= 4) {
      const last4Tps = tpss.slice(-4)
      this._check({
        rule: 'TPS_STALL', elapsed,
        entry: last4Tps.every(v => v < 1) && latest.vus > 3,
        exit:  latest.tps > 2,
        message: `Zero / near-zero throughput for 4 consecutive intervals despite ` +
          `${latest.vus} active VUs. Server may be unresponsive.`,
      })
    }

    // ── E3 · High per-transaction error rate — evaluated FIRST so dominance is ─
    // established before global error rules are checked.
    // Entry: no longer requires cumErrPct < 5 — when one endpoint dominates
    // overall errors (e.g. 50% fail rate on 1 of 7 endpoints → cumErrPct ≈ 7%),
    // HIGH_TX_ERROR must still fire to become the primary incident card.
    const maxTxErr = latest.max_tx_error_rate ?? 0
    const worstTx  = latest.worst_tx_name     ?? 'an endpoint'
    const txShare  = latest.worst_tx_share    ?? 0
    this._check({
      rule: 'HIGH_TX_ERROR', elapsed,
      entry: hasEnoughReqs && maxTxErr >= 5,
      exit:  maxTxErr < 3,
      message: `${worstTx.length > 55 ? '…' + worstTx.slice(-52) : worstTx} has a ` +
        `${maxTxErr.toFixed(1)}% error rate` +
        `${maxTxErr >= 30 && txShare >= 10
          ? ` — dominant root cause (${txShare.toFixed(0)}% of traffic, drives overall ${cumErrPct.toFixed(1)}%)`
          : ` (overall: ${cumErrPct.toFixed(1)}%)`}. Investigate this endpoint.`,
    })

    // ── E1 · Error burst ─────────────────────────────────────────────────────
    this._check({
      rule: 'ERROR_BURST', elapsed,
      entry: hasEnoughReqs && latest.error_rate > 2 && prev.error_rate < 0.5
             && cumErrPct < 0.5,
      exit:  latest.error_rate < 0.5,
      message: `Error rate surged from ${prev.error_rate.toFixed(1)}% → ` +
        `${latest.error_rate.toFixed(1)}% in this interval ` +
        `(cumulative overall: ${cumErrPct.toFixed(2)}%). ` +
        `Identify failing endpoints in the error log.`,
    })

    // ── E2 · High overall error rate — severity evolves with cumErrPct ────────
    const highErrSev = cumErrPct >= 5 ? 'critical' : 'warning'
    this._check({
      rule: 'HIGH_ERROR_RATE', elapsed,
      entry: hasEnoughReqs && cumErrPct >= 5,
      exit:  cumErrPct < 3,
      liveSeverity: this.ruleActive.HIGH_ERROR_RATE ? highErrSev : null,
      message: `Overall error rate at ${cumErrPct.toFixed(1)}% (cumulative) — ` +
        `${cumErrPct >= 5 ? 'critical 5%' : 'elevated 3–5%'} threshold zone. ` +
        `Test results may be unreliable. Investigate failing requests.`,
    })

    // ── E4 · Persistent error trend ──────────────────────────────────────────
    const last3Errs = errs.slice(-3)
    const persistentRolling = last3Errs.length >= 3 && last3Errs.every(e => e > 1)
    this._check({
      rule: 'ERROR_TREND', elapsed,
      entry: hasEnoughReqs && persistentRolling && cumErrPct > 1,
      exit:  cumErrPct < 1,
      message: `Error rate above 1% for 3 consecutive intervals ` +
        `(rolling: ${latest.error_rate.toFixed(1)}%, cumulative: ${cumErrPct.toFixed(1)}%). ` +
        `Sustained failure pattern — not a transient spike.`,
    })

    // ── Post-evaluation reconciliation: absorb global error alerts into primary ─
    // Handles the case where ERROR_TREND / HIGH_ERROR_RATE were created in a
    // previous cycle before HIGH_TX_ERROR became dominant.
    this._reconcileIncidentDominance()

    // ── S1 · Instability (suppressed when TPS_STALL active) ──────────────────
    if (avgRts.length >= 4) {
      const cv = latest.avg_rt > 0 ? _stddev(avgRts) / _mean(avgRts) : 0
      this._check({
        rule: 'INSTABILITY', elapsed,
        entry: cv > 0.35 && latest.avg_rt > NOISE.MIN_RT_MS,
        exit:  cv < 0.25,
        message: `Response time coefficient of variation is ${Math.round(cv * 100)}% — ` +
          `highly inconsistent performance. Possible GC pauses, bursty load, or ` +
          `competing workloads on the target server.`,
      })
    }

    // ── X1 · Under-utilised load (suppressed when TPS_STALL active) ──────────
    this._check({
      rule: 'LOW_LOAD', elapsed,
      entry: latest.vus < 5 && latest.avg_rt > 0 && latest.avg_rt < 200 && latest.error_rate < 1,
      exit:  latest.vus >= 5,
      message: `Only ${latest.vus} VU(s) active with avg RT ${Math.round(latest.avg_rt)} ms. ` +
        `System is not under meaningful stress. Increase VUs to find the capacity limit.`,
    })
  }

  // ── Review cycle ──────────────────────────────────────────────────────────
  // Runs every 45 / 60 / 90 s (adaptive). Advances lifecycle states,
  // updates confidence (including downgrade), refreshes duration fields,
  // decrements fast-review counters, recomputes risk score.

  _review() {
    if (!this._active) return
    const now     = Date.now()
    const elapsed = Math.round((now - this._startMs) / 1000)
    let   changed = false

    // Latest metric snapshot — used for near-exit-threshold confidence downgrade
    const cumErrPct  = this._latestMetric?.cum_error_rate ?? this._latestMetric?.error_rate ?? 0
    const rollingErr = this._latestMetric?.error_rate ?? 0

    for (const [rule, alert] of Object.entries(this._alerts)) {
      if (alert.state === 'RESOLVED') continue

      const isActive   = !!this.ruleActive[rule]
      const inactiveMs = isActive ? 0 : (now - (this._inactiveStartMs[rule] ?? now))

      if (isActive) {
        // ── Rule still firing ────────────────────────────────────────────────
        this._stableReviewCount[rule] = 0

        alert.activeDurationSecs = elapsed - (alert.activePhaseStartAt ?? alert.firstDetectedAt)
        alert.stableDurationSecs = 0
        alert.lastObservedAt     = elapsed

        // ── Fast-review window: decrement counter for critical-severity alerts ─
        if (alert.severity === 'critical' && (alert.fastReviewCyclesRemaining ?? 0) > 0) {
          alert.fastReviewCyclesRemaining = Math.max(0, alert.fastReviewCyclesRemaining - 1)
        }

        // ── Confidence: compute base from review count, then check for downgrade ─
        alert._reviewActiveCount = (alert._reviewActiveCount ?? 0) + 1
        const baseConf = alert._reviewActiveCount >= CONF_HIGH_AFTER   ? 'HIGH'
                       : alert._reviewActiveCount >= CONF_MEDIUM_AFTER ? 'MEDIUM'
                       : 'LOW'

        // Downgrade conditions (v6):
        // a) Alert severity was downgraded since the previous review cycle
        const prevSev        = alert._prevReviewSeverity ?? alert.severity
        const sevDowngraded  = (SEV_RANK[alert.severity] ?? 0) < (SEV_RANK[prevSev] ?? 0)

        // b) Error rule's metric is within 20% above its natural exit threshold
        const nearErrExit =
          (rule === 'HIGH_ERROR_RATE' && cumErrPct  < 3 * 1.2)  ||   // exit=3%
          (rule === 'ERROR_TREND'     && cumErrPct  < 1 * 1.2)  ||   // exit=1%
          (rule === 'ERROR_BURST'     && rollingErr < 0.5 * 1.2)      // exit=0.5%

        const shouldDowngrade = sevDowngraded || nearErrExit

        const CONF_ORDER = ['LOW', 'MEDIUM', 'HIGH']
        const baseIdx    = CONF_ORDER.indexOf(baseConf)
        const newConf    = shouldDowngrade
                           ? CONF_ORDER[Math.max(0, baseIdx - 1)]
                           : baseConf

        alert.confidenceLevel     = newConf
        alert._prevReviewSeverity = alert.severity    // remember for next cycle

        // ── State + statusMessage ────────────────────────────────────────────
        const mins      = _fmtMins(alert.activeDurationSecs)
        const confNote  = `. Confidence: ${_confLabel(newConf)}.`
        const improving = shouldDowngrade ? ' (conditions improving)' : ''

        if (alert.state === 'NEW') {
          alert.state = 'OBSERVING'
          alert.statusMessage = `Consistent behaviour observed for the last ${mins}. Investigation recommended${confNote}`
          alert.lastStatusUpdateTime = elapsed
          changed = true

        } else if (alert.state === 'OBSERVING') {
          const verb = newConf === 'HIGH'   ? 'Consistent degradation confirmed'
                     : shouldDowngrade      ? `Behaviour improving${improving} — observed`
                     :                        'Consistent behaviour continuing'
          alert.statusMessage = `${verb} for the last ${mins}${confNote}`
          alert.lastStatusUpdateTime = elapsed
          changed = true

        } else if (alert.state === 'RECURRING') {
          alert.statusMessage = `Issue reappeared after stable period. Observed again for the last ${mins}${confNote}`
          alert.lastStatusUpdateTime = elapsed
          changed = true
        }

      } else {
        // ── Rule inactive ────────────────────────────────────────────────────
        this._stableReviewCount[rule] = (this._stableReviewCount[rule] ?? 0) + 1
        alert.stableDurationSecs      = inactiveMs / 1000
        const stableMins              = _fmtMins(inactiveMs / 1000)

        if (inactiveMs >= RESOLVE_AFTER_MS) {
          alert.state         = 'RESOLVED'
          alert.statusMessage = 'Issue resolved. No recurrence observed for the last 10 minutes.'
          alert.lastStatusUpdateTime = elapsed
          changed = true
          this._emitSubtleHint('improvement',
            'Performance improvement observed. Check Perfora updates.')

        } else if (this._stableReviewCount[rule] >= STABLE_REVIEW_THRESHOLD
                   && alert.state !== 'STABLE') {
          alert.state              = 'STABLE'
          alert._reviewActiveCount = 0
          alert.confidenceLevel    = 'LOW'
          alert.statusMessage = `Issue observed during earlier phase (possible ramp-up or cold start). System stable for the last ${stableMins}.`
          alert.lastStatusUpdateTime = elapsed
          changed = true
          this._emitSubtleHint('improvement',
            'Performance improvement observed. Check Perfora updates.')

        } else if (alert.state === 'STABLE') {
          alert.statusMessage = `Issue observed during earlier phase. System stable for the last ${stableMins}.`
          alert.lastStatusUpdateTime = elapsed
          changed = true
        }
      }
    }

    // Recompute composite risk score after all alert states are resolved
    this._updateRiskScore()

    if (changed) this._onAlertChange?.([...Object.values(this._alerts)])
  }

  // ── Alert lifecycle helpers ────────────────────────────────────────────────

  _activateAlert(rule, severity, elapsed, message) {
    // Severity dominance: don't create INFO alerts when warning/critical is active
    if (severity === 'info' && this._domRank >= SEV_RANK.warning) return false

    // Conditional correlation suppression (v6):
    // Only suppress if suppressor alert has ≥ child severity AND its confidence > LOW.
    const suppressors = CORRELATION_SUPPRESS[rule]
    if (suppressors?.some(s => {
      if (!this.ruleActive[s]) return false
      const suppAlert = this._alerts[s]
      if (!suppAlert) return false
      const suppSevRank  = SEV_RANK[suppAlert.severity] ?? 0
      const childSevRank = SEV_RANK[RULE_META[rule]?.severity ?? 'info'] ?? 0
      return suppSevRank >= childSevRank && suppAlert.confidenceLevel !== 'LOW'
    })) return false

    // Incident dominance (creation-time check):
    // If HIGH_TX_ERROR is dominant, absorb global error alert attempts as impact notes.
    // No confidence gate — dominance applies even at LOW confidence.
    const GLOBAL_ERROR_RULES = ['ERROR_TREND', 'HIGH_ERROR_RATE']
    if (GLOBAL_ERROR_RULES.includes(rule)) {
      const txAlert = this._alerts['HIGH_TX_ERROR']
      if (txAlert && this.ruleActive['HIGH_TX_ERROR'] && this._isTxDominantByMetrics()) {
        const noteMap = {
          ERROR_TREND:     'Overall error rate rising persistently — driven by this endpoint failure.',
          HIGH_ERROR_RATE: 'Cumulative error threshold breached — endpoint is the dominant contributor.',
        }
        this._addImpactNote('HIGH_TX_ERROR', noteMap[rule])
        return false   // suppress separate card
      }
    }

    const existing = this._alerts[rule]

    if (!existing || existing.state === 'RESOLVED') {
      // ── NEW lifecycle ───────────────────────────────────────────────────────
      const alert = {
        id:                        rule,
        ruleCode:                  rule,
        severity,
        firstDetectedAt:           elapsed,
        lastObservedAt:            elapsed,
        activePhaseStartAt:        elapsed,
        state:                     'NEW',
        statusMessage:             'Issue first detected. Monitoring for consistent pattern.',
        confidenceLevel:           'LOW',
        _reviewActiveCount:        0,
        _prevReviewSeverity:       severity,
        fastReviewCyclesRemaining: severity === 'critical' ? 3 : 0,
        recurrenceCount:           0,
        activeDurationSecs:        0,
        stableDurationSecs:        0,
        lastStatusUpdateTime:      elapsed,
        impactNotes:               [],
        isPrimary:                 rule === 'HIGH_TX_ERROR' && this._isTxDominantByMetrics(),
        message,
      }
      this._alerts[rule] = alert
      this._stableReviewCount[rule] = 0
      delete this._inactiveStartMs[rule]

      this._onAlertChange?.([...Object.values(this._alerts)])
      this._onToast?.(alert)
      return true

    } else if (existing.state === 'STABLE') {
      // ── RECURRING (only from STABLE) ───────────────────────────────────────
      existing.state                     = 'RECURRING'
      existing.recurrenceCount          += 1
      existing.lastObservedAt            = elapsed
      existing.activePhaseStartAt        = elapsed
      existing.lastStatusUpdateTime      = elapsed
      existing.activeDurationSecs        = 0
      existing.stableDurationSecs        = 0
      existing._reviewActiveCount        = 0
      existing.confidenceLevel           = 'LOW'
      existing._prevReviewSeverity       = severity
      existing.fastReviewCyclesRemaining = severity === 'critical' ? 3 : 0
      existing.severity                  = severity
      existing.message                   = message
      existing.impactNotes               = []
      existing.isPrimary                 = rule === 'HIGH_TX_ERROR' && this._isTxDominantByMetrics()
      existing.statusMessage = `Issue reappeared after stable period. Observed again for the last 0 mins. Confidence: LOW.`
      this._stableReviewCount[rule] = 0
      delete this._inactiveStartMs[rule]

      this._onAlertChange?.([...Object.values(this._alerts)])
      this._onToast?.(existing)
      return true

    } else {
      // ── Active alert (NEW / OBSERVING / RECURRING) — refresh message + isPrimary ──
      existing.lastObservedAt = elapsed
      existing.message        = message
      if (rule === 'HIGH_TX_ERROR') {
        existing.isPrimary = this._isTxDominantByMetrics()
      }
      this._onAlertChange?.([...Object.values(this._alerts)])
      return true
    }
  }

  _deactivateAlert(rule) {
    const alert = this._alerts[rule]
    if (!alert) return
    if (!this._inactiveStartMs[rule]) {
      this._inactiveStartMs[rule] = Date.now()
    }
    // Clear primary status when the rule stops firing —
    // if it was causing incident dominance, secondary rules can now activate.
    if (rule === 'HIGH_TX_ERROR') alert.isPrimary = false
    // State + duration transitions deferred to _review().
    this._onAlertChange?.([...Object.values(this._alerts)])
  }

  // Returns true if HIGH_TX_ERROR currently satisfies full dominance criteria:
  //   endpoint error rate ≥30%, ≥10 calls, ≥10% of total traffic.
  // No confidence gate — incident grouping is a structural signal, not a judgment.
  _isTxDominantByMetrics() {
    const maxTxErr = this._latestMetric?.max_tx_error_rate ?? 0
    const txCount  = this._latestMetric?.worst_tx_count    ?? 0
    const txShare  = this._latestMetric?.worst_tx_share    ?? 0
    return maxTxErr >= 30 && txCount >= 10 && txShare >= 10
  }

  // Retroactive incident dominance reconciliation.
  // Called after every rule evaluation pass. If HIGH_TX_ERROR is dominant and
  // global error alert cards (ERROR_TREND / HIGH_ERROR_RATE) exist from earlier
  // cycles, they are absorbed as impact notes and their cards are removed so the
  // UI shows a single root-cause incident instead of fragmented alert cards.
  _reconcileIncidentDominance() {
    if (!this.ruleActive['HIGH_TX_ERROR']) return
    if (!this._isTxDominantByMetrics())    return

    const txAlert = this._alerts['HIGH_TX_ERROR']
    if (!txAlert) return

    txAlert.isPrimary = true

    const ABSORB_RULES = {
      ERROR_TREND:     'Overall error rate rising persistently — driven by this endpoint failure.',
      HIGH_ERROR_RATE: 'Cumulative error threshold breached — endpoint is the dominant contributor.',
    }

    let absorbed = false
    for (const [absRule, note] of Object.entries(ABSORB_RULES)) {
      const gAlert = this._alerts[absRule]
      if (!gAlert || gAlert.state === 'RESOLVED') continue

      this._addImpactNote('HIGH_TX_ERROR', note)

      // Remove global alert card and reset its rule state so it can
      // reactivate normally once dominance ends.
      delete this._alerts[absRule]
      this.ruleActive[absRule]   = false
      this.confirmCount[absRule] = 0
      this.exitCount[absRule]    = 0
      delete this._inactiveStartMs[absRule]
      delete this._stableReviewCount[absRule]
      absorbed = true
    }

    if (absorbed) this._onAlertChange?.([...Object.values(this._alerts)])
  }

  // ── Impact note helper ────────────────────────────────────────────────────
  // Appends a contextual note to a primary alert's impactNotes array (deduped).

  _addImpactNote(primaryRule, note) {
    const alert = this._alerts[primaryRule]
    if (!alert || !note) return
    if (!Array.isArray(alert.impactNotes)) alert.impactNotes = []
    if (alert.impactNotes.includes(note)) return    // already recorded
    alert.impactNotes.push(note)
    this._onAlertChange?.([...Object.values(this._alerts)])
  }

  // ── Severity evolution helper (v6) ───────────────────────────────────────
  // Handles in-place severity change without a new lifecycle.
  // Side-effects:
  //   · Downgrade: immediately reduces confidence one step
  //   · Escalation to critical: starts a new 3-cycle fast-review window

  _evolveSeverity(rule, newSeverity, message) {
    const alert = this._alerts[rule]
    if (!alert || alert.severity === newSeverity) return

    const oldRank = SEV_RANK[alert.severity] ?? 0
    const newRank = SEV_RANK[newSeverity] ?? 0

    if (newRank < oldRank) {
      // Severity downgraded → step confidence down by one level
      const CONF_ORDER = ['LOW', 'MEDIUM', 'HIGH']
      const curIdx     = CONF_ORDER.indexOf(alert.confidenceLevel ?? 'LOW')
      alert.confidenceLevel = CONF_ORDER[Math.max(0, curIdx - 1)]
      // Subtle improvement hint on severity downgrade (critical → warning/info)
      this._emitSubtleHint('improvement',
        'Performance improvement observed. Check Perfora updates.')
    } else if (newRank > oldRank && newSeverity === 'critical') {
      // Severity escalated to critical → fast-review window + degradation hint
      alert.fastReviewCyclesRemaining = 3
      this._emitSubtleHint('degradation',
        'Performance degradation observed. Check Perfora updates.')
    }

    alert.severity = newSeverity
    alert.message  = message
    this._onAlertChange?.([...Object.values(this._alerts)])
  }

  // ── State-machine _check ───────────────────────────────────────────────────
  // liveSeverity: if supplied, will update the active alert's severity when it
  //               differs from the stored value (severity evolution, no new alert).

  _check({ rule, elapsed, entry, exit = null, message, baseline = null, liveSeverity = null }) {
    const meta     = RULE_META[rule]
    const isActive = this.ruleActive[rule]

    if (!isActive) {
      if (entry) {
        if (this.confirmCount[rule] === 0 && baseline !== null) {
          this.ruleBaseline[rule] = baseline
        }
        this.confirmCount[rule]++
        this.exitCount[rule] = 0

        if (this.confirmCount[rule] >= meta.confirm) {
          this.confirmCount[rule] = 0
          const activated = this._activateAlert(rule, meta.severity, elapsed, message)
          if (activated) this.ruleActive[rule] = true
        }
      } else {
        this.confirmCount[rule] = 0
        this.ruleBaseline[rule] = null
      }

    } else {
      // ── Severity evolution while rule is active ────────────────────────────
      if (liveSeverity !== null) {
        this._evolveSeverity(rule, liveSeverity, message)
      }

      const exitCond = exit !== null ? exit : !entry

      if (exitCond) {
        this.exitCount[rule]++
        this.confirmCount[rule] = 0

        if (this.exitCount[rule] >= meta.exitConfirm) {
          this.ruleActive[rule]   = false
          this.exitCount[rule]    = 0
          this.ruleBaseline[rule] = null
          this._deactivateAlert(rule)
        }
      } else {
        this.exitCount[rule] = 0
      }
    }
  }
}

/**
 * useAnalytics — React hook for the PT0 telemetry-driven metrics pipeline.
 *
 * Polls raw request telemetry from the backend at a fixed interval,
 * feeds records into the metricsEngine, and exposes graph-ready state
 * for the Quick Test dashboard.
 *
 * Usage:
 *   const analytics = useAnalytics(testRunId, { active: isRunning, totalDurationSecs: 300 })
 *   // analytics.chartData        → same shape as genEmptyData() / nextTick()
 *   // analytics.cumulative       → { totalRequests, cumulativeAvgRt, ... }
 *   // analytics.perScript        → { [scriptId]: { tps, avgRt, activeVUs, ... } }
 *   // analytics.isLive           → polling is active
 *   // analytics.testStatus       → latest execution status from backend
 *   // analytics.guardianAlerts   → living alert lifecycle objects (one per rule)
 *   // analytics.guardianToastQueue → toast-worthy transitions (NEW + RECURRING only)
 *   // analytics.guardianRiskScore → 0–100 composite risk
 *   // analytics.reset()          → clear engine + state
 */

import { useState, useEffect, useRef, useCallback } from 'react'
import { getExecutionTelemetry, getExecution } from '../api'
import { createEngine } from './metricsEngine'
import { PerforaGuardian } from './perforaGuardian'

const POLL_INTERVAL_MS = 5_000
const FETCH_BATCH      = 2_000

// totalDurationSecs is accepted for API compatibility but the Guardian now
// self-manages its review interval based on elapsed time and active alert severity.
export function useAnalytics(testRunId, { active = false, totalDurationSecs: _unused = 0 } = {}) { // eslint-disable-line no-unused-vars
  const engineRef   = useRef(null)
  const pollRef     = useRef(null)
  const mountedRef  = useRef(true)
  const guardianRef = useRef(null)

  const [chartData,           setChartData]           = useState(null)
  const [cumulative,          setCumulative]          = useState(null)
  const [perScript,           setPerScript]           = useState({})
  const [apiStats,            setApiStats]            = useState({})
  const [txStats,             setTxStats]             = useState({})
  const [apiGraphData,        setApiGraphData]        = useState({})
  const [txGraphData,         setTxGraphData]         = useState({})
  const [isLive,              setIsLive]              = useState(false)
  const [testStatus,          setTestStatus]          = useState(null)
  const [guardianAlerts,      setGuardianAlerts]      = useState([])
  const [guardianToastQueue,  setGuardianToastQueue]  = useState([])
  const [guardianRiskScore,   setGuardianRiskScore]   = useState(0)
  const [guardianSubtleHint,  setGuardianSubtleHint]  = useState(null)

  // Lazy engine initialisation
  function engine() {
    if (!engineRef.current) engineRef.current = createEngine({ pollInterval: POLL_INTERVAL_MS })
    return engineRef.current
  }

  // ── single poll cycle ──
  const poll = useCallback(async () => {
    if (!testRunId || !mountedRef.current) return

    const eng = engine()

    try {
      // Incremental fetch — keep pulling until we drain the new records
      let hasMore = true
      while (hasMore) {
        const batch = await getExecutionTelemetry(testRunId, FETCH_BATCH, eng.fetchOffset)
        if (batch?.length > 0) {
          eng.ingest(batch)
          hasMore = batch.length >= FETCH_BATCH
        } else {
          hasMore = false
        }
      }

      // Compute rolling + cumulative + graph data
      const result = eng.computeTick()

      // Feed rolling snapshot into Perfora Guardian
      if (guardianRef.current?.active && result.rolling) {
        // Compute max per-API cumulative error rate + traffic share for dominance logic
        const currentApiStats = eng.getApiStats()
        let maxTxErrRate  = 0
        let worstTxName   = ''
        let worstTxCount  = 0
        for (const [path, s] of Object.entries(currentApiStats)) {
          if (!s.total || s.total < 10) continue
          const rate = s.total > 0 ? (s.fail / s.total) * 100 : 0
          if (rate > maxTxErrRate) {
            maxTxErrRate = rate
            worstTxName  = path
            worstTxCount = s.total
          }
        }
        const _totReqs     = result.cumulative?.totalRequests ?? 1
        const worstTxShare = _totReqs > 0 ? (worstTxCount / _totReqs) * 100 : 0

        guardianRef.current.ingestInterval({
          vus:               result.rolling.activeVUs          ?? 0,
          avg_rt:            result.rolling.avgRt              ?? 0,
          p95:               result.rolling.p95                ?? 0,
          tps:               result.rolling.tps                ?? 0,
          error_rate:        result.rolling.errorPct           ?? 0,
          cum_error_rate:    result.cumulative?.totalErrorPct  ?? 0,
          total_requests:    result.cumulative?.totalRequests  ?? 0,
          max_tx_error_rate: parseFloat(maxTxErrRate.toFixed(2)),
          worst_tx_name:     worstTxName,
          worst_tx_count:    worstTxCount,
          worst_tx_share:    parseFloat(worstTxShare.toFixed(1)),
        })
        // Risk score is updated inside the Guardian's review cycle, NOT here.
        // Reading it after every 5s poll would apply stale values and bypass
        // the confidence-weighted computation. The onAlertChange callback
        // (fired by _review) updates the UI score at review-cycle cadence.
      }

      if (!mountedRef.current) return

      setChartData(result.graphData)
      setCumulative(result.cumulative)
      setPerScript(result.perScript)
      setApiStats(eng.getApiStats())
      setTxStats(eng.getTxStats())
      setApiGraphData(eng.getApiGraphData())
      setTxGraphData(eng.getTxGraphData())

      // Check execution lifecycle
      try {
        const status = await getExecution(testRunId)
        if (!mountedRef.current) return
        setTestStatus(status)

        const s = status?.status
        if (s === 'COMPLETED' || s === 'FAILED' || s === 'ABORTED' || s === 'STOPPED') {
          setIsLive(false)
          if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
        }
      } catch { /* backend status check is best-effort */ }
    } catch (err) {
      console.error('[PT0 Analytics] poll error:', err)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testRunId])

  // ── start / stop polling ──
  useEffect(() => {
    if (active && testRunId) {
      // Reset engine for a fresh test
      engine().reset()
      setIsLive(true)
      setChartData(null)
      setCumulative(null)
      setPerScript({})
      setApiStats({})
      setTxStats({})
      setApiGraphData({})
      setTxGraphData({})
      setTestStatus(null)
      setGuardianRiskScore(0)

      // Initialise a fresh Guardian for this test run
      const guardian = new PerforaGuardian({
        windowSize: 5,
        onAlertChange: (alerts) => {
          if (!mountedRef.current) return
          setGuardianAlerts([...alerts])
          // Risk score is recomputed inside _review() before onAlertChange fires.
          // Updating here keeps UI in sync with the review cadence only.
          setGuardianRiskScore(guardianRef.current?.riskScore ?? 0)
        },
        onToast: (alert) => {
          if (mountedRef.current) {
            setGuardianToastQueue(prev => [...prev, { ...alert, _toastId: Date.now() }])
          }
        },
        onSubtleHint: ({ direction, label }) => {
          if (mountedRef.current) {
            setGuardianSubtleHint({ direction, label, _id: Date.now() })
          }
        },
      })
      guardian.start()
      guardianRef.current = guardian
      setGuardianAlerts([])
      setGuardianToastQueue([])
      setGuardianSubtleHint(null)

      // Slight delay before first poll so the backend has time to
      // record at least one request after INITIALIZING → RAMPING_UP.
      const first = setTimeout(() => { if (mountedRef.current) poll() }, 800)
      pollRef.current = setInterval(poll, POLL_INTERVAL_MS)

      return () => {
        clearTimeout(first)
        if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
      }
    }

    // When deactivated, stop guardian + polling (final drain happens below)
    if (guardianRef.current) { guardianRef.current.stop(); guardianRef.current = null }
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
    return undefined
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, testRunId])

  // ── final drain: one last poll when the test stops ──
  const prevActive = useRef(active)
  useEffect(() => {
    if (prevActive.current && !active && testRunId) {
      poll().then(() => { if (mountedRef.current) setIsLive(false) })
    }
    prevActive.current = active
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active])

  // Cleanup on unmount
  useEffect(() => {
    mountedRef.current = true
    return () => { mountedRef.current = false }
  }, [])

  // ── reset (called externally, e.g. "Run Again") ──
  const reset = useCallback(() => {
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
    if (engineRef.current) engineRef.current.reset()
    if (guardianRef.current) { guardianRef.current.reset(); guardianRef.current = null }
    setChartData(null)
    setCumulative(null)
    setPerScript({})
    setApiStats({})
    setTxStats({})
    setApiGraphData({})
    setTxGraphData({})
    setIsLive(false)
    setTestStatus(null)
      setGuardianAlerts([])
      setGuardianToastQueue([])
      setGuardianRiskScore(0)
      setGuardianSubtleHint(null)
  }, [])

  return {
    chartData, cumulative, perScript,
    apiStats, txStats, apiGraphData, txGraphData,
    isLive, testStatus, reset,
    guardianAlerts, guardianToastQueue, guardianRiskScore, guardianSubtleHint,
  }
}

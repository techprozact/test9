/**
 * PT0 Analytics Engine — Frontend-Driven Metrics Pipeline  (v2)
 *
 * Computes real-time performance metrics from raw request telemetry.
 *
 * v2 enhancements over v1:
 *   1. Smarter rolling-window math — TPS uses actual timestamp span,
 *      clamped to 1 s minimum to prevent spikes.
 *   2. Bucketed histogram estimator for O(n) percentile computation
 *      (replaces O(n log n) full-sort).  Nearest-rank fallback for < 30
 *      samples.
 *   3. EMA smoothing (α = 0.2) on throughput, avg RT and latency spread
 *      for graph stability.  Raw values are retained for cumulative stats.
 *   4. Adaptive active-VU window:
 *        max(2 × pollInterval, 3 × rolling_avg_rt)
 *   5. Stability guardrails — percentiles and latency spread not emitted
 *      until ≥ 20 window samples; previous stable value held until then.
 *
 * Public API is unchanged from v1.
 */

import { normalizeApiPath } from './pathNormalizer'

// ───────────────────────── constants ─────────────────────────

const DEFAULT_POLL_MS        = 5_000
const DEFAULT_ROLLING_WINDOW = 5_000       // ms
const MIN_SPAN_MS            = 1_000       // clamp denominator to avoid TPS spikes
const HISTOGRAM_BUCKETS      = 200
const HISTOGRAM_MAX_MS       = 10_000      // 10 s covers most HTTP latencies
const MIN_PERCENTILE_SAMPLES = 5           // guardrail — allows low-concurrency tests (2 VUs × 1s ≈ 10 samples/window)
const NEAREST_RANK_THRESHOLD = 30          // below this, use sorted fallback
const EMA_ALPHA              = 0.2
const MAX_GRAPH_POINTS       = 200         // ~16 min at 5 s intervals
const RECORD_RETENTION_MS    = 120_000     // 2 minutes

// ───────────────────────── helpers ────────────────────────────

function parseTs(ts) {
  if (typeof ts === 'number') return ts
  if (ts instanceof Date) return ts.getTime()
  if (typeof ts === 'string') { const ms = Date.parse(ts); return Number.isNaN(ms) ? 0 : ms }
  return 0
}

/** Nearest-rank percentile on a pre-sorted array.  */
function nearestRank(sorted, p) {
  const n = sorted.length
  if (n === 0) return 0
  const idx = Math.ceil((p / 100) * n) - 1
  return sorted[Math.max(0, Math.min(idx, n - 1))]
}

/** EMA: smoothed = α × raw + (1 − α) × prev */
function ema(prev, raw) {
  return prev === null ? raw : EMA_ALPHA * raw + (1 - EMA_ALPHA) * prev
}

/** Compute rolling avg/tps/errPct for a single item window accumulator. */
function _itemStats(w) {
  if (!w || w.total === 0) return { avgRt: 0, tps: 0, errPct: 0 }
  const avgRt  = Math.round(w.rtSum / w.total)
  let span = w.total > 1 ? w.latest - w.earliest : 0
  if (span < MIN_SPAN_MS) span = MIN_SPAN_MS
  const tps    = Math.round(w.total / (span / 1000))
  const errPct = parseFloat(((w.errors / w.total) * 100).toFixed(2))
  return { avgRt, tps, errPct }
}

// ─────────────────── bucketed histogram estimator ────────────

const BUCKET_WIDTH = HISTOGRAM_MAX_MS / HISTOGRAM_BUCKETS

/**
 * Lightweight bucketed histogram for O(n) + O(buckets) percentile
 * queries without full-array sorting.
 *
 * - Fixed 200 buckets covering 0–10 000 ms (50 ms each).
 * - Overflow bucket for values > 10 000 ms.
 * - Linear interpolation within the target bucket for smoother output.
 * - Reusable: call clear() then add() per tick.
 */
function createHistogram() {
  const counts = new Uint32Array(HISTOGRAM_BUCKETS)
  let total = 0
  let overflow = 0
  let overflowMax = 0

  function clear() {
    counts.fill(0)
    total = 0
    overflow = 0
    overflowMax = 0
  }

  function add(val) {
    total++
    if (val >= HISTOGRAM_MAX_MS) {
      overflow++
      if (val > overflowMax) overflowMax = val
      return
    }
    const idx = Math.min((val / BUCKET_WIDTH) | 0, HISTOGRAM_BUCKETS - 1)
    counts[idx]++
  }

  function percentile(p) {
    if (total === 0) return 0
    const target = Math.ceil((p / 100) * total)
    let cum = 0
    for (let i = 0; i < HISTOGRAM_BUCKETS; i++) {
      cum += counts[i]
      if (cum >= target) {
        const prev = cum - counts[i]
        const frac = counts[i] > 0 ? (target - prev) / counts[i] : 0
        return Math.round(i * BUCKET_WIDTH + frac * BUCKET_WIDTH)
      }
    }
    return Math.round(overflowMax || HISTOGRAM_MAX_MS)
  }

  return { clear, add, percentile, get count() { return total } }
}

// ───────────────────────── factory ────────────────────────────

export function createEngine(options = {}) {
  const pollMs   = options.pollInterval  ?? DEFAULT_POLL_MS
  const windowMs = options.rollingWindow ?? DEFAULT_ROLLING_WINDOW

  // ── internal state ──

  let records     = []
  let fetchOffset = 0
  let tickIndex   = 0

  // Global cumulative (updated incrementally)
  const cum = { totalReqs: 0, totalRtSum: 0, totalErrors: 0, peakTps: 0 }

  // Per-script cumulative
  const perScriptCum = {}

  // Per-API-path cumulative (for API Wise table)
  const perApiCum = {}

  // Per-transaction cumulative keyed by `${scriptId}:${sequenceNumber}` (for Transaction Wise table)
  const perTxCum = {}

  // Graph point arrays (bounded)
  const graph = {
    throughput: [], avg_rt: [], hits: [], active_vus: [],
    error_rate: [], requests: [], latency: [], ux_variance: [],
  }

  // Per-API and per-TX time series: { [key]: Array<{t, avgRt, tps, errPct}> }
  const perApiGraph = {}
  const perTxGraph  = {}

  // Reusable histogram (cleared each tick)
  const histo = createHistogram()

  // EMA state for graph smoothing (null = uninitialised)
  const smooth = { tps: null, avgRt: null, uxVar: null }

  // Previous stable percentile values (guardrail fallback)
  const stablePerc = { p50: 0, p90: 0, p95: 0, p99: 0, uxVar: 0 }

  // ── ingest ──

  function ingest(batch) {
    if (!batch?.length) return 0
    let ingested = 0

    for (const raw of batch) {
      const startMs  = parseTs(raw.request_start_ts)
      const endMs    = parseTs(raw.request_end_ts)
      const rtMs     = raw.response_time_ms ?? Math.max(1, endMs - startMs)
      const failed   = (raw.http_status_code >= 500) || raw.success === false || raw.success === 0
      const vuId     = raw.virtual_user_id || ''
      const scriptId = raw.script_id || ''

      const apiPath = normalizeApiPath(raw.api_path || '(unknown)')
      const seqKey  = `${scriptId}:${raw.sequence_number ?? 0}`

      records.push({ startMs, endMs, rtMs, failed, vuId, scriptId, apiPath, seqKey })

      cum.totalReqs++
      cum.totalRtSum += rtMs
      if (failed) cum.totalErrors++

      if (!perScriptCum[scriptId]) {
        perScriptCum[scriptId] = { totalReqs: 0, totalRtSum: 0, totalErrors: 0, maxRt: 0 }
      }
      const sc = perScriptCum[scriptId]
      sc.totalReqs++
      sc.totalRtSum += rtMs
      if (failed) sc.totalErrors++
      if (rtMs > sc.maxRt) sc.maxRt = rtMs

      // Per-API and per-Transaction cumulative accumulators
      for (const [map, key] of [[perApiCum, apiPath], [perTxCum, seqKey]]) {
        if (!map[key]) map[key] = { total: 0, errors: 0, rtSum: 0, minRt: Infinity, maxRt: 0, rts: [] }
        const a = map[key]
        a.total++; a.rtSum += rtMs; a.rts.push(rtMs)
        if (rtMs < a.minRt) a.minRt = rtMs
        if (rtMs > a.maxRt) a.maxRt = rtMs
        if (failed) a.errors++
      }

      ingested++
    }

    fetchOffset += ingested
    return ingested
  }

  // ── tick computation ──

  function computeTick(referenceMs) {
    const now = referenceMs
      || (records.length > 0 ? records[records.length - 1].endMs : Date.now())

    const wStart = now - windowMs

    // ── collect window records (reverse scan, time-ordered) ──
    const windowRecs = []
    let windowEarliest = Infinity
    let windowLatest   = -Infinity
    let rtSum          = 0
    let failedCount    = 0

    // We need the VU window too; compute adaptive bound after raw avg RT
    // First pass: gather main window records
    for (let i = records.length - 1; i >= 0; i--) {
      const r = records[i]
      if (r.endMs <= wStart) break
      if (r.endMs <= now) {
        windowRecs.push(r)
        rtSum += r.rtMs
        if (r.failed) failedCount++
        if (r.endMs < windowEarliest) windowEarliest = r.endMs
        if (r.endMs > windowLatest)   windowLatest   = r.endMs
      }
    }

    const total = windowRecs.length
    const rawAvgRt = total > 0 ? rtSum / total : 0

    // ── 1. Throughput — actual timestamp span ──
    let actualSpanMs = total > 1 ? windowLatest - windowEarliest : 0
    if (actualSpanMs < MIN_SPAN_MS) actualSpanMs = MIN_SPAN_MS
    const rawTps = total > 0 ? Math.round(total / (actualSpanMs / 1000)) : 0
    const rawHps = rawTps

    // ── 4. Adaptive Active VU Window ──
    const adaptiveVuWindowMs = Math.max(pollMs * 2, 3 * rawAvgRt)
    const vuStart = now - adaptiveVuWindowMs

    const vuIds = new Set()
    for (let i = records.length - 1; i >= 0; i--) {
      const r = records[i]
      if (r.endMs <= vuStart) break
      if (r.endMs <= now) vuIds.add(r.vuId)
    }
    const activeVUs = vuIds.size

    // ── 2. Percentiles — histogram or nearest-rank fallback ──
    let p50, p90, p95, p99
    const canComputePercentiles = total >= MIN_PERCENTILE_SAMPLES

    if (!canComputePercentiles) {
      // 5. Stability guardrail: hold previous stable values
      p50 = stablePerc.p50
      p90 = stablePerc.p90
      p95 = stablePerc.p95
      p99 = stablePerc.p99
    } else if (total < NEAREST_RANK_THRESHOLD) {
      // Small sample: exact nearest-rank on sorted array
      const sorted = windowRecs.map(r => r.rtMs).sort((a, b) => a - b)
      p50 = nearestRank(sorted, 50)
      p90 = nearestRank(sorted, 90)
      p95 = nearestRank(sorted, 95)
      p99 = nearestRank(sorted, 99)
      stablePerc.p50 = p50; stablePerc.p90 = p90
      stablePerc.p95 = p95; stablePerc.p99 = p99
    } else {
      // Larger sample: bucketed histogram estimator
      histo.clear()
      for (let i = 0; i < total; i++) histo.add(windowRecs[i].rtMs)
      p50 = histo.percentile(50)
      p90 = histo.percentile(90)
      p95 = histo.percentile(95)
      p99 = histo.percentile(99)
      stablePerc.p50 = p50; stablePerc.p90 = p90
      stablePerc.p95 = p95; stablePerc.p99 = p99
    }

    // ── UX Variance with guardrail ──
    const rawUxVar = canComputePercentiles ? Math.max(0, p95 - p50) : stablePerc.uxVar
    if (canComputePercentiles) stablePerc.uxVar = rawUxVar

    // ── 6. Error rate ──
    // Rolling rate (used for rolling stats return value only)
    const errorPct = total > 0
      ? parseFloat(((failedCount / total) * 100).toFixed(2))
      : 0

    // Cumulative rate for the graph — never drops back to zero between error bursts
    const cumulativeErrorPct = cum.totalReqs > 0
      ? parseFloat(((cum.totalErrors / cum.totalReqs) * 100).toFixed(2))
      : 0

    // ── 8. Cumulative requests ──
    const totalRequests = cum.totalReqs

    // ── 3. EMA smoothing for graph values ──
    smooth.tps   = ema(smooth.tps,   rawTps)
    smooth.avgRt = ema(smooth.avgRt, Math.round(rawAvgRt))
    smooth.uxVar = ema(smooth.uxVar, rawUxVar)

    const graphTps   = Math.round(smooth.tps)
    const graphAvgRt = Math.round(smooth.avgRt)
    const graphUxVar = Math.round(smooth.uxVar)
    const graphHps   = graphTps

    // Peak throughput uses raw (not smoothed) to catch true peaks
    if (rawTps > cum.peakTps) cum.peakTps = rawTps

    // ── append graph point ──
    tickIndex++
    const t = tickIndex
    const push = (arr, pt) => { arr.push(pt); if (arr.length > MAX_GRAPH_POINTS) arr.shift() }

    push(graph.throughput,  { t, v: graphTps })
    push(graph.avg_rt,      { t, v: graphAvgRt })
    push(graph.hits,        { t, v: graphHps })
    push(graph.active_vus,  { t, v: activeVUs })
    // Use cumulative error rate so the graph never resets to 0 after a burst of errors.
    // Store totalErrors on the point so the stats card can display the exact count.
    push(graph.error_rate,  { t, v: cumulativeErrorPct, totalErrors: cum.totalErrors })
    push(graph.requests,    { t, v: totalRequests })
    push(graph.latency,     { t, p50, p90, p95, p99 })
    push(graph.ux_variance, { t, v: graphUxVar })

    // ── per-API and per-TX rolling stats for time series ──
    const apiWin = {}
    const txWin  = {}
    for (const r of windowRecs) {
      let aw = apiWin[r.apiPath]
      if (!aw) { aw = { total: 0, errors: 0, rtSum: 0, earliest: Infinity, latest: -Infinity }; apiWin[r.apiPath] = aw }
      aw.total++; aw.rtSum += r.rtMs; if (r.failed) aw.errors++
      if (r.endMs < aw.earliest) aw.earliest = r.endMs
      if (r.endMs > aw.latest)   aw.latest   = r.endMs

      let tw = txWin[r.seqKey]
      if (!tw) { tw = { total: 0, errors: 0, rtSum: 0, earliest: Infinity, latest: -Infinity }; txWin[r.seqKey] = tw }
      tw.total++; tw.rtSum += r.rtMs; if (r.failed) tw.errors++
      if (r.endMs < tw.earliest) tw.earliest = r.endMs
      if (r.endMs > tw.latest)   tw.latest   = r.endMs
    }
    for (const apiPath of Object.keys(perApiCum)) {
      if (!perApiGraph[apiPath]) perApiGraph[apiPath] = []
      push(perApiGraph[apiPath], { t, ..._itemStats(apiWin[apiPath]) })
    }
    for (const seqKey of Object.keys(perTxCum)) {
      if (!perTxGraph[seqKey]) perTxGraph[seqKey] = []
      push(perTxGraph[seqKey], { t, ..._itemStats(txWin[seqKey]) })
    }

    // ── evict old records (strict timestamp filtering) ──
    const evictBefore = now - RECORD_RETENTION_MS
    let cutIdx = 0
    while (cutIdx < records.length && records[cutIdx].endMs < evictBefore) cutIdx++
    if (cutIdx > 0) records = records.slice(cutIdx)

    return {
      rolling:    { tps: rawTps, hps: rawHps, avgRt: Math.round(rawAvgRt), p50, p90, p95, p99, uxVar: rawUxVar, errorPct, activeVUs },
      cumulative: getCumulativeStats(),
      graphData:  getGraphData(),
      perScript:  _perScriptStats(windowRecs, now, adaptiveVuWindowMs),
    }
  }

  // ── cumulative stats ──

  function getCumulativeStats() {
    return {
      totalRequests:   cum.totalReqs,
      cumulativeAvgRt: cum.totalReqs > 0 ? Math.round(cum.totalRtSum / cum.totalReqs) : 0,
      totalErrors:     cum.totalErrors,
      totalErrorPct:   cum.totalReqs > 0
        ? parseFloat(((cum.totalErrors / cum.totalReqs) * 100).toFixed(2))
        : 0,
      peakThroughput:  cum.peakTps,
    }
  }

  // ── graph data (shallow copy) ──

  function getGraphData() {
    return {
      throughput:  graph.throughput.slice(),
      avg_rt:      graph.avg_rt.slice(),
      hits:        graph.hits.slice(),
      active_vus:  graph.active_vus.slice(),
      error_rate:  graph.error_rate.slice(),
      requests:    graph.requests.slice(),
      latency:     graph.latency.slice(),
      ux_variance: graph.ux_variance.slice(),
    }
  }

  // ── per-script breakdown ──

  function _perScriptStats(windowRecs, now, vuWindowMs) {
    const vuStart = now - vuWindowMs
    const byScript = {}

    for (const r of windowRecs) {
      if (!byScript[r.scriptId]) byScript[r.scriptId] = { total: 0, failed: 0, rtSum: 0, vuSet: new Set(), earliest: Infinity, latest: -Infinity }
      const s = byScript[r.scriptId]
      s.total++
      if (r.failed) s.failed++
      s.rtSum += r.rtMs
      if (r.endMs < s.earliest) s.earliest = r.endMs
      if (r.endMs > s.latest) s.latest = r.endMs
    }

    // VU set from adaptive window (separate scan)
    for (let i = records.length - 1; i >= 0; i--) {
      const r = records[i]
      if (r.endMs <= vuStart) break
      if (r.endMs <= now) {
        if (!byScript[r.scriptId]) byScript[r.scriptId] = { total: 0, failed: 0, rtSum: 0, vuSet: new Set(), earliest: Infinity, latest: -Infinity }
        byScript[r.scriptId].vuSet.add(r.vuId)
      }
    }

    const result = {}
    const allIds = new Set([...Object.keys(byScript), ...Object.keys(perScriptCum)])
    for (const sid of allIds) {
      const r = byScript[sid] || { total: 0, failed: 0, rtSum: 0, vuSet: new Set(), earliest: 0, latest: 0 }
      const c = perScriptCum[sid] || { totalReqs: 0, totalRtSum: 0, totalErrors: 0 }
      // Per-script TPS also uses actual span
      let span = r.total > 1 ? r.latest - r.earliest : 0
      if (span < MIN_SPAN_MS) span = MIN_SPAN_MS
      result[sid] = {
        tps:           r.total > 0 ? Math.round(r.total / (span / 1000)) : 0,
        avgRt:         r.total > 0 ? Math.round(r.rtSum / r.total) : 0,
        maxRt:         c.maxRt || 0,
        activeVUs:     r.vuSet.size,
        totalRequests: c.totalReqs,
        totalErrors:   c.totalErrors,
      }
    }
    return result
  }

  // ── per-API / per-Transaction stats (cumulative, for the stats table) ──

  function _buildStats(acc) {
    const rts = acc.rts.slice().sort((a, b) => a - b)
    const n   = rts.length
    const pct = (p) => n > 0 ? rts[Math.min(Math.ceil(p / 100 * n) - 1, n - 1)] : 0
    return {
      min:   acc.minRt === Infinity ? 0 : acc.minRt,
      avg:   n > 0 ? Math.round(acc.rtSum / n) : 0,
      max:   acc.maxRt,
      p90:   pct(90),
      p95:   pct(95),
      p99:   pct(99),
      pass:  acc.total - acc.errors,
      fail:  acc.errors,
      total: acc.total,
    }
  }

  function getApiStats() {
    return Object.fromEntries(Object.entries(perApiCum).map(([k, v]) => [k, _buildStats(v)]))
  }

  function getTxStats() {
    return Object.fromEntries(Object.entries(perTxCum).map(([k, v]) => [k, _buildStats(v)]))
  }

  // ── per-API / per-TX time series (shallow copy) ──

  function getApiGraphData() {
    return Object.fromEntries(Object.entries(perApiGraph).map(([k, v]) => [k, v.slice()]))
  }

  function getTxGraphData() {
    return Object.fromEntries(Object.entries(perTxGraph).map(([k, v]) => [k, v.slice()]))
  }

  // ── reset ──

  function reset() {
    records = []
    fetchOffset = 0
    tickIndex = 0
    cum.totalReqs = 0; cum.totalRtSum = 0; cum.totalErrors = 0; cum.peakTps = 0
    smooth.tps = null; smooth.avgRt = null; smooth.uxVar = null
    stablePerc.p50 = 0; stablePerc.p90 = 0; stablePerc.p95 = 0; stablePerc.p99 = 0; stablePerc.uxVar = 0
    histo.clear()
    for (const k of Object.keys(perScriptCum)) delete perScriptCum[k]
    for (const k of Object.keys(perApiCum))    delete perApiCum[k]
    for (const k of Object.keys(perTxCum))     delete perTxCum[k]
    for (const k of Object.keys(perApiGraph))  delete perApiGraph[k]
    for (const k of Object.keys(perTxGraph))   delete perTxGraph[k]
    for (const k of Object.keys(graph)) graph[k] = []
  }

  // ── public API ──

  return {
    ingest,
    computeTick,
    getCumulativeStats,
    getGraphData,
    getApiStats,
    getTxStats,
    getApiGraphData,
    getTxGraphData,
    reset,
    get fetchOffset() { return fetchOffset },
    get recordCount() { return records.length },
    get tickCount()   { return tickIndex },
  }
}

/**
 * Replay Engine — reconstructs chart data from raw telemetry records.
 * Used by the Test Results page to display historical test run dashboards.
 */

import { getExecutionTelemetry } from '../api'
import { normalizeApiPath } from './pathNormalizer'

const INTERVAL_MS = 5000
const WINDOW_MS   = 5000

export async function fetchAllTelemetry(testRunId) {
  const BATCH = 2000
  let offset = 0
  let all = []
  while (true) {
    const batch = await getExecutionTelemetry(testRunId, BATCH, offset)
    if (!batch || !batch.length) break
    all = all.concat(batch)
    if (batch.length < BATCH) break
    offset += BATCH
  }
  return all
}

function emptyChartData() {
  return {
    throughput:  [{ t: 0, v: 0 }],
    avg_rt:      [{ t: 0, v: 0 }],
    hits:        [{ t: 0, v: 0 }],
    active_vus:  [{ t: 0, v: 0 }],
    error_rate:  [{ t: 0, v: 0 }],
    requests:    [{ t: 0, v: 0 }],
    latency:     [{ t: 0, p50: 0, p90: 0, p95: 0, p99: 0 }],
    ux_variance: [{ t: 0, v: 0 }],
  }
}

function pctile(sorted, p) {
  if (!sorted.length) return 0
  return sorted[Math.max(0, Math.ceil(p / 100 * sorted.length) - 1)]
}

export function replayTelemetry(records) {
  if (!records?.length) return emptyChartData()

  const parsed = records.map(r => ({
    endMs:    new Date(r.request_end_ts).getTime(),
    startMs:  new Date(r.request_start_ts).getTime(),
    rtMs:     r.response_time_ms || 0,
    success:  r.success !== false && r.success !== 0 && ((r.http_status_code || 200) < 500),
    vuId:     r.virtual_user_id || '',
    scriptId: r.script_id || '',
  })).sort((a, b) => a.endMs - b.endMs)

  const testStart = parsed[0].startMs
  const testEnd   = parsed[parsed.length - 1].endMs

  const data = { throughput: [], avg_rt: [], hits: [], active_vus: [], error_rate: [], requests: [], latency: [], ux_variance: [] }
  let sampleIdx = 0

  for (let t = testStart + INTERVAL_MS; t <= testEnd + INTERVAL_MS; t += INTERVAL_MS) {
    const wStart = t - WINDOW_MS
    const wRecs  = parsed.filter(r => r.endMs > wStart && r.endMs <= t)
    const count  = wRecs.length
    const cumCount  = parsed.filter(r => r.endMs <= t).length
    const cumErrors = parsed.filter(r => r.endMs <= t && !r.success).length

    let spanMs = count > 1 ? wRecs[count - 1].endMs - wRecs[0].endMs : 1000
    if (spanMs < 1000) spanMs = 1000
    const tps = count > 0 ? Math.round(count / (spanMs / 1000)) : 0

    const rts   = wRecs.map(r => r.rtMs)
    const avgRt = rts.length > 0 ? Math.round(rts.reduce((s, v) => s + v, 0) / rts.length) : 0

    const sorted = [...rts].sort((a, b) => a - b)
    const p50 = pctile(sorted, 50), p90 = pctile(sorted, 90)
    const p95 = pctile(sorted, 95), p99 = pctile(sorted, 99)

    const vuWindow = Math.max(10000, 3 * avgRt)
    const vuStart  = t - vuWindow
    const activeVUs = new Set(
      parsed.filter(r => r.endMs > vuStart && r.endMs <= t).map(r => r.vuId)
    ).size

    const uxVar = Math.max(0, p95 - p50)

    // Use cumulative error rate so the graph never resets to 0 after a burst of errors.
    // Store totalErrors on each point so the stats card can display the exact count.
    const cumulativeErrorPct = cumCount > 0
      ? parseFloat(((cumErrors / cumCount) * 100).toFixed(2))
      : 0

    data.throughput.push({ t: sampleIdx, v: tps })
    data.avg_rt.push({ t: sampleIdx, v: avgRt })
    data.hits.push({ t: sampleIdx, v: tps })
    data.active_vus.push({ t: sampleIdx, v: activeVUs })
    data.error_rate.push({ t: sampleIdx, v: cumulativeErrorPct, totalErrors: cumErrors })
    data.requests.push({ t: sampleIdx, v: cumCount })
    data.latency.push({ t: sampleIdx, p50, p90, p95, p99 })
    data.ux_variance.push({ t: sampleIdx, v: uxVar })
    sampleIdx++
  }

  return sampleIdx === 0 ? emptyChartData() : data
}

/**
 * Compute per-API and per-TX time series from raw telemetry (replayed at 5 s intervals).
 * Returns { apiGraphData: { [apiPath]: [{t, avgRt, tps, errPct}] },
 *           txGraphData:  { [seqKey]:  [{t, avgRt, tps, errPct}] } }
 */
export function replayApiTxGraphData(records) {
  if (!records?.length) return { apiGraphData: {}, txGraphData: {} }

  const parsed = records.map(r => ({
    endMs:   new Date(r.request_end_ts).getTime(),
    rtMs:    r.response_time_ms || 0,
    success: r.success !== false && r.success !== 0 && ((r.http_status_code || 200) < 500),
    apiPath: normalizeApiPath(r.api_path || '(unknown)'),
    seqKey:  `${r.script_id || ''}:${r.sequence_number ?? 0}`,
  })).sort((a, b) => a.endMs - b.endMs)

  const testStart = parsed[0].endMs - INTERVAL_MS
  const testEnd   = parsed[parsed.length - 1].endMs

  const apiGraphData = {}
  const txGraphData  = {}
  let sampleIdx = 0

  for (let time = testStart + INTERVAL_MS; time <= testEnd + INTERVAL_MS; time += INTERVAL_MS) {
    const wStart = time - WINDOW_MS
    const wRecs  = parsed.filter(r => r.endMs > wStart && r.endMs <= time)

    const apiWin = {}
    const txWin  = {}
    for (const r of wRecs) {
      for (const [map, key] of [[apiWin, r.apiPath], [txWin, r.seqKey]]) {
        let w = map[key]
        if (!w) { w = { total: 0, errors: 0, rtSum: 0, earliest: Infinity, latest: -Infinity }; map[key] = w }
        w.total++; w.rtSum += r.rtMs; if (!r.success) w.errors++
        if (r.endMs < w.earliest) w.earliest = r.endMs
        if (r.endMs > w.latest)   w.latest   = r.endMs
      }
    }

    const mkPt = (w, t) => {
      if (!w || w.total === 0) return { t, avgRt: 0, tps: 0, errPct: 0 }
      const avgRt = Math.round(w.rtSum / w.total)
      let span = w.total > 1 ? w.latest - w.earliest : 0
      if (span < 1000) span = 1000
      return {
        t,
        avgRt,
        tps:    Math.round(w.total / (span / 1000)),
        errPct: parseFloat(((w.errors / w.total) * 100).toFixed(2)),
      }
    }

    for (const [apiPath, w] of Object.entries(apiWin)) {
      if (!apiGraphData[apiPath]) apiGraphData[apiPath] = []
      apiGraphData[apiPath].push(mkPt(w, sampleIdx))
    }
    for (const [seqKey, w] of Object.entries(txWin)) {
      if (!txGraphData[seqKey]) txGraphData[seqKey] = []
      txGraphData[seqKey].push(mkPt(w, sampleIdx))
    }

    sampleIdx++
  }

  return { apiGraphData, txGraphData }
}

/**
 * Compute per-API-path and per-transaction stats from raw telemetry.
 * Returns { apiStats: { [apiPath]: {...} }, txStats: { ["scriptId:seqNum"]: {...} } }
 * Each entry has: min, avg, max, p90, p95, p99, pass, fail, total
 */
export function computeApiTxStats(records) {
  if (!records?.length) return { apiStats: {}, txStats: {} }

  const perApi = {}
  const perTx  = {}

  for (const r of records) {
    const succeeded = r.success !== false && r.success !== 0 && ((r.http_status_code || 200) < 500)
    const rtMs    = r.response_time_ms || 0
    const apiPath = normalizeApiPath(r.api_path || '(unknown)')
    const seqKey  = `${r.script_id || ''}:${r.sequence_number ?? 0}`

    for (const [map, key] of [[perApi, apiPath], [perTx, seqKey]]) {
      if (!map[key]) map[key] = { total: 0, errors: 0, rtSum: 0, minRt: Infinity, maxRt: 0, rts: [] }
      const a = map[key]
      a.total++; a.rtSum += rtMs; a.rts.push(rtMs)
      if (rtMs < a.minRt) a.minRt = rtMs
      if (rtMs > a.maxRt) a.maxRt = rtMs
      if (!succeeded) a.errors++
    }
  }

  function buildStats(acc) {
    const rts = acc.rts.slice().sort((a, b) => a - b)
    const n   = rts.length
    const pct = (p) => n > 0 ? rts[Math.min(Math.ceil(p / 100 * n) - 1, n - 1)] : 0
    return {
      min:   acc.minRt === Infinity ? 0 : acc.minRt,
      avg:   n > 0 ? Math.round(acc.rtSum / n) : 0,
      max:   acc.maxRt,
      p90:   pct(90),
      p95:   pct(95),
      p99:   pct(99),
      pass:  acc.total - acc.errors,
      fail:  acc.errors,
      total: acc.total,
    }
  }

  return {
    apiStats: Object.fromEntries(Object.entries(perApi).map(([k, v]) => [k, buildStats(v)])),
    txStats:  Object.fromEntries(Object.entries(perTx).map(([k, v]) => [k, buildStats(v)])),
  }
}

/**
 * Compute per-script aggregate stats from raw telemetry records.
 * Returns { [scriptId]: { passed, failed, avgRt, maxRt, tps } }
 */
export function computePerScriptStats(records) {
  if (!records?.length) return {}

  const parsed = records.map(r => ({
    endMs:    new Date(r.request_end_ts).getTime(),
    rtMs:     r.response_time_ms || 0,
    success:  r.success !== false && r.success !== 0 && ((r.http_status_code || 200) < 500),
    scriptId: r.script_id || '',
  }))

  const buckets = {}
  for (const r of parsed) {
    const sid = r.scriptId
    if (!buckets[sid]) {
      buckets[sid] = { totalReqs: 0, totalErrors: 0, rtSum: 0, maxRt: 0, minTs: Infinity, maxTs: -Infinity }
    }
    const b = buckets[sid]
    b.totalReqs++
    if (!r.success) b.totalErrors++
    b.rtSum  += r.rtMs
    if (r.rtMs  > b.maxRt) b.maxRt = r.rtMs
    if (r.endMs < b.minTs) b.minTs = r.endMs
    if (r.endMs > b.maxTs) b.maxTs = r.endMs
  }

  const result = {}
  for (const [sid, b] of Object.entries(buckets)) {
    const durationMs = Math.max(1000, b.maxTs - b.minTs)
    result[sid] = {
      passed: b.totalReqs - b.totalErrors,
      failed: b.totalErrors,
      avgRt:  b.totalReqs > 0 ? Math.round(b.rtSum / b.totalReqs) : 0,
      maxRt:  b.maxRt,
      tps:    Math.round(b.totalReqs / (durationMs / 1000)),
    }
  }
  return result
}

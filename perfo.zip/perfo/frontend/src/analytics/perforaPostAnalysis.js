/**
 * Perfora Guardian — Post-Test Analysis Engine
 *
 * Analyses completed test data and generates plain-language observations
 * and recommendations. All findings are written for any team member to
 * understand — not just performance engineers.
 */

// ── Internal thresholds (not exposed in UI language) ──────────────────────

const RT = { excellent: 200, good: 500, acceptable: 1000, poor: 2000 }
const ER = { excellent: 0.5, acceptable: 2, warning: 5 }

// ── Math helpers ───────────────────────────────────────────────────────────

function _mean(arr) {
  return arr.length ? arr.reduce((s, v) => s + v, 0) / arr.length : 0
}
function _stddev(arr) {
  if (arr.length < 2) return 0
  const m = _mean(arr)
  return Math.sqrt(arr.reduce((s, v) => s + (v - m) ** 2, 0) / arr.length)
}
function _pct(oldV, newV) {
  if (!oldV || oldV <= 0) return 0
  return ((newV - oldV) / oldV) * 100
}
function _fmt(n) { return Math.round(n).toLocaleString() }

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Analyse a completed test run and return a prioritised list of findings.
 *
 * @param {{ chartData, apiStats, txStats, totalVUs }} opts
 * @returns {Array<{ id, category, severity, title, finding, recommendation }>}
 */
export function analyzeTestResults({ chartData = {}, apiStats = {}, txStats = {}, totalVUs = 0 } = {}) {
  const findings = []

  // ── Extract aggregate series ─────────────────────────────────────────────

  const rtSeries  = (chartData.avg_rt    || []).map(p => p.v).filter(v => v > 0)
  const tpsSeries = (chartData.throughput || []).map(p => p.v).filter(v => v > 0)
  const errSeries = (chartData.error_rate || [])
  const latSeries = (chartData.latency    || [])

  const avgRt   = rtSeries.length  ? Math.round(_mean(rtSeries))  : 0
  const avgTps  = tpsSeries.length ? parseFloat(_mean(tpsSeries).toFixed(2)) : 0
  const peakTps = tpsSeries.length ? Math.max(...tpsSeries) : 0

  const p95vals = latSeries.map(p => p.p95).filter(v => v > 0)
  const avgP95  = p95vals.length ? Math.round(_mean(p95vals)) : 0
  const p99vals = latSeries.map(p => p.p99).filter(v => v > 0)
  const avgP99  = p99vals.length ? Math.round(_mean(p99vals)) : 0

  const totalRequests = Object.values(apiStats).reduce((s, v) => s + (v.pass || 0) + (v.fail || 0), 0)
  const totalErrors   = Object.values(apiStats).reduce((s, v) => s + (v.fail || 0), 0)
  const errPct        = totalRequests > 0 ? (totalErrors / totalRequests) * 100
                        : (errSeries.at(-1)?.v ?? 0)

  const apiEntries = Object.entries(apiStats).filter(([k]) => k && k !== '(unknown)')

  // ── 1 · Overall Response Time ─────────────────────────────────────────────

  if (avgRt > 0) {
    if (avgRt < RT.excellent) {
      findings.push({
        id: 'rt_excellent', category: 'Response Time', severity: 'good',
        title: 'App responds quickly — users won\'t notice any delay',
        finding: `Average response time was ${_fmt(avgRt)} ms — fast enough that the app feels instant to users. This is well within the recommended target.`,
        recommendation: 'Great result. Before going live, run the same test with more users to make sure the app stays this fast under heavier traffic.',
      })
    } else if (avgRt < RT.good) {
      findings.push({
        id: 'rt_good', category: 'Response Time', severity: 'info',
        title: 'Decent response times — room to improve',
        finding: `Average response time was ${_fmt(avgRt)} ms — most users will find this acceptable, but the app isn't at its fastest. Anything above 200 ms starts to feel slightly sluggish in interactive apps.`,
        recommendation: 'Look at which APIs or database queries are slowest. Small wins in query plans and caching often give the biggest speed improvement.',
      })
    } else if (avgRt < RT.acceptable) {
      findings.push({
        id: 'rt_elevated', category: 'Response Time', severity: 'warning',
        title: 'App feels slow — users will notice delays',
        finding: `Average response time was ${_fmt(avgRt)} ms — at this level, most users will experience a noticeable wait. Pages feel sluggish and actions take a moment longer than expected.`,
        recommendation: 'Check for slow database queries (especially ones that run multiple times per request), missing caches on frequently read data, or APIs that call other services one-by-one instead of in parallel.',
      })
    } else {
      findings.push({
        id: 'rt_poor', category: 'Response Time', severity: 'critical',
        title: avgRt < RT.poor ? 'App is very slow — users will likely give up' : 'App is critically slow — system appears overloaded',
        finding: avgRt < RT.poor
          ? `Average response time was ${_fmt(avgRt)} ms — users will clearly feel the lag. At this speed, most people will abandon pages before they load.`
          : `Average response time was ${_fmt(avgRt)} ms — this is extremely slow and suggests the system is struggling to cope with this many users.`,
        recommendation: avgRt < RT.poor
          ? 'Profile the slowest parts of your application — look at database queries, external API calls, and whether the server is running out of threads to handle requests.'
          : 'Reduce the number of simulated users and re-run to find where things start breaking down. Also check server health: CPU, memory usage, and whether connection limits are being hit.',
      })
    }
  }

  // ── 2 · Consistency of response times (slowest requests vs average) ────────

  if (avgRt > 0 && avgP95 > 0) {
    const ratio = avgP95 / avgRt
    if (ratio > 4) {
      findings.push({
        id: 'tail_severe', category: 'Response Time', severity: 'critical',
        title: 'Some users waited much longer — response times are very inconsistent',
        finding: `While the average response time was ${_fmt(avgRt)} ms, the slowest 5% of requests took ${_fmt(avgP95)} ms or more — ${ratio.toFixed(1)}× longer. That means roughly 1 in 20 users had a significantly worse experience than the headline number suggests.`,
        recommendation: 'Look into what makes the slow requests different from the fast ones. Common causes: database row-level locks causing queuing, occasional memory cleanup pauses on the server, or a slow external service that times out intermittently.',
      })
    } else if (ratio > 2.5) {
      findings.push({
        id: 'tail_warning', category: 'Response Time', severity: 'warning',
        title: 'Response times are inconsistent — some users wait much longer',
        finding: `The average was ${_fmt(avgRt)} ms, but the slowest 5% of requests took ${_fmt(avgP95)} ms — ${ratio.toFixed(1)}× longer than average. There is a clear gap between how fast most requests are and how long the worst ones take.`,
        recommendation: 'Set timeouts on calls to external services so a slow dependency doesn\'t hold up every request. Consider wrapping unreliable downstream calls so one slow service can\'t bring down the whole response.',
      })
    } else if (avgP95 > 0) {
      findings.push({
        id: 'tail_good', category: 'Response Time', severity: 'good',
        title: 'Response times are consistent — very few slow outliers',
        finding: `The slowest 5% of requests (${_fmt(avgP95)} ms) were only ${ratio.toFixed(1)}× the average (${_fmt(avgRt)} ms). Most users are getting a similar experience — there are very few unusually slow requests.`,
        recommendation: 'Consistent performance across requests is a good sign. Run a longer test to confirm this holds up over an extended period.',
      })
    }
  }

  // ── 2b · Rare but very severe slowdowns ───────────────────────────────────

  if (avgP95 > 0 && avgP99 > 0) {
    const p99p95 = avgP99 / avgP95
    if (p99p95 > 3) {
      findings.push({
        id: 'p99_extreme', category: 'Response Time', severity: 'warning',
        title: 'Occasional requests are extremely slow — a small group of users hit bad delays',
        finding: `The slowest 1% of requests took ${_fmt(avgP99)} ms — ${p99p95.toFixed(1)}× worse than even the slowest 5% (${_fmt(avgP95)} ms). While this affects a small number of users, those sessions are likely ruined by the wait.`,
        recommendation: 'These rare but extreme delays are often caused by the server pausing for memory cleanup, a connection being set up for the very first time, or a retry loop piling up on a slow request. Worth tracking down even though they\'re infrequent — they disproportionately hurt user experience.',
      })
    }
  }

  // ── 3 · Did the app get faster or slower as the test ran? ─────────────────

  if (rtSeries.length >= 6) {
    const q      = Math.max(1, Math.ceil(rtSeries.length / 5))
    const early  = _mean(rtSeries.slice(0, q))
    const late   = _mean(rtSeries.slice(-q))
    const trend  = _pct(early, late)

    if (trend > 40) {
      findings.push({
        id: 'rt_degrading', category: 'Stability', severity: 'critical',
        title: 'App got significantly slower as the test ran',
        finding: `Response times started at around ${_fmt(early)} ms but climbed to ${_fmt(late)} ms by the end — a ${Math.round(trend)}% increase. The app couldn't keep up with sustained load over time.`,
        recommendation: 'This usually points to a gradual resource drain — memory not being freed, the connection pool filling up, or a queue backing up. Run a longer test (30–60 min) to see how far performance keeps declining.',
      })
    } else if (trend > 20) {
      findings.push({
        id: 'rt_degrading_mild', category: 'Stability', severity: 'warning',
        title: 'App got slightly slower over time',
        finding: `Response times drifted from ${_fmt(early)} ms at the start to ${_fmt(late)} ms by the end — a ${Math.round(trend)}% increase. Performance wasn't fully stable under sustained load.`,
        recommendation: 'Keep an eye on memory and connection usage over the test window. A longer soak test will reveal whether this is a slow leak or if performance eventually plateaus.',
      })
    } else if (trend < -25) {
      findings.push({
        id: 'rt_warmup', category: 'Stability', severity: 'info',
        title: 'App started slow then improved — likely just warming up',
        finding: `Response times were ${_fmt(early)} ms at the start but dropped to ${_fmt(late)} ms by the end — a ${Math.round(Math.abs(trend))}% improvement. This pattern is normal when the app (or database) is cold and needs a moment to warm up.`,
        recommendation: 'Add a short warm-up phase at the start of your test where a few users run through key flows before results are recorded. This gives a more accurate picture of real-world performance.',
      })
    } else {
      findings.push({
        id: 'rt_stable', category: 'Stability', severity: 'good',
        title: 'Performance stayed consistent throughout the test',
        finding: `Response times were ${_fmt(early)} ms at the start and ${_fmt(late)} ms at the end — only ${Math.round(trend) >= 0 ? '+' : ''}${Math.round(trend)}% drift. The app held up well under sustained load.`,
        recommendation: 'Consistent performance over time is a strong result. Run the same test with more users to find the point where things start to degrade.',
      })
    }
  }

  // ── 4 · Were response times steady or all over the place? ─────────────────

  if (rtSeries.length >= 4) {
    const cv = avgRt > 0 ? _stddev(rtSeries) / _mean(rtSeries) : 0
    if (cv > 0.45) {
      findings.push({
        id: 'instability', category: 'Stability', severity: 'warning',
        title: 'Response times were all over the place — user experience was unpredictable',
        finding: `Response times varied by ${Math.round(cv * 100)}% throughout the test — some moments were fast, others noticeably slow. Users running the same actions at different times had very different experiences.`,
        recommendation: 'Unpredictable performance is often caused by background jobs or scheduled tasks competing for resources during the test. Try to identify what the app is doing during the slow patches — check logs and server metrics for unusual activity.',
      })
    }
  }

  // ── 5 · Overall error rate ────────────────────────────────────────────────

  if (errPct < ER.excellent) {
    findings.push({
      id: 'err_excellent', category: 'Reliability', severity: 'good',
      title: 'Almost no errors — app handled load reliably',
      finding: `Only ${errPct.toFixed(2)}% of requests failed — just ${totalErrors.toLocaleString()} failures out of ${totalRequests.toLocaleString()} total. The app dealt with this load without significant problems.`,
      recommendation: 'Strong reliability result. Also check that the app handles edge cases gracefully — things like rate limits, timeouts, and partial failures — before going live.',
    })
  } else if (errPct < ER.acceptable) {
    findings.push({
      id: 'err_low', category: 'Reliability', severity: 'info',
      title: 'Mostly reliable — a small number of errors worth investigating',
      finding: `${errPct.toFixed(2)}% of requests failed — ${totalErrors.toLocaleString()} failures out of ${totalRequests.toLocaleString()} total. This is within tolerable range, but worth understanding where these failures came from.`,
      recommendation: 'Check which specific APIs were failing and look at server logs for the reason. Make sure these failures aren\'t happening on critical flows like login, checkout, or data saves.',
    })
  } else if (errPct < ER.warning) {
    findings.push({
      id: 'err_warning', category: 'Reliability', severity: 'warning',
      title: 'Noticeable errors — some users are hitting failures',
      finding: `${errPct.toFixed(2)}% of requests failed — ${totalErrors.toLocaleString()} failures out of ${totalRequests.toLocaleString()} total. At this level, users will regularly run into errors during normal use.`,
      recommendation: 'Find the failing endpoints from the API breakdown below and check server logs for the root cause. Common culprits: rate limits being hit, connection timeouts, or a backend service throwing errors under load.',
    })
  } else {
    findings.push({
      id: 'err_critical', category: 'Reliability', severity: 'critical',
      title: 'Too many errors — app is not ready for this load',
      finding: `${errPct.toFixed(2)}% of requests failed — ${totalErrors.toLocaleString()} out of ${totalRequests.toLocaleString()} total. At this failure rate, the majority of users will encounter errors during normal use.`,
      recommendation: 'Don\'t ship under this load. Reduce the number of simulated users and re-run to find where failures start. Also check: is the server running out of connections? Are any backend services timing out or crashing?',
    })
  }

  // ── 5b · Did the error rate get better or worse during the test? ──────────

  if (errSeries.length >= 6 && errPct > 0.5) {
    const errVals = errSeries.map(p => p.v ?? p).filter(v => typeof v === 'number' && v >= 0)
    if (errVals.length >= 6) {
      const q        = Math.max(1, Math.ceil(errVals.length / 4))
      const earlyErr = _mean(errVals.slice(0, q))
      const lateErr  = _mean(errVals.slice(-q))

      if (earlyErr > 0 && lateErr / earlyErr > 1.5) {
        findings.push({
          id: 'err_rising', category: 'Reliability', severity: 'warning',
          title: 'Errors kept getting worse as the test ran',
          finding: `The error rate was ${earlyErr.toFixed(1)}% at the start and rose to ${lateErr.toFixed(1)}% by the end — a ${Math.round((lateErr / earlyErr - 1) * 100)}% increase. The app didn't just have a rough start — it progressively deteriorated under load.`,
          recommendation: 'Progressive worsening like this usually means something is being exhausted over time — database connections, memory, or file handles. Check server resource metrics over the test window to see what started building up.',
        })
      } else if (earlyErr > 0 && lateErr / earlyErr < 0.5 && earlyErr > 2) {
        findings.push({
          id: 'err_improving', category: 'Reliability', severity: 'info',
          title: 'Errors were high at the start but improved — likely a warm-up issue',
          finding: `The error rate was ${earlyErr.toFixed(1)}% early on but dropped to ${lateErr.toFixed(1)}% later. The app likely struggled with a cold start — caches not ready, connections not yet established — before settling down.`,
          recommendation: 'Add a warm-up phase before the main test window to give the system time to initialise. This way early failures won\'t inflate your overall error count.',
        })
      }
    }
  }

  // ── 6 · How steady was the throughput? ────────────────────────────────────

  if (avgTps > 0) {
    const burstRatio = peakTps / avgTps
    if (burstRatio > 6) {
      findings.push({
        id: 'tps_bursty', category: 'Throughput', severity: 'warning',
        title: 'Very uneven traffic — occasional large spikes in activity',
        finding: `At its peak the app handled ${_fmt(peakTps)} requests/sec, but the average was only ${avgTps}/sec — a ${burstRatio.toFixed(1)}× difference. This wide gap suggests very uneven activity rather than a steady flow.`,
        recommendation: 'Check your test pacing settings — this gap can come from how the test sends requests. If it reflects real traffic, make sure the app can absorb sudden bursts through queuing, auto-scaling, or rate limiting.',
      })
    }

    if (tpsSeries.length >= 6) {
      const q      = Math.max(1, Math.ceil(tpsSeries.length / 5))
      const early  = _mean(tpsSeries.slice(0, q))
      const late   = _mean(tpsSeries.slice(-q))
      const trend  = _pct(early, late)
      if (trend < -25) {
        findings.push({
          id: 'tps_declining', category: 'Throughput', severity: 'warning',
          title: 'App processed fewer requests over time — throughput declined',
          finding: `The app was processing ${early.toFixed(1)} requests/sec early on, dropping to ${late.toFixed(1)}/sec later — a ${Math.round(Math.abs(trend))}% fall. The system struggled to maintain the same pace under sustained load.`,
          recommendation: 'Declining throughput over time usually means a resource is filling up — thread pool, connection pool, or memory. Compare server CPU and memory usage between the start and end of the test.',
        })
      }
    }
  }

  // ── 7 · Per-Endpoint Analysis ─────────────────────────────────────────────

  if (apiEntries.length > 0) {
    // Slowest endpoints
    const slowSorted = [...apiEntries]
      .filter(([, s]) => s.avg > 0)
      .sort((a, b) => b[1].avg - a[1].avg)
    const slowTop = slowSorted.slice(0, 3).filter(([, s]) => s.avg > 500)
    if (slowTop.length > 0) {
      const lines = slowTop.map(([path, s]) =>
        `${path.length > 50 ? '…' + path.slice(-47) : path} — avg ${_fmt(s.avg)} ms${s.p95 ? `, slowest 5% took ${_fmt(s.p95)} ms` : ''}`)
      findings.push({
        id: 'slow_endpoints', category: 'Endpoints',
        severity: slowTop[0][1].avg > 1000 ? 'critical' : 'warning',
        title: `Slow API${slowTop.length > 1 ? 's' : ''} dragging down overall performance`,
        finding: `${slowTop.length > 1 ? 'These APIs are' : 'This API is'} taking much longer than the rest:\n• ${lines.join('\n• ')}`,
        recommendation: 'Profile these APIs individually to find what\'s causing the slowness. Common fixes: optimise the database queries they run, reduce how many queries fire per request, or add caching for data that doesn\'t change often.',
      })
    }

    // High-error endpoints
    const errorApis = apiEntries.filter(([, s]) => {
      const total = (s.pass || 0) + (s.fail || 0)
      return total > 0 && s.fail > 0 && (s.fail / total) >= 0.05
    }).sort((a, b) => (b[1].fail / ((b[1].pass || 0) + b[1].fail)) - (a[1].fail / ((a[1].pass || 0) + a[1].fail)))

    if (errorApis.length > 0) {
      const lines = errorApis.slice(0, 3).map(([path, s]) => {
        const total = (s.pass || 0) + (s.fail || 0)
        return `${path.length > 50 ? '…' + path.slice(-47) : path} — ${((s.fail / total) * 100).toFixed(1)}% failed (${s.fail} out of ${total} requests)`
      })
      findings.push({
        id: 'error_endpoints', category: 'Endpoints', severity: 'critical',
        title: `${errorApis.length > 1 ? 'APIs' : 'API'} failing at an unacceptable rate`,
        finding: `${errorApis.length > 1 ? 'These APIs are' : 'This API is'} failing more than 1 in 20 requests:\n• ${lines.join('\n• ')}`,
        recommendation: 'Reproduce these failures in a staging environment. Check whether the errors are "400-type" issues (bad request data or auth problems) or "500-type" (server crashes, timeouts). Each has a different fix.',
      })
    }

    // Endpoints with good average but bad occasional performance
    const p95OutlierApis = [...apiEntries]
      .filter(([, s]) => s.avg > 0 && s.p95 > 0 && (s.p95 / s.avg) > 5 && s.avg < 300)
      .sort((a, b) => (b[1].p95 / b[1].avg) - (a[1].p95 / a[1].avg))
      .slice(0, 2)

    if (p95OutlierApis.length > 0) {
      const lines = p95OutlierApis.map(([path, s]) =>
        `${path.length > 50 ? '…' + path.slice(-47) : path} — usually ${_fmt(s.avg)} ms but occasionally ${_fmt(s.p95)} ms (${(s.p95 / s.avg).toFixed(1)}× slower)`)
      findings.push({
        id: 'p95_outlier_endpoints', category: 'Endpoints', severity: 'warning',
        title: `Some APIs look fast usually, but occasionally take much longer`,
        finding: `These APIs respond quickly most of the time, but every so often spike dramatically:\n• ${lines.join('\n• ')}\nMost users are served quickly, but some will occasionally experience a bad delay.`,
        recommendation: 'Add detailed logging for these APIs to capture what\'s different about the slow requests. Usually it\'s a lock being held by another process, a database connection being established for the first time, or an occasional timeout from a downstream service.',
      })
    }

    // One endpoint handling most of the traffic
    const byLoad = [...apiEntries].sort((a, b) =>
      ((b[1].pass || 0) + (b[1].fail || 0)) - ((a[1].pass || 0) + (a[1].fail || 0)))
    if (byLoad.length > 0 && totalRequests > 0) {
      const [hotPath, hotStats] = byLoad[0]
      const hotTotal = (hotStats.pass || 0) + (hotStats.fail || 0)
      const hotPct   = (hotTotal / totalRequests) * 100
      if (hotPct > 35) {
        findings.push({
          id: 'load_hotspot', category: 'Endpoints', severity: 'info',
          title: 'One API is handling most of the traffic',
          finding: `${hotPath.length > 55 ? '…' + hotPath.slice(-52) : hotPath} handled ${Math.round(hotPct)}% of all requests (${hotTotal.toLocaleString()} calls). Relying heavily on a single endpoint creates a bottleneck risk.`,
          recommendation: 'Make sure this API is well-optimised and can scale. Also check whether the test scenario reflects real user behaviour — are real users hitting this endpoint this often?',
        })
      }
    }
  }

  // ── 8 · Is the system close to its capacity limit? ────────────────────────

  if (totalVUs > 0 && avgTps > 0 && avgRt > 0) {
    const tpsPerVu = avgTps / totalVUs
    if (tpsPerVu < 0.08 && avgRt > 200) {
      findings.push({
        id: 'low_tps_per_vu', category: 'Throughput', severity: 'info',
        title: 'App isn\'t handling as many requests as expected',
        finding: `With ${totalVUs} simulated users active, the app only processed around ${avgTps} requests/sec. That\'s lower than expected for this many users — the system may already be near its capacity limit.`,
        recommendation: 'Check if this is expected based on how the test is set up (e.g. think-time delays between actions). If there are no delays, the system is likely bottlenecked and needs to scale to handle more concurrent users.',
      })
    } else if (tpsPerVu > 0.5 && avgRt < RT.good) {
      findings.push({
        id: 'good_capacity', category: 'Throughput', severity: 'good',
        title: 'System is handling the load well — more headroom available',
        finding: `With ${totalVUs} simulated users, the app processed ${avgTps} requests/sec at an average of ${_fmt(avgRt)} ms. Response times and throughput together suggest the system isn't close to its limit yet.`,
        recommendation: 'Run the same test with more users to find where performance starts to degrade. That number gives you a realistic capacity ceiling for planning infrastructure.',
      })
    }
  }

  // ── Sort: critical → warning → info → good ─────────────────────────────
  const ORDER = { critical: 0, warning: 1, info: 2, good: 3 }
  findings.sort((a, b) => ORDER[a.severity] - ORDER[b.severity])

  return findings
}

/**
 * Derive an overall test verdict from the findings list.
 * @param {Array} findings
 * @returns {{ label: string, color: string, description: string }}
 */
export function computeVerdict(findings) {
  if (!findings.length) return { label: 'No Data', color: '#6b7280', description: 'Not enough data to draw conclusions.' }
  const hasCritical  = findings.some(f => f.severity === 'critical')
  const hasWarning   = findings.some(f => f.severity === 'warning')
  const goodCount    = findings.filter(f => f.severity === 'good').length
  const infoCount    = findings.filter(f => f.severity === 'info').length
  const allPositive  = !hasCritical && !hasWarning

  if (hasCritical)
    return { label: 'Needs Improvement', color: '#ef4444',
             description: 'Critical issues found. The system is not ready for production at this load level.' }
  if (hasWarning)
    return { label: 'Attention Required', color: '#f59e0b',
             description: 'Some performance concerns were found. Review and address the warnings before going live.' }
  if (allPositive && goodCount >= 3)
    return { label: 'Excellent', color: '#22c55e',
             description: 'All key metrics are within great ranges. The system looks well-prepared for this load.' }
  if (allPositive && goodCount >= 1)
    return { label: 'Good', color: '#10b981',
             description: 'Performance is on target with positive signals across key areas. Keep validating under higher load.' }
  if (allPositive && infoCount > 0)
    return { label: 'Acceptable', color: '#06b6d4',
             description: 'Performance is within acceptable range. Review the observations below before scaling further.' }
  return { label: 'Passing', color: '#22c55e',
           description: 'Performance meets the bar. A few areas have room for further improvement.' }
}

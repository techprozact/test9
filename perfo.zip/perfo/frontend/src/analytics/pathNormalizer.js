/**
 * pathNormalizer — normalizes dynamic segments in API paths so that
 * /api/orders/217/cancel and /api/orders/218/cancel are both stored
 * as /api/orders/{{order_id}}/cancel and aggregated together.
 *
 * Rules for "dynamic" segments:
 *   1. Pure numeric  → /^\d+$/
 *   2. UUID          → 8-4-4-4-12 hex
 *   3. Long mixed alphanumeric token (≥ 8 chars, contains both letters + digits)
 *
 * Placeholder naming: look backwards to the nearest non-dynamic ancestor
 * segment, singularize it, and append _id.
 * e.g.  orders → {{order_id}},  products → {{product_id}}
 */

const RX_DIGITS = /^\d+$/
const RX_UUID   = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
// 8+ chars, alphanumeric only, must contain at least one letter AND one digit
const RX_TOKEN  = /^(?=[a-zA-Z0-9]*[a-zA-Z])(?=[a-zA-Z0-9]*\d)[a-zA-Z0-9]{8,}$/

function isDynamic(seg) {
  return RX_DIGITS.test(seg) || RX_UUID.test(seg) || RX_TOKEN.test(seg)
}

function singularize(word) {
  if (!word) return 'item'
  const w = word.toLowerCase()
  // categories → category
  if (w.length > 4 && w.endsWith('ies')) return w.slice(0, -3) + 'y'
  // statuses → status, indexes → index
  if (w.endsWith('ses') || w.endsWith('xes') || w.endsWith('zes')) return w.slice(0, -2)
  // orders → order, users → user  (but not "ss" ending like "class")
  if (w.length > 2 && w.endsWith('s') && !w.endsWith('ss')) return w.slice(0, -1)
  return w
}

/**
 * Replace dynamic path segments with human-readable {{placeholder}} names.
 *
 * @param {string} rawPath  — raw api_path from telemetry, e.g. /api/orders/217/cancel
 * @returns {string}        — normalized path, e.g. /api/orders/{{order_id}}/cancel
 */
export function normalizeApiPath(rawPath) {
  if (!rawPath || rawPath === '(unknown)') return rawPath

  // Strip query string and fragment
  const pathPart = rawPath.split('?')[0].split('#')[0]

  // Already contains placeholders — don't double-process
  if (pathPart.includes('{{')) return pathPart

  const segments = pathPart.split('/')

  // Track used placeholder names so we can de-duplicate when needed
  // e.g. /a/1/1 would naively produce {{a_id}}/{{a_id}} → {{a_id}}/{{a_id_2}}
  const nameCount = {}

  const normalized = segments.map((seg, idx) => {
    if (!seg || !isDynamic(seg)) return seg

    // Walk backwards to find the nearest non-dynamic ancestor segment for naming
    let label = 'item'
    for (let i = idx - 1; i >= 0; i--) {
      if (segments[i] && !isDynamic(segments[i])) {
        label = singularize(segments[i])
        break
      }
    }

    const base = `${label}_id`
    if (!nameCount[base]) {
      nameCount[base] = 1
      return `{{${base}}}`
    }
    nameCount[base]++
    return `{{${base}_${nameCount[base]}}}`
  })

  return normalized.join('/')
}

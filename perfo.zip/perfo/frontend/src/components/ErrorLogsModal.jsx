import { useState, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { useTheme } from '../context/ThemeContext'
import { getExecutionErrors, getExecutionErrorsDownloadUrl } from '../api'

/* ── helpers ── */
function fmtTimestamp(ts) {
  if (!ts) return '—'
  try {
    return new Date(ts).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
  } catch { return ts }
}

function statusColor(code) {
  if (!code || code === 0) return '#f97316'
  if (code >= 500) return '#ef4444'
  if (code >= 400) return '#f59e0b'
  return '#f97316'
}

function renderHeaders(headers) {
  if (!headers || !Object.keys(headers).length) return null
  return Object.entries(headers).map(([k, v]) => (
    <div key={k} style={{ fontFamily: 'monospace', fontSize: 11 }}>
      <span style={{ color: '#94a3b8' }}>{k}: </span>
      <span style={{ color: '#e2e8f0' }}>{v}</span>
    </div>
  ))
}

/* ── main component ── */
export default function ErrorLogsModal({ testRunId, scriptId, scriptName, onClose }) {
  const { t, isDark } = useTheme()
  const [loading, setLoading]   = useState(true)
  const [errors, setErrors]     = useState([])
  const [total, setTotal]       = useState(0)
  const [expanded, setExpanded] = useState({})

  useEffect(() => {
    setLoading(true)
    getExecutionErrors(testRunId, scriptId, 20, 0)
      .then(d => {
        setErrors(d.records || [])
        setTotal(d.total || 0)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [testRunId, scriptId])

  const downloadUrl = getExecutionErrorsDownloadUrl(testRunId, scriptId)

  const toggle = (i) => setExpanded(prev => ({ ...prev, [i]: !prev[i] }))

  /* ── styles ── */
  const overlay = {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.72)',
    backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
    zIndex: 9500,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    padding: 24,
  }
  const modal = {
    background: isDark ? '#0f172a' : '#fff',
    border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.12)'}`,
    borderRadius: 14,
    width: '100%', maxWidth: 820,
    maxHeight: '88vh',
    display: 'flex', flexDirection: 'column',
    boxShadow: '0 24px 64px rgba(0,0,0,0.5)',
    overflow: 'hidden',
  }
  const codeBlock = {
    background: '#0d1117',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 6,
    padding: '10px 14px',
    fontFamily: 'monospace',
    fontSize: 11,
    color: '#e2e8f0',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-all',
    maxHeight: 200,
    overflowY: 'auto',
    lineHeight: 1.6,
  }
  const sectionLabel = {
    color: '#64748b',
    fontSize: 10,
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    marginBottom: 6,
  }

  return createPortal(
    <div style={overlay} onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div style={modal}>

        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '16px 20px',
          borderBottom: `1px solid ${isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)'}`,
          flexShrink: 0,
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#ef4444" strokeWidth="1.8">
                <circle cx="8" cy="8" r="6.5" />
                <path d="M8 5v3M8 10.5v.5" strokeLinecap="round" />
              </svg>
              <span style={{ color: t.textPrimary, fontSize: 15, fontWeight: 700 }}>
                Failed Transactions
              </span>
              {scriptName && (
                <span style={{ color: t.textFaint, fontSize: 12, fontWeight: 500 }}>— {scriptName}</span>
              )}
            </div>
            <div style={{ color: t.textFaint, fontSize: 12, marginTop: 3 }}>
              {loading ? 'Loading…' : `Showing first ${errors.length} of ${total} error${total !== 1 ? 's' : ''}`}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {total > 0 && (
              <a
                href={downloadUrl}
                download
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                  background: isDark ? 'rgba(99,102,241,0.15)' : 'rgba(99,102,241,0.1)',
                  border: `1px solid ${isDark ? 'rgba(99,102,241,0.4)' : 'rgba(99,102,241,0.3)'}`,
                  borderRadius: 7, padding: '7px 14px',
                  color: '#818cf8', fontSize: 12, fontWeight: 600,
                  textDecoration: 'none',
                }}
              >
                <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.7">
                  <path d="M14 10v3a1 1 0 01-1 1H3a1 1 0 01-1-1v-3M8 2v8M5 7l3 3 3-3" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Download Full Error Logs
              </a>
            )}
            <button
              onClick={onClose}
              style={{
                width: 30, height: 30, borderRadius: '50%',
                border: `1px solid ${t.border}`,
                background: 'transparent', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: t.textFaint, fontSize: 16, lineHeight: 1,
              }}
              onMouseEnter={e => { e.currentTarget.style.color = '#ef4444'; e.currentTarget.style.borderColor = '#ef4444' }}
              onMouseLeave={e => { e.currentTarget.style.color = t.textFaint; e.currentTarget.style.borderColor = t.border }}
            >×</button>
          </div>
        </div>

        {/* Body */}
        <div style={{ overflowY: 'auto', flex: 1, padding: '16px 20px' }}>
          {loading && (
            <div style={{ textAlign: 'center', padding: 40, color: t.textFaint, fontSize: 13 }}>
              Loading error logs…
            </div>
          )}

          {!loading && errors.length === 0 && (
            <div style={{ textAlign: 'center', padding: 40, color: t.textFaint, fontSize: 13 }}>
              No error records found for this script.
            </div>
          )}

          {!loading && errors.map((err, i) => {
            const isOpen = expanded[i] !== false  // default open
            const authKeys = Object.keys(err.auth_headers || {})
            const hasBody  = !!(err.request_body && err.request_body.trim())
            const hasAuth  = authKeys.length > 0

            let prettyBody = err.request_body || ''
            try { prettyBody = JSON.stringify(JSON.parse(prettyBody), null, 2) } catch { /* keep raw */ }

            let prettyResp = err.response_body || ''
            try { prettyResp = JSON.stringify(JSON.parse(prettyResp), null, 2) } catch { /* keep raw */ }

            return (
              <div key={i} style={{
                border: `1px solid ${isDark ? 'rgba(239,68,68,0.2)' : 'rgba(239,68,68,0.15)'}`,
                borderRadius: 10,
                marginBottom: 12,
                overflow: 'hidden',
                background: isDark ? 'rgba(239,68,68,0.04)' : 'rgba(255,255,255,1)',
              }}>
                {/* Error header row */}
                <div
                  style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '10px 14px',
                    background: isDark ? 'rgba(239,68,68,0.07)' : 'rgba(239,68,68,0.04)',
                    borderBottom: isOpen ? `1px solid ${isDark ? 'rgba(239,68,68,0.15)' : 'rgba(239,68,68,0.1)'}` : 'none',
                    cursor: 'pointer',
                  }}
                  onClick={() => toggle(i)}
                >
                  <span style={{
                    fontSize: 10, fontWeight: 700, letterSpacing: '0.04em',
                    color: '#fff', background: '#ef4444',
                    borderRadius: 4, padding: '2px 7px', flexShrink: 0,
                  }}>#{i + 1}</span>

                  <span style={{
                    fontSize: 11, fontWeight: 700, letterSpacing: '0.04em',
                    color: '#fff',
                    background: err.method === 'GET' ? '#3b82f6' : err.method === 'POST' ? '#10b981' : err.method === 'PUT' ? '#f59e0b' : err.method === 'DELETE' ? '#ef4444' : '#6b7280',
                    borderRadius: 4, padding: '2px 7px', flexShrink: 0,
                  }}>{err.method || 'GET'}</span>

                  <span style={{ color: t.textSecondary, fontSize: 12, fontFamily: 'monospace', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {err.url}
                  </span>

                  <span style={{
                    fontSize: 12, fontWeight: 700,
                    color: statusColor(err.response_code),
                    background: statusColor(err.response_code) + '20',
                    border: `1px solid ${statusColor(err.response_code)}40`,
                    borderRadius: 5, padding: '2px 8px', flexShrink: 0,
                  }}>
                    {err.response_code || 'ERR'} {err.error_message ? `— ${err.error_message.slice(0, 40)}` : ''}
                  </span>

                  <span style={{ color: t.textFaint, fontSize: 11, flexShrink: 0 }}>{fmtTimestamp(err.timestamp)}</span>

                  <span style={{ color: t.textFaint, fontSize: 16, flexShrink: 0, lineHeight: 1 }}>
                    {isOpen ? '▲' : '▼'}
                  </span>
                </div>

                {/* Expandable detail */}
                {isOpen && (
                  <div style={{ padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
                    {/* Request */}
                    <div>
                      <div style={sectionLabel}>Request</div>
                      <div style={codeBlock}>
                        <span style={{ color: '#7dd3fc' }}>{err.method || 'GET'}</span>
                        {' '}
                        <span style={{ color: '#86efac' }}>{err.url}</span>
                        {'\n'}
                        {err.vu_id && (
                          <span style={{ color: '#94a3b8', fontSize: 10 }}>VU: {err.vu_id}  |  Iteration: {err.iteration}  |  RT: {err.response_time_ms} ms</span>
                        )}
                      </div>
                    </div>

                    {/* Auth headers */}
                    {hasAuth && (
                      <div>
                        <div style={sectionLabel}>Auth Parameters</div>
                        <div style={codeBlock}>
                          {Object.entries(err.auth_headers).map(([k, v]) => (
                            <div key={k}>
                              <span style={{ color: '#fbbf24' }}>{k}: </span>
                              <span style={{ color: '#e2e8f0' }}>{v}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* All request headers (excluding auth which is shown separately) */}
                    {err.request_headers && Object.keys(err.request_headers).length > 0 && (
                      <div>
                        <div style={sectionLabel}>Request Headers</div>
                        <div style={codeBlock}>
                          {Object.entries(err.request_headers)
                            .filter(([k]) => !Object.keys(err.auth_headers || {}).includes(k))
                            .map(([k, v]) => (
                              <div key={k}>
                                <span style={{ color: '#94a3b8' }}>{k}: </span>
                                <span style={{ color: '#e2e8f0' }}>{v}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}

                    {/* Request body */}
                    {hasBody && (
                      <div>
                        <div style={sectionLabel}>Request Body</div>
                        <div style={codeBlock}>{prettyBody}</div>
                      </div>
                    )}

                    {/* Response */}
                    <div>
                      <div style={sectionLabel}>
                        Response
                        <span style={{ marginLeft: 8, color: statusColor(err.response_code), fontWeight: 700 }}>
                          {err.response_code ? `${err.response_code}` : 'Network Error'}
                        </span>
                      </div>
                      <div style={{ ...codeBlock, borderColor: statusColor(err.response_code) + '40' }}>
                        {err.error_message
                          ? <span style={{ color: '#f87171' }}>{err.error_message}</span>
                          : (prettyResp || <span style={{ color: '#64748b' }}>(empty response)</span>)
                        }
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )
          })}

          {!loading && total > 20 && (
            <div style={{ textAlign: 'center', padding: '8px 0 4px', color: t.textFaint, fontSize: 12 }}>
              Showing first 20 of {total} errors. Download full log to see all.
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  )
}

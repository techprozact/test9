import { useState, useEffect, useRef } from 'react'
import { Link, Outlet, useLocation } from 'react-router-dom'
import { useTheme } from '../context/ThemeContext'
import { LayoutContext } from '../context/LayoutContext'
import pt0LogoIcon      from '../assets/pt0-logo-icon.png'
import pt0LogoIconDark  from '../assets/pt0-logo-icon-dark.png'

const SIDEBAR_W = 200
const TOPBAR_H = 56

const NAV_GROUPS = [
  {
    group: 'OVERVIEW',
    items: [
      { label: 'Dashboard', path: '/app', icon: 'dashboard', desc: 'Overview of your performance testing activity' },
    ],
  },
  {
    group: 'BUILD',
    items: [
      { label: 'API Studio', path: '/app/perfzy', icon: 'api', desc: 'Build and test API flows for performance scripts' },
      { label: 'Upload HAR', path: '/app/upload', icon: 'upload', desc: 'Upload a HAR file to generate a performance script' },
      { label: 'Scripts', path: '/app/scripts', icon: 'scripts', desc: 'Browse and manage your generated test scripts' },
    ],
  },
  {
    group: 'EXECUTE',
    items: [
      { label: 'Load Designer', path: '/app/load-designer', icon: 'load', desc: 'Design and configure load test scenarios' },
      { label: 'Quick Test', path: '/app/quick-test', icon: 'quick', desc: 'Run instant load tests without configuration' },
    ],
  },
  {
    group: 'ANALYZE',
    items: [
      { label: 'Test Results', path: '/app/test-results', icon: 'results', desc: 'Analyze performance results and metrics' },
      { label: 'Reports', path: '/app/reports', icon: 'reports', desc: 'Generate and share performance reports', comingSoon: true },
    ],
  },
]

function NavIcon({ name, size = 15 }) {
  const s = { width: size, height: size, flexShrink: 0 }
  if (name === 'dashboard') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <rect x="1" y="1" width="6" height="6" rx="1.2" />
      <rect x="9" y="1" width="6" height="6" rx="1.2" />
      <rect x="1" y="9" width="6" height="6" rx="1.2" />
      <rect x="9" y="9" width="6" height="6" rx="1.2" />
    </svg>
  )
  if (name === 'api') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <polyline points="4,5 1,8 4,11" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="12,5 15,8 12,11" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="9" y1="2" x2="7" y2="14" strokeLinecap="round" />
    </svg>
  )
  if (name === 'load') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path d="M8 2 L13.5 13 L8 10.5 L2.5 13 Z" strokeLinejoin="round" />
    </svg>
  )
  if (name === 'quick') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <polygon points="4,2 14,8 4,14" strokeLinejoin="round" />
    </svg>
  )
  if (name === 'results') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <line x1="2" y1="14" x2="2" y2="8" strokeLinecap="round" />
      <line x1="6" y1="14" x2="6" y2="5" strokeLinecap="round" />
      <line x1="10" y1="14" x2="10" y2="9" strokeLinecap="round" />
      <line x1="14" y1="14" x2="14" y2="3" strokeLinecap="round" />
    </svg>
  )
  if (name === 'reports') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <rect x="2" y="1" width="12" height="14" rx="1.5" />
      <line x1="5" y1="5" x2="11" y2="5" strokeLinecap="round" />
      <line x1="5" y1="8" x2="11" y2="8" strokeLinecap="round" />
      <line x1="5" y1="11" x2="8" y2="11" strokeLinecap="round" />
    </svg>
  )
  if (name === 'scripts') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path d="M3 1h7l4 4v10H3V1z" strokeLinejoin="round" />
      <polyline points="10,1 10,5 14,5" strokeLinejoin="round" />
      <line x1="5" y1="8" x2="11" y2="8" strokeLinecap="round" />
      <line x1="5" y1="11" x2="9" y2="11" strokeLinecap="round" />
    </svg>
  )
  if (name === 'upload') return (
    <svg style={s} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path d="M2 11v2a1 1 0 001 1h10a1 1 0 001-1v-2" strokeLinecap="round" />
      <line x1="8" y1="2" x2="8" y2="10" strokeLinecap="round" />
      <polyline points="5,5 8,2 11,5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
  return null
}

function NavItem({ item, isActive, collapsed }) {
  const { t } = useTheme()
  const [hovered, setHovered] = useState(false)
  return (
    <Link
      to={item.path}
      title={collapsed ? item.label : undefined}
      style={{
        display: 'flex', alignItems: 'center',
        justifyContent: collapsed ? 'center' : 'flex-start',
        gap: collapsed ? 0 : 9,
        padding: collapsed ? '8px 0' : '7px 10px 7px 14px',
        borderRadius: 6, marginBottom: 1,
        textDecoration: 'none', position: 'relative',
        background: isActive ? t.bgActiveNav : hovered ? t.bgHover : 'transparent',
        color: isActive ? t.textNavActive : item.comingSoon ? t.textNavSoon : hovered ? t.textNavHover : t.textNavInactive,
        fontSize: 13, fontWeight: isActive ? 600 : 400,
        transition: 'background 0.12s, color 0.12s, padding 0.22s, justify-content 0.22s',
        cursor: item.comingSoon ? 'default' : 'pointer',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={item.comingSoon ? (e) => e.preventDefault() : undefined}
    >
      {isActive && (
        <span style={{
          position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)',
          width: 3, height: 18, background: t.activeBar, borderRadius: '0 2px 2px 0',
        }} />
      )}
      <NavIcon name={item.icon} size={15} />
      {!collapsed && <span style={{ flex: 1 }}>{item.label}</span>}
    </Link>
  )
}

function UserMenu() {
  const { t } = useTheme()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    function handle(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [])

  const menuItems = [
    { label: 'Logout', icon: LogoutIcon, danger: true },
  ]

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          width: 34, height: 34, borderRadius: '50%',
          background: 'linear-gradient(135deg, #1d9bf0 0%, #0d6efd 100%)',
          border: open ? '2px solid rgba(29,155,240,0.6)' : '2px solid rgba(29,155,240,0.25)',
          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontSize: 13, fontWeight: 700, transition: 'border-color 0.15s',
          boxShadow: open ? '0 0 0 3px rgba(29,155,240,0.12)' : 'none',
        }}
      >
        U
      </button>
      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 8px)', right: 0,
          background: t.dropdownBg, border: `1px solid ${t.dropdownBorder}`, borderRadius: 10,
          boxShadow: t.dropdownShadow, minWidth: 168, zIndex: 300,
          overflow: 'hidden', padding: '4px 0',
        }}>
          <div style={{ padding: '10px 14px 8px', borderBottom: `1px solid ${t.border}`, marginBottom: 4 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: t.textPrimary }}>User</div>
            <div style={{ fontSize: 11, color: t.textMuted, marginTop: 1 }}>user@example.com</div>
          </div>
          {menuItems.map((item, i) =>
            item.type === 'divider' ? (
              <div key={i} style={{ height: 1, background: '#21262d', margin: '4px 0' }} />
            ) : (
              <MenuButton key={item.label} label={item.label} Icon={item.icon} danger={item.danger} />
            )
          )}
        </div>
      )}
    </div>
  )
}

function MenuButton({ label, Icon, danger }) {
  const { t } = useTheme()
  const [hovered, setHovered] = useState(false)
  return (
    <button
      style={{
        width: '100%', padding: '8px 14px',
        background: hovered ? t.bgHover : 'none',
        border: 'none', cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 9,
        color: danger ? '#f85149' : t.textSecondary, fontSize: 13,
        textAlign: 'left', transition: 'background 0.1s',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <Icon size={14} />
      {label}
    </button>
  )
}

const SIDEBAR_COLLAPSED_W = 56

function SidebarSeparator({ collapsed, onToggle, sidebarW }) {
  const { t } = useTheme()
  const [hovered, setHovered] = useState(false)
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onToggle}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onToggle() } }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      style={{
        position: 'fixed',
        left: sidebarW - 4,
        top: 0,
        bottom: 0,
        width: 8,
        zIndex: 101,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'left 0.22s cubic-bezier(0.4,0,0.2,1)',
        borderLeft: `1px solid ${t.border}`,
      }}
    >
      {hovered && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 2, pointerEvents: 'none' }}>
          <svg width="10" height="10" viewBox="0 0 10 10" fill={t.textMuted} style={{ flexShrink: 0 }}>
            <path d="M6 2 L2 5 L6 8 Z" />
          </svg>
          <svg width="10" height="10" viewBox="0 0 10 10" fill={t.textMuted} style={{ flexShrink: 0 }}>
            <path d="M4 2 L8 5 L4 8 Z" />
          </svg>
        </div>
      )}
    </div>
  )
}

function SunIcon({ size = 12, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ display: 'block', flexShrink: 0 }}>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41" fill="none" />
    </svg>
  )
}

function MoonIcon({ size = 12, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ display: 'block', flexShrink: 0 }}>
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  )
}

function ThemeToggle() {
  const { isDark, toggle, t } = useTheme()
  const [showTooltip, setShowTooltip] = useState(false)
  const tooltipText = isDark ? 'Switch to light mode' : 'Switch to dark mode'
  return (
    <span
      style={{ position: 'relative', display: 'inline-flex' }}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <button
        onClick={toggle}
        style={{
          width: 36, height: 20, borderRadius: 10, border: 'none', cursor: 'pointer',
          background: isDark ? '#30363d' : '#e2e8f0',
          position: 'relative', flexShrink: 0,
          transition: 'background 0.22s',
          display: 'flex', alignItems: 'center', padding: '0 3px',
        }}
      >
        {/* Moon — left (dark mode), black */}
        <span style={{
          position: 'absolute', left: 5, top: '50%', transform: 'translateY(-50%)',
          opacity: isDark ? 1 : 0.5, transition: 'opacity 0.2s',
          color: '#000',
        }}>
          <MoonIcon size={10} color="currentColor" />
        </span>
        {/* Sun — right (light mode), always bright white for visibility on dark track */}
        <span style={{
          position: 'absolute', right: 5, top: '50%', transform: 'translateY(-50%)',
          opacity: 1,
        }}>
          <SunIcon size={10} color="#ffffff" />
        </span>
        {/* Thumb */}
        <span style={{
          width: 14, height: 14, borderRadius: '50%',
          background: isDark ? '#8b98a5' : '#0284c7',
          boxShadow: '0 1px 3px rgba(0,0,0,0.25)',
          transform: `translateX(${isDark ? 0 : 16}px)`,
          transition: 'transform 0.22s cubic-bezier(0.4,0,0.2,1), background 0.22s',
          display: 'block', flexShrink: 0,
        }} />
      </button>
      {showTooltip && (
        <span
          role="tooltip"
          style={{
            position: 'absolute',
            right: '100%',
            top: '50%',
            transform: 'translateY(-50%) translateX(-8px)',
            padding: '4px 8px',
            fontSize: 11,
            fontWeight: 500,
            color: t?.textPrimary ?? '#e6edf3',
            background: t?.bgRaised ?? '#161b22',
            border: `1px solid ${t?.border ?? '#30363d'}`,
            borderRadius: 6,
            whiteSpace: 'nowrap',
            pointerEvents: 'none',
            zIndex: 1000,
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
          }}
        >
          {tooltipText}
        </span>
      )}
    </span>
  )
}

export default function Layout() {
  const { t } = useTheme()
  const location = useLocation()
  const [collapsed, setCollapsed] = useState(false)
  const sidebarW = collapsed ? SIDEBAR_COLLAPSED_W : SIDEBAR_W

  const allItems = NAV_GROUPS.flatMap(g => g.items)
  const activeItem = allItems.find(item =>
    item.path === '/app' ? location.pathname === '/app' : location.pathname.startsWith(item.path)
  ) || allItems[0]

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: t.pageBg }}>
      {/* ── Sidebar ── */}
      <aside style={{
        position: 'fixed', top: 0, left: 0, bottom: 0, width: sidebarW,
        background: t.sidebarBg, borderRight: `1px solid ${t.border}`,
        display: 'flex', flexDirection: 'column', zIndex: 100,
        overflowX: 'hidden', overflowY: collapsed ? 'hidden' : 'auto',
        transition: 'width 0.22s cubic-bezier(0.4,0,0.2,1)',
      }}>
        {/* Brand */}
        <div style={{
          padding: collapsed ? '14px 10px 12px' : '14px 12px 12px',
          borderBottom: `1px solid ${t.border}`, flexShrink: 0,
          transition: 'padding 0.22s',
          display: 'flex', flexDirection: 'column', alignItems: 'center',
        }}>
          <div style={{ position: 'relative', width: '100%', display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'flex-start' }}>
            {collapsed ? (
              /* Collapsed: icon only, click to expand */
              <button
                type="button"
                onClick={() => setCollapsed(false)}
                title="Expand sidebar"
                style={{
                  padding: 0, border: 'none', background: 'none', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  borderRadius: 6,
                }}
              >
                <img src={t.isDark ? pt0LogoIcon : pt0LogoIconDark} alt="PTI"
                  style={{ height: 32, width: 32, objectFit: 'contain', display: 'block' }} />
              </button>
            ) : (
              /* Expanded: icon + PTI text + collapse toggle */
              <>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, flex: 1 }}>
                  <img src={t.isDark ? pt0LogoIcon : pt0LogoIconDark} alt="PTI"
                    style={{ height: 28, width: 28, objectFit: 'contain', display: 'block', flexShrink: 0 }} />
                  <span style={{
                    fontSize: 20, fontWeight: 700, letterSpacing: 0.8,
                    color: t.isDark ? '#ffffff' : '#000000',
                    lineHeight: 1,
                  }}>PTI</span>
                </div>
                <CollapseToggle collapsed={collapsed} onToggle={() => setCollapsed(v => !v)} />
              </>
            )}
          </div>

          {/* Tagline — only when expanded */}
          {!collapsed && (
            <div style={{
              fontSize: 10.5, color: t.textFaint, letterSpacing: 0.15,
              lineHeight: 1.4, marginTop: 7, textAlign: 'left', width: '100%',
              paddingLeft: 2,
            }}>
              Performance Testing Intelligence
            </div>
          )}
        </div>

        {/* Nav groups */}
        <nav style={{
          flex: 1,
          padding: collapsed ? '8px 6px' : '10px 8px',
          transition: 'padding 0.22s',
        }}>
          {NAV_GROUPS.map((group, gi) => (
            <div key={group.group} style={{ marginBottom: collapsed ? 0 : 4 }}>
              {/* Group label or divider */}
              {collapsed ? (
                gi > 0 && (
                  <div style={{ height: 1, background: t.border, margin: '6px 4px 5px' }} />
                )
              ) : (
                <div style={{
                  fontSize: 10, fontWeight: 600, color: t.textNavGroup, letterSpacing: 0.9,
                  padding: '6px 14px 3px', textTransform: 'uppercase', whiteSpace: 'nowrap',
                }}>
                  {group.group}
                </div>
              )}
              {group.items.map((item) => {
                const isActive = item.path === '/app'
                  ? location.pathname === '/app'
                  : location.pathname.startsWith(item.path)
                return (
                  <NavItem key={item.path} item={item} isActive={isActive} collapsed={collapsed} />
                )
              })}
            </div>
          ))}
        </nav>

      </aside>

      {/* ── Separator (hover: <--> icon, click: expand/collapse) ── */}
      <SidebarSeparator
        collapsed={collapsed}
        onToggle={() => setCollapsed(v => !v)}
        sidebarW={sidebarW}
      />

      {/* ── Main Column ── */}
      <LayoutContext.Provider value={{ sidebarCollapsed: collapsed, collapseSidebar: () => setCollapsed(true) }}>
      <div style={{
        marginLeft: sidebarW, flex: 1,
        display: 'flex', flexDirection: 'column', minHeight: '100vh',
        transition: 'margin-left 0.22s cubic-bezier(0.4,0,0.2,1)',
      }}>
        {/* Topbar */}
        <header style={{
          position: 'sticky', top: 0, zIndex: 50,
          height: TOPBAR_H, background: t.topbarBg,
          borderBottom: `1px solid ${t.topbarBorder}`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 24px', flexShrink: 0,
          backdropFilter: 'blur(8px)',
        }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: t.textPrimary, lineHeight: 1.2 }}>
              {activeItem.label}
            </div>
            <div style={{ fontSize: 11.5, color: t.textMuted, marginTop: 1 }}>
              {activeItem.desc}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <ThemeToggle />
            <UserMenu />
          </div>
        </header>

        {/* Page content */}
        <main style={{ flex: 1, overflowX: 'hidden', padding: '24px' }}>
          <Outlet />
        </main>
      </div>
      </LayoutContext.Provider>
    </div>
  )
}

function CollapseToggle({ collapsed, onToggle }) {
  const { t } = useTheme()
  const [hovered, setHovered] = useState(false)
  return (
    <button
      onClick={onToggle}
      title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        width: 24, height: 24, borderRadius: 6, border: 'none',
        background: hovered ? t.bgHover : 'transparent',
        cursor: 'pointer', flexShrink: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: hovered ? t.textTertiary : t.textFaint,
        transition: 'background 0.12s, color 0.12s',
        padding: 0,
      }}
    >
      {collapsed ? (
        /* chevrons pointing right — expand */
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="3,3 7,7 3,11" />
          <polyline points="7,3 11,7 7,11" />
        </svg>
      ) : (
        /* chevrons pointing left — collapse */
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="11,3 7,7 11,11" />
          <polyline points="7,3 3,7 7,11" />
        </svg>
      )}
    </button>
  )
}

/* ── Icon components ── */
function LogoutIcon({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path d="M6 2H3a1 1 0 00-1 1v10a1 1 0 001 1h3" strokeLinecap="round" />
      <polyline points="11,5 14,8 11,11" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="14" y1="8" x2="6" y2="8" strokeLinecap="round" />
    </svg>
  )
}

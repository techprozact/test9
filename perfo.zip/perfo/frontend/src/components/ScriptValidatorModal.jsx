import { useState, useRef, useEffect } from 'react'
import { replayStart, replayNext, replayStop } from '../api'

export default function ScriptValidatorModal({ scriptId, scriptName, onClose }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [started, setStarted] = useState(false)
  const [tree, setTree] = useState([])
  const [steps, setSteps] = useState([])
  const [currentStep, setCurrentStep] = useState(null)
  const [done, setDone] = useState(false)
  const [summary, setSummary] = useState(null)
  const [executing, setExecuting] = useState(false)
  const [expanded, setExpanded] = useState({})
  const [selectedIdx, setSelectedIdx] = useState(null)
  const [reqTab, setReqTab] = useState('headers')
  const [resTab, setResTab] = useState('body')
  const bodyRef = useRef(null)

  useEffect(() => {
    return () => { replayStop(scriptId).catch(() => {}) }
  }, [scriptId])

  async function handleStart() {
    setLoading(true)
    setError(null)
    try {
      const data = await replayStart(scriptId)
      setTree(data.tree || [])
      setSteps(data.steps || [])
      setStarted(true)
      const exp = {}
      ;(data.tree || []).forEach((tx, i) => { exp[i] = true })
      setExpanded(exp)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  async function handleNext() {
    setExecuting(true)
    setError(null)
    try {
      const data = await replayNext(scriptId)
      setSteps(data.steps || [])
      if (data.step) {
        setCurrentStep(data.step)
        setSelectedIdx(data.step.request_index)
      }
      if (data.done) {
        setDone(true)
        if (data.summary) setSummary(data.summary)
      }
      updateTree(data.steps || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setExecuting(false)
    }
  }

  function updateTree(updatedSteps) {
    setTree(prev => prev.map(tx => ({
      ...tx,
      apis: tx.apis.map(api => {
        const s = updatedSteps.find(st => st.request_index === api.request_index)
        return s ? { ...api, status: s.status } : api
      })
    })))
  }

  function getStatusIcon(status) {
    if (status === 'passed') return <span style={{ color: '#7ee787' }}>✓</span>
    if (status === 'failed') return <span style={{ color: '#f85149' }}>✗</span>
    if (status === 'running') return <span style={{ color: '#d29922' }}>⟳</span>
    return <span style={{ color: '#8b98a5' }}>⌛</span>
  }

  function getTxStatus(apis) {
    if (apis.every(a => a.status === 'passed')) return 'passed'
    if (apis.some(a => a.status === 'failed')) return 'failed'
    if (apis.some(a => a.status === 'running')) return 'running'
    if (apis.some(a => a.status === 'passed')) return 'running'
    return 'pending'
  }

  const viewStep = selectedIdx != null ? steps.find(s => s.request_index === selectedIdx) : currentStep

  return (
    <div style={overlay} onClick={onClose}>
      <div style={modal} onClick={e => e.stopPropagation()}>
        <div style={modalHeader}>
          <span style={{ fontSize: 15, fontWeight: 600 }}>Script Validator — {scriptName}</span>
          <button onClick={onClose} style={closeBtn}>✕</button>
        </div>

        <div style={modalBody}>
          {/* Left Panel — Transaction Tree */}
          <div style={leftPanel}>
            <div style={panelTitle}>Transactions</div>
            {!started ? (
              <div style={{ padding: 12, color: '#8b98a5', fontSize: 13 }}>
                Click <b>Next</b> to begin validation.
              </div>
            ) : (
              <div style={{ overflow: 'auto', flex: 1 }}>
                {tree.map((tx, ti) => (
                  <div key={ti}>
                    <div
                      style={txRow}
                      onClick={() => setExpanded(p => ({ ...p, [ti]: !p[ti] }))}
                    >
                      <span style={{ marginRight: 6, fontSize: 10 }}>{expanded[ti] ? '▼' : '▶'}</span>
                      {getStatusIcon(getTxStatus(tx.apis))}
                      <span style={{ marginLeft: 6, fontSize: 13, fontWeight: 500 }}>{tx.transaction_name}</span>
                      <span style={{ marginLeft: 'auto', fontSize: 11, color: '#8b98a5' }}>
                        {tx.apis.filter(a => a.status === 'passed').length}/{tx.apis.length}
                      </span>
                    </div>
                    {expanded[ti] && tx.apis.map((api, ai) => (
                      <div
                        key={ai}
                        style={{
                          ...apiRow,
                          background: selectedIdx === api.request_index ? '#1c2128' : 'transparent',
                        }}
                        onClick={() => setSelectedIdx(api.request_index)}
                      >
                        {getStatusIcon(api.status)}
                        <span style={methodBadge(api.method)}>{api.method}</span>
                        <span style={{ fontSize: 12, color: '#c9d1d9', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {shortUrl(api.url)}
                        </span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}

            {summary && (
              <div style={summaryBox}>
                <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 4 }}>Summary</div>
                <div style={{ fontSize: 12 }}>
                  <span style={{ color: '#7ee787' }}>✓ {summary.passed}</span>
                  {' · '}
                  <span style={{ color: '#f85149' }}>✗ {summary.failed}</span>
                  {' · '}
                  Retries: {summary.total_retries}
                  {' · '}
                  Repairs: {summary.total_repairs}
                </div>
              </div>
            )}
          </div>

          {/* Right Panel — Request / Response Viewer */}
          <div style={rightPanel}>
            {!started ? (
              <div style={welcomeBox}>
                <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 8 }}>Welcome to Script Validator</div>
                <div style={{ color: '#8b98a5', fontSize: 13 }}>
                  Click <b>Next</b> to execute the first transaction.
                  Each request will be replayed against the live server.
                  Failed correlations are automatically detected and repaired.
                </div>
              </div>
            ) : viewStep ? (
              <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
                {/* Request Section */}
                <div style={sectionHeader}>
                  <span>Request</span>
                  <span style={{ marginLeft: 8, ...methodBadge(viewStep.method) }}>{viewStep.method}</span>
                  <span style={{ marginLeft: 8, fontSize: 12, color: '#c9d1d9', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
                    {viewStep.url}
                  </span>
                </div>
                <div style={tabBar}>
                  {['headers', 'payload'].map(t => (
                    <button key={t} onClick={() => setReqTab(t)}
                      style={{ ...tabBtn, ...(reqTab === t ? tabBtnActive : {}) }}>
                      {t === 'headers' ? 'Headers' : 'Payload'}
                    </button>
                  ))}
                </div>
                <div style={sectionContent}>
                  {reqTab === 'headers' ? (
                    <KeyValueTable data={viewStep.request_headers} />
                  ) : (
                    <pre style={preStyle}>{formatPayload(viewStep.request_payload)}</pre>
                  )}
                </div>

                {/* Response Section */}
                <div style={{ ...sectionHeader, marginTop: 4 }}>
                  <span>Response</span>
                  <StatusBadge status={viewStep.status} code={viewStep.replay_status_code} recorded={viewStep.recorded_status_code} />
                  {viewStep.retries > 0 && (
                    <span style={{ marginLeft: 8, fontSize: 11, color: '#d29922' }}>
                      {viewStep.retries} {viewStep.retries === 1 ? 'retry' : 'retries'}
                    </span>
                  )}
                  {viewStep.repaired_rules?.length > 0 && (
                    <span style={{ marginLeft: 8, fontSize: 11, color: '#a371f7' }}>
                      {viewStep.repaired_rules.length} rule{viewStep.repaired_rules.length > 1 ? 's' : ''} repaired
                    </span>
                  )}
                </div>
                <div style={tabBar}>
                  {['body', 'headers'].map(t => (
                    <button key={t} onClick={() => setResTab(t)}
                      style={{ ...tabBtn, ...(resTab === t ? tabBtnActive : {}) }}>
                      {t === 'body' ? 'Body' : 'Headers'}
                    </button>
                  ))}
                </div>
                <div style={{ ...sectionContent, flex: 1 }} ref={bodyRef}>
                  {resTab === 'headers' ? (
                    <KeyValueTable data={viewStep.response_headers} />
                  ) : (
                    <pre style={preStyle}>{formatBody(viewStep.response_body)}</pre>
                  )}
                </div>

                {viewStep.error && (
                  <div style={errorBar}>{viewStep.error}</div>
                )}
              </div>
            ) : (
              <div style={welcomeBox}>
                <div style={{ color: '#8b98a5', fontSize: 13 }}>
                  Click <b>Next</b> to execute the next request.
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div style={modalFooter}>
          {error && <span style={{ color: '#f85149', fontSize: 13, marginRight: 12 }}>{error}</span>}
          <div style={{ flex: 1 }} />
          {!started ? (
            <button onClick={handleStart} disabled={loading} style={nextBtn}>
              {loading ? 'Initializing...' : 'Start'}
            </button>
          ) : (
            <button onClick={handleNext} disabled={executing || done} style={{
              ...nextBtn,
              opacity: (executing || done) ? 0.6 : 1,
              cursor: (executing || done) ? 'not-allowed' : 'pointer',
            }}>
              {executing ? 'Running...' : done ? 'Complete' : 'Next'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function StatusBadge({ status, code, recorded }) {
  const color = status === 'passed' ? '#7ee787'
    : status === 'failed' ? '#f85149'
    : status === 'running' ? '#d29922'
    : '#8b98a5'
  return (
    <span style={{ marginLeft: 8, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
      {code > 0 && <span style={{ fontSize: 12, fontWeight: 600, color }}>{code}</span>}
      {recorded > 0 && code > 0 && code !== recorded && (
        <span style={{ fontSize: 11, color: '#8b98a5' }}>(expected {recorded})</span>
      )}
    </span>
  )
}

function KeyValueTable({ data }) {
  if (!data || Object.keys(data).length === 0) {
    return <div style={{ color: '#8b98a5', fontSize: 12, padding: 8 }}>No data</div>
  }
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
      <tbody>
        {Object.entries(data).map(([k, v]) => (
          <tr key={k}>
            <td style={kvKey}>{k}</td>
            <td style={kvVal}>{typeof v === 'string' ? v : JSON.stringify(v)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function shortUrl(url) {
  try {
    const u = new URL(url)
    return u.pathname + u.search
  } catch {
    return url
  }
}

function formatPayload(payload) {
  if (payload == null) return '(no payload)'
  if (typeof payload === 'string') return payload
  try { return JSON.stringify(payload, null, 2) } catch { return String(payload) }
}

function formatBody(body) {
  if (!body) return '(empty response)'
  try {
    const parsed = JSON.parse(body)
    return JSON.stringify(parsed, null, 2)
  } catch {
    return body.slice(0, 30000)
  }
}

function methodBadge(method) {
  const colors = { GET: '#61affe', POST: '#49cc90', PUT: '#fca130', DELETE: '#f93e3e', PATCH: '#50e3c2' }
  return {
    fontSize: 10, fontWeight: 700, padding: '1px 5px', borderRadius: 3,
    background: (colors[method] || '#8b98a5') + '22',
    color: colors[method] || '#8b98a5',
    flexShrink: 0,
  }
}

const overlay = {
  position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 1000,
  display: 'flex', alignItems: 'center', justifyContent: 'center',
}
const modal = {
  background: '#0d1117', border: '1px solid #30363d', borderRadius: 12,
  width: '92vw', maxWidth: 1200, height: '85vh', display: 'flex', flexDirection: 'column',
  overflow: 'hidden', color: '#c9d1d9',
}
const modalHeader = {
  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  padding: '12px 20px', borderBottom: '1px solid #21262d',
}
const closeBtn = {
  background: 'none', border: 'none', color: '#8b98a5', fontSize: 18, cursor: 'pointer',
  padding: '2px 6px', borderRadius: 4,
}
const modalBody = {
  display: 'flex', flex: 1, overflow: 'hidden',
}
const leftPanel = {
  width: 300, minWidth: 260, borderRight: '1px solid #21262d',
  display: 'flex', flexDirection: 'column', overflow: 'hidden',
}
const rightPanel = {
  flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden',
}
const panelTitle = {
  padding: '10px 14px', fontSize: 12, fontWeight: 600, color: '#8b98a5',
  borderBottom: '1px solid #21262d', textTransform: 'uppercase', letterSpacing: 0.5,
}
const txRow = {
  display: 'flex', alignItems: 'center', padding: '6px 12px', cursor: 'pointer',
  fontSize: 13, borderBottom: '1px solid #161b22',
}
const apiRow = {
  display: 'flex', alignItems: 'center', gap: 6, padding: '4px 12px 4px 28px',
  cursor: 'pointer', fontSize: 12, borderBottom: '1px solid #161b22',
}
const summaryBox = {
  padding: '10px 14px', borderTop: '1px solid #21262d', background: '#161b22',
}
const welcomeBox = {
  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
  height: '100%', padding: 40, textAlign: 'center',
}
const sectionHeader = {
  display: 'flex', alignItems: 'center', padding: '8px 16px',
  fontSize: 13, fontWeight: 600, background: '#161b22', borderBottom: '1px solid #21262d',
  flexShrink: 0,
}
const tabBar = {
  display: 'flex', gap: 0, borderBottom: '1px solid #21262d', flexShrink: 0,
}
const tabBtn = {
  padding: '6px 14px', background: 'transparent', border: 'none',
  borderBottom: '2px solid transparent', color: '#8b98a5', fontSize: 12,
  cursor: 'pointer', fontWeight: 500,
}
const tabBtnActive = {
  color: '#c9d1d9', borderBottomColor: '#1d9bf0',
}
const sectionContent = {
  overflow: 'auto', padding: '8px 16px', fontSize: 12, maxHeight: 220, minHeight: 80,
}
const preStyle = {
  margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: 12, color: '#c9d1d9',
  fontFamily: "'SF Mono', Menlo, monospace",
}
const kvKey = {
  padding: '3px 8px', color: '#7ee787', whiteSpace: 'nowrap', verticalAlign: 'top',
  borderBottom: '1px solid #161b22', fontWeight: 500, maxWidth: 200,
}
const kvVal = {
  padding: '3px 8px', color: '#c9d1d9', wordBreak: 'break-all',
  borderBottom: '1px solid #161b22',
}
const errorBar = {
  padding: '6px 16px', background: '#f8514922', color: '#f85149',
  fontSize: 12, borderTop: '1px solid #f8514944', flexShrink: 0,
}
const modalFooter = {
  display: 'flex', alignItems: 'center', padding: '10px 20px',
  borderTop: '1px solid #21262d',
}
const nextBtn = {
  padding: '8px 24px', background: '#238636', color: '#fff', border: 'none',
  borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer',
}

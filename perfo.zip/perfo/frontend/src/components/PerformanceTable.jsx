/**
 * PerformanceTable — LoadRunner-style API/Transaction stats table.
 *
 * Props:
 *   apiStats   { [apiPath]:  { min, avg, max, p90, p95, p99, pass, fail } }
 *   txStats    { [seqKey]:   { min, avg, max, p90, p95, p99, pass, fail } }
 *   txRows     [{ key, name }]  ordered rows for the Transaction Wise tab
 *   theme      theme object from parent
 *   isDark     boolean
 */
import { useState } from 'react'

const COLS = [
  { key: 'min',  label: 'Min',    unit: 'ms' },
  { key: 'avg',  label: 'Avg',    unit: 'ms' },
  { key: 'max',  label: 'Max',    unit: 'ms' },
  { key: 'p90',  label: '90th %', unit: 'ms' },
  { key: 'p95',  label: '95th %', unit: 'ms' },
  { key: 'p99',  label: '99th %', unit: 'ms' },
  { key: 'pass', label: 'Pass',   unit: ''   },
  { key: 'fail', label: 'Fail',   unit: ''   },
]

export default function PerformanceTable({ apiStats = {}, txStats = {}, txRows = [], theme: t, isDark }) {
  const [activeTab, setActiveTab] = useState('api')
  const [sortCol,   setSortCol]   = useState(null)
  const [sortAsc,   setSortAsc]   = useState(false)

  function handleSort(col) {
    if (sortCol === col) setSortAsc(a => !a)
    else { setSortCol(col); setSortAsc(false) }
  }

  /* ── build rows ── */

  const apiRows = Object.entries(apiStats)
    .map(([path, s]) => ({ key: path, name: path, ...s }))

  const txDataRows = txRows.length > 0
    ? txRows.map(({ key, name }) => {
        const s = txStats[key] || { min: 0, avg: 0, max: 0, p90: 0, p95: 0, p99: 0, pass: 0, fail: 0 }
        return { key, name, ...s }
      })
    : Object.entries(txStats).map(([key, s]) => ({ key, name: key, ...s }))

  const rows = activeTab === 'api' ? apiRows : txDataRows

  /* ── sort ── */
  const sorted = sortCol
    ? [...rows].sort((a, b) => {
        const va = a[sortCol] ?? 0
        const vb = b[sortCol] ?? 0
        const cmp = typeof va === 'string' ? va.localeCompare(vb) : va - vb
        return sortAsc ? cmp : -cmp
      })
    : rows

  if (!sorted.length) return null

  /* ── styles ── */
  const thStyle = (isName, col) => ({
    padding: '8px 10px',
    textAlign: isName ? 'left' : 'right',
    color: sortCol === col ? t.accent : t.textTertiary,
    fontSize: 10,
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
    borderBottom: `1px solid ${t.border}`,
    whiteSpace: 'nowrap',
    cursor: col ? 'pointer' : 'default',
    userSelect: 'none',
    background: isDark ? 'rgba(255,255,255,0.025)' : 'rgba(15,23,42,0.025)',
    transition: 'color 0.15s',
  })

  const tdStyle = (isName, isFail, val) => ({
    padding: '7px 10px',
    textAlign: isName ? 'left' : 'right',
    fontSize: 12,
    fontVariantNumeric: 'tabular-nums',
    color: isFail && val > 0 ? '#ef4444' : isName ? t.textPrimary : t.textSecondary,
    borderBottom: `1px solid ${isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)'}`,
    whiteSpace: 'nowrap',
    maxWidth: isName ? 260 : undefined,
    overflow: isName ? 'hidden' : undefined,
    textOverflow: isName ? 'ellipsis' : undefined,
  })

  const tabBtn = (key, label) => (
    <button
      key={key}
      onClick={() => setActiveTab(key)}
      style={{
        padding: '6px 16px',
        fontSize: 12,
        fontWeight: 600,
        border: 'none',
        borderRadius: 6,
        cursor: 'pointer',
        background: activeTab === key
          ? (isDark ? 'rgba(99,102,241,0.18)' : 'rgba(99,102,241,0.1)')
          : 'transparent',
        color: activeTab === key ? t.accent : t.textMuted,
        transition: 'background 0.15s, color 0.15s',
      }}
    >{label}</button>
  )

  const sortArrow = (col) => {
    if (sortCol !== col) return <span style={{ opacity: 0.3, marginLeft: 3 }}>↕</span>
    return <span style={{ marginLeft: 3 }}>{sortAsc ? '↑' : '↓'}</span>
  }

  return (
    <div style={{ marginTop: 18 }}>
      {/* ── section header + tabs ── */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 10,
      }}>
        <div style={{ color: t.textMuted, fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          Performance Breakdown
        </div>
        <div style={{
          display: 'flex', gap: 4,
          background: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)',
          borderRadius: 8, padding: '3px 4px',
          border: `1px solid ${t.border}`,
        }}>
          {tabBtn('api', 'API Wise')}
          {tabBtn('tx',  'Transaction Wise')}
        </div>
      </div>

      {/* ── table ── */}
      <div style={{ overflowX: 'auto', borderRadius: 8, border: `1px solid ${t.border}` }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'auto', minWidth: 700 }}>
          <thead>
            <tr>
              <th style={thStyle(true, null)}>
                {activeTab === 'api' ? 'API Endpoint' : 'Transaction Name'}
              </th>
              {COLS.map(c => (
                <th
                  key={c.key}
                  style={thStyle(false, c.key)}
                  onClick={() => handleSort(c.key)}
                  title={`Sort by ${c.label}`}
                >
                  {c.label}{c.unit ? ` (${c.unit})` : ''}{sortArrow(c.key)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map((row, i) => (
              <tr
                key={row.key}
                style={{
                  background: i % 2 === 0
                    ? 'transparent'
                    : (isDark ? 'rgba(255,255,255,0.018)' : 'rgba(15,23,42,0.018)'),
                  transition: 'background 0.1s',
                }}
                onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.07)' : 'rgba(99,102,241,0.045)' }}
                onMouseLeave={e => { e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : (isDark ? 'rgba(255,255,255,0.018)' : 'rgba(15,23,42,0.018)') }}
              >
                <td style={tdStyle(true, false, null)} title={row.name}>{row.name}</td>
                {COLS.map(c => (
                  <td key={c.key} style={tdStyle(false, c.key === 'fail', row[c.key] ?? 0)}>
                    {row[c.key] ?? 0}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{ color: t.textFaint, fontSize: 10, marginTop: 6, marginBottom: 0, textAlign: 'right' }}>
        All response times in ms · {sorted.length} {activeTab === 'api' ? 'endpoints' : 'transactions'} · Click column headers to sort
      </p>
    </div>
  )
}

const API_BASE = 'http://localhost:8000'
const DEBUG = true // set to false to disable console logs

function log(...args) {
  if (DEBUG) console.log('[perfSense]', ...args)
}

export async function uploadScript(file) {
  const form = new FormData()
  form.append('file', file)
  log('POST upload-script', { url: `${API_BASE}/upload-script`, filename: file?.name })
  const res = await fetch(`${API_BASE}/upload-script`, {
    method: 'POST',
    body: form,
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    log('Upload failed', { status: res.status, body: data })
    throw new Error(data.detail || 'Upload failed')
  }
  log('Upload OK', {
    status: res.status,
    scriptId: data?.script?.id,
    scriptIdType: typeof data?.script?.id,
    scriptKeys: data?.script ? Object.keys(data.script) : [],
    fullScript: data?.script,
  })
  return data
}

export async function listScripts() {
  const res = await fetch(`${API_BASE}/scripts`)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Failed to load scripts')
  }
  return res.json()
}

export async function getScriptTransactions(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  const url = `${API_BASE}/scripts/${encodeURIComponent(id)}/transactions`
  log('GET transactions', { scriptIdParam: scriptId, scriptIdType: typeof scriptId, idAfterTrim: id, url })
  if (!id) throw new Error('Script not found')
  const res = await fetch(url)
  const body = await res.json().catch(() => ({}))
  if (!res.ok) {
    log('GET transactions failed', { status: res.status, url, body })
    const err = new Error(body.detail || 'Failed to load transactions')
    err.status = res.status
    err.body = body
    err.debug = body.debug
    throw err
  }
  log('GET transactions OK', { status: res.status, count: Array.isArray(body) ? body.length : 'n/a' })
  return body
}

export async function getPythonScript(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) throw new Error('Script not found')
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}/python-script`)
  if (!res.ok) {
    const err = await res.json().catch(() => null)
    const detail = err?.detail || res.statusText
    throw new Error(typeof detail === 'string' ? detail : 'Failed to load Python script')
  }
  return res.text()
}

/** Get download URL for the generated Python script (opens in new tab or use with fetch + blob for download). */
export function getDownloadScriptUrl(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) return null
  return `${API_BASE}/scripts/${encodeURIComponent(id)}/download-script`
}

/** Trigger download of the generated Python script as .py file. */
export async function downloadScript(scriptId, filename = 'script.py') {
  const url = getDownloadScriptUrl(scriptId)
  if (!url) throw new Error('Script not found')
  const res = await fetch(url)
  if (!res.ok) throw new Error('Failed to download script')
  const blob = await res.blob()
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = filename
  a.click()
  URL.revokeObjectURL(a.href)
}


export async function deleteScript(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) throw new Error('Script not found')
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}`, { method: 'DELETE' })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Failed to delete script')
  return data
}

export async function correlateScript(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) throw new Error('Script not found')
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}/correlate`, {
    method: 'POST',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Correlation failed')
  return data
}

export async function downloadCorrelatedScript(scriptId, filename = 'script_correlated.py') {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) throw new Error('Script not found')
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}/download-correlated-script`)
  if (!res.ok) throw new Error('Failed to download correlated script')
  const blob = await res.blob()
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = filename
  a.click()
  URL.revokeObjectURL(a.href)
}

// ---------- Script Replay Validator ----------

export async function replayStart(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) throw new Error('Script not found')
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}/replay/start`, {
    method: 'POST',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Failed to start replay')
  return data
}

export async function replayNext(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) throw new Error('Script not found')
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}/replay/next`, {
    method: 'POST',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Failed to execute next step')
  return data
}

export async function replayStop(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) throw new Error('Script not found')
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}/replay/stop`, {
    method: 'POST',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Failed to stop replay')
  return data
}

// ---------- Script Parameters ----------

export async function getScriptParameters(scriptId) {
  const id = scriptId != null ? String(scriptId).trim() : ''
  if (!id) return []
  const res = await fetch(`${API_BASE}/scripts/${encodeURIComponent(id)}/parameters`)
  if (!res.ok) return []
  return res.json()
}

// ---------- Scenarios (Load Designer) ----------

export async function listScenarios() {
  const res = await fetch(`${API_BASE}/scenarios`)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Failed to load scenarios')
  }
  return res.json()
}

export async function createScenario(data) {
  const res = await fetch(`${API_BASE}/scenarios`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(body.detail || 'Failed to create scenario')
  return body
}

export async function updateScenario(id, data) {
  const res = await fetch(`${API_BASE}/scenarios/${encodeURIComponent(id)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(body.detail || 'Failed to update scenario')
  return body
}

export async function deleteScenario(id) {
  const res = await fetch(`${API_BASE}/scenarios/${encodeURIComponent(id)}`, { method: 'DELETE' })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(body.detail || 'Failed to delete scenario')
  return body
}

// ---------- Execution Engine ----------

export async function startExecution(config) {
  const res = await fetch(`${API_BASE}/executions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Failed to start execution')
  return data
}

export async function listExecutions() {
  const res = await fetch(`${API_BASE}/executions`)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Failed to list executions')
  }
  return res.json()
}

export async function getExecution(testRunId) {
  const res = await fetch(`${API_BASE}/executions/${encodeURIComponent(testRunId)}`)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Failed to get execution status')
  }
  return res.json()
}

export async function stopExecution(testRunId) {
  const res = await fetch(`${API_BASE}/executions/${encodeURIComponent(testRunId)}/stop`, {
    method: 'POST',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Failed to stop execution')
  return data
}

export async function getExecutionTelemetry(testRunId, limit = 500, offset = 0) {
  const res = await fetch(`${API_BASE}/executions/${encodeURIComponent(testRunId)}/telemetry?limit=${limit}&offset=${offset}`)
  if (!res.ok) return []
  return res.json()
}

export async function getExecutionSummary(testRunId) {
  const res = await fetch(`${API_BASE}/executions/${encodeURIComponent(testRunId)}/summary`)
  if (!res.ok) return null
  return res.json()
}

export async function getExecutionErrors(testRunId, scriptId = null, limit = 20, offset = 0) {
  let url = `${API_BASE}/executions/${encodeURIComponent(testRunId)}/errors?limit=${limit}&offset=${offset}`
  if (scriptId != null) url += `&script_id=${encodeURIComponent(scriptId)}`
  const res = await fetch(url)
  if (!res.ok) return { records: [], total: 0 }
  return res.json()
}

export function getExecutionErrorsDownloadUrl(testRunId, scriptId = null) {
  let url = `${API_BASE}/executions/${encodeURIComponent(testRunId)}/errors/download`
  if (scriptId != null) url += `?script_id=${encodeURIComponent(scriptId)}`
  return url
}

export async function deleteExecution(testRunId) {
  const res = await fetch(`${API_BASE}/executions/${encodeURIComponent(testRunId)}`, {
    method: 'DELETE',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Failed to delete execution')
  return data
}

// ---------- Perfzy (API Script Builder) ----------

export async function perfzyExecute(requestDef) {
  log('POST perfzy/execute', requestDef)
  const res = await fetch(`${API_BASE}/perfzy/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(requestDef),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Request execution failed')
  return data
}

export async function perfzyCreateScript(workflow) {
  log('POST perfzy/create-script', workflow)
  const res = await fetch(`${API_BASE}/perfzy/create-script`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(workflow),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || 'Script creation failed')
  return data
}

export { API_BASE }

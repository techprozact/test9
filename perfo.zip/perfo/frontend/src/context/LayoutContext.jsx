import { createContext } from 'react'

export const LayoutContext = createContext({
  sidebarCollapsed: false,
  collapseSidebar: () => {},
})

import { createContext, useContext, useState, useEffect } from 'react'

export const DARK = {
  pageBg:          '#0f1419',
  bgBase:          '#0d1117',
  bgRaised:        '#161b22',
  bgOverlay:       '#1c2128',
  bgHover:         'rgba(255,255,255,0.05)',
  bgHoverStrong:   'rgba(255,255,255,0.08)',
  bgActiveNav:     'rgba(29,155,240,0.12)',
  bgInput:         '#0d1117',
  border:          '#21262d',
  borderMuted:     '#30363d',
  textPrimary:     '#e7e9ea',
  textSecondary:   '#c9d1d9',
  textTertiary:    '#8b98a5',
  textMuted:       '#6e7681',
  textFaint:       '#4b5563',
  textNavGroup:    '#3d4450',
  textNavActive:   '#1d9bf0',
  textNavInactive: '#8b98a5',
  textNavHover:    '#c9d1d9',
  textNavSoon:     '#4b5563',
  activeBar:       '#1d9bf0',
  accent:          '#1d9bf0',
  accentPurple:    '#a78bfa',
  sidebarBg:       '#0d1117',
  topbarBg:        '#0d1117',
  topbarBorder:    '#21262d',
  dropdownBg:      '#161b22',
  dropdownBorder:  '#30363d',
  dropdownShadow:  '0 12px 32px rgba(0,0,0,0.5)',
  cardShadow:      '0 2px 12px rgba(0,0,0,0.25)',
  tableRowAlt:     'rgba(255,255,255,0.01)',
  tagBg:           '#0d1117',
  tagBorder:       '#30363d',
  isDark:          true,
}

export const LIGHT = {
  pageBg:          '#f6f8fa',
  bgBase:          '#ffffff',
  bgRaised:        '#f8fafc',
  bgOverlay:       '#f1f5f9',
  bgHover:         'rgba(15,23,42,0.04)',
  bgHoverStrong:   'rgba(15,23,42,0.07)',
  bgActiveNav:     'rgba(2,132,199,0.08)',
  bgInput:         '#ffffff',
  border:          '#e2e8f0',
  borderMuted:     '#cbd5e1',
  textPrimary:     '#0f172a',
  textSecondary:   '#1e293b',
  textTertiary:    '#475569',
  textMuted:       '#64748b',
  textFaint:       '#94a3b8',
  textNavGroup:    '#94a3b8',
  textNavActive:   '#0284c7',
  textNavInactive: '#64748b',
  textNavHover:    '#0f172a',
  textNavSoon:     '#94a3b8',
  activeBar:       '#0284c7',
  accent:          '#0284c7',
  accentPurple:    '#7c3aed',
  sidebarBg:       '#ffffff',
  topbarBg:        '#ffffff',
  topbarBorder:    '#e2e8f0',
  dropdownBg:      '#ffffff',
  dropdownBorder:  '#e2e8f0',
  dropdownShadow:  '0 8px 24px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.05)',
  cardShadow:      '0 1px 4px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.04)',
  tableRowAlt:     'rgba(15,23,42,0.02)',
  tagBg:           '#f1f5f9',
  tagBorder:       '#e2e8f0',
  isDark:          false,
}

const ThemeCtx = createContext({ t: DARK, isDark: true, toggle: () => {} })

export function ThemeProvider({ children }) {
  const [isDark, setIsDark] = useState(
    () => localStorage.getItem('pt0-theme') !== 'light'
  )

  useEffect(() => {
    const t = isDark ? DARK : LIGHT
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light')
    document.body.style.background = t.pageBg
    document.body.style.color      = t.textPrimary
    localStorage.setItem('pt0-theme', isDark ? 'dark' : 'light')
  }, [isDark])

  const toggle = () => setIsDark(v => !v)
  const t = isDark ? DARK : LIGHT

  return (
    <ThemeCtx.Provider value={{ t, isDark, toggle }}>
      {children}
    </ThemeCtx.Provider>
  )
}

export function useTheme() {
  return useContext(ThemeCtx)
}

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTheme } from '../context/ThemeContext'

const FEATURE_DETAILS = {
  'Load Designer': {
    desc: 'Design sophisticated load test scenarios with virtual user ramps, think times, and test duration configuration.',
    accent: '#f97316',
    features: [
      'VU ramp-up and ramp-down patterns',
      'Constant, spike, and stress test profiles',
      'Per-endpoint throughput targets',
      'Custom think time distribution',
    ],
    eta: 'Q2 2025',
    icon: LoadIcon,
  },
  'Quick Test': {
    desc: 'Instantly fire a simple load test with minimal configuration — perfect for quick sanity checks.',
    accent: '#22c55e',
    features: [
      'One-click test execution',
      'Real-time response monitoring',
      'Instant pass/fail assessment',
      'Shareable test snapshots',
    ],
    eta: 'Q2 2025',
    icon: QuickIcon,
  },
  'Test Results': {
    desc: 'Deep-dive into execution metrics with interactive charts, percentile analysis, and error breakdowns.',
    accent: '#a78bfa',
    features: [
      'Response time percentile charts (p50, p90, p95, p99)',
      'Error rate and failure analysis',
      'Throughput over time graphs',
      'Side-by-side test comparisons',
    ],
    eta: 'Q3 2025',
    icon: ResultsIcon,
  },
  'Reports': {
    desc: 'Generate professional performance reports and share test insights with your team.',
    accent: '#38bdf8',
    features: [
      'PDF and HTML report export',
      'Customizable report templates',
      'Trend analysis across runs',
      'Team sharing and annotations',
    ],
    eta: 'Q3 2025',
    icon: ReportsIcon,
  },
}

export default function ComingSoonPage({ feature = 'Feature' }) {
  const { t } = useTheme()
  const navigate = useNavigate()
  const [notified, setNotified] = useState(false)
  const detail = FEATURE_DETAILS[feature] || {
    desc: 'This feature is currently in development and will be available soon.',
    accent: '#1d9bf0',
    features: [],
    eta: 'Soon',
    icon: DefaultIcon,
  }
  const Icon = detail.icon

  return (
    <div style={{
      maxWidth: 720, margin: '0 auto', padding: '48px 0 64px',
      display: 'flex', flexDirection: 'column', alignItems: 'center',
    }}>
      {/* Icon */}
      <div style={{
        width: 72, height: 72, borderRadius: 20,
        background: `${detail.accent}14`, border: `1px solid ${detail.accent}30`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginBottom: 24, color: detail.accent,
        boxShadow: `0 0 40px ${detail.accent}15`,
      }}>
        <Icon size={32} />
      </div>

      {/* ETA badge */}
      <span style={{
        fontSize: 10.5, fontWeight: 700, padding: '3px 10px', borderRadius: 999,
        background: 'rgba(251,191,36,0.08)', color: '#ca8a04',
        border: '1px solid rgba(251,191,36,0.2)', letterSpacing: 0.6,
        marginBottom: 16,
      }}>
        COMING {detail.eta}
      </span>

      <h2 style={{
        margin: '0 0 12px', fontSize: 28, fontWeight: 800, color: t.textPrimary,
        letterSpacing: -0.5, textAlign: 'center',
      }}>
        {feature}
      </h2>
      <p style={{
        margin: '0 0 36px', fontSize: 15, color: t.textMuted, lineHeight: 1.7,
        textAlign: 'center', maxWidth: 500,
      }}>
        {detail.desc}
      </p>

      {/* Feature preview */}
      {detail.features.length > 0 && (
        <div style={{
          width: '100%', background: t.bgBase, border: `1px solid ${t.border}`,
          borderRadius: 12, padding: '24px 28px', marginBottom: 32,
          boxShadow: t.cardShadow,
        }}>
          <div style={{
            fontSize: 11, fontWeight: 600, color: t.textFaint, letterSpacing: 0.8,
            textTransform: 'uppercase', marginBottom: 16,
          }}>
            WHAT'S PLANNED
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {detail.features.map((f, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 9 }}>
                <span style={{
                  width: 16, height: 16, borderRadius: 5,
                  background: `${detail.accent}14`, border: `1px solid ${detail.accent}25`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, marginTop: 1,
                }}>
                  <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
                    <polyline points="1.5,4 3,5.5 6.5,2.5" stroke={detail.accent} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </span>
                <span style={{ fontSize: 13, color: t.textTertiary, lineHeight: 1.5 }}>{f}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
        <button
          onClick={() => { setNotified(true); setTimeout(() => setNotified(false), 3000) }}
          style={{
            padding: '10px 22px', borderRadius: 8, fontSize: 13, fontWeight: 600,
            background: notified ? `${detail.accent}18` : detail.accent,
            border: notified ? `1px solid ${detail.accent}40` : 'none',
            color: notified ? detail.accent : '#fff',
            cursor: 'pointer', transition: 'all 0.2s',
            boxShadow: notified ? 'none' : `0 2px 16px ${detail.accent}30`,
          }}
        >
          {notified ? '✓ You\'ll be notified!' : 'Notify me when ready'}
        </button>
        <button
          onClick={() => navigate('/app')}
          style={{
            padding: '10px 22px', borderRadius: 8, fontSize: 13, fontWeight: 600,
            background: t.bgHover, border: `1px solid ${t.borderMuted}`,
            color: t.textTertiary, cursor: 'pointer',
          }}
        >
          Back to Dashboard
        </button>
      </div>

      {/* Progress bar */}
      <div style={{ marginTop: 48, width: '100%', maxWidth: 420, textAlign: 'center' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
          <span style={{ fontSize: 11.5, color: t.textFaint }}>Development progress</span>
          <span style={{ fontSize: 11.5, color: detail.accent, fontWeight: 600 }}>
            {feature === 'Load Designer' || feature === 'Quick Test' ? '35%' : '15%'}
          </span>
        </div>
        <div style={{
          height: 4, background: t.border, borderRadius: 999, overflow: 'hidden',
        }}>
          <div style={{
            height: '100%', borderRadius: 999,
            width: feature === 'Load Designer' || feature === 'Quick Test' ? '35%' : '15%',
            background: `linear-gradient(90deg, ${detail.accent}80, ${detail.accent})`,
            transition: 'width 0.8s ease',
          }} />
        </div>
      </div>
    </div>
  )
}

function LoadIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path d="M16 4 L27 27 L16 21 L5 27 Z" strokeLinejoin="round" />
    </svg>
  )
}
function QuickIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <polygon points="8,4 28,16 8,28" strokeLinejoin="round" />
    </svg>
  )
}
function ResultsIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <line x1="4" y1="28" x2="4" y2="16" strokeLinecap="round" />
      <line x1="12" y1="28" x2="12" y2="10" strokeLinecap="round" />
      <line x1="20" y1="28" x2="20" y2="18" strokeLinecap="round" />
      <line x1="28" y1="28" x2="28" y2="6" strokeLinecap="round" />
    </svg>
  )
}
function ReportsIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <rect x="4" y="2" width="24" height="28" rx="3" />
      <line x1="10" y1="10" x2="22" y2="10" strokeLinecap="round" />
      <line x1="10" y1="16" x2="22" y2="16" strokeLinecap="round" />
      <line x1="10" y1="22" x2="16" y2="22" strokeLinecap="round" />
    </svg>
  )
}
function DefaultIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <circle cx="16" cy="16" r="13" />
      <line x1="16" y1="10" x2="16" y2="18" strokeLinecap="round" />
      <circle cx="16" cy="23" r="1.5" fill="currentColor" stroke="none" />
    </svg>
  )
}

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { uploadScript } from '../api'
import { useTheme } from '../context/ThemeContext'

const DEBUG = true

export default function UploadPage() {
  const { t } = useTheme()
  const [file, setFile] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    if (!file) {
      setError('Please select a file')
      return
    }
    setError(null)
    setLoading(true)
    try {
      const data = await uploadScript(file)
      setFile(null)
      const scriptId = data?.script?.id
      const redirectPath = `/app/scripts/${String(scriptId)}`
      if (DEBUG) {
        console.log('[perfSense] UploadPage: after upload', {
          hasScript: !!data?.script,
          scriptId,
          scriptIdType: typeof scriptId,
          redirectPath,
          fullResponseKeys: data ? Object.keys(data) : [],
        })
      }
      if (scriptId != null && scriptId !== '') {
        navigate(redirectPath)
      }
    } catch (err) {
      setError(err.message || 'Upload failed')
    } finally {
      setLoading(false)
    }
  }

  const inputStyle = { padding: '0.5rem', background: t.bgBase, border: `1px solid ${t.border}`, borderRadius: 6, color: t.textPrimary }
  const buttonStyle = { padding: '0.75rem 1.25rem', background: t.accent, border: 'none', borderRadius: 6, color: '#fff', fontWeight: 600, cursor: 'pointer' }

  return (
    <div>
      <h2 style={{ fontSize: 20, marginBottom: 25, marginTop: 0, color: t.textPrimary }}>
        Upload Script<span style={{ color: t.textTertiary, fontWeight: 400, fontSize: 14, marginLeft: 8 }}>Upload existing k6 or Locust scripts for execution</span>
      </h2>
      <p style={{ color: t.textTertiary, fontSize: 14, marginBottom: 25 }}>
        Upload a HAR file (.har) exported from your browser. The parser will extract API requests and generate a performance script.
      </p>
      <form onSubmit={handleSubmit} style={formStyle}>
        <input
          type="file"
          accept=".har,application/json"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          style={inputStyle}
        />
        <button type="submit" disabled={loading} style={buttonStyle}>
          {loading ? 'Uploading...' : 'Upload and Parse'}
        </button>
      </form>
      {error && <p style={{ color: '#f4212e', marginTop: '1rem' }}>{error}</p>}
    </div>
  )
}

const formStyle = { display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: 400 }

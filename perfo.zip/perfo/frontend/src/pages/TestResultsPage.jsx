import { useState, useEffect, useRef, useMemo, useCallback } from 'react'
import { createPortal } from 'react-dom'
import { useTheme } from '../context/ThemeContext'
import { useSearchParams } from 'react-router-dom'
import {
  listExecutions, getExecution, getExecutionSummary,
  deleteExecution, listScenarios, getScriptTransactions,
  API_BASE,
} from '../api'
import { fetchAllTelemetry, replayTelemetry, computePerScriptStats, computeApiTxStats, replayApiTxGraphData } from '../analytics/replayEngine'
import { analyzeTestResults, computeVerdict } from '../analytics/perforaPostAnalysis'
import ErrorLogsModal from '../components/ErrorLogsModal'
import PerformanceTable from '../components/PerformanceTable'
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar, ComposedChart,
  ResponsiveContainer, Tooltip, CartesianGrid, XAxis, YAxis, ReferenceLine,
} from 'recharts'

/* ─────────────────────── shared metric config (matches QuickTestPage) ─────────────────────── */

const METRICS = [
  { key: 'active_vus',  label: 'Active Virtual Users',    unit: 'VUs',    color: '#3b82f6', type: 'area',       idleMax: 100,  hasPerItem: false },
  { key: 'throughput',  label: 'Throughput',               unit: 'TPS',    color: '#06b6d4', type: 'area',       idleMax: 500,  hasPerItem: true,  perItemField: 'tps'    },
  { key: 'avg_rt',      label: 'Avg Response Time',        unit: 'ms',     color: '#10b981', type: 'line',       idleMax: 300,  hasPerItem: true,  perItemField: 'avgRt'  },
  { key: 'hits',        label: 'Hits / Second',            unit: 'hits/s', color: '#f59e0b', type: 'bar',        idleMax: 500,  hasPerItem: true,  perItemField: 'tps'    },
  { key: 'error_rate',  label: 'Error Rate',               unit: '%',      color: '#ef4444', type: 'area',       idleMax: 5,    hasPerItem: true,  perItemField: 'errPct' },
  { key: 'requests',    label: 'Requests Completed',       unit: '',       color: '#14b8a6', type: 'area',       idleMax: 1000, hasPerItem: false },
  { key: 'latency',     label: 'Latency Trend',            unit: 'ms',     color: '#a78bfa', type: 'multi-line', idleMax: 500,  hasPerItem: false },
  { key: 'ux_variance', label: 'User Experience Variance', unit: 'ms',     color: '#f472b6', type: 'area',       idleMax: 400,  hasPerItem: false },
]
const LAT_COLORS = { p50: '#06b6d4', p90: '#10b981', p95: '#8b5cf6', p99: '#f59e0b' }

const SERIES_PALETTE = [
  '#f59e0b', '#3b82f6', '#ec4899', '#8b5cf6',
  '#06b6d4', '#84cc16', '#f97316', '#14b8a6',
  '#ef4444', '#a855f7', '#0ea5e9', '#d946ef',
]

const TABLE_DEFS = {
  avg_rt: {
    cols: [
      { label: 'Avg RT (ms)', isFail: false },
      { label: 'Min RT (ms)', isFail: false },
      { label: 'Max RT (ms)', isFail: false },
      { label: 'Calls',       isFail: false },
      { label: 'Fail',        isFail: true  },
    ],
    avgRow:    (v, totReqs, totErrs) => [
      v.length ? Math.round(v.reduce((s, x) => s + x, 0) / v.length) : 0,
      v.length ? Math.min(...v) : 0,
      v.length ? Math.max(...v) : 0,
      totReqs ?? null, totErrs ?? null,
    ],
    seriesRow: (st) => [
      st?.avg ?? 0, st?.min ?? null, st?.max ?? null,
      st ? (st.pass || 0) + (st.fail || 0) : null, st?.fail ?? null,
    ],
  },
  throughput: {
    cols: [
      { label: 'Avg TPS',  isFail: false },
      { label: 'Peak TPS', isFail: false },
      { label: 'Calls',    isFail: false },
      { label: 'Fail',     isFail: true  },
    ],
    avgRow:    (v, totReqs, totErrs) => [
      v.length ? Math.round(v.reduce((s, x) => s + x, 0) / v.length) : 0,
      v.length ? Math.max(...v) : 0,
      totReqs ?? null, totErrs ?? null,
    ],
    seriesRow: (st, gpts) => {
      const tpsV = (gpts || []).map(p => p.tps).filter(x => x > 0)
      return [
        tpsV.length ? Math.round(tpsV.reduce((s, x) => s + x, 0) / tpsV.length) : 0,
        tpsV.length ? Math.max(...tpsV) : 0,
        st ? (st.pass || 0) + (st.fail || 0) : null, st?.fail ?? null,
      ]
    },
  },
  hits: {
    cols: [
      { label: 'Avg Hits/s',  isFail: false },
      { label: 'Peak Hits/s', isFail: false },
      { label: 'Calls',       isFail: false },
      { label: 'Fail',        isFail: true  },
    ],
    avgRow:    (v, totReqs, totErrs) => [
      v.length ? Math.round(v.reduce((s, x) => s + x, 0) / v.length) : 0,
      v.length ? Math.max(...v) : 0,
      totReqs ?? null, totErrs ?? null,
    ],
    seriesRow: (st, gpts) => {
      const tpsV = (gpts || []).map(p => p.tps).filter(x => x > 0)
      return [
        tpsV.length ? Math.round(tpsV.reduce((s, x) => s + x, 0) / tpsV.length) : 0,
        tpsV.length ? Math.max(...tpsV) : 0,
        st ? (st.pass || 0) + (st.fail || 0) : null, st?.fail ?? null,
      ]
    },
  },
  error_rate: {
    cols: [
      { label: 'Error %', isFail: true  },
      { label: 'Errors',  isFail: true  },
      { label: 'Calls',   isFail: false },
      { label: 'Pass',    isFail: false },
    ],
    avgRow:    (_v, totReqs, totErrs, lastVal) => {
      const pass = totReqs != null && totErrs != null ? Math.max(0, totReqs - totErrs) : null
      return [Number(lastVal ?? 0).toFixed(2), totErrs ?? null, totReqs ?? null, pass]
    },
    seriesRow: (st) => {
      const total  = st ? (st.pass || 0) + (st.fail || 0) : 0
      const errPct = total > 0 && st ? ((st.fail / total) * 100).toFixed(2) : '0.00'
      return [errPct, st?.fail ?? null, total || null, st?.pass ?? null]
    },
  },
}

/* ─────────────────────── helpers ─────────────────────── */

function fmtLocalTime(d) {
  if (!d) return '—'
  const dt = typeof d === 'string' ? new Date(d) : d
  if (isNaN(dt)) return '—'
  return dt.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
}

function fmtLocalDate(d) {
  if (!d) return '—'
  const dt = typeof d === 'string' ? new Date(d) : d
  if (isNaN(dt)) return '—'
  return dt.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) + ' ' +
    dt.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
}

function fmtTime(secs) {
  if (!secs || secs <= 0) return '0s'
  if (secs < 60) return `${Math.round(secs)}s`
  const m = Math.floor(secs / 60), s = Math.round(secs % 60)
  return s > 0 ? `${m}m ${s}s` : `${m}m`
}

function fmtElapsed(sampleIdx) {
  const secs = (sampleIdx ?? 0) * 5
  if (secs < 60) return `${secs}s`
  const m = Math.floor(secs / 60)
  const s = String(secs % 60).padStart(2, '0')
  return `${m}:${s} min`
}

function buildTipText(payload, label, unit, isMulti) {
  if (!payload?.length) return ''
  const time = fmtElapsed(label)
  if (isMulti) {
    return payload.map(p => `${p.name?.toUpperCase()}: ${p.value}`).join('  ') + `  (${time})`
  }
  const val  = payload[0]?.value ?? 0
  const disp = unit ? `${val} ${unit}` : `${val}`
  return `${disp}  (${time})`
}

function shortId(id) {
  if (!id) return '—'
  return id.length > 8 ? id.slice(0, 8) : id
}

function parseSnapshot(snap) {
  if (!snap) return null
  try { return typeof snap === 'string' ? JSON.parse(snap) : snap } catch { return null }
}

function fmtHHMMSS(totalSecs) {
  const s = Math.max(0, Math.round(totalSecs || 0))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
}

function fmtSecs(s) {
  if (!s || s <= 0) return '0s'
  if (s < 60) return `${Math.round(s)}s`
  const m = Math.floor(s / 60), r = Math.round(s % 60)
  return r > 0 ? `${m}m ${r}s` : `${m}m`
}

function mapStatus(rawStatus) {
  // User-facing: only "Completed" or "Stopped"
  if (rawStatus === 'COMPLETED') return { label: 'Completed', color: '#22c55e' }
  if (rawStatus === 'INITIALIZING' || rawStatus === 'RAMPING_UP' || rawStatus === 'STEADY' || rawStatus === 'RAMPING_DOWN') {
    return { label: 'Running', color: '#3b82f6' }
  }
  return { label: 'Stopped', color: '#f97316' }
}

function getCardStats(metricKey, data) {
  const arr  = data[metricKey] || []
  const vals = arr.map(d => d.v ?? 0)
  const pos  = vals.filter(v => v > 0)
  const min  = pos.length ? Math.min(...pos) : 0
  const max  = pos.length ? Math.max(...pos) : 0
  const avg  = pos.length ? Math.round(pos.reduce((s, v) => s + v, 0) / pos.length) : 0
  const cur  = vals.at(-1) ?? 0
  const sorted = [...pos].sort((a, b) => a - b)
  const p95v = sorted.length ? (sorted[Math.floor(sorted.length * 0.95)] ?? sorted.at(-1)) : 0

  switch (metricKey) {
    case 'avg_rt': return [{ label: 'Min', val: `${min} ms` }, { label: 'Max', val: `${max} ms` }, { label: 'Avg', val: `${avg} ms` }, { label: 'P95', val: `${p95v} ms` }]
    case 'throughput': return [{ label: 'Avg', val: `${avg}` }, { label: 'Peak', val: `${max}` }]
    case 'hits': return [{ label: 'Avg', val: `${avg}` }, { label: 'Peak', val: `${max}` }]
    case 'error_rate': { const arr2 = data.error_rate || []; const totalErrors = arr2.at(-1)?.totalErrors ?? Math.round((data.requests?.at(-1)?.v ?? 0) * ((cur || 0) / 100)); return [{ label: 'Error %', val: `${cur.toFixed ? cur.toFixed(2) : cur}%` }, { label: 'Total Err', val: `${totalErrors}` }, { label: 'Failed', val: `${totalErrors}` }] }
    case 'active_vus': return [{ label: 'Active', val: `${cur}` }, { label: 'Peak', val: `${max}` }]
    case 'requests': { const rate = data.throughput?.at(-1)?.v ?? 0; const err = data.error_rate?.at(-1)?.v ?? 0; const succ = cur > 0 ? (100 - err).toFixed(1) : '0.0'; return [{ label: 'Total', val: cur > 999 ? `${(cur / 1000).toFixed(1)}K` : `${cur}` }, { label: 'Rate', val: `${rate}/s` }, { label: 'Success', val: `${succ}%` }] }
    case 'latency': { const last = arr.at(-1) ?? {}; return [{ label: 'P50', val: `${last.p50 ?? 0} ms` }, { label: 'P90', val: `${last.p90 ?? 0} ms` }, { label: 'P95', val: `${last.p95 ?? 0} ms` }, { label: 'P99', val: `${last.p99 ?? 0} ms` }] }
    case 'ux_variance': { const sp = cur; const latLast = (data.latency || []).at(-1) ?? {}; return [{ label: 'Spread', val: `${sp} ms` }, { label: 'P95', val: `${latLast.p95 ?? 0} ms` }, { label: 'Median', val: `${latLast.p50 ?? 0} ms` }] }
    default: return []
  }
}

/* ─────────── hover-reveal filter header cell ─────────── */

function FilterTh({ label, value, onChange, type, thStyle, inputStyle }) {
  const [hovered, setHovered] = useState(false)
  const [focused, setFocused] = useState(false)
  const show = hovered || focused || !!value
  return (
    <th
      style={thStyle}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {show ? (
        <input
          type={type || 'text'}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={label}
          autoFocus={hovered && !focused && !value}
          style={{ ...inputStyle, cursor: type === 'date' ? 'pointer' : 'text' }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onClick={e => e.stopPropagation()}
        />
      ) : label}
    </th>
  )
}

/* ─────────────────────── component ─────────────────────── */

export default function TestResultsPage() {
  const { t, isDark } = useTheme()
  const [searchParams, setSearchParams] = useSearchParams()

  const [runs, setRuns]             = useState([])
  const [scenarios, setScenarios]   = useState([])
  const [summaries, setSummaries]   = useState({})
  const [loading, setLoading]       = useState(true)

  const [openTabs, setOpenTabs]     = useState([])
  const [activeTab, setActiveTab]   = useState('list')
  const [tabData, setTabData]       = useState({})

  const [expandedKey,          setExpandedKey]          = useState(null)
  const [hoveredCard,          setHoveredCard]          = useState(null)
  const [showGuardianPanel,    setShowGuardianPanel]    = useState(false)
  const [ttip,                 setTtip]                 = useState({ visible: false, text: '', x: 0, y: 0 })
  const ttipRef = useRef({ visible: false, text: '' })
  const [expandedHiddenSeries, setExpandedHiddenSeries] = useState({})  // { [metricKey]: Set<string> }
  const [expandedTableMode,    setExpandedTableMode]    = useState({})  // { [metricKey]: 'api' | 'tx' }

  const [deleteConfirm, setDeleteConfirm] = useState(null)
  const [errorModal, setErrorModal]       = useState(null) // { testRunId, scriptId, scriptName }

  /* ── table filters ── */
  const [filterRunId, setFilterRunId]         = useState('')
  const [filterScenario, setFilterScenario]   = useState('')
  const [filterStartDate, setFilterStartDate] = useState('')
  const [filterEndDate, setFilterEndDate]     = useState('')

  /* ── load data ── */
  const loadRuns = useCallback(async () => {
    setLoading(true)
    try {
      const [execs, scens] = await Promise.all([listExecutions(), listScenarios()])
      setRuns(execs || [])
      setScenarios(scens || [])
      const completed = (execs || []).filter(r => r.status === 'COMPLETED' || r.status === 'FAILED' || r.status === 'ABORTED')
      const summaryResults = await Promise.all(
        completed.map(r => getExecutionSummary(r.id).catch(() => null))
      )
      const map = {}
      completed.forEach((r, i) => { if (summaryResults[i]) map[r.id] = summaryResults[i] })
      setSummaries(map)
    } catch { /* silent */ }
    setLoading(false)
  }, [])

  useEffect(() => { loadRuns() }, [loadRuns])

  /* ── auto-open tab from URL param ── */
  useEffect(() => {
    const openId = searchParams.get('open')
    if (openId && runs.length > 0) {
      openRunTab(openId)
      setSearchParams({}, { replace: true })
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runs, searchParams])

  /* ── keyframes ── */
  useEffect(() => {
    if (document.getElementById('tr-styles')) return
    const el = document.createElement('style')
    el.id = 'tr-styles'
    el.textContent = `
      @keyframes trFadeIn { from{opacity:0;transform:scale(0.975)} to{opacity:1;transform:scale(1)} }
      @keyframes trSlideDown { from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:translateY(0)} }
    `
    document.head.appendChild(el)
  }, [])

  /* ── tooltip mouse tracker ── */
  useEffect(() => {
    const onMove = e => {
      if (ttipRef.current.visible) {
        setTtip(prev => ({ ...prev, x: e.clientX, y: e.clientY }))
      }
    }
    window.addEventListener('mousemove', onMove)
    return () => window.removeEventListener('mousemove', onMove)
  }, [])

  /* ── scenario name lookup ── */
  const scenarioMap = useMemo(() => {
    const m = {}
    scenarios.forEach(s => { m[String(s.id)] = s.scenario_name })
    return m
  }, [scenarios])

  /* ── sequential run number map (sorted by start_time ascending → #1, #2 …) ── */
  const runSeqMap = useMemo(() => {
    const sorted = [...runs].sort((a, b) => new Date(a.start_time || 0) - new Date(b.start_time || 0))
    const m = {}
    sorted.forEach((r, i) => { m[r.id] = i + 1 })
    return m
  }, [runs])

  function displayRunId(id) {
    const n = runSeqMap[id]
    return n ? `${n}` : shortId(id)
  }

  /* ── filtered runs ── */
  const filteredRuns = useMemo(() => {
    let list = runs
    if (filterRunId.trim()) {
      const q = filterRunId.trim()
      list = list.filter(r => {
        const seq = runSeqMap[r.id]
        return seq && String(seq).startsWith(q)
      })
    }
    if (filterScenario.trim()) {
      const q = filterScenario.trim().toLowerCase()
      list = list.filter(r => {
        const snap = parseSnapshot(r.scenario_snapshot)
        const name = scenarioMap[r.scenario_id] || snap?.scripts?.[0]?.script_name || ''
        return name.toLowerCase().includes(q)
      })
    }
    if (filterStartDate) {
      const d = new Date(filterStartDate)
      if (!isNaN(d)) list = list.filter(r => r.start_time && new Date(r.start_time) >= d)
    }
    if (filterEndDate) {
      const d = new Date(filterEndDate)
      d.setHours(23, 59, 59, 999)
      if (!isNaN(d)) list = list.filter(r => r.end_time && new Date(r.end_time) <= d)
    }
    return list
  }, [runs, filterRunId, filterScenario, filterStartDate, filterEndDate, runSeqMap, scenarioMap])

  /* ── handlers ── */

  async function openRunTab(runId) {
    if (!openTabs.find(t => t.runId === runId)) {
      const n = runSeqMap[runId]
      setOpenTabs(prev => [...prev, { runId, label: n ? `Run ${n}` : `Run: ${shortId(runId)}` }])
    }
    setActiveTab(runId)
    setShowGuardianPanel(false)

    if (tabData[runId]) return
    setTabData(prev => ({ ...prev, [runId]: { loading: true, runInfo: null, chartData: null, perScript: {}, apiStats: {}, txStats: {}, apiGraphData: {}, txGraphData: {}, txNameMap: {}, error: null } }))
    try {
      const [runInfo, records] = await Promise.all([
        getExecution(runId),
        fetchAllTelemetry(runId),
      ])
      const chartData       = replayTelemetry(records)
      const perScript       = computePerScriptStats(records)
      const { apiStats, txStats } = computeApiTxStats(records)
      const { apiGraphData, txGraphData } = replayApiTxGraphData(records)

      // Fetch transaction names for all scripts in this run's scenario
      let txNameMap = {}
      try {
        const snapshot = runInfo?.scenario_snapshot
        const cfg = typeof snapshot === 'string' ? JSON.parse(snapshot) : (snapshot || {})
        const scriptConfigs = cfg.scripts || []
        for (const sc of scriptConfigs) {
          const sid = String(sc.script_id || '')
          if (!sid) continue
          const txs = await getScriptTransactions(sid).catch(() => [])
          for (const tx of txs) {
            txNameMap[`${sid}:${tx.execution_order}`] = tx.transaction_name || `Step ${tx.execution_order}`
          }
        }
      } catch { /* non-fatal */ }

      setTabData(prev => ({ ...prev, [runId]: { loading: false, runInfo, chartData, perScript, apiStats, txStats, apiGraphData, txGraphData, txNameMap, error: null } }))
    } catch (err) {
      setTabData(prev => ({ ...prev, [runId]: { loading: false, runInfo: null, chartData: null, perScript: {}, apiStats: {}, txStats: {}, apiGraphData: {}, txGraphData: {}, txNameMap: {}, error: err.message } }))
    }
  }

  function closeTab(runId) {
    setOpenTabs(prev => prev.filter(t => t.runId !== runId))
    if (activeTab === runId) setActiveTab('list')
    setTabData(prev => { const n = { ...prev }; delete n[runId]; return n })
  }

  async function handleDelete(runId) {
    try {
      await deleteExecution(runId)
      setDeleteConfirm(null)
      closeTab(runId)
      loadRuns()
    } catch { /* silent */ }
  }

  /* ── Perfora Guardian post-test analysis ── */
  const guardianFindings = useMemo(() => {
    if (!activeTab || activeTab === 'list') return []
    const td = tabData[activeTab]
    if (!td?.chartData || td.loading) return []
    const totalVUs = (() => {
      const run  = runs.find(r => r.id === activeTab)
      const snap = run?.scenario_snapshot ? (() => { try { return JSON.parse(run.scenario_snapshot) } catch { return {} } })() : {}
      const scripts = snap?.scripts || run?.scripts || []
      return run?.total_users_target || scripts.reduce((s, sc) => s + (parseInt(sc.users) || 0), 0)
    })()
    return analyzeTestResults({
      chartData:  td.chartData,
      apiStats:   td.apiStats   || {},
      txStats:    td.txStats    || {},
      totalVUs,
    })
  }, [activeTab, tabData, runs])

  /* ── expanded overlay: per-series entries + merged chart data ── */
  const expandedSeriesData = useMemo(() => {
    const m = METRICS.find(x => x.key === expandedKey)
    if (!m?.hasPerItem || !expandedKey || activeTab === 'list') return { entries: [], mergedData: null }

    const td = tabData[activeTab]
    if (!td?.chartData) return { entries: [], mergedData: null }

    const mode = expandedTableMode[expandedKey] || 'api'
    const rawGraphData = mode === 'tx' ? (td.txGraphData || {}) : (td.apiGraphData || {})

    const keys = Object.keys(rawGraphData)
    if (!keys.length) return { entries: [], mergedData: null }

    const txNameMap = td.txNameMap || {}
    const entries = keys.slice(0, 14).map((k, i) => ({
      id:      k,
      label:   mode === 'tx' ? (txNameMap[k] || k) : k,
      color:   SERIES_PALETTE[i % SERIES_PALETTE.length],
      safeKey: `_s${i}`,
    }))

    const mainArr = td.chartData[expandedKey] || []
    const seriesMaps = {}
    for (const entry of entries) {
      const pts = rawGraphData[entry.id] || []
      const map = {}
      for (const pt of pts) map[pt.t] = pt
      seriesMaps[entry.id] = map
    }

    const mergedData = mainArr.map(pt => {
      const merged = { ...pt }
      for (const entry of entries) {
        const apiPt = seriesMaps[entry.id]?.[pt.t]
        merged[entry.safeKey] = apiPt ? (apiPt[m.perItemField] ?? null) : null
      }
      return merged
    })

    return { entries, mergedData }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expandedKey, expandedTableMode, activeTab, tabData])

  /* ── chart renderer ── */

  function renderChart(metricKey, data, expanded, extraSeries = [], hiddenSeriesSet = new Set()) {
    const m = METRICS.find(x => x.key === metricKey)
    if (!m || !data) return null
    const arr  = data[metricKey] || []
    const grid = isDark ? 'rgba(255,255,255,0.055)' : 'rgba(0,0,0,0.055)'
    const ax   = t.textFaint
    const axisProps = { tick: { fill: ax, fontSize: 10 }, axisLine: false, tickLine: false }
    const miniMargin  = { top: 2, right: 1, left: 1, bottom: 1 }
    const largeMargin = { top: 10, right: 24, left: 0, bottom: 8 }
    const margin = expanded ? largeMargin : miniMargin

    const vals = arr.map(d => d.v ?? 0).filter(v => v > 0)
    const peak = vals.length ? Math.max(...vals) : 0
    const cur  = arr.at(-1)?.v ?? 0

    const showMain    = !hiddenSeriesSet.has('_average')
    const visibleExtra = expanded ? extraSeries.filter(s => !hiddenSeriesSet.has(s.id)) : []

    const chartMove = ({ activePayload, activeLabel }) => {
      if (!activePayload?.length) return
      const text = buildTipText(activePayload, activeLabel, m.unit, m.type === 'multi-line')
      ttipRef.current = { visible: true, text }
      setTtip(prev => ({ ...prev, visible: true, text }))
    }
    const chartLeave = () => {
      ttipRef.current = { visible: false, text: '' }
      setTtip(prev => ({ ...prev, visible: false }))
    }
    const cursorLine = { stroke: m.color, strokeWidth: 1, strokeDasharray: '4 2', strokeOpacity: 0.45 }
    const hiddenTip  = <Tooltip content={() => null} cursor={cursorLine} />

    if (m.type === 'area') {
      const gid = `tr-g-${metricKey}`
      return (
        <AreaChart data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <defs><linearGradient id={gid} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={m.color} stopOpacity={expanded ? 0.22 : 0.3} /><stop offset="100%" stopColor={m.color} stopOpacity={0.01} /></linearGradient></defs>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded ? <XAxis dataKey="t" {...axisProps} label={{ value: 'Sample', fill: ax, fontSize: 9, position: 'insideBottom', offset: -2 }} /> : <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={[0, 'auto']} width={expanded ? 44 : 32} />
          {hiddenTip}
          {expanded && peak > 0 && <ReferenceLine y={peak} stroke={m.color} strokeDasharray="5 3" strokeOpacity={0.55} label={{ value: `Peak ${peak}`, fill: m.color, fontSize: 9, position: 'insideTopRight' }} />}
          {expanded && cur > 0 && cur !== peak && <ReferenceLine y={cur} stroke={m.color} strokeDasharray="2 3" strokeOpacity={0.35} label={{ value: `Now ${cur}`, fill: ax, fontSize: 9, position: 'insideBottomRight' }} />}
          {showMain && <Area type="monotone" dataKey="v" stroke={m.color} strokeWidth={expanded ? 2.5 : 1.8} fill={`url(#${gid})`} dot={false} isAnimationActive={false} />}
          {visibleExtra.map(s => (
            <Line key={s.safeKey} type="monotone" dataKey={s.safeKey} stroke={s.color} strokeWidth={1.5} dot={false} isAnimationActive={false} strokeOpacity={0.85} connectNulls />
          ))}
        </AreaChart>
      )
    }

    if (m.type === 'line') {
      return (
        <LineChart data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded ? <XAxis dataKey="t" {...axisProps} /> : <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={[0, 'auto']} width={expanded ? 44 : 32} />
          {hiddenTip}
          {expanded && peak > 0 && <ReferenceLine y={peak} stroke={m.color} strokeDasharray="5 3" strokeOpacity={0.55} label={{ value: `Peak ${peak}`, fill: m.color, fontSize: 9, position: 'insideTopRight' }} />}
          {showMain && <Line type="monotone" dataKey="v" stroke={m.color} strokeWidth={expanded ? 2.5 : 1.8} dot={false} isAnimationActive={false} />}
          {visibleExtra.map(s => (
            <Line key={s.safeKey} type="monotone" dataKey={s.safeKey} stroke={s.color} strokeWidth={1.5} dot={false} isAnimationActive={false} strokeOpacity={0.85} connectNulls />
          ))}
        </LineChart>
      )
    }

    if (m.type === 'bar') {
      const useComposed = expanded && visibleExtra.length > 0
      const ChartEl = useComposed ? ComposedChart : BarChart
      return (
        <ChartEl data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded ? <XAxis dataKey="t" {...axisProps} /> : <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={[0, 'auto']} width={expanded ? 44 : 32} />
          <Tooltip content={() => null} cursor={{ fill: m.color, fillOpacity: 0.06 }} />
          {expanded && peak > 0 && <ReferenceLine y={peak} stroke={m.color} strokeDasharray="5 3" strokeOpacity={0.55} label={{ value: `Peak`, fill: m.color, fontSize: 9, position: 'insideTopRight' }} />}
          {showMain && <Bar dataKey="v" fill={m.color} radius={[2, 2, 0, 0]} opacity={0.78} isAnimationActive={false} />}
          {visibleExtra.map(s => (
            <Line key={s.safeKey} type="monotone" dataKey={s.safeKey} stroke={s.color} strokeWidth={1.5} dot={false} isAnimationActive={false} strokeOpacity={0.85} connectNulls />
          ))}
        </ChartEl>
      )
    }

    if (m.type === 'multi-line') {
      const latKeys = expanded ? ['p50', 'p90', 'p95', 'p99'] : ['p50', 'p95', 'p99']
      const latPeak = Math.max(...arr.flatMap(d => latKeys.map(k => d[k] ?? 0)))
      const latCursor = { stroke: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.15)', strokeWidth: 1, strokeDasharray: '4 2' }
      return (
        <LineChart data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded ? <XAxis dataKey="t" {...axisProps} /> : <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={[0, 'auto']} width={expanded ? 44 : 32} />
          <Tooltip content={() => null} cursor={latCursor} />
          {expanded && latPeak > 0 && <ReferenceLine y={latPeak} stroke={LAT_COLORS.p99} strokeDasharray="5 3" strokeOpacity={0.4} label={{ value: `P99 Peak`, fill: ax, fontSize: 9, position: 'insideTopRight' }} />}
          {latKeys.map(dk => (
            <Line key={dk} type="monotone" dataKey={dk} stroke={LAT_COLORS[dk]} strokeWidth={expanded ? 2 : 1.5} dot={false} name={dk} isAnimationActive={false} />
          ))}
        </LineChart>
      )
    }
    return null
  }

  /* ── styles ── */
  const pageStyle = { minHeight: '100%', background: t.pageBg, padding: '24px 28px 32px', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', boxSizing: 'border-box' }
  const card = { background: t.bgRaised, border: `1px solid ${t.border}`, borderRadius: 12, boxShadow: t.cardShadow }

  const expandedMeta = METRICS.find(x => x.key === expandedKey)

  /* ══════════════════════ RENDER ══════════════════════ */

  return (
    <div style={pageStyle}>

      {/* Page header */}
      <div style={{ marginBottom: 16 }}>
        <h1 style={{ color: t.textPrimary, fontSize: 21, fontWeight: 700, margin: 0, letterSpacing: '-0.01em' }}>Test Results</h1>
        <p style={{ color: t.textMuted, fontSize: 13, margin: '3px 0 0' }}>View and analyze performance test execution results</p>
      </div>

      {/* ── Tab Bar ── */}
      <div style={{
        display: 'flex', alignItems: 'stretch', gap: 0,
        borderBottom: `1px solid ${t.border}`,
        marginBottom: 16,
        background: isDark ? 'rgba(255,255,255,0.015)' : 'rgba(15,23,42,0.015)',
        borderRadius: '8px 8px 0 0',
        overflow: 'hidden',
      }}>
        {/* List tab */}
        <button
          onClick={() => { setActiveTab('list'); setExpandedKey(null) }}
          style={{
            padding: '10px 20px',
            fontSize: 13, fontWeight: 600,
            color: activeTab === 'list' ? t.accent : t.textMuted,
            background: activeTab === 'list' ? (isDark ? 'rgba(99,102,241,0.08)' : 'rgba(99,102,241,0.05)') : 'transparent',
            border: 'none',
            borderBottom: activeTab === 'list' ? `2px solid ${t.accent}` : '2px solid transparent',
            cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 6,
            whiteSpace: 'nowrap',
            transition: 'all 0.15s',
          }}
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M2 4h12M2 8h12M2 12h12" /></svg>
          Test Results
        </button>

        {/* Dynamic run tabs */}
        {openTabs.map(tab => (
          <div
            key={tab.runId}
            style={{
              display: 'flex', alignItems: 'center', gap: 0,
              borderLeft: `1px solid ${t.border}`,
              background: activeTab === tab.runId ? (isDark ? 'rgba(99,102,241,0.08)' : 'rgba(99,102,241,0.05)') : 'transparent',
              borderBottom: activeTab === tab.runId ? `2px solid ${t.accent}` : '2px solid transparent',
              transition: 'all 0.15s',
            }}
          >
            <button
              onClick={() => { setActiveTab(tab.runId); setExpandedKey(null) }}
              style={{
                padding: '10px 8px 10px 16px',
                fontSize: 12, fontWeight: 600,
                color: activeTab === tab.runId ? t.accent : t.textMuted,
                background: 'transparent',
                border: 'none',
                cursor: 'pointer',
                whiteSpace: 'nowrap',
              }}
            >
              {tab.label}
            </button>
            <button
              onClick={e => { e.stopPropagation(); closeTab(tab.runId) }}
              style={{
                padding: '4px 10px 4px 4px',
                fontSize: 14,
                color: t.textFaint,
                background: 'transparent',
                border: 'none',
                cursor: 'pointer',
                lineHeight: 1,
              }}
              onMouseEnter={e => { e.currentTarget.style.color = '#ef4444' }}
              onMouseLeave={e => { e.currentTarget.style.color = t.textFaint }}
            >
              ×
            </button>
          </div>
        ))}
      </div>

      {/* ══ LIST VIEW ══ */}
      {activeTab === 'list' && (
        <div style={{ ...card, overflow: 'hidden', animation: 'trSlideDown 0.2s ease-out' }}>
          {loading ? (
            <div style={{ padding: 60, textAlign: 'center', color: t.textMuted, fontSize: 14 }}>Loading test results...</div>
          ) : runs.length === 0 ? (
            <div style={{ padding: 60, textAlign: 'center' }}>
              <div style={{ color: t.textFaint, fontSize: 48, marginBottom: 12 }}>📊</div>
              <div style={{ color: t.textMuted, fontSize: 15, fontWeight: 600, marginBottom: 4 }}>No test results yet</div>
              <div style={{ color: t.textFaint, fontSize: 13 }}>Run a load test from the Quick Test page to see results here</div>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed', minWidth: 1020 }}>
                <colgroup>
                  <col style={{ width: '10%' }} />
                  <col style={{ width: '14%' }} />
                  <col style={{ width: '12%' }} />
                  <col style={{ width: '12%' }} />
                  <col style={{ width: '7%' }} />
                  <col style={{ width: '7%' }} />
                  <col style={{ width: '8%' }} />
                  <col style={{ width: '8%' }} />
                  <col style={{ width: '8%' }} />
                  <col style={{ width: '8%' }} />
                  <col style={{ width: '6%' }} />
                </colgroup>
                <thead>
                  <tr style={{ background: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(15,23,42,0.025)' }}>
                    {(() => {
                      const thBase = {
                        padding: '10px 12px', textAlign: 'left',
                        color: t.textTertiary, fontSize: 10, fontWeight: 600,
                        textTransform: 'uppercase', letterSpacing: '0.04em',
                        borderBottom: `1px solid ${t.border}`,
                        whiteSpace: 'nowrap',
                      }
                      const fInput = {
                        width: '100%', padding: '3px 6px', fontSize: 11,
                        border: `1px solid ${t.border}`, borderRadius: 4,
                        background: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(15,23,42,0.03)',
                        color: t.textPrimary, outline: 'none', fontWeight: 500,
                      }
                      return (
                        <>
                          <FilterTh label="Run ID" value={filterRunId} onChange={setFilterRunId} thStyle={thBase} inputStyle={fInput} />
                          <FilterTh label="Scenario" value={filterScenario} onChange={setFilterScenario} thStyle={thBase} inputStyle={fInput} />
                          <FilterTh label="Start Time" value={filterStartDate} onChange={setFilterStartDate} type="date" thStyle={thBase} inputStyle={fInput} />
                          <FilterTh label="End Time" value={filterEndDate} onChange={setFilterEndDate} type="date" thStyle={thBase} inputStyle={fInput} />
                          {['Scripts', 'VUsers', 'Total TPH', 'Avg RT', 'UX Var', 'Status', ''].map(h => (
                            <th key={h} style={thBase}>{h}</th>
                          ))}
                        </>
                      )
                    })()}
                  </tr>
                </thead>
                <tbody>
                  {filteredRuns.map((run, i) => {
                    const snap = parseSnapshot(run.scenario_snapshot)
                    const scenName = scenarioMap[run.scenario_id] || snap?.scripts?.[0]?.script_name || `Scenario #${run.scenario_id || '?'}`
                    const scripts = snap?.scripts || []
                    const totalVUs = run.total_users_target || scripts.reduce((s, sc) => s + (parseInt(sc.users) || 0), 0)
                    const sum = summaries[run.id]
                    const st = mapStatus(run.status)
                    const statusClr = st.color

                    return (
                      <tr
                        key={run.id}
                        style={{
                          background: i % 2 === 1 ? (isDark ? 'rgba(255,255,255,0.015)' : 'rgba(15,23,42,0.012)') : 'transparent',
                          cursor: 'pointer',
                          transition: 'background 0.1s',
                        }}
                        onClick={() => openRunTab(run.id)}
                        onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.06)' : 'rgba(99,102,241,0.04)' }}
                        onMouseLeave={e => { e.currentTarget.style.background = i % 2 === 1 ? (isDark ? 'rgba(255,255,255,0.015)' : 'rgba(15,23,42,0.012)') : 'transparent' }}
                      >
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.accent, fontSize: 12, fontWeight: 600, fontFamily: 'monospace' }}>{displayRunId(run.id)}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textPrimary, fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{scenName}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 11 }}>{fmtLocalDate(run.start_time)}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 11 }}>{fmtLocalDate(run.end_time)}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, textAlign: 'center' }}>
                          <span style={{ background: isDark ? 'rgba(99,102,241,0.12)' : 'rgba(99,102,241,0.08)', color: t.accent, fontSize: 11, fontWeight: 600, borderRadius: 10, padding: '2px 8px' }}>{scripts.length}</span>
                        </td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, textAlign: 'center', fontWeight: 600 }}>{totalVUs}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{sum ? sum.tph.toLocaleString() : '—'}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{sum ? `${sum.avg_rt} ms` : '—'}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{sum ? `${sum.ux_variance} ms` : '—'}</td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}` }}>
                          <span style={{
                            display: 'inline-flex', alignItems: 'center', gap: 5,
                            fontSize: 10, fontWeight: 600, color: statusClr,
                            background: statusClr + '18', border: `1px solid ${statusClr}35`,
                            borderRadius: 5, padding: '2px 8px',
                          }}>
                            <span style={{ width: 5, height: 5, borderRadius: '50%', background: statusClr }} />
                            {st.label}
                          </span>
                        </td>
                        <td style={{ padding: '10px 12px', borderBottom: `1px solid ${t.border}`, textAlign: 'center' }}>
                          <button
                            onClick={e => { e.stopPropagation(); setDeleteConfirm(run.id) }}
                            style={{
                              background: 'transparent', border: 'none', cursor: 'pointer',
                              color: t.textFaint, padding: 4, borderRadius: 4,
                              transition: 'color 0.15s',
                            }}
                            onMouseEnter={e => { e.currentTarget.style.color = '#ef4444' }}
                            onMouseLeave={e => { e.currentTarget.style.color = t.textFaint }}
                          >
                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M2 4h12M5 4V2.5A.5.5 0 015.5 2h5a.5.5 0 01.5.5V4M6 7v4M10 7v4M3.5 4l.7 9.1a1 1 0 001 .9h5.6a1 1 0 001-.9L12.5 4" /></svg>
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ══ RUN DETAIL VIEW ══ */}
      {activeTab !== 'list' && (() => {
        const td = tabData[activeTab]
        const run = runs.find(r => r.id === activeTab)
        if (!td || td.loading) {
          return (
            <div style={{ ...card, padding: 60, textAlign: 'center', animation: 'trSlideDown 0.2s ease-out' }}>
              <div style={{ color: t.textMuted, fontSize: 14 }}>Loading test results...</div>
              <div style={{ marginTop: 12 }}>
                <div style={{ width: 40, height: 40, border: `3px solid ${t.border}`, borderTopColor: t.accent, borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto' }} />
              </div>
              <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
            </div>
          )
        }
        if (td.error) {
          return <div style={{ ...card, padding: 40, textAlign: 'center', color: '#ef4444', fontSize: 14 }}>Error loading results: {td.error}</div>
        }

        const { runInfo, chartData, perScript = {} } = td
        const snap = parseSnapshot(runInfo?.scenario_snapshot)
        const scenName = scenarioMap[runInfo?.scenario_id] || snap?.scripts?.[0]?.script_name || 'Unknown Scenario'
        const scripts = snap?.scripts || runInfo?.scripts || []
        const totalVUs = runInfo?.total_users_target || scripts.reduce((s, sc) => s + (parseInt(sc.users) || 0), 0)
        const rampUpSecs    = runInfo?.ramp_up_secs    || 0
        const steadySecs    = runInfo?.planned_duration_secs || runInfo?.duration_secs || 0
        const rampDownSecs  = runInfo?.ramp_down_secs  || 0
        const totalDurSecs  = rampUpSecs + steadySecs + rampDownSecs
        const sum = summaries[activeTab] || {}

        return (
          <div style={{ animation: 'trSlideDown 0.2s ease-out' }}>

            {/* Run header */}
            <div style={{ ...card, padding: '14px 20px', marginBottom: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Run ID</div>
                  <div style={{ color: t.accent, fontSize: 13, fontWeight: 700, fontFamily: 'monospace' }}>{displayRunId(activeTab)}</div>
                </div>
                <div style={{ width: 1, height: 30, background: t.border }} />
                <div>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Scenario</div>
                  <div style={{ color: t.textPrimary, fontSize: 13, fontWeight: 600 }}>{scenName}</div>
                </div>
                <div style={{ width: 1, height: 30, background: t.border }} />
                <div>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Ramp-up</div>
                  <div style={{ color: t.textSecondary, fontSize: 13 }}>{fmtSecs(rampUpSecs)}</div>
                </div>
                <div style={{ width: 1, height: 30, background: t.border }} />
                <div>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Steady State</div>
                  <div style={{ color: t.textSecondary, fontSize: 13 }}>{fmtSecs(steadySecs)}</div>
                </div>
                <div style={{ width: 1, height: 30, background: t.border }} />
                <div>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Ramp-down</div>
                  <div style={{ color: t.textSecondary, fontSize: 13 }}>{fmtSecs(rampDownSecs)}</div>
                </div>
                <div style={{ width: 1, height: 30, background: t.border }} />
                <div>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>VUsers</div>
                  <div style={{ color: t.textSecondary, fontSize: 13, fontWeight: 600 }}>{totalVUs}</div>
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                {(() => {
                  const st2 = mapStatus(runInfo?.status)
                  return (
                    <span style={{
                      display: 'inline-flex', alignItems: 'center', gap: 5,
                      fontSize: 11, fontWeight: 600,
                      color: st2.color,
                      background: st2.color + '18',
                      border: `1px solid ${st2.color}35`,
                      borderRadius: 6, padding: '4px 12px',
                    }}>
                      <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'currentColor' }} />
                      {st2.label}
                    </span>
                  )
                })()}
                {/* Perfora Guardian button */}
                {guardianFindings.length > 0 && (() => {
                  const crit = guardianFindings.filter(f => f.severity === 'critical').length
                  const warn = guardianFindings.filter(f => f.severity === 'warning').length
                  const badgeColor = crit > 0 ? '#ef4444' : warn > 0 ? '#f59e0b' : '#22c55e'
                  return (
                    <button
                      onClick={() => setShowGuardianPanel(true)}
                      style={{
                        display: 'inline-flex', alignItems: 'center', gap: 7,
                        background: isDark ? 'rgba(99,102,241,0.1)' : 'rgba(99,102,241,0.07)',
                        border: `1px solid ${t.accent}40`,
                        borderRadius: 8, padding: '7px 14px',
                        color: t.accent, fontSize: 12, fontWeight: 600,
                        cursor: 'pointer', transition: 'background 0.15s, border-color 0.15s',
                        whiteSpace: 'nowrap',
                      }}
                      onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.18)' : 'rgba(99,102,241,0.13)'; e.currentTarget.style.borderColor = t.accent + '70' }}
                      onMouseLeave={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.1)' : 'rgba(99,102,241,0.07)'; e.currentTarget.style.borderColor = t.accent + '40' }}
                      title="View Perfora Guardian post-test analysis and recommendations"
                    >
                      <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                        <path d="M5.5 8l1.8 1.8L10.5 6" />
                      </svg>
                      Perfora Guardian
                      <span style={{
                        minWidth: 18, height: 18, borderRadius: 9, padding: '0 5px',
                        background: badgeColor, color: '#fff',
                        fontSize: 10, fontWeight: 800,
                        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      }}>{guardianFindings.length}</span>
                    </button>
                  )
                })()}
              </div>
            </div>

            {/* Status panel — Quick Test format */}
            <div style={{ ...card, marginBottom: 14, overflow: 'hidden' }}>
              {/* Header stats strip */}
              <div style={{
                display: 'flex', gap: 0,
                borderBottom: `1px solid ${t.border}`,
                background: isDark ? 'rgba(255,255,255,0.02)' : 'rgba(15,23,42,0.02)',
              }}>
                {/* Merged: Run ID · Start Time · End Time */}
                <div style={{ flex: 2, padding: '11px 16px', borderRight: `1px solid ${t.border}` }}>
                  <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start', justifyContent: 'space-between' }}>
                    {[
                      { lbl: 'Run ID',     val: displayRunId(activeTab), mono: true },
                      { lbl: 'Start Time', val: fmtLocalTime(runInfo?.start_time) },
                      { lbl: 'End Time',   val: fmtLocalTime(runInfo?.end_time) },
                    ].map(item => (
                      <div key={item.lbl} style={{ flex: 1 }}>
                        <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3, whiteSpace: 'nowrap' }}>{item.lbl}</div>
                        <div style={{ fontSize: 13, fontWeight: 700, fontVariantNumeric: 'tabular-nums', fontFamily: item.mono ? 'monospace' : 'inherit', color: item.mono ? t.accent : t.textPrimary, whiteSpace: 'nowrap' }}>{item.val}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Total Duration cell */}
                <div style={{ flex: 1, padding: '11px 16px', textAlign: 'center', borderRight: `1px solid ${t.border}` }}>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>Total Duration</div>
                  <div style={{ fontSize: 15, fontWeight: 700, fontVariantNumeric: 'tabular-nums', color: t.textPrimary }}>
                    {totalDurSecs > 0 ? fmtHHMMSS(totalDurSecs) : '—'}
                  </div>
                </div>

                {/* Remaining standard stat cells */}
                {[
                  { label: 'Total VUs',    val: totalVUs },
                  { label: 'Requests',     val: (sum.total_requests || 0).toLocaleString() },
                  { label: 'Avg RT',       val: `${sum.avg_rt || 0} ms` },
                  { label: 'Total Errors', val: sum.total_errors || 0, isErr: (sum.total_errors || 0) > 0 },
                ].map(s => (
                  <div key={s.label} style={{ flex: 1, padding: '11px 16px', textAlign: 'center', borderRight: `1px solid ${t.border}` }}>
                    <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>{s.label}</div>
                    <div style={{ fontSize: 15, fontWeight: 700, fontVariantNumeric: 'tabular-nums', color: s.isErr ? '#ef4444' : t.textPrimary }}>{s.val}</div>
                  </div>
                ))}

                {/* Test Phase — just status, no sub-line */}
                <div style={{ flex: 1, padding: '11px 16px', textAlign: 'center' }}>
                  <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>Test Phase</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: '#22c55e' }}>Completed</div>
                </div>
              </div>

              {/* Script table — grouped VUsers / Transactions format */}
              {scripts.length > 0 && (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed', minWidth: 900 }}>
                    <colgroup>
                      <col style={{ width: '18%' }} />
                      <col style={{ width: '7%' }} /><col style={{ width: '7%' }} /><col style={{ width: '7%' }} /><col style={{ width: '7%' }} />
                      <col style={{ width: '9%' }} /><col style={{ width: '7%' }} /><col style={{ width: '8%' }} /><col style={{ width: '10%' }} /><col style={{ width: '10%' }} />
                    </colgroup>
                    <thead>
                      <tr style={{ background: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)' }}>
                        <th rowSpan={2} style={{ padding: '8px 12px', textAlign: 'left', color: t.textTertiary, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', borderBottom: `1px solid ${t.border}`, borderRight: `1px solid ${t.border}`, whiteSpace: 'nowrap', verticalAlign: 'bottom' }}>Script Name</th>
                        <th colSpan={4} style={{ padding: '6px 12px', textAlign: 'center', color: '#3b82f6', fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: `1px solid ${t.border}`, borderRight: `1px solid ${t.border}`, background: isDark ? 'rgba(59,130,246,0.07)' : 'rgba(59,130,246,0.05)' }}>Virtual Users</th>
                        <th colSpan={5} style={{ padding: '6px 12px', textAlign: 'center', color: '#22c55e', fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: `1px solid ${t.border}`, background: isDark ? 'rgba(34,197,94,0.07)' : 'rgba(34,197,94,0.05)' }}>Transactions</th>
                      </tr>
                      <tr style={{ background: isDark ? 'rgba(255,255,255,0.025)' : 'rgba(15,23,42,0.025)' }}>
                        {[
                          { lbl: 'Target', grp: 'vu' }, { lbl: 'Running', grp: 'vu' }, { lbl: 'Pending', grp: 'vu' }, { lbl: 'Failed', grp: 'vu', last: true },
                          { lbl: 'Passed', grp: 'tx' }, { lbl: 'Failed', grp: 'tx' }, { lbl: 'TPS', grp: 'tx' }, { lbl: 'Avg RT', grp: 'tx' }, { lbl: 'Max RT', grp: 'tx' },
                        ].map(h => (
                          <th key={`${h.grp}-${h.lbl}`} style={{ padding: '6px 12px', textAlign: 'left', color: t.textTertiary, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', borderBottom: `1px solid ${t.border}`, borderRight: h.last ? `1px solid ${t.border}` : 'none', whiteSpace: 'nowrap' }}>{h.lbl}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {scripts.map((sc, i) => {
                        const sid = String(sc.script_id || sc.id || '')
                        const ps  = perScript[sid] || {}
                        return (
                          <tr key={i} style={{ background: i % 2 === 1 ? (isDark ? 'rgba(255,255,255,0.015)' : 'rgba(15,23,42,0.01)') : 'transparent' }}>
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, borderRight: `1px solid ${t.border}`, color: t.textPrimary, fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{sc.script_name || 'Script'}</td>
                            {/* VUsers — test complete so running/pending/failed = 0 */}
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{sc.users || 1}</td>
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textMuted, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>0</td>
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textMuted, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>0</td>
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, borderRight: `1px solid ${t.border}`, color: t.textMuted, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>0</td>
                            {/* Transactions */}
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: '#22c55e', fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{(ps.passed ?? 0).toLocaleString()}</td>
                            <td
                              style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: (ps.failed ?? 0) > 0 ? '#ef4444' : t.textMuted, fontSize: 12, fontVariantNumeric: 'tabular-nums', cursor: (ps.failed ?? 0) > 0 ? 'pointer' : 'default', textDecoration: (ps.failed ?? 0) > 0 ? 'underline' : 'none' }}
                              onClick={() => (ps.failed ?? 0) > 0 && setErrorModal({ testRunId: activeTab, scriptId: sid, scriptName: sc.script_name || 'Script' })}
                              title={(ps.failed ?? 0) > 0 ? 'Click to view error details' : ''}
                            >{ps.failed ?? 0}</td>
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.accent, fontSize: 12, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{ps.tps ?? 0}</td>
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{ps.avgRt != null ? `${ps.avgRt} ms` : '—'}</td>
                            <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{ps.maxRt != null ? `${ps.maxRt} ms` : '—'}</td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Metric cards grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              {METRICS.map(m => {
                const stats   = getCardStats(m.key, chartData)
                const dispVal = (() => {
                  const arr = chartData[m.key] || []
                  if (!arr.length) return '0'
                  if (m.key === 'error_rate') { const v = arr.at(-1)?.v ?? 0; return v.toFixed ? v.toFixed(2) : String(v) }
                  if (m.key === 'requests')   { const v = arr.at(-1)?.v ?? 0; return v > 999 ? `${(v / 1000).toFixed(1)}K` : String(Math.round(v)) }
                  if (m.key === 'active_vus') { return String(Math.round(arr.at(-1)?.v ?? 0)) }
                  if (m.key === 'latency') {
                    const p50s = arr.map(d => d.p50 ?? 0).filter(v => v > 0)
                    return p50s.length ? String(Math.round(p50s.reduce((s, v) => s + v, 0) / p50s.length)) : '0'
                  }
                  const nonZero = arr.map(d => d.v ?? 0).filter(v => v > 0)
                  return nonZero.length ? String(Math.round(nonZero.reduce((s, v) => s + v, 0) / nonZero.length)) : '0'
                })()
                const isHov = hoveredCard === m.key

                return (
                  <div
                    key={m.key}
                    style={{
                      background: t.bgRaised,
                      border: `1px solid ${isHov ? m.color + '55' : t.border}`,
                      borderRadius: 11, overflow: 'hidden', cursor: 'pointer',
                      boxShadow: isHov
                        ? isDark ? `0 0 0 1px ${m.color}25, 0 6px 20px rgba(0,0,0,0.35)` : `0 0 0 1px ${m.color}20, 0 4px 14px rgba(0,0,0,0.09)`
                        : t.cardShadow,
                      transition: 'border-color 0.15s, box-shadow 0.15s',
                    }}
                    onMouseEnter={() => setHoveredCard(m.key)}
                    onMouseLeave={() => setHoveredCard(null)}
                    onClick={() => setExpandedKey(m.key)}
                  >
                    <div style={{ padding: '10px 12px 4px', display: 'flex', alignItems: 'center', gap: 5 }}>
                      <span style={{ width: 6, height: 6, borderRadius: '50%', background: m.color, flexShrink: 0 }} />
                      <span style={{ color: t.textTertiary, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{m.label}</span>
                    </div>
                    <div style={{ padding: '2px 12px 5px', display: 'flex', alignItems: 'baseline', gap: 5 }}>
                      <span style={{ color: t.textPrimary, fontSize: m.key === 'latency' ? 17 : 20, fontWeight: 700, fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{dispVal}</span>
                      {m.unit && !['latency','ux_variance','error_rate','requests','active_vus'].includes(m.key) && <span style={{ color: t.textFaint, fontSize: 10 }}>avg {m.unit}</span>}
                      {['error_rate','requests','active_vus'].includes(m.key) && m.unit && <span style={{ color: t.textFaint, fontSize: 10 }}>{m.unit}</span>}
                      {m.key === 'latency' && <span style={{ color: t.textFaint, fontSize: 9 }}>ms (avg p50)</span>}
                      {m.key === 'ux_variance' && <span style={{ color: t.textFaint, fontSize: 9 }}>ms avg · P95 − P50</span>}
                    </div>
                    <div style={{ height: 82 }}>
                      <ResponsiveContainer width="100%" height="100%">
                        {renderChart(m.key, chartData, false)}
                      </ResponsiveContainer>
                    </div>
                    <div style={{
                      borderTop: `1px solid ${t.border}`, padding: '5px 12px', display: 'flex', gap: 0,
                      background: isDark ? 'rgba(0,0,0,0.12)' : 'rgba(15,23,42,0.018)',
                    }}>
                      {stats.map((s, i) => (
                        <div key={s.label} style={{
                          flex: 1, textAlign: i === 0 ? 'left' : 'center',
                          borderRight: i < stats.length - 1 ? `1px solid ${t.border}` : 'none',
                          paddingRight: i < stats.length - 1 ? 6 : 0, paddingLeft: i > 0 ? 6 : 0,
                        }}>
                          <div style={{ color: t.textFaint, fontSize: 9, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.03em' }}>{s.label}</div>
                          <div style={{ color: t.textSecondary, fontSize: 11, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{s.val}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>

            <p style={{ color: t.textFaint, fontSize: 11, textAlign: 'center', marginTop: 8, marginBottom: 0 }}>
              Click any metric card to expand · Test completed: {fmtLocalDate(runInfo?.end_time)}
            </p>

            {/* ══ PERFORMANCE BREAKDOWN TABLE ══ */}
            {Object.keys(td.apiStats || {}).length > 0 && (() => {
              const txRows = Object.entries(td.txNameMap || {})
                .map(([key, name]) => ({ key, name }))
                .sort((a, b) => {
                  const [, sa] = a.key.split(':'); const [, sb] = b.key.split(':')
                  return (parseInt(sa) || 0) - (parseInt(sb) || 0)
                })
              return (
                <PerformanceTable
                  apiStats={td.apiStats}
                  txStats={td.txStats}
                  txRows={txRows}
                  theme={t}
                  isDark={isDark}
                />
              )
            })()}
          </div>
        )
      })()}

      {/* ══ EXPANDED OVERLAY ══ */}
      {expandedKey && expandedMeta && activeTab !== 'list' && tabData[activeTab]?.chartData && createPortal(
        <div
          style={{
            position: 'fixed', inset: 0,
            background: isDark ? 'rgba(0,0,0,0.75)' : 'rgba(0,0,0,0.5)',
            backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)',
            zIndex: 9000, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
          onClick={e => { if (e.target === e.currentTarget) setExpandedKey(null) }}
        >
          {(() => {
            const td = tabData[activeTab]
            const { entries: seriesEntries, mergedData } = expandedSeriesData
            const hiddenSet   = expandedHiddenSeries[expandedKey] || new Set()
            const tableMode   = expandedTableMode[expandedKey] || 'api'
            const hasSeries   = expandedMeta.hasPerItem && seriesEntries.length > 0
            const chartData_  = hasSeries && mergedData
              ? { ...td.chartData, [expandedKey]: mergedData }
              : td.chartData

            const statsSource = tableMode === 'tx' ? td.txStats : td.apiStats
            const graphSource = tableMode === 'tx' ? td.txGraphData : td.apiGraphData

            const allIds     = ['_average', ...seriesEntries.map(s => s.id)]
            const allVisible = allIds.every(id => !hiddenSet.has(id))
            const someHidden = allIds.some(id => hiddenSet.has(id))

            const mainVals = (td.chartData[expandedKey] || []).map(d => d.v ?? 0).filter(v => v > 0)
            const mainAvg  = mainVals.length ? Math.round(mainVals.reduce((s, v) => s + v, 0) / mainVals.length) : 0
            const mainMin  = mainVals.length ? Math.min(...mainVals) : 0
            const mainMax  = mainVals.length ? Math.max(...mainVals) : 0

            const totalReqs   = Object.values(td.apiStats || {}).reduce((s, v) => s + (v.pass || 0) + (v.fail || 0), 0)
            const totalErrors = Object.values(td.apiStats || {}).reduce((s, v) => s + (v.fail || 0), 0)

            const thCell = (right = false) => ({
              padding: '7px 10px', textAlign: right ? 'right' : 'left',
              color: t.textTertiary, fontSize: 10, fontWeight: 700,
              textTransform: 'uppercase', letterSpacing: '0.05em',
              borderBottom: `1px solid ${t.border}`, whiteSpace: 'nowrap',
              background: isDark ? 'rgba(255,255,255,0.025)' : 'rgba(15,23,42,0.025)',
            })
            const tdCell = (right = false, fail = false, val = 0) => ({
              padding: '6px 10px', textAlign: right ? 'right' : 'left',
              fontSize: 12, fontVariantNumeric: 'tabular-nums',
              color: fail && val > 0 ? '#ef4444' : right ? t.textSecondary : t.textPrimary,
              borderBottom: `1px solid ${isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)'}`,
              whiteSpace: 'nowrap',
            })

            return (
              <div style={{
                background: t.bgRaised, border: `1px solid ${expandedMeta.color}45`,
                borderRadius: 16, padding: '20px 24px 16px',
                width: '88vw', maxWidth: 1040,
                maxHeight: '92vh', overflowY: 'auto',
                boxShadow: isDark
                  ? `0 0 0 1px ${expandedMeta.color}18, 0 32px 80px rgba(0,0,0,0.72)`
                  : `0 0 0 1px ${expandedMeta.color}18, 0 20px 56px rgba(0,0,0,0.2)`,
                animation: 'trFadeIn 0.18s ease-out', position: 'relative',
              }}>
                <button
                  onClick={() => setExpandedKey(null)}
                  style={{
                    position: 'sticky', top: 0, float: 'right',
                    width: 30, height: 30, borderRadius: 8,
                    border: `1px solid ${t.border}`, background: t.bgInput,
                    color: t.textMuted, cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 16, lineHeight: 1, transition: 'background 0.15s, color 0.15s', zIndex: 2,
                    marginBottom: -30,
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(239,68,68,0.15)' : 'rgba(239,68,68,0.08)'; e.currentTarget.style.color = '#ef4444' }}
                  onMouseLeave={e => { e.currentTarget.style.background = t.bgInput; e.currentTarget.style.color = t.textMuted }}
                >✕</button>

                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14, paddingRight: 36 }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                      <span style={{ width: 9, height: 9, borderRadius: '50%', background: expandedMeta.color, boxShadow: `0 0 8px ${expandedMeta.color}` }} />
                      <span style={{ color: t.textPrimary, fontSize: 17, fontWeight: 700 }}>{expandedMeta.label}</span>
                    </div>
                    <span style={{ color: t.textFaint, fontSize: 11 }}>
                      Click ✕ or backdrop to close · {td.chartData[expandedKey]?.length ?? 0} samples
                    </span>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: 20 }}>
                    <div style={{
                      color: t.textPrimary,
                      fontSize: expandedMeta.key === 'latency' ? 20 : 34,
                      fontWeight: 800, fontVariantNumeric: 'tabular-nums', lineHeight: 1, letterSpacing: '-0.02em',
                    }}>
                      {(() => {
                        const arr = td.chartData[expandedKey] || []
                        if (!arr.length) return '0'
                        if (expandedMeta.key === 'error_rate') { const v = arr.at(-1)?.v ?? 0; return `${v.toFixed ? v.toFixed(2) : v}%` }
                        if (expandedMeta.key === 'requests')   { const v = arr.at(-1)?.v ?? 0; return v > 999 ? `${(v / 1000).toFixed(1)}K` : String(Math.round(v)) }
                        if (expandedMeta.key === 'active_vus') { return String(Math.round(arr.at(-1)?.v ?? 0)) }
                        if (expandedMeta.key === 'latency') {
                          const avgOf = key => { const s = arr.map(d => d[key] ?? 0).filter(v => v > 0); return s.length ? Math.round(s.reduce((a,v)=>a+v,0)/s.length) : 0 }
                          return `P50: ${avgOf('p50')} / P95: ${avgOf('p95')}`
                        }
                        const nz = arr.map(d => d.v ?? 0).filter(v => v > 0)
                        const avg = nz.length ? Math.round(nz.reduce((s,v)=>s+v,0)/nz.length) : 0
                        if (expandedMeta.key === 'ux_variance') return `${avg} ms`
                        return String(avg)
                      })()}
                    </div>
                    {expandedMeta.unit && !['latency','ux_variance','error_rate','requests','active_vus'].includes(expandedMeta.key) && (
                      <div style={{ color: t.textMuted, fontSize: 12, marginTop: 2 }}>avg {expandedMeta.unit}</div>
                    )}
                    {['error_rate','requests','active_vus'].includes(expandedMeta.key) && expandedMeta.unit && (
                      <div style={{ color: t.textMuted, fontSize: 12, marginTop: 2 }}>{expandedMeta.unit}</div>
                    )}
                    {expandedMeta.key === 'ux_variance' && <div style={{ color: t.textMuted, fontSize: 11, marginTop: 3 }}>avg P95 − P50 spread</div>}
                    {expandedMeta.key === 'latency' && (
                      <div style={{ display: 'flex', gap: 10, marginTop: 6, justifyContent: 'flex-end' }}>
                        {Object.entries(LAT_COLORS).map(([k, c]) => (
                          <span key={k} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: t.textMuted }}>
                            <span style={{ width: 16, height: 2.5, borderRadius: 2, background: c, display: 'inline-block' }} />
                            {k.toUpperCase()}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Full chart */}
                <div style={{ height: 340 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    {renderChart(expandedKey, chartData_, true, seriesEntries, hiddenSet)}
                  </ResponsiveContainer>
                </div>

                {/* Bottom stats row */}
                <div style={{ display: 'flex', gap: 0, marginTop: 12, borderTop: `1px solid ${t.border}`, paddingTop: 12 }}>
                  {getCardStats(expandedKey, td.chartData).map((s, i, arr) => (
                    <div key={s.label} style={{
                      flex: 1, textAlign: 'center',
                      borderRight: i < arr.length - 1 ? `1px solid ${t.border}` : 'none',
                      paddingRight: 12, paddingLeft: i > 0 ? 12 : 0,
                    }}>
                      <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 3 }}>{s.label}</div>
                      <div style={{ color: t.textPrimary, fontSize: 14, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{s.val}</div>
                    </div>
                  ))}
                </div>

                {/* ── Transaction/API breakdown table with checkboxes ── */}
                {hasSeries && (() => {
                  const tableDef = TABLE_DEFS[expandedKey]
                  if (!tableDef) return null

                  const allMainPts = td.chartData[expandedKey] || []
                  const lastVal    = allMainPts.at(-1)?.v ?? 0
                  const nonZeroV   = allMainPts.map(d => d.v ?? 0).filter(v => v > 0)

                  const avgVals = tableDef.avgRow(nonZeroV, totalReqs || null, totalErrors || null, lastVal)

                  const tableRows = [{
                    id: '_average', label: 'Average (All)', color: expandedMeta.color, vals: avgVals,
                  }, ...seriesEntries.map(s => {
                    const st   = statsSource?.[s.id]
                    const gpts = graphSource?.[s.id] || []
                    return { id: s.id, label: s.label, color: s.color, vals: tableDef.seriesRow(st, gpts) }
                  })]

                  return (
                    <div style={{ marginTop: 18, borderTop: `1px solid ${t.border}`, paddingTop: 14 }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                        <span style={{ color: t.textMuted, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                          Transaction Summary
                        </span>
                        <div style={{
                          display: 'flex', gap: 3,
                          background: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)',
                          borderRadius: 7, padding: '3px 4px', border: `1px solid ${t.border}`,
                        }}>
                          {[['api', 'API Wise'], ['tx', 'Transaction Wise']].map(([mode, label]) => (
                            <button
                              key={mode}
                              onClick={() => setExpandedTableMode(prev => ({ ...prev, [expandedKey]: mode }))}
                              style={{
                                padding: '4px 13px', fontSize: 11, fontWeight: 600,
                                border: 'none', borderRadius: 5, cursor: 'pointer',
                                background: tableMode === mode
                                  ? (isDark ? 'rgba(99,102,241,0.22)' : 'rgba(99,102,241,0.12)')
                                  : 'transparent',
                                color: tableMode === mode ? t.accent : t.textMuted,
                                transition: 'background 0.15s, color 0.15s',
                              }}
                            >{label}</button>
                          ))}
                        </div>
                      </div>

                      <div style={{ overflowX: 'auto', borderRadius: 8, border: `1px solid ${t.border}` }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 560 }}>
                          <thead>
                            <tr>
                              <th style={thCell(false)}>
                                <label style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', userSelect: 'none' }}>
                                  <input
                                    type="checkbox"
                                    checked={allVisible}
                                    ref={el => { if (el) el.indeterminate = someHidden && !allIds.every(id => hiddenSet.has(id)) }}
                                    onChange={() => {
                                      setExpandedHiddenSeries(prev => ({
                                        ...prev,
                                        [expandedKey]: allVisible ? new Set(allIds) : new Set(),
                                      }))
                                    }}
                                    style={{ cursor: 'pointer', accentColor: t.accent }}
                                  />
                                  Series
                                </label>
                              </th>
                              {tableDef.cols.map((col, ci) => (
                                <th key={ci} style={thCell(true)}>{col.label}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {tableRows.map((row, ri) => {
                              const isHidden = hiddenSet.has(row.id)
                              return (
                                <tr
                                  key={row.id}
                                  style={{
                                    background: ri % 2 === 0 ? 'transparent' : (isDark ? 'rgba(255,255,255,0.018)' : 'rgba(15,23,42,0.018)'),
                                    opacity: isHidden ? 0.4 : 1, transition: 'opacity 0.15s, background 0.1s',
                                  }}
                                  onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.07)' : 'rgba(99,102,241,0.045)' }}
                                  onMouseLeave={e => { e.currentTarget.style.background = ri % 2 === 0 ? 'transparent' : (isDark ? 'rgba(255,255,255,0.018)' : 'rgba(15,23,42,0.018)') }}
                                >
                                  <td style={{ ...tdCell(false), maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                    <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', userSelect: 'none' }}>
                                      <input
                                        type="checkbox"
                                        checked={!isHidden}
                                        onChange={() => {
                                          setExpandedHiddenSeries(prev => {
                                            const next = new Set(prev[expandedKey] || [])
                                            if (next.has(row.id)) next.delete(row.id)
                                            else next.add(row.id)
                                            return { ...prev, [expandedKey]: next }
                                          })
                                        }}
                                        style={{ cursor: 'pointer', accentColor: row.color, flexShrink: 0 }}
                                      />
                                      <span style={{ width: 10, height: 10, borderRadius: '50%', background: row.color, flexShrink: 0, display: 'inline-block', boxShadow: `0 0 4px ${row.color}88` }} />
                                      <span title={row.label} style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: t.textPrimary, fontSize: 12 }}>{row.label}</span>
                                    </label>
                                  </td>
                                  {tableDef.cols.map((col, ci) => {
                                    const cellVal = row.vals[ci]
                                    return (
                                      <td key={ci} style={tdCell(true, col.isFail, parseFloat(cellVal) || 0)}>
                                        {cellVal != null ? cellVal : '—'}
                                      </td>
                                    )
                                  })}
                                </tr>
                              )
                            })}
                          </tbody>
                        </table>
                      </div>
                      <p style={{ color: t.textFaint, fontSize: 10, marginTop: 6, marginBottom: 0, textAlign: 'right' }}>
                        Toggle checkboxes to show / hide individual series on the graph above
                      </p>
                    </div>
                  )
                })()}
              </div>
            )
          })()}
        </div>,
        document.body
      )}

      {/* ══ TOOLTIP ══ */}
      {ttip.visible && ttip.text && createPortal(
        <div style={{
          position: 'fixed', left: ttip.x + 14, top: ttip.y - 10,
          background: 'rgba(15,15,20,0.82)', color: '#fff',
          fontSize: 11, fontWeight: 600, padding: '3px 9px',
          borderRadius: 5, whiteSpace: 'nowrap', pointerEvents: 'none',
          letterSpacing: '0.01em', lineHeight: 1.6, zIndex: 99999,
          boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
        }}>{ttip.text}</div>,
        document.body
      )}

      {/* ══ DELETE CONFIRMATION ══ */}
      {deleteConfirm && createPortal(
        <div
          style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
            backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)',
            zIndex: 9500, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
          onClick={e => { if (e.target === e.currentTarget) setDeleteConfirm(null) }}
        >
          <div style={{
            background: t.bgRaised, border: `1px solid ${t.border}`,
            borderRadius: 14, padding: '24px 28px', width: 380,
            boxShadow: '0 20px 60px rgba(0,0,0,0.35)',
            animation: 'trFadeIn 0.15s ease-out',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(239,68,68,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="#ef4444" strokeWidth="1.5"><path d="M2 4h12M5 4V2.5A.5.5 0 015.5 2h5a.5.5 0 01.5.5V4M6 7v4M10 7v4M3.5 4l.7 9.1a1 1 0 001 .9h5.6a1 1 0 001-.9L12.5 4" /></svg>
              </div>
              <div>
                <div style={{ color: t.textPrimary, fontSize: 15, fontWeight: 700 }}>Delete Test Run</div>
                <div style={{ color: t.textMuted, fontSize: 12, marginTop: 1 }}>This action cannot be undone</div>
              </div>
            </div>
            <p style={{ color: t.textSecondary, fontSize: 13, margin: '0 0 20px', lineHeight: 1.5 }}>
              Are you sure you want to delete run <span style={{ fontFamily: 'monospace', color: t.accent, fontWeight: 600 }}>{shortId(deleteConfirm)}</span> and all its telemetry data?
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button onClick={() => setDeleteConfirm(null)} style={{
                padding: '8px 18px', fontSize: 13, fontWeight: 600, borderRadius: 8,
                border: `1px solid ${t.border}`, background: 'transparent', color: t.textSecondary,
                cursor: 'pointer',
              }}>Cancel</button>
              <button onClick={() => handleDelete(deleteConfirm)} style={{
                padding: '8px 18px', fontSize: 13, fontWeight: 600, borderRadius: 8,
                border: 'none', background: '#ef4444', color: '#fff', cursor: 'pointer',
              }}>Delete</button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* ══ ERROR LOGS MODAL ══ */}
      {errorModal && (
        <ErrorLogsModal
          testRunId={errorModal.testRunId}
          scriptId={errorModal.scriptId}
          scriptName={errorModal.scriptName}
          onClose={() => setErrorModal(null)}
        />
      )}

      {/* ══ PERFORA GUARDIAN POST-TEST PANEL ══ */}
      {showGuardianPanel && createPortal(
        <div
          style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)',
            backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
            zIndex: 9600, display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
            padding: '32px 16px',
          }}
          onClick={e => { if (e.target === e.currentTarget) setShowGuardianPanel(false) }}
        >
          <div style={{
            background: t.bgRaised, border: `1px solid ${t.border}`,
            borderRadius: 16, width: '100%', maxWidth: 740,
            maxHeight: 'calc(100vh - 64px)', display: 'flex', flexDirection: 'column',
            boxShadow: '0 24px 80px rgba(0,0,0,0.45)',
            animation: 'trFadeIn 0.18s ease-out',
          }}>
            {/* Header */}
            {(() => {
              const verdict = computeVerdict(guardianFindings)
              const crit = guardianFindings.filter(f => f.severity === 'critical').length
              const warn = guardianFindings.filter(f => f.severity === 'warning').length
              const info = guardianFindings.filter(f => f.severity === 'info').length
              const good = guardianFindings.filter(f => f.severity === 'good').length
              return (
                <>
                  <div style={{
                    padding: '18px 22px 16px', borderBottom: `1px solid ${t.border}`,
                    display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16,
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div style={{
                        width: 42, height: 42, borderRadius: 12,
                        background: `linear-gradient(135deg, ${t.accent}22, ${t.accent}0a)`,
                        border: `1.5px solid ${t.accent}40`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                      }}>
                        <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                          <path d="M5.5 8l1.8 1.8L10.5 6" />
                        </svg>
                      </div>
                      <div>
                        <div style={{ color: t.textPrimary, fontSize: 16, fontWeight: 700 }}>Perfora Guardian</div>
                        <div style={{ color: t.textMuted, fontSize: 12, marginTop: 2 }}>Post-test analysis · {guardianFindings.length} finding{guardianFindings.length !== 1 ? 's' : ''}</div>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowGuardianPanel(false)}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, padding: 4, lineHeight: 1, borderRadius: 6, marginTop: 2 }}
                    >
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 4L4 12M4 4l8 8" /></svg>
                    </button>
                  </div>
                  {/* Verdict banner */}
                  <div style={{
                    margin: '14px 22px 0',
                    background: verdict.color + '12',
                    border: `1px solid ${verdict.color}35`,
                    borderRadius: 10, padding: '12px 16px',
                    display: 'flex', alignItems: 'center', gap: 14,
                  }}>
                    <div style={{
                      width: 44, height: 44, borderRadius: 10, flexShrink: 0,
                      background: verdict.color + '20',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      {verdict.label === 'Excellent' || verdict.label === 'Passing' ? (
                        <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={verdict.color} strokeWidth="2"><path d="M2 8l4 4 8-8" /></svg>
                      ) : verdict.label === 'Needs Improvement' ? (
                        <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={verdict.color} strokeWidth="1.8"><circle cx="8" cy="8" r="6.5" /><path d="M8 5v3.5M8 10.5v.5" /></svg>
                      ) : (
                        <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={verdict.color} strokeWidth="1.8"><path d="M8 2L14.5 13H1.5Z" /><path d="M8 6v3.5M8 11v.5" /></svg>
                      )}
                    </div>
                    <div>
                      <div style={{ color: verdict.color, fontSize: 14, fontWeight: 700 }}>{verdict.label}</div>
                      <div style={{ color: t.textSecondary, fontSize: 12, marginTop: 2, lineHeight: 1.4 }}>{verdict.description}</div>
                    </div>
                    {/* Severity pills */}
                    <div style={{ marginLeft: 'auto', display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                      {[
                        { label: 'Critical', count: crit, color: '#ef4444' },
                        { label: 'Warning',  count: warn, color: '#f59e0b' },
                        { label: 'Info',     count: info, color: '#06b6d4' },
                        { label: 'Good',     count: good, color: '#22c55e' },
                      ].filter(s => s.count > 0).map(s => (
                        <span key={s.label} style={{
                          display: 'inline-flex', alignItems: 'center', gap: 4,
                          padding: '3px 8px', borderRadius: 20,
                          background: s.color + '18', border: `1px solid ${s.color}35`,
                          color: s.color, fontSize: 11, fontWeight: 700, whiteSpace: 'nowrap',
                        }}>
                          <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor' }} />
                          {s.count} {s.label}
                        </span>
                      ))}
                    </div>
                  </div>
                </>
              )
            })()}

            {/* Findings list */}
            <div style={{ overflowY: 'auto', padding: '14px 22px 20px', flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {guardianFindings.map(f => {
                const colors = {
                  critical: '#ef4444', warning: '#f59e0b', info: '#06b6d4', good: '#22c55e',
                }
                const cat2icon = {
                  'Response Time':  <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="8" cy="8" r="6.5"/><path d="M8 4.5v4l2.5 2"/></svg>,
                  'Stability':      <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M2 10 L5 6 L7 8 L10 4 L12 7 L14 5"/></svg>,
                  'Reliability':    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M8 1.5L14 4v4C14 11.5 11 14 8 15c-3-1-6-3.5-6-7V4z"/><path d="M5.5 8l1.8 1.8L10.5 6"/></svg>,
                  'Throughput':     <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="1.5" y="6" width="3" height="8" rx="1"/><rect x="6.5" y="4" width="3" height="10" rx="1"/><rect x="11.5" y="1.5" width="3" height="12.5" rx="1"/></svg>,
                  'Endpoints':      <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="8" cy="5" r="2.5"/><path d="M3 13c0-3 2-5 5-5s5 2 5 5"/></svg>,
                }
                const col = colors[f.severity] || '#6b7280'
                return (
                  <div key={f.id} style={{
                    background: col + '08',
                    border: `1px solid ${col}28`,
                    borderLeft: `3px solid ${col}`,
                    borderRadius: 10, padding: '12px 14px',
                  }}>
                    {/* Title row */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                      <span style={{
                        display: 'inline-flex', alignItems: 'center', gap: 4,
                        padding: '2px 7px', borderRadius: 4,
                        background: col + '18', color: col, fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em',
                      }}>
                        {f.severity}
                      </span>
                      <span style={{
                        display: 'inline-flex', alignItems: 'center', gap: 4,
                        color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em',
                      }}>
                        {cat2icon[f.category] || null}
                        {f.category}
                      </span>
                      <span style={{ color: t.textPrimary, fontSize: 13, fontWeight: 700, marginLeft: 2 }}>{f.title}</span>
                    </div>
                    {/* Finding */}
                    <div style={{ color: t.textSecondary, fontSize: 12, lineHeight: 1.55, whiteSpace: 'pre-line', marginBottom: f.recommendation ? 8 : 0 }}>
                      {f.finding}
                    </div>
                    {/* Recommendation */}
                    {f.recommendation && (
                      <div style={{
                        marginTop: 8, paddingTop: 8, borderTop: `1px solid ${col}20`,
                        display: 'flex', alignItems: 'flex-start', gap: 7,
                      }}>
                        <svg style={{ flexShrink: 0, marginTop: 1 }} width="12" height="12" viewBox="0 0 16 16" fill="none" stroke={col} strokeWidth="2"><path d="M8 1v7M8 12v1M3 5l2 2M13 5l-2 2" /><circle cx="8" cy="13" r="1" fill={col} stroke="none"/></svg>
                        <div style={{ color: t.textMuted, fontSize: 11.5, lineHeight: 1.5 }}>
                          <span style={{ color: col, fontWeight: 700 }}>Recommendation: </span>
                          {f.recommendation}
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>

            {/* Footer */}
            <div style={{
              borderTop: `1px solid ${t.border}`, padding: '11px 22px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: t.textFaint, fontSize: 11 }}>
                <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M8 1.5L14 4v4C14 11.5 11 14 8 15c-3-1-6-3.5-6-7V4z"/></svg>
                Perfora Guardian · Post-test static analysis
              </div>
              <button
                onClick={() => setShowGuardianPanel(false)}
                style={{
                  background: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(15,23,42,0.05)',
                  border: `1px solid ${t.border}`, borderRadius: 7,
                  padding: '5px 14px', color: t.textSecondary,
                  fontSize: 12, fontWeight: 600, cursor: 'pointer',
                }}
              >Close</button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  )
}

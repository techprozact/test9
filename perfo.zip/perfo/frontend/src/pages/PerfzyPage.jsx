import React, { useState, useRef, useCallback, useEffect, useContext, useMemo } from 'react'
import { perfzyExecute, perfzyCreateScript } from '../api'
import { useTheme } from '../context/ThemeContext'
import { LayoutContext } from '../context/LayoutContext'
import { indexResponseBody, searchCandidates, findInstances, generateExpression } from '../correlation/correlationIndexer'

const PERFZY_STORAGE_KEY = 'perfzy_workspace_v1'
const PERFZY_SEEN_REC_PREFIX = 'PERFZY_SEEN_REC_'

let _labelCounter = 1  // only used for display name numbering, not uniqueness
function createEmptyTab() {
  const id = Date.now() + Math.floor(Math.random() * 1000)  // globally unique
  const label = _labelCounter++
  return {
    id,
    name: `Request ${label}`,
    method: 'GET',
    path: '',
    authType: 'none',
    authValue: {},
    headers: [{ key: '', value: '' }],
    // Body builder state
    payloadMode: 'none', // none | raw_json | json_kv | formdata | urlencoded
    rawJson: '',
    jsonFields: [{ key: '', value: '' }],
    formFields: [{ key: '', type: 'text', value: '' }],
    urlencodedFields: [{ key: '', value: '' }],
    isArchived: false,
    extractions: [{ name: '', source: 'json_path', expression: '' }],
    parameters: [],
  }
}

export default function PerfzyPage() {
  const { t, isDark } = useTheme()
  const layoutCtx = useContext(LayoutContext)
  const sidebarExpanded = layoutCtx && !layoutCtx.sidebarCollapsed
  const sidebarDelta = sidebarExpanded ? 0 : 144
  const rightPaneFontDelta = sidebarExpanded ? -1 : 0
  const [tabs, setTabs] = useState(() => {
    if (typeof window === 'undefined') return [createEmptyTab()]
    try {
      const raw = window.localStorage.getItem(PERFZY_STORAGE_KEY)
      if (raw) {
        const data = JSON.parse(raw)
        if (Array.isArray(data.tabs) && data.tabs.length) {
          // Bump label counter so new tabs get distinct display names
          _labelCounter = data.tabs.length + 1
          return data.tabs
        }
      }
    } catch {
      // ignore bad localStorage
    }
    return [createEmptyTab()]
  })
  const [activeTabId, setActiveTabId] = useState(() => {
    if (typeof window === 'undefined') return null
    try {
      const raw = window.localStorage.getItem(PERFZY_STORAGE_KEY)
      if (raw) {
        const data = JSON.parse(raw)
        if (data.activeTabId) return data.activeTabId
        if (Array.isArray(data.tabs) && data.tabs.length) return data.tabs[0].id
      }
    } catch {
      // ignore
    }
    return null
  })
  const [globalVars, setGlobalVars] = useState(() => {
    if (typeof window === 'undefined') return [{ key: 'base_url', value: '' }]
    try {
      const raw = window.localStorage.getItem(PERFZY_STORAGE_KEY)
      if (raw) {
        const data = JSON.parse(raw)
        if (Array.isArray(data.globalVars) && data.globalVars.length) {
          return data.globalVars
        }
      }
    } catch {
      // ignore
    }
    return [{ key: 'base_url', value: '' }]
  })
  const [responses, setResponses] = useState(() => {
    // Restore saved responses from persisted tab data so panel shows on page load
    try {
      const raw = window.localStorage.getItem(PERFZY_STORAGE_KEY)
      if (raw) {
        const data = JSON.parse(raw)
        if (Array.isArray(data.tabs)) {
          const init = {}
          data.tabs.forEach((t) => { if (t.lastResponse) init[t.id] = t.lastResponse })
          return init
        }
      }
    } catch {}
    return {}
  })
  const [running, setRunning] = useState({})
  const [runHover, setRunHover] = useState(false)
  const [variableCtx, setVariableCtx] = useState({})
  const [showScriptDialog, setShowScriptDialog] = useState(false)
  const [scriptNames, setScriptNames] = useState({})
  const [scriptName, setScriptName] = useState('')
  const [scriptNameError, setScriptNameError] = useState('')
  const [creating, setCreating] = useState(false)
  const [createdScript, setCreatedScript] = useState(null)
  const [detailTab, setDetailTab] = useState('response')
  const [centerTab, setCenterTab] = useState('request_design')
  const [showVarsModal, setShowVarsModal] = useState(false)
  const [varsDraft, setVarsDraft] = useState([])
  const [varsDirty, setVarsDirty] = useState(false)
  const [varsOriginal, setVarsOriginal] = useState('')
  const [flowTab, setFlowTab] = useState('active') // active | archived
  const [codeLanguage, setCodeLanguage] = useState(null) // 'java' | 'python' | null
  const [codeContent, setCodeContent] = useState('')
  const tabsRef = useRef(null)
  const [debugMode, setDebugMode] = useState(false)
  const [debugIndex, setDebugIndex] = useState(0)
  const [dragSrcId, setDragSrcId] = useState(null)
  const [dragOverId, setDragOverId] = useState(null)
  const [scriptSelected, setScriptSelected] = useState({})
  const [savedScriptId, setSavedScriptId] = useState(null)
  const [showSuccessDialog, setShowSuccessDialog] = useState(false)
  const [hasSeenRecommendations, setHasSeenRecommendations] = useState(false)

  // Sync "seen recommendations" from sessionStorage when tab changes (persists across Perfzy tab leave/return)
  useEffect(() => {
    if (typeof window === 'undefined' || !activeTabId) return
    setHasSeenRecommendations(window.sessionStorage.getItem(PERFZY_SEEN_REC_PREFIX + activeTabId) === '1')
  }, [activeTabId])
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  // Parameters feature state
  const [showParamModal, setShowParamModal] = useState(false)
  const [pendingParams, setPendingParams] = useState([])
  const [paramModalTabId, setParamModalTabId] = useState(null)
  const [paramNameError, setParamNameError] = useState('')
  const [paramTableError, setParamTableError] = useState('')
  const [manualParamDraft, setManualParamDraft] = useState(null)
  // Correlation Assistant state
  const [recentlyAccepted, setRecentlyAccepted] = useState({}) // { [tabId]: Set<name> }
  const [showCorrAssistant, setShowCorrAssistant] = useState(false)
  const [corrSearch, setCorrSearch] = useState('')
  const [corrSelected, setCorrSelected] = useState(null) // { entityName, fieldName }
  const [corrInstanceMode, setCorrInstanceMode] = useState('first')
  const [corrSpecificIndex, setCorrSpecificIndex] = useState(0)
  const [baseUrlHistory, setBaseUrlHistory] = useState(() => {
    try {
      const raw = window.localStorage.getItem('PERFZY_BASEURL_HISTORY')
      return raw ? JSON.parse(raw) : []
    } catch { return [] }
  })
  const [showBaseUrlDropdown, setShowBaseUrlDropdown] = useState(false)

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0]
  const resp = responses[activeTabId]

  // Index the active response body for the Correlation Assistant (computed once per response change)
  const corrCandidates = useMemo(() => {
    if (!resp?.body) return []
    return indexResponseBody(resp.body)
  }, [resp?.body])

  const baseUrl = (globalVars.find((v) => v.key === 'base_url') || {}).value || ''

  function persistWorkspace(nextTabs, nextGlobalVars, nextActiveId) {
    if (typeof window === 'undefined') return
    try {
      const payload = {
        tabs: nextTabs || tabs,
        globalVars: nextGlobalVars || globalVars,
        activeTabId: nextActiveId || activeTabId,
      }
      window.localStorage.setItem(PERFZY_STORAGE_KEY, JSON.stringify(payload))
    } catch {
      // ignore storage errors
    }
  }

  // Keep workspace snapshot up to date whenever core state changes
  useEffect(() => {
    persistWorkspace()
  }, [tabs, globalVars, activeTabId])

  // Inject CSS animations once
  useEffect(() => {
    const id = 'perfzy-keyframes'
    if (document.getElementById(id)) return
    const s = document.createElement('style')
    s.id = id
    s.textContent = `
      @keyframes perfzy-glow-pulse {
        0%,100% { box-shadow: 0 0 6px 1px rgba(35,134,54,0.35); }
        50%      { box-shadow: 0 0 18px 4px rgba(35,134,54,0.75); }
      }
      @keyframes perfzy-dot-blink {
        0%,100% { opacity: 1; }
        50%      { opacity: 0; }
      }
    `
    document.head.appendChild(s)
  }, [])

  const updateTab = useCallback((id, changes) => {
    setTabs((prev) => {
      const next = prev.map((t) => (t.id === id ? { ...t, ...changes } : t))
      // persist with updated tabs
      persistWorkspace(next, null, null)
      return next
    })
  }, [])

  function addTab() {
    const t = createEmptyTab()
    setTabs((prev) => {
      const next = [...prev, t]
      persistWorkspace(next, null, t.id)
      return next
    })
    setActiveTabId(t.id)
  }

  function removeTab(id) {
    setTabs((prev) => {
      if (prev.length <= 1) {
        const single = createEmptyTab()
        setActiveTabId(single.id)
        persistWorkspace([single], null, single.id)
        return [single]
      }
      const next = prev.filter((t) => t.id !== id)
      if (activeTabId === id && next.length) {
        setActiveTabId(next[0].id)
        persistWorkspace(next, null, next[0].id)
      } else {
        persistWorkspace(next, null, activeTabId)
      }
      return next
    })
  }

  function scrollTabs(dir) {
    if (tabsRef.current) tabsRef.current.scrollBy({ left: dir * 120, behavior: 'smooth' })
  }

  function openVarsModal() {
    const nonBase = globalVars.filter((v) => v.key !== 'base_url')
    const draft = nonBase.length ? nonBase : []
    setVarsDraft(draft)
    setVarsOriginal(JSON.stringify(draft.filter((v) => v.key.trim()).map((v) => ({ key: v.key, value: v.value }))))
    setVarsDirty(false)
    setShowVarsModal(true)
  }

  function buildVariables() {
    const vars = {}
    // Global vars (base_url + custom global parameters)
    globalVars.forEach((v) => { if (v.key) vars[v.key] = v.value })
    // All request-level parameters have global scope — inject by customName
    tabs.filter((t) => !t.isArchived).forEach((t) => {
      ;(t.parameters || []).forEach((p) => {
        if (p.customName) vars[p.customName] = p.value
      })
    })
    // Runtime extracted values take highest priority
    Object.assign(vars, variableCtx)
    return vars
  }

  async function executeSingle(tab, injectedVars = null) {
    const t = tab
    const variables = injectedVars || buildVariables()
    const fullUrl = (variables.base_url || baseUrl) + t.path

    // Persist base URL to history
    const currentBase = (variables.base_url || baseUrl || '').trim()
    if (currentBase && !baseUrlHistory.includes(currentBase)) {
      const next = [currentBase, ...baseUrlHistory].slice(0, 10)
      setBaseUrlHistory(next)
      try { window.localStorage.setItem('PERFZY_BASEURL_HISTORY', JSON.stringify(next)) } catch {}
    }

    const headers = {}
    t.headers.forEach((h) => { if (h.key.trim()) headers[h.key.trim()] = h.value })

    // Build payload and content type based on payloadMode
    let payload = null
    let payloadTypeForBackend = 'none'
    const mode = t.payloadMode || 'none'

    const hasContentType = Object.keys(headers).some(
      (k) => k.toLowerCase() === 'content-type'
    )

    if (mode === 'raw_json') {
      payloadTypeForBackend = 'json'
      if (t.rawJson && t.rawJson.trim()) {
        try {
          payload = JSON.parse(t.rawJson)
        } catch {
          payload = t.rawJson // still send raw for debugging even if invalid
        }
      }
      if (!hasContentType) headers['Content-Type'] = 'application/json'
    } else if (mode === 'json_kv') {
      payloadTypeForBackend = 'json'
      const obj = {}
      ;(t.jsonFields || []).forEach(({ key, value }) => {
        if (key && key.trim()) obj[key] = value
      })
      payload = obj
      if (!hasContentType) headers['Content-Type'] = 'application/json'
    } else if (mode === 'formdata') {
      payloadTypeForBackend = 'form'
      const obj = {}
      ;(t.formFields || []).forEach(({ key, type, value }) => {
        if (key && key.trim()) {
          // For now we just send string values; file handling can be extended later.
          obj[key] = value
        }
      })
      payload = obj
      if (!hasContentType) headers['Content-Type'] = 'multipart/form-data'
    } else if (mode === 'urlencoded') {
      payloadTypeForBackend = 'urlencoded'
      const obj = {}
      ;(t.urlencodedFields || []).forEach(({ key, value }) => {
        if (key && key.trim()) obj[key] = value
      })
      payload = obj
      if (!hasContentType) headers['Content-Type'] = 'application/x-www-form-urlencoded'
    } else {
      payload = null
      payloadTypeForBackend = 'none'
    }

    // Build a human-readable preview of the request body (what will be sent)
    let requestPreview = ''
    if (mode === 'raw_json') {
      requestPreview = t.rawJson || ''
    } else if (mode === 'json_kv') {
      const obj = {}
      ;(t.jsonFields || []).forEach(({ key, value }) => {
        if (key && key.trim()) obj[key] = value
      })
      requestPreview = Object.keys(obj).length ? JSON.stringify(obj, null, 2) : ''
    } else if (mode === 'formdata') {
      requestPreview = (t.formFields || [])
        .filter(({ key }) => key && key.trim())
        .map(({ key, type, value }) => `${key}: ${type === 'file' ? '<file>' : value || ''}`)
        .join('\n')
    } else if (mode === 'urlencoded') {
      requestPreview = (t.urlencodedFields || [])
        .filter(({ key }) => key && key.trim())
        .map(({ key, value }) => `${key}=${encodeURIComponent(value || '')}`)
        .join('&')
    } else {
      requestPreview = ''
    }

    setRunning((p) => ({ ...p, [t.id]: true }))
    // New execution: re-show recommendations badge until user opens the tab (clear persisted "seen" for this tab)
    try { window.sessionStorage.removeItem(PERFZY_SEEN_REC_PREFIX + t.id) } catch {}
    if (t.id === activeTabId) setHasSeenRecommendations(false)
    try {
      const data = await perfzyExecute({
        method: t.method,
        url: fullUrl,
        headers,
        payload,
        payload_type: payloadTypeForBackend,
        auth_type: t.authType,
        auth_value: t.authValue,
        variables,
        extractions: t.extractions.filter((e) => e.name && e.expression),
      })
      setResponses((p) => ({ ...p, [t.id]: data }))
      if (data.extracted_values) {
        setVariableCtx((prev) => ({ ...prev, ...data.extracted_values }))
      }
      // Persist response + passed status into the tab itself
      const sc = data.status_code || 0
      const execStatus = sc >= 200 && sc < 400 ? 'passed' : 'failed'
      setTabs((prev) =>
        prev.map((tab) =>
          tab.id === t.id ? { ...tab, lastResponse: data, execStatus, lastRequestPreview: requestPreview } : tab
        )
      )
      // After each run, focus the Response tab and clear accepted suggestions for this tab.
      setDetailTab('response')
      setRecentlyAccepted((prev) => { const n = { ...prev }; delete n[t.id]; return n })

      // Auto-show Parameter Assistant if there are new/unparameterized params detected
      const detected = detectParams(t)
      if (detected.length > 0) {
        const alreadyKeys = new Set(
          tabs.filter((tab2) => !tab2.isArchived).flatMap((tab2) => (tab2.parameters || []).map((p) => p.key))
        )
        const hasNew = detected.some((p) => !alreadyKeys.has(p.key))
        if (hasNew) {
          const toShow = detected.map((p) => ({
            ...p, checked: false, customName: 'user_' + p.key,
            alreadyParameterized: alreadyKeys.has(p.key),
          }))
          setPendingParams(toShow)
          setParamModalTabId(t.id)
          setParamNameError('')
          setShowParamModal(true)
        }
      }

      return data
    } catch (e) {
      setResponses((p) => ({ ...p, [t.id]: { error: e.message, status_code: 0 } }))
      setTabs((prev) =>
        prev.map((tab) =>
          tab.id === t.id
            ? {
                ...tab,
                lastResponse: { error: e.message, status_code: 0 },
                execStatus: 'failed',
                lastRequestPreview: requestPreview,
              }
            : tab
        )
      )
    } finally {
      setRunning((p) => ({ ...p, [t.id]: false }))
      // Ensure current workspace is saved after a run
      persistWorkspace()
    }
  }

  async function handleRun() {
    layoutCtx?.collapseSidebar?.()
    if (debugMode) {
      const activeList = tabs.filter((t) => !t.isArchived)
      if (!activeList.length) return
      const current = activeList[debugIndex]
      if (!current) return
      await executeSingle(current)
      // Stay on the executed request so user sees its request/response
      setActiveTabId(current.id)
      const nextIdx = debugIndex + 1
      if (nextIdx >= activeList.length) {
        // All requests executed — auto-disable sequential mode
        setDebugMode(false)
        setDebugIndex(0)
      } else {
        setDebugIndex(nextIdx)
      }
    } else {
      await executeSingle(activeTab)
    }
  }

  async function runAllRequests() {
    const activeList = tabs.filter((t) => !t.isArchived)
    // Seed with current state once; then accumulate extractions synchronously so
    // each request sees the variables extracted by all previous requests — without
    // waiting for React's async setVariableCtx to propagate between iterations.
    let localVars = buildVariables()
    for (const t of activeList) {
      const data = await executeSingle(t, localVars)
      if (data?.extracted_values && Object.keys(data.extracted_values).length) {
        localVars = { ...localVars, ...data.extracted_values }
      }
    }
  }

  function acceptSuggestion(suggestion) {
    const ext = { name: suggestion.name, source: suggestion.source, expression: suggestion.expression }
    updateTab(activeTabId, { extractions: [...activeTab.extractions, ext] })
    const resp = responses[activeTabId]
    if (resp?.extracted_values?.[suggestion.name] == null && suggestion.preview) {
      setVariableCtx((prev) => ({ ...prev, [suggestion.name]: suggestion.preview }))
    }
    setRecentlyAccepted((prev) => {
      const existing = prev[activeTabId] ? new Set(prev[activeTabId]) : new Set()
      existing.add(suggestion.name)
      return { ...prev, [activeTabId]: existing }
    })
  }

  // ── Parameter helpers ──────────────────────────────────────────────────

  function getAllParamNames(excludeTabId, excludeIdx) {
    return new Set(
      tabs.filter((t) => !t.isArchived).flatMap((t) =>
        (t.parameters || [])
          .filter((p, i) => !(t.id === excludeTabId && i === excludeIdx))
          .map((p) => p.customName || p.key)
      )
    )
  }

  function openParamsAssistant() {
    const t = activeTab
    if (!t) return
    const detected = detectParams(t)
    if (detected.length === 0) {
      setPendingParams([])
      setParamModalTabId(t.id)
      setParamNameError('')
      setShowParamModal(true)
      return
    }
    const storedKeys = new Set((t.parameters || []).map((p) => p.key))
    const alreadyKeys = new Set(
      tabs.filter((tab2) => !tab2.isArchived).flatMap((tab2) => (tab2.parameters || []).map((p) => p.key))
    )
    const toShow = detected.map((p) => ({
      ...p, checked: false, customName: 'user_' + p.key,
      alreadyParameterized: alreadyKeys.has(p.key) || storedKeys.has(p.key),
    }))
    setPendingParams(toShow)
    setParamModalTabId(t.id)
    setParamNameError('')
    setShowParamModal(true)
  }

  function handleRenameParam(idx, newName) {
    handleRenameParamForTab(activeTabId, idx, newName)
  }

  function handleValueChange(idx, newValue) {
    handleValueChangeForTab(activeTabId, idx, newValue)
  }

  function handleDeleteParam(idx) {
    handleDeleteParamForTab(activeTabId, idx)
  }

  function handleRenameParamForTab(tabId, idx, newName) {
    if (!newName.trim()) return
    const existing = getAllParamNames(tabId, idx)
    if (existing.has(newName.trim())) {
      setParamTableError(`Parameter name "${newName}" already exists. Please provide a unique name.`)
      return
    }
    setParamTableError('')
    const tab = tabs.find((t) => t.id === tabId)
    if (!tab) return
    const params = [...(tab.parameters || [])]
    params[idx] = { ...params[idx], customName: newName.trim() }
    updateTab(tabId, { parameters: params })
  }

  function handleValueChangeForTab(tabId, idx, newValue) {
    const tab = tabs.find((t) => t.id === tabId)
    if (!tab) return
    const params = [...(tab.parameters || [])]
    params[idx] = { ...params[idx], value: newValue }
    updateTab(tabId, { parameters: params })
  }

  function handleDeleteParamForTab(tabId, idx) {
    const tab = tabs.find((t) => t.id === tabId)
    if (!tab) return
    const removed = tab.parameters?.[idx]
    const params = (tab.parameters || []).filter((_, i) => i !== idx)

    // Restore {{customName}} placeholders back to original literal values
    const tabPatch = { parameters: params }
    if (removed?.customName && removed?.value) {
      const placeholder = `{{${removed.customName}}}`
      const original = removed.value

      function restoreInStr(str) {
        if (!str) return str
        try {
          const escaped = placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
          return str.replace(new RegExp(escaped, 'g'), original)
        } catch { return str }
      }

      if (tab.path) tabPatch.path = restoreInStr(tab.path)
      if (tab.payloadMode === 'raw_json' && tab.rawJson) {
        tabPatch.rawJson = restoreInStr(tab.rawJson)
      }
      if (tab.payloadMode === 'json_kv' && tab.jsonFields) {
        tabPatch.jsonFields = tab.jsonFields.map((f) => ({ ...f, value: restoreInStr(f.value) }))
      }
      if (tab.payloadMode === 'formdata' && tab.formFields) {
        tabPatch.formFields = tab.formFields.map((f) => ({ ...f, value: restoreInStr(f.value) }))
      }
      if (tab.payloadMode === 'urlencoded' && tab.urlencodedFields) {
        tabPatch.urlencodedFields = tab.urlencodedFields.map((f) => ({ ...f, value: restoreInStr(f.value) }))
      }
      if (tab.headers) {
        tabPatch.headers = tab.headers.map((h) => ({ ...h, value: restoreInStr(h.value) }))
      }
      if (tab.lastRequestPreview) {
        tabPatch.lastRequestPreview = restoreInStr(tab.lastRequestPreview)
      }
    }

    updateTab(tabId, tabPatch)
    setParamTableError('')
  }

  function handleAddManualParam() {
    if (!manualParamDraft) return
    const { key, customName, value } = manualParamDraft
    if (!key.trim()) { setParamNameError('Key is required.'); return }
    if (!customName.trim()) { setParamNameError('Custom name is required.'); return }
    const existing = getAllParamNames(null, null)
    if (existing.has(customName.trim())) {
      setParamNameError(`Parameter name "${customName}" already exists. Please provide a unique name.`)
      return
    }
    setParamNameError('')
    const newParam = { key: key.trim(), customName: customName.trim(), value: value || '', source: 'manual', masked: isSensitiveKey(key) }
    updateTab(activeTabId, { parameters: [...(activeTab.parameters || []), newParam] })
    setManualParamDraft(null)
  }

  function handleAddSelectedParams() {
    const selected = pendingParams.filter((p) => p.checked && !p.alreadyParameterized)
    if (selected.length === 0) { setShowParamModal(false); return }
    // Validate no dups within selection
    const selNames = selected.map((p) => p.customName.trim())
    const selfDup = selNames.find((n, i) => selNames.indexOf(n) !== i)
    if (selfDup) {
      setParamNameError(`Duplicate parameter name "${selfDup}". Please use unique names.`)
      return
    }
    // Validate against all existing
    const existing = getAllParamNames(null, null)
    const conflict = selected.find((p) => existing.has(p.customName.trim()))
    if (conflict) {
      setParamNameError(`Parameter name "${conflict.customName}" already exists. Please provide a unique name.`)
      return
    }
    setParamNameError('')
    const tab = tabs.find((t) => t.id === paramModalTabId)
    if (!tab) { setShowParamModal(false); return }
    const newParams = selected.map((p) => ({
      key: p.key, customName: p.customName.trim(), value: p.value, source: p.source, masked: p.masked,
    }))
    const updatedParams = [...(tab.parameters || []), ...newParams]
    const parameterizedPreview = parameterizePreview(tab.lastRequestPreview || '', newParams)

    // Replace literal values in the actual request fields with {{customName}}
    const tabPatch = { parameters: updatedParams, lastRequestPreview: parameterizedPreview }

    function replaceInStr(str) {
      if (!str) return str
      let result = str
      newParams.forEach(({ customName, value }) => {
        if (!value || !customName) return
        try {
          const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
          result = result.replace(new RegExp(escaped, 'g'), `{{${customName}}}`)
        } catch { /* ignore */ }
      })
      return result
    }

    // Replace in path (URL)
    if (tab.path) {
      tabPatch.path = replaceInStr(tab.path)
    }
    // Replace in raw JSON body
    if (tab.payloadMode === 'raw_json' && tab.rawJson) {
      tabPatch.rawJson = replaceInStr(tab.rawJson)
    }
    // Replace in json_kv fields
    if (tab.payloadMode === 'json_kv' && tab.jsonFields) {
      tabPatch.jsonFields = tab.jsonFields.map((f) => ({ ...f, value: replaceInStr(f.value) }))
    }
    // Replace in formdata fields
    if (tab.payloadMode === 'formdata' && tab.formFields) {
      tabPatch.formFields = tab.formFields.map((f) => ({ ...f, value: replaceInStr(f.value) }))
    }
    // Replace in urlencoded fields
    if (tab.payloadMode === 'urlencoded' && tab.urlencodedFields) {
      tabPatch.urlencodedFields = tab.urlencodedFields.map((f) => ({ ...f, value: replaceInStr(f.value) }))
    }
    // Replace in headers
    if (tab.headers) {
      tabPatch.headers = tab.headers.map((h) => ({ ...h, value: replaceInStr(h.value) }))
    }

    updateTab(paramModalTabId, tabPatch)
    setShowParamModal(false)
    setDetailTab('response')
  }

  function openScriptDialog() {
    const activeTabs = tabs.filter((t) => !t.isArchived)
    const sel = {}
    activeTabs.forEach((t) => { sel[t.id] = true })
    setScriptSelected(sel)
    setScriptName('')
    setScriptNameError('')
    setCreatedScript(null)
    setShowScriptDialog(true)
  }

  function reorderTabs(srcId, overId) {
    if (!srcId || !overId || srcId === overId) return
    setTabs((prev) => {
      const next = [...prev]
      const fromIdx = next.findIndex((t) => t.id === srcId)
      const toIdx = next.findIndex((t) => t.id === overId)
      if (fromIdx < 0 || toIdx < 0) return prev
      const [moved] = next.splice(fromIdx, 1)
      next.splice(toIdx, 0, moved)
      persistWorkspace(next, null, null)
      return next
    })
  }

  async function handleCreateScript() {
    if (!scriptName.trim()) {
      setScriptNameError('Script name is required.')
      return
    }
    setScriptNameError('')
    setCreating(true)
    try {
      const variables = buildVariables()
      const selectedTabs = tabs.filter((t) => !t.isArchived && scriptSelected[t.id])
      if (!selectedTabs.length) { alert('Please select at least one request.'); setCreating(false); return }
      const reqs = selectedTabs.map((t) => {
        // Build headers (same as executeSingle)
        const headers = {}
        ;(t.headers || []).forEach((h) => { if (h.key && h.key.trim()) headers[h.key.trim()] = h.value })

        // Build payload + resolve Content-Type (mirrors executeSingle exactly)
        let payload = null
        let payloadType = 'none'
        const mode = t.payloadMode || 'none'
        const hasContentType = Object.keys(headers).some((k) => k.toLowerCase() === 'content-type')

        if (mode === 'raw_json') {
          payloadType = 'json'
          if (t.rawJson && t.rawJson.trim()) {
            try { payload = JSON.parse(t.rawJson) } catch { payload = t.rawJson }
          }
          if (!hasContentType) headers['Content-Type'] = 'application/json'
        } else if (mode === 'json_kv') {
          payloadType = 'json'
          const obj = {}
          ;(t.jsonFields || []).forEach(({ key, value }) => { if (key && key.trim()) obj[key] = value })
          payload = Object.keys(obj).length ? obj : null
          if (!hasContentType) headers['Content-Type'] = 'application/json'
        } else if (mode === 'formdata') {
          payloadType = 'form'
          const obj = {}
          ;(t.formFields || []).forEach(({ key, type, value }) => { if (key && key.trim()) obj[key] = value })
          payload = Object.keys(obj).length ? obj : null
          if (!hasContentType) headers['Content-Type'] = 'multipart/form-data'
        } else if (mode === 'urlencoded') {
          payloadType = 'urlencoded'
          const obj = {}
          ;(t.urlencodedFields || []).forEach(({ key, value }) => { if (key && key.trim()) obj[key] = value })
          payload = Object.keys(obj).length ? obj : null
          if (!hasContentType) headers['Content-Type'] = 'application/x-www-form-urlencoded'
        }

        // Handle auth (same ordering as executeSingle)
        const authType  = t.authType  || 'none'
        const authValue = t.authValue || {}
        if (authType === 'bearer' && authValue.token) {
          headers['Authorization'] = `Bearer ${authValue.token}`
        } else if (authType === 'apikey' && authValue.key && authValue.location === 'header') {
          headers[authValue.key] = authValue.value || ''
        }

        return {
          name: t.name,
          method: t.method,
          path: t.path,
          headers,
          payload,
          payload_type: payloadType,
          auth_type: authType,
          auth_value: authType === 'bearer' ? {} : authValue, // bearer already injected above
          extractions: (t.extractions || []).filter((e) => e.name && e.expression),
          request_parameters: (t.parameters || []).map((p) => ({
            key: p.key || '',
            custom_name: p.customName || p.key || '',
            value: p.value || '',
            source: p.source || 'manual',
          })),
        }
      })
      // Collect all finalized parameters across selected requests
      const allParams = selectedTabs.flatMap((t) =>
        (t.parameters || []).map((p) => ({ key: p.key, custom_name: p.customName || p.key, value: p.value, source: p.source }))
      )
      const data = await perfzyCreateScript({
        script_name: scriptName.trim(),
        base_url: variables.base_url || baseUrl,
        requests: reqs,
        global_variables: Object.fromEntries(globalVars.filter((v) => v.key && v.key !== 'base_url').map((v) => [v.key, v.value])),
        parameters: allParams,
        think_time: 0,
      })
      setCreatedScript(data)
      setSavedScriptId(data.script_id)
      setShowScriptDialog(false)
      setShowSuccessDialog(true)
    } catch (e) {
      alert(e.message)
    } finally {
      setCreating(false)
    }
  }

  function downloadCreatedScript() {
    if (!createdScript?.script_content) return
    const blob = new Blob([createdScript.script_content], { type: 'text/x-python' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = (scriptName || 'perfzy_script') + '.py'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const isRunning = running[activeTabId]
  const responseSizeLabel = (() => {
    if (!resp || resp.body == null) return null
    try {
      const raw = typeof resp.body === 'string' ? resp.body : JSON.stringify(resp.body)
      const kb = raw.length / 1024
      return kb > 0 ? `Size: ${kb.toFixed(1)} KB` : null
    } catch {
      return null
    }
  })()

  const recommendations = (() => {
    if (!resp) return []
    const out = []
    const headers = resp.headers || {}
    const sentHeaders = resp.sent_headers || {}
    const getHeader = (name, source = headers) => {
      const lower = name.toLowerCase()
      return Object.entries(source).find(([k]) => String(k).toLowerCase() === lower)?.[1]
    }

    // Helper: push recommendation
    const pushRec = (category, severity, title, details, recommendation, metric) => {
      out.push({ category, severity, title, details, recommendation, metric })
    }

    // RESPONSE TIME ANALYSIS
    if (typeof resp.elapsed_ms === 'number' && resp.elapsed_ms > 0) {
      const ms = resp.elapsed_ms
      if (ms > 1000) {
        pushRec(
          'Performance',
          'critical',
          'API response time is significantly high',
          `Measured response time: ${ms} ms.`,
          'Optimize database queries, introduce caching, or review backend service dependencies.',
          ms
        )
      } else if (ms > 500) {
        pushRec(
          'Performance',
          'warning',
          'Response time is higher than recommended threshold',
          `Measured response time: ${ms} ms. Recommended: < 300 ms for optimal API performance.`,
          'Investigate backend processing, database queries, or caching.',
          ms
        )
      }
    }

    // RESPONSE SIZE ANALYSIS
    let bodyBytes = 0
    if (resp.body != null) {
      try {
        const raw = typeof resp.body === 'string' ? resp.body : JSON.stringify(resp.body)
        bodyBytes = raw.length
        const kb = bodyBytes / 1024
        if (kb > 500) {
          pushRec(
            'Payload Size',
            'critical',
            'Response payload is excessively large',
            `Payload size: ${kb.toFixed(1)} KB.`,
            'Implement pagination or optimize response structure.',
            kb
          )
        } else if (kb > 100) {
          pushRec(
            'Payload Size',
            'warning',
            'Response payload is larger than recommended',
            `Payload size: ${kb.toFixed(1)} KB.`,
            'Consider pagination, filtering fields, or reducing unnecessary data in the response.',
            kb
          )
        }
      } catch {
        // ignore
      }
    }

    // COMPRESSION ANALYSIS
    const enc = getHeader('Content-Encoding')
    if (enc) {
      pushRec(
        'Compression',
        'info',
        'Compression detected',
        `Content-Encoding: ${enc}`,
        'Compression reduces bandwidth usage and improves performance.',
        enc
      )
    } else {
      pushRec(
        'Compression',
        'warning',
        'Response compression is not enabled',
        'No gzip or brotli compression detected.',
        'Enable gzip or brotli compression to reduce payload size and improve response time.'
      )
    }

    // CACHE ANALYSIS
    const cacheCtrl = getHeader('Cache-Control')
    if (typeof cacheCtrl === 'string') {
      const v = cacheCtrl.toLowerCase()
      if (v.includes('no-cache') || v.includes('no-store')) {
        pushRec(
          'Caching',
          'info',
          'Response caching disabled',
          'Cache-Control header indicates response is not cached.',
          'For static content consider enabling caching to reduce server load.',
          cacheCtrl
        )
      } else if (v.includes('max-age')) {
        pushRec(
          'Caching',
          'info',
          'Caching enabled',
          'Cache-Control max-age detected.',
          '',
          cacheCtrl
        )
      }
    }

    // COOKIE ANALYSIS (request cookies)
    const cookieHeader = getHeader('Cookie', sentHeaders) || getHeader('cookie', sentHeaders)
    if (cookieHeader) {
      const size = String(cookieHeader).length
      const parts = String(cookieHeader).split(';').filter(Boolean)
      const count = parts.length
      if (size > 4096) {
        pushRec(
          'Cookies',
          'warning',
          'Large cookie header detected',
          `Total cookie size: ${size} bytes.`,
          'Reduce cookie size to minimize request overhead.',
          size
        )
      }
      if (count > 5) {
        pushRec(
          'Cookies',
          'info',
          'Multiple cookies detected',
          `Cookie count: ${count}.`,
          'Excess cookies increase request size and may impact performance.',
          count
        )
      }
    }

    // HEADER ANALYSIS
    const headerCount = Object.keys(headers).length
    if (headerCount > 15) {
      pushRec(
        'Headers',
        'info',
        'Large number of response headers detected',
        `Header count: ${headerCount}.`,
        'Review headers and remove unnecessary metadata if possible.',
        headerCount
      )
    }

    // SECURITY HEADER ANALYSIS
    const securityHeaders = [
      'Strict-Transport-Security',
      'X-Content-Type-Options',
      'X-Frame-Options',
      'Content-Security-Policy',
    ]
    const missing = securityHeaders.filter((h) => !getHeader(h))
    if (missing.length > 0) {
      pushRec(
        'Security',
        'info',
        'Recommended security headers not detected',
        `Missing headers: ${missing.join(', ')}.`,
        'Consider enabling common security headers to improve application security.'
      )
    }

    // API DESIGN ANALYSIS
    const method = (resp.sent_method || '').toUpperCase()
    const sentPayload = resp.sent_payload

    // GET request with payload
    if (method === 'GET' && sentPayload != null) {
      let hasBody = false
      if (typeof sentPayload === 'string') {
        hasBody = sentPayload.trim().length > 0
      } else if (typeof sentPayload === 'object') {
        hasBody = Object.keys(sentPayload).length > 0
      }
      if (hasBody) {
        pushRec(
          'API Design',
          'warning',
          'GET request contains a payload',
          'GET request was sent with a non-empty request body.',
          'GET requests should generally not include request bodies.'
        )
      }
    }

    // Large request payload
    if (sentPayload != null) {
      try {
        const rawReq = typeof sentPayload === 'string' ? sentPayload : JSON.stringify(sentPayload)
        const kbReq = rawReq.length / 1024
        if (kbReq > 50) {
          pushRec(
            'Payload Size',
            'warning',
            'Large request payload detected',
            `Approximate request payload size: ${kbReq.toFixed(1)} KB.`,
            'Consider reducing request payload size.',
            kbReq
          )
        }
      } catch {
        // ignore
      }
    }

    return out
  })()

  const criticalCount = recommendations.filter((r) => r.severity === 'critical').length
  const warningCount = recommendations.filter((r) => r.severity === 'warning').length
  const infoCount = recommendations.filter((r) => r.severity === 'info').length

  function highlightMetrics(text) {
    if (!text) return null
    const parts = String(text).split(/(\d+(?:\.\d+)?\s*(?:ms|KB|bytes)?)/g)
    return parts.map((part, idx) => {
      if (!part) return null
      const isMetric = /\d/.test(part)
      return (
        <span
          key={idx}
          style={isMetric ? { color: '#fca5a5' } : undefined}
        >
          {part}
        </span>
      )
    })
  }

  function openCodeModal(lang) {
    if (!activeTab) return
    const method = (activeTab.method || 'GET').toUpperCase()
    const url = (baseUrl || '').replace(/\/$/, '') + (activeTab.path || '')

    // Build a simple headers object from current tab
    const headersObj = {}
    ;(activeTab.headers || []).forEach(({ key, value }) => {
      if (key && key.trim()) headersObj[key.trim()] = value
    })

    // Build a payload preview for code
    let bodySnippet = ''
    const mode = activeTab.payloadMode || 'none'
    if (mode === 'raw_json') {
      bodySnippet = activeTab.rawJson || ''
    } else if (mode === 'json_kv') {
      const obj = {}
      ;(activeTab.jsonFields || []).forEach(({ key, value }) => {
        if (key && key.trim()) obj[key] = value
      })
      bodySnippet = JSON.stringify(obj, null, 2)
    } else if (mode === 'formdata') {
      bodySnippet = (activeTab.formFields || [])
        .filter(({ key }) => key && key.trim())
        .map(({ key, type, value }) => `${key}: ${type === 'file' ? '<file>' : value || ''}`)
        .join('\n')
    } else if (mode === 'urlencoded') {
      const pairs = (activeTab.urlencodedFields || [])
        .filter(({ key }) => key && key.trim())
        .map(({ key, value }) => `${key}=${encodeURIComponent(value || '')}`)
      bodySnippet = pairs.join('&')
    }

    let code = ''
    if (lang === 'python') {
      const headerLine = Object.keys(headersObj).length
        ? 'headers = ' + JSON.stringify(headersObj, null, 2)
        : 'headers = {}'

      let payloadDecl = 'payload = None'
      if (mode === 'raw_json' || mode === 'json_kv') {
        payloadDecl = 'payload = ' + (bodySnippet ? bodySnippet : '{}')
      } else if (mode === 'formdata') {
        payloadDecl = '# multipart/form-data fields\n# ' + (bodySnippet || 'key: value')
      } else if (mode === 'urlencoded') {
        payloadDecl = '# x-www-form-urlencoded\n# ' + (bodySnippet || 'key=value')
      }

      let requestLine = `response = requests.${method.toLowerCase()}(url, headers=headers)`
      if (mode === 'raw_json' || mode === 'json_kv') {
        requestLine = `response = requests.${method.toLowerCase()}(url, headers=headers, json=payload)`
      } else if (mode === 'urlencoded') {
        requestLine = `response = requests.${method.toLowerCase()}(url, headers=headers, data={})`
      }

      code = [
        'import requests',
        '',
        `url = "${url || 'https://api.example.com/path'}"`,
        '',
        headerLine,
        '',
        payloadDecl,
        '',
        requestLine,
        '',
        'print(response.status_code)',
        'print(response.text)',
      ].join('\n')
    } else {
      // Java (HttpClient) snippet
      const headerLines = Object.entries(headersObj).map(
        ([k, v]) => `        .header("${k}", "${String(v).replace(/"/g, '\\"')}")`,
      )
      const escapedBody = bodySnippet ? bodySnippet.replace(/"/g, '\\"') : ''
      const javaBody =
        mode === 'none'
          ? 'HttpRequest.BodyPublishers.noBody()'
          : `HttpRequest.BodyPublishers.ofString("${escapedBody}")`

      code = [
        'import java.net.http.*;',
        'import java.net.URI;',
        '',
        'HttpClient client = HttpClient.newHttpClient();',
        'HttpRequest.Builder builder = HttpRequest.newBuilder()',
        `        .uri(URI.create("${url || 'https://api.example.com/path'}"))`,
        ...headerLines,
        `        .method("${method}", ${javaBody});`,
        '',
        'HttpRequest request = builder.build();',
        'HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());',
        'System.out.println(response.statusCode());',
        'System.out.println(response.body());',
      ].join('\n')
    }

    setCodeLanguage(lang)
    setCodeContent(code)
  }

  function closeCodeModal() {
    setCodeLanguage(null)
    setCodeContent('')
  }

  return (
    <div style={{
      maxWidth: 1600, margin: '0 auto',
      '--ps-bg': t.bgBase,
      '--ps-card': t.bgRaised,
      '--ps-border': t.border,
      '--ps-border-muted': t.borderMuted,
      '--ps-text': t.textPrimary,
      '--ps-text-2': t.textSecondary,
      '--ps-text-muted': t.textTertiary,
      '--ps-text-faint': t.textMuted,
      '--ps-hover': t.bgHover,
      '--ps-input-bg': t.bgInput,
      '--ps-accent': t.accent,
    }}>
      <h2 style={{ fontSize: 20, marginBottom: 25, marginTop: 0, color: t.textPrimary }}>
        Perfzy<span style={{ color: t.textTertiary, fontWeight: 400, fontSize: 14, marginLeft: 8 }}>API Script Builder</span>
      </h2>

      {/* Top bar row: Base URL tile (left) + Create Script tile (right) */}
      <div style={{ display: 'flex', gap: 7, alignItems: 'center' }}>
        {/* Global Variables Bar — spans flow panel + center designer */}
        <div style={{ ...globalBarStyle, flex: '0 0 689px', minWidth: 0, padding: '5px 14px' }}>
          {globalVars.slice(0, 1).map((v, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', position: 'relative' }}>
              <label style={{ ...labelStyle, marginBottom: 0, marginRight: 0 }}>Base URL</label>
              <div style={{ position: 'relative' }}>
                <input
                  style={{ ...inputStyle, width: 280, flex: '0 0 auto' }}
                  placeholder="https://api.example.com"
                  value={v.value}
                  onFocus={() => baseUrlHistory.length > 0 && setShowBaseUrlDropdown(true)}
                  onBlur={() => setTimeout(() => setShowBaseUrlDropdown(false), 150)}
                  onChange={(e) => {
                    const next = [...globalVars]
                    next[i] = { ...next[i], key: 'base_url', value: e.target.value }
                    setGlobalVars(next)
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && v.value) {
                      const url = v.value.trim()
                      if (url && !baseUrlHistory.includes(url)) {
                        const next = [url, ...baseUrlHistory].slice(0, 10)
                        setBaseUrlHistory(next)
                        try { window.localStorage.setItem('PERFZY_BASEURL_HISTORY', JSON.stringify(next)) } catch {}
                      }
                    }
                  }}
                />
                {showBaseUrlDropdown && baseUrlHistory.length > 0 && (
                  <div style={{
                    position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 9999,
                    background: '#161b22', border: '1px solid #30363d', borderRadius: 6,
                    marginTop: 2, boxShadow: '0 4px 16px rgba(0,0,0,0.5)', maxHeight: 200, overflowY: 'auto',
                  }}>
                    {baseUrlHistory.map((url, idx) => (
                      <div
                        key={idx}
                        style={{
                          padding: '7px 12px', fontSize: 13, color: '#c9d1d9', cursor: 'pointer',
                          borderBottom: idx < baseUrlHistory.length - 1 ? '1px solid #21262d' : 'none',
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.background = '#21262d'}
                        onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                        onMouseDown={() => {
                          const next = [...globalVars]
                          next[i] = { ...next[i], key: 'base_url', value: url }
                          setGlobalVars(next)
                          setShowBaseUrlDropdown(false)
                        }}
                      >
                        {url}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {/* Run All + Debug Mode — right-aligned inside the tile */}
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 6, alignItems: 'center' }}>
            <button
              type="button"
              style={smallBtnStyle}
              onClick={runAllRequests}
              disabled={tabs.length === 0}
            >
              Run All
            </button>
            <button
              type="button"
              style={{ ...smallBtnStyle, ...(debugMode ? { background: 'rgba(59,130,246,0.15)', color: '#60a5fa', borderColor: '#60a5fa' } : {}), position: 'relative' }}
              title="Run requests sequentially"
              onClick={() => {
                const next = !debugMode
                setDebugMode(next)
                if (next) {
                  // Clean slate: reset all execStatus so icons start fresh
                  setTabs((prev) => prev.map((t) => ({ ...t, execStatus: null })))
                  setDebugIndex(0)
                  const first = tabs.find((t) => !t.isArchived)
                  if (first) setActiveTabId(first.id)
                } else {
                  setDebugIndex(0)
                }
              }}
            >
              {debugMode && (
                <span style={{
                  position: 'absolute', top: 3, right: 4,
                  width: 6, height: 6, borderRadius: '50%',
                  background: '#22c55e',
                  animation: 'perfzy-dot-blink 1s ease-in-out infinite',
                  display: 'inline-block',
                }} />
              )}
              Sequential Run
            </button>
          </div>
        </div>

        {/* Create Script tile — aligned with right panel */}
        <div style={{ ...globalBarStyle, flex: `0 0 ${490 + sidebarDelta}px`, justifyContent: 'flex-end' }}>
          <button
            style={{ ...smallBtnStyle, background: '#1d9bf0', color: '#fff', border: '1px solid #1d9bf0' }}
            onClick={openScriptDialog}
          >
            Create Script
          </button>
        </div>
      </div>

      {/* Main layout */}
      <div style={{ display: 'flex', gap: 7, marginTop: 8 }}>

        {/* Flow panel with request tabs */}
        <div style={flowPanelStyle}>
          <div style={flowHeaderStyle}>Requests</div>
          <div style={flowTabsRowStyle}>
            <button
              type="button"
              style={{ ...flowTabBtnStyle, ...(flowTab === 'active' ? flowTabActiveStyle : {}) }}
              onClick={() => setFlowTab('active')}
            >
              Active
            </button>
            <button
              type="button"
              style={{ ...flowTabBtnStyle, ...(flowTab === 'archived' ? flowTabActiveStyle : {}) }}
              onClick={() => setFlowTab('archived')}
            >
              Archived
            </button>
          </div>
          <div
            style={flowListStyle}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => { reorderTabs(dragSrcId, dragOverId); setDragSrcId(null); setDragOverId(null) }}
          >
            {(flowTab === 'active'
              ? tabs.filter((t) => !t.isArchived)
              : tabs.filter((t) => t.isArchived)
            ).map((t, idx) => {
              const isActive = t.id === activeTabId
              const isDragOver = dragOverId === t.id && dragSrcId !== t.id
              const label = (t.name || '').trim() || `Request ${idx + 1}`
              // In sequential mode, show play icon on the scheduled-next request
              const seqStatus = (debugMode && flowTab === 'active' && idx === debugIndex)
                ? 'seq_next'
                : t.execStatus
              return (
                <div
                  key={t.id}
                  draggable
                  onDragStart={() => setDragSrcId(t.id)}
                  onDragEnter={() => setDragOverId(t.id)}
                  onDragEnd={() => { setDragSrcId(null); setDragOverId(null) }}
                  onClick={() => setActiveTabId(t.id)}
                  title={label}
                  style={{
                    ...flowItemStyle,
                    ...(isActive ? flowItemActiveStyle : flowItemInactiveStyle),
                    cursor: dragSrcId === t.id ? 'grabbing' : 'grab',
                    borderTop: isDragOver ? '2px solid #1d9bf0' : '2px solid transparent',
                    userSelect: 'none',
                  }}
                >
                  <span style={flowIndexStyle}>{idx + 1}</span>
                  <span style={flowLabelStyle}>{label}</span>
                  <ExecStatusIcon status={seqStatus} />
                </div>
              )
            })}
          </div>
          <button type="button" style={flowAddBtnStyle} onClick={addTab}>
            + New Request
          </button>
        </div>

        {/* LEFT PANEL: request designer */}
        <div style={leftPanelStyle}>
          {/* Center panel tab bar */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '8px 14px 0', borderBottom: '1px solid var(--ps-border)', flexShrink: 0, background: 'var(--ps-bg)' }}>
            <button
              type="button"
              style={{ ...detailTabBtnStyle, ...(centerTab === 'request_design' ? detailTabActiveStyle : {}), fontSize: 13 + rightPaneFontDelta }}
              onClick={() => setCenterTab('request_design')}
            >
              Request Design
            </button>
            <button
              type="button"
              style={{ ...detailTabBtnStyle, ...(centerTab === 'correlations' ? detailTabActiveStyle : {}), fontSize: 13 + rightPaneFontDelta }}
              onClick={() => setCenterTab('correlations')}
            >
              Correlations
              {(() => {
                const count = tabs.filter((t) => !t.isArchived).reduce((s, t) => s + (t.extractions || []).filter((e) => e.name && e.expression).length, 0)
                return count > 0 ? (
                  <span style={{ marginLeft: 5, fontSize: 10, background: centerTab === 'correlations' ? 'var(--ps-accent)' : 'rgba(139,152,165,0.3)', color: centerTab === 'correlations' ? '#fff' : 'var(--ps-text-muted)', borderRadius: 8, padding: '1px 5px', fontWeight: 600 }}>{count}</span>
                ) : null
              })()}
            </button>
            <button
              type="button"
              style={{ ...detailTabBtnStyle, ...(centerTab === 'parameters' ? detailTabActiveStyle : {}), fontSize: 13 + rightPaneFontDelta }}
              onClick={() => { setCenterTab('parameters'); setParamTableError(''); setManualParamDraft(null) }}
              title="Parameters captured across all requests"
            >
              Parameters
              {(() => {
                const count = tabs.filter((t) => !t.isArchived).reduce((s, t) => s + (t.parameters || []).length, 0)
                return count > 0 ? (
                  <span style={{ marginLeft: 5, fontSize: 10, background: centerTab === 'parameters' ? 'var(--ps-accent)' : 'rgba(139,152,165,0.3)', color: centerTab === 'parameters' ? '#fff' : 'var(--ps-text-muted)', borderRadius: 8, padding: '1px 5px', fontWeight: 600 }}>{count}</span>
                ) : null
              })()}
            </button>
          </div>

          {centerTab === 'request_design' && <div style={designerScrollStyle}>

            {/* ── Section 1: Request Name + Method/Path ── */}
            <div style={designerSectionStyle}>
              <div style={fieldRowStyle}>
                <label style={fieldLabelStyle}>Request Name</label>
                <input
                  style={{ ...dInputStyle, flex: 1 }}
                  value={activeTab.name}
                  onChange={(e) => updateTab(activeTabId, { name: e.target.value })}
                />
              </div>
              <div style={{ ...fieldRowStyle, marginTop: 10 }}>
                <label style={fieldLabelStyle}>Endpoint</label>
                <div style={{ display: 'flex', gap: 6, flex: 1 }}>
                  <select
                    style={{ ...dInputStyle, width: 100, flex: 'none', fontWeight: 600 }}
                    value={activeTab.method}
                    onChange={(e) => updateTab(activeTabId, { method: e.target.value })}
                  >
                    {['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].map((m) => <option key={m}>{m}</option>)}
                  </select>
                  <input
                    style={{ ...dInputStyle, flex: 1 }}
                    placeholder="/api/endpoint"
                    value={activeTab.path}
                    onChange={(e) => updateTab(activeTabId, { path: e.target.value })}
                  />
                </div>
              </div>
            </div>

            {/* ── Section 2: Authentication + Headers ── */}
            <div style={designerSectionStyle}>
              <div style={fieldRowStyle}>
                <label style={fieldLabelStyle}>Authentication</label>
                <select
                  style={{ ...dInputStyle, width: 190, flex: '0 0 auto' }}
                  value={activeTab.authType}
                  onChange={(e) => updateTab(activeTabId, { authType: e.target.value, authValue: {} })}
                >
                  <option value="none">None</option>
                  <option value="bearer">Bearer Token</option>
                  <option value="basic">Basic Auth</option>
                  <option value="apikey">API Key</option>
                  <option value="reuse">Reuse Previous</option>
                </select>
              </div>
              {activeTab.authType === 'bearer' && (
                <input style={{ ...dInputStyle, marginTop: 6, marginLeft: 110 }} placeholder="Token (or {{var}})" value={activeTab.authValue.token || ''} onChange={(e) => updateTab(activeTabId, { authValue: { token: e.target.value } })} />
              )}
              {activeTab.authType === 'basic' && (
                <div style={{ display: 'flex', gap: 6, marginTop: 6, marginLeft: 110 }}>
                  <input style={dInputStyle} placeholder="Username" value={activeTab.authValue.username || ''} onChange={(e) => updateTab(activeTabId, { authValue: { ...activeTab.authValue, username: e.target.value } })} />
                  <input style={dInputStyle} placeholder="Password" type="password" value={activeTab.authValue.password || ''} onChange={(e) => updateTab(activeTabId, { authValue: { ...activeTab.authValue, password: e.target.value } })} />
                </div>
              )}
              {activeTab.authType === 'apikey' && (
                <div style={{ display: 'flex', gap: 6, marginTop: 6, marginLeft: 110, flexWrap: 'wrap' }}>
                  <input style={{ ...dInputStyle, width: 130 }} placeholder="Key name" value={activeTab.authValue.key || ''} onChange={(e) => updateTab(activeTabId, { authValue: { ...activeTab.authValue, key: e.target.value } })} />
                  <input style={dInputStyle} placeholder="Value" value={activeTab.authValue.value || ''} onChange={(e) => updateTab(activeTabId, { authValue: { ...activeTab.authValue, value: e.target.value } })} />
                  <select style={{ ...dInputStyle, width: 100 }} value={activeTab.authValue.location || 'header'} onChange={(e) => updateTab(activeTabId, { authValue: { ...activeTab.authValue, location: e.target.value } })}>
                    <option value="header">Header</option>
                    <option value="query">Query</option>
                  </select>
                </div>
              )}

              <div style={{ marginTop: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label style={{ ...fieldLabelStyle, marginBottom: 0 }}>Headers</label>
                  <button type="button" style={addBtnStyle} onClick={() => updateTab(activeTabId, { headers: [...(activeTab.headers || []), { key: '', value: '' }] })}>+ Add</button>
                </div>
                {activeTab.headers.length === 0 && (
                  <div style={{ fontSize: 12, color: '#484f58', marginTop: 4 }}>No headers added</div>
                )}
                <div style={{ marginTop: 6 }}>
                  {activeTab.headers.map((h, i) => (
                    <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 5 }}>
                      <input style={{ ...dInputStyle, width: '40%' }} placeholder="Header name" value={h.key} onChange={(e) => { const next = [...activeTab.headers]; next[i] = { ...next[i], key: e.target.value }; updateTab(activeTabId, { headers: next }) }} />
                      <input style={{ ...dInputStyle, flex: 1 }} placeholder="Value" value={h.value} onChange={(e) => { const next = [...activeTab.headers]; next[i] = { ...next[i], value: e.target.value }; updateTab(activeTabId, { headers: next }) }} />
                      <button type="button" style={removeBtnStyle} onClick={() => updateTab(activeTabId, { headers: activeTab.headers.filter((_, j) => j !== i) })}>×</button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* ── Section 3: Body + Body Preview ── */}
            <div style={designerSectionStyle}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={fieldRowStyle}>
                  <label style={fieldLabelStyle}>Body</label>
                  <select
                    style={{ ...dInputStyle, width: 250, flex: '0 0 auto' }}
                    value={activeTab.payloadMode}
                    onChange={(e) => {
                      const mode = e.target.value
                      const patch = { payloadMode: mode }
                      if (mode === 'urlencoded' && !(activeTab.urlencodedFields && activeTab.urlencodedFields.length)) {
                        patch.urlencodedFields = [{ key: '', value: '' }]
                      }
                      updateTab(activeTabId, patch)
                    }}
                  >
                    <option value="none">None</option>
                    <option value="raw_json">Raw JSON</option>
                    <option value="json_kv">JSON Builder</option>
                    <option value="formdata">Form Data (multipart/form-data)</option>
                    <option value="urlencoded">x-www-form-urlencoded</option>
                  </select>
                </div>
                {activeTab.payloadMode === 'json_kv' && (
                  <button type="button" style={addBtnStyle} onClick={() => updateTab(activeTabId, { jsonFields: [...(activeTab.jsonFields || []), { key: '', value: '' }] })}>+ Add</button>
                )}
                {activeTab.payloadMode === 'formdata' && (
                  <button type="button" style={addBtnStyle} onClick={() => updateTab(activeTabId, { formFields: [...(activeTab.formFields || []), { key: '', type: 'text', value: '' }] })}>+ Add</button>
                )}
                {activeTab.payloadMode === 'urlencoded' && (
                  <button type="button" style={addBtnStyle} onClick={() => updateTab(activeTabId, { urlencodedFields: [...(activeTab.urlencodedFields || []), { key: '', value: '' }] })}>+ Add</button>
                )}
              </div>

              {activeTab.payloadMode === 'raw_json' && (
                <div style={{ marginTop: 8 }}>
                  <textarea
                    style={dTextareaStyle}
                    rows={6}
                    placeholder={'{\n  "email": "{{email}}",\n  "password": "{{password}}"\n}'}
                    value={activeTab.rawJson}
                    onChange={(e) => updateTab(activeTabId, { rawJson: e.target.value })}
                  />
                  {activeTab.rawJson && activeTab.rawJson.trim() && (() => {
                    try { JSON.parse(activeTab.rawJson); return null } catch {
                      return <div style={{ color: '#f85149', fontSize: 11, marginTop: 3 }}>Invalid JSON format</div>
                    }
                  })()}
                </div>
              )}

              {activeTab.payloadMode === 'json_kv' && (
                <div style={{ marginTop: 8 }}>
                  {(activeTab.jsonFields || []).map((field, idx) => (
                    <div key={idx} style={{ display: 'flex', gap: 6, marginBottom: 4 }}>
                      <input style={{ ...dInputStyle, width: '40%' }} placeholder="key" value={field.key} onChange={(e) => { const next = [...(activeTab.jsonFields || [])]; next[idx] = { ...next[idx], key: e.target.value }; updateTab(activeTabId, { jsonFields: next }) }} />
                      <input style={{ ...dInputStyle, flex: 1 }} placeholder="value (supports {{var}})" value={field.value} onChange={(e) => { const next = [...(activeTab.jsonFields || [])]; next[idx] = { ...next[idx], value: e.target.value }; updateTab(activeTabId, { jsonFields: next }) }} />
                      <button type="button" style={removeBtnStyle} onClick={() => updateTab(activeTabId, { jsonFields: (activeTab.jsonFields || []).filter((_, j) => j !== idx) })}>×</button>
                    </div>
                  ))}
                </div>
              )}

              {activeTab.payloadMode === 'formdata' && (
                <div style={{ marginTop: 8 }}>
                  {(activeTab.formFields || []).map((field, idx) => (
                    <div key={idx} style={{ display: 'flex', gap: 6, marginBottom: 4, flexWrap: 'wrap' }}>
                      <input style={{ ...dInputStyle, width: 130 }} placeholder="key" value={field.key} onChange={(e) => { const next = [...(activeTab.formFields || [])]; next[idx] = { ...next[idx], key: e.target.value }; updateTab(activeTabId, { formFields: next }) }} />
                      <select style={{ ...dInputStyle, width: 90 }} value={field.type} onChange={(e) => { const next = [...(activeTab.formFields || [])]; next[idx] = { ...next[idx], type: e.target.value }; updateTab(activeTabId, { formFields: next }) }}>
                        <option value="text">text</option>
                        <option value="file">file</option>
                      </select>
                      {field.type === 'file' ? (
                        <input style={{ ...dInputStyle, flex: 1 }} type="file" onChange={(e) => { const file = e.target.files && e.target.files[0]; const next = [...(activeTab.formFields || [])]; next[idx] = { ...next[idx], value: file ? file.name : '' }; updateTab(activeTabId, { formFields: next }) }} />
                      ) : (
                        <input style={{ ...dInputStyle, flex: 1 }} placeholder="value (supports {{var}})" value={field.value} onChange={(e) => { const next = [...(activeTab.formFields || [])]; next[idx] = { ...next[idx], value: e.target.value }; updateTab(activeTabId, { formFields: next }) }} />
                      )}
                      <button type="button" style={removeBtnStyle} onClick={() => updateTab(activeTabId, { formFields: (activeTab.formFields || []).filter((_, j) => j !== idx) })}>×</button>
                    </div>
                  ))}
                </div>
              )}

              {activeTab.payloadMode === 'urlencoded' && (
                <div style={{ marginTop: 8 }}>
                  {(activeTab.urlencodedFields || []).map((field, idx) => (
                    <div key={idx} style={{ display: 'flex', gap: 6, marginBottom: 4 }}>
                      <input style={{ ...dInputStyle, width: '40%' }} placeholder="key" value={field.key} onChange={(e) => { const next = [...(activeTab.urlencodedFields || [])]; next[idx] = { ...next[idx], key: e.target.value }; updateTab(activeTabId, { urlencodedFields: next }) }} />
                      <input style={{ ...dInputStyle, flex: 1 }} placeholder="value (supports {{var}})" value={field.value} onChange={(e) => { const next = [...(activeTab.urlencodedFields || [])]; next[idx] = { ...next[idx], value: e.target.value }; updateTab(activeTabId, { urlencodedFields: next }) }} />
                      <button type="button" style={removeBtnStyle} onClick={() => updateTab(activeTabId, { urlencodedFields: (activeTab.urlencodedFields || []).filter((_, j) => j !== idx) })}>×</button>
                    </div>
                  ))}
                </div>
              )}

              {activeTab.payloadMode !== 'none' && (
                <div style={{ marginTop: 10 }}>
                  <label style={{ ...fieldLabelStyle, fontSize: 12 }}>Body Preview</label>
                  <pre style={dPreStyle}>
                    {(() => {
                      if (activeTab.payloadMode === 'raw_json') return activeTab.rawJson || ''
                      if (activeTab.payloadMode === 'json_kv') {
                        const obj = {}; (activeTab.jsonFields || []).forEach(({ key, value }) => { if (key && key.trim()) obj[key] = value }); return JSON.stringify(obj, null, 2)
                      }
                      if (activeTab.payloadMode === 'formdata') return (activeTab.formFields || []).filter(({ key }) => key && key.trim()).map(({ key, type, value }) => `${key}: ${type === 'file' ? '<file>' : value || ''}`).join('\n')
                      if (activeTab.payloadMode === 'urlencoded') return (activeTab.urlencodedFields || []).filter(({ key }) => key && key.trim()).map(({ key, value }) => `${key}=${encodeURIComponent(value || '')}`).join('&')
                      return ''
                    })()}
                  </pre>
                </div>
              )}
            </div>

            {/* ── Section 4: Extractions ── */}
            <div style={{ ...designerSectionStyle, borderBottom: 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label style={{ ...fieldLabelStyle, marginBottom: 0 }}>Extractions</label>
                <button type="button" style={addBtnStyle} onClick={() => updateTab(activeTabId, { extractions: [...activeTab.extractions, { name: '', source: 'json_path', expression: '' }] })}>+ Add</button>
              </div>
              {activeTab.extractions.length === 0 && (
                <div style={{ fontSize: 12, color: '#484f58', marginTop: 6 }}>No extraction rules defined</div>
              )}
              <div style={{ marginTop: 6 }}>
                {activeTab.extractions.map((ext, i) => (
                  <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 5, flexWrap: 'wrap' }}>
                    <input style={{ ...dInputStyle, width: 110 }} placeholder="var name" value={ext.name} onChange={(e) => { const next = [...activeTab.extractions]; next[i] = { ...next[i], name: e.target.value }; updateTab(activeTabId, { extractions: next }) }} />
                    <select style={{ ...dInputStyle, width: 115 }} value={ext.source} onChange={(e) => { const next = [...activeTab.extractions]; next[i] = { ...next[i], source: e.target.value }; updateTab(activeTabId, { extractions: next }) }}>
                      <option value="json_path">JSON Path</option>
                      <option value="header">Header</option>
                      <option value="regex">Regex</option>
                      <option value="boundary">Boundary</option>
                    </select>
                    <input style={{ ...dInputStyle, flex: 1 }} placeholder="$.data.token" value={ext.expression} onChange={(e) => { const next = [...activeTab.extractions]; next[i] = { ...next[i], expression: e.target.value }; updateTab(activeTabId, { extractions: next }) }} />
                    <button type="button" style={removeBtnStyle} onClick={() => updateTab(activeTabId, { extractions: activeTab.extractions.filter((_, j) => j !== i) })}>×</button>
                  </div>
                ))}
              </div>

            </div>

          </div>}

          {centerTab === 'correlations' && (
            <div style={{ ...designerScrollStyle, padding: '14px 16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text)' }}>Correlations</div>
              </div>
              <p style={{ fontSize: 12, color: 'var(--ps-text-muted)', marginBottom: 14, marginTop: 0, lineHeight: 1.5 }}>
                Dynamic values captured from responses are listed below and can be reused in subsequent requests at runtime. Use <code style={{ fontFamily: 'monospace', color: 'var(--ps-accent)' }}>{'{{Variable_name}}'}</code> in any request to reference them.
              </p>
              {(() => {
                const allTabsWithExtractions = tabs.filter(
                  (t) => !t.isArchived && (t.extractions || []).some((e) => e.name && e.expression)
                )
                if (allTabsWithExtractions.length === 0) {
                  return (
                    <div style={{ fontSize: 13, color: 'var(--ps-text-muted)', padding: '24px 0', textAlign: 'center' }}>
                      No extraction rules defined yet.<br />
                      <span style={{ fontSize: 12 }}>Add extractions in the &quot;Request Design&quot; tab to correlate values across requests.</span>
                    </div>
                  )
                }
                const sourceColors = {
                  json_path: { bg: 'rgba(29,155,240,0.15)',  color: '#1d9bf0',  label: 'JSON' },
                  header:    { bg: 'rgba(168,85,247,0.15)',  color: '#a855f7',  label: 'HDR' },
                  regex:     { bg: 'rgba(34,197,94,0.15)',   color: '#22c55e',  label: 'RGX' },
                  boundary:  { bg: 'rgba(251,146,60,0.15)',  color: '#fb923c',  label: 'BND' },
                }
                return (
                  <div style={{ background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 8, overflow: 'hidden' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                      <colgroup>
                        <col style={{ width: '52px' }} />
                        <col style={{ width: '120px' }} />
                        <col />
                        <col style={{ width: '110px' }} />
                        <col style={{ width: '28px' }} />
                      </colgroup>
                      <thead>
                        <tr style={{ background: 'var(--ps-bg)', borderBottom: '1px solid var(--ps-border)' }}>
                          {['TYPE', 'VARIABLE NAME', 'EXPRESSION', 'CAPTURED VALUE', ''].map((h, i) => (
                            <th key={i} style={{ padding: '6px 8px', textAlign: 'left', fontSize: 10, fontWeight: 600, color: 'var(--ps-text-muted)', letterSpacing: 0.4, whiteSpace: 'nowrap' }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {allTabsWithExtractions.map((t) => (
                          <React.Fragment key={t.id}>
                            <tr>
                              <td colSpan={5} style={{
                                padding: '5px 8px 4px',
                                fontSize: 10,
                                fontWeight: 600,
                                color: 'var(--ps-text-muted)',
                                background: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.03)',
                                borderBottom: '1px solid var(--ps-border)',
                                letterSpacing: 0.3,
                              }}>
                                <span style={{ opacity: 0.6, marginRight: 4 }}>REQUEST</span>
                                <span style={{ color: 'var(--ps-text)', fontWeight: 700 }}>{t.name || 'Unnamed'}</span>
                                {t.id === activeTabId && (
                                  <span style={{ marginLeft: 6, fontSize: 9, background: 'var(--ps-accent)', color: '#fff', borderRadius: 3, padding: '1px 4px', verticalAlign: 'middle', opacity: 0.85 }}>current</span>
                                )}
                              </td>
                            </tr>
                            {(t.extractions || []).filter((e) => e.name && e.expression).map((ext, i) => {
                              const sc = sourceColors[ext.source] || sourceColors.json_path
                              const capturedVal = variableCtx[ext.name]
                              return (
                                <tr key={i} style={{ borderBottom: '1px solid var(--ps-border)' }}>
                                  <td style={{ padding: '6px 8px' }}>
                                    <span style={{ display: 'inline-block', fontSize: 9, fontWeight: 700, background: sc.bg, color: sc.color, borderRadius: 4, padding: '2px 5px', letterSpacing: 0.3 }}>{sc.label}</span>
                                  </td>
                                  <td style={{ padding: '6px 8px' }}>
                                    <input
                                      style={{ ...dInputStyle, fontSize: 12, width: '100%', padding: '3px 6px' }}
                                      value={ext.name}
                                      onChange={(e) => {
                                        const oldName = ext.name
                                        const newName = e.target.value
                                        const next = [...(t.extractions || [])]
                                        const realIdx = (t.extractions || []).indexOf(ext)
                                        next[realIdx] = { ...next[realIdx], name: newName }
                                        updateTab(t.id, { extractions: next })
                                        if (oldName && oldName !== newName) {
                                          setVariableCtx((prev) => {
                                            const updated = { ...prev }
                                            if (oldName in updated) {
                                              if (newName) updated[newName] = updated[oldName]
                                              delete updated[oldName]
                                            }
                                            return updated
                                          })
                                        }
                                      }}
                                    />
                                  </td>
                                  <td style={{ padding: '6px 8px' }}>
                                    <input
                                      style={{ ...dInputStyle, fontSize: 12, width: '100%', padding: '3px 6px' }}
                                      value={ext.expression}
                                      onChange={(e) => {
                                        const next = [...(t.extractions || [])]
                                        const realIdx = (t.extractions || []).indexOf(ext)
                                        next[realIdx] = { ...next[realIdx], expression: e.target.value }
                                        updateTab(t.id, { extractions: next })
                                      }}
                                    />
                                  </td>
                                  <td style={{ padding: '6px 8px' }}>
                                    {capturedVal != null ? (
                                      <span style={{ fontSize: 11, color: '#7ee787', fontFamily: 'monospace', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={String(capturedVal)}>
                                        {String(capturedVal).substring(0, 24)}{String(capturedVal).length > 24 ? '…' : ''}
                                      </span>
                                    ) : (
                                      <span style={{ fontSize: 11, color: 'var(--ps-text-muted)', opacity: 0.5 }}>—</span>
                                    )}
                                  </td>
                                  <td style={{ padding: '4px 6px', textAlign: 'center' }}>
                                    <button
                                      type="button"
                                      style={{ ...removeBtnStyle, fontSize: 13, padding: '1px 5px' }}
                                      onClick={() => {
                                        const next = (t.extractions || []).filter((e) => e !== ext)
                                        updateTab(t.id, { extractions: next })
                                        if (ext.name) {
                                          setVariableCtx((prev) => {
                                            const updated = { ...prev }
                                            delete updated[ext.name]
                                            return updated
                                          })
                                        }
                                      }}
                                    >×</button>
                                  </td>
                                </tr>
                              )
                            })}
                          </React.Fragment>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              })()}
              {/* Runtime captured values summary — only show entries matching current extraction names */}
              {(() => {
                const activeExtNames = new Set(
                  tabs.filter((t) => !t.isArchived)
                    .flatMap((t) => (t.extractions || []).map((e) => e.name).filter(Boolean))
                )
                const filtered = Object.entries(variableCtx).filter(([k]) => activeExtNames.has(k))
                if (filtered.length === 0) return null
                return (
                  <div style={{ marginTop: 16, background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 8, padding: '10px 12px' }}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--ps-text-muted)', letterSpacing: 0.4, marginBottom: 8 }}>RUNTIME CAPTURED VALUES</div>
                    <div style={{ fontSize: 12, lineHeight: 1.9 }}>
                      {filtered.map(([k, v]) => (
                        <div key={k} style={{ display: 'flex', gap: 6, alignItems: 'baseline' }}>
                          <span style={{ color: '#d2a8ff', fontFamily: 'monospace', whiteSpace: 'nowrap' }}>{'{{' + k + '}}'}</span>
                          <span style={{ color: 'var(--ps-text-muted)', fontSize: 10 }}>=</span>
                          <span style={{ color: '#7ee787', fontFamily: 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 240 }} title={String(v)}>{String(v).substring(0, 60)}{String(v).length > 60 ? '…' : ''}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })()}
            </div>
          )}

          {centerTab === 'parameters' && (
            <div style={{ ...designerScrollStyle, padding: '14px 16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text)' }}>All Parameters</div>
                <button
                  type="button"
                  style={{
                    ...smallBtnStyle,
                    background: isDark ? 'rgba(35,134,54,0.2)' : 'rgba(22,101,52,0.12)',
                    color: isDark ? '#7ee787' : '#166534',
                    border: isDark ? '1px solid rgba(35,134,54,0.4)' : '1px solid rgba(22,101,52,0.35)',
                  }}
                  onClick={() => { setManualParamDraft({ key: '', customName: '', value: '' }); setParamNameError('') }}
                >
                  + Add Parameter
                </button>
              </div>
              <p style={{ fontSize: 12, color: 'var(--ps-text-muted)', marginBottom: 12, marginTop: 0, lineHeight: 1.5 }}>
                All parameters used across requests. Use <code style={{ fontFamily: 'monospace', color: 'var(--ps-accent)' }}>{'{{parameter_name}}'}</code> in any request to reference them.
              </p>
              {paramTableError && (
                <div style={{ fontSize: 12, color: '#f85149', background: 'rgba(248,81,73,0.08)', border: '1px solid rgba(248,81,73,0.3)', borderRadius: 6, padding: '6px 10px', marginBottom: 10 }}>
                  {paramTableError}
                </div>
              )}
              {(() => {
                const allParams = tabs.filter((t) => !t.isArchived && t.parameters && t.parameters.length > 0)
                  .flatMap((t) => t.parameters.map((p, idx) => ({ ...p, _tabId: t.id, _idx: idx })))
                if (allParams.length === 0 && !manualParamDraft) {
                  return (
                    <div style={{ fontSize: 13, color: 'var(--ps-text-muted)', padding: '20px 0', textAlign: 'center' }}>
                      No parameters defined.<br />
                      <span style={{ fontSize: 12, color: 'var(--ps-text-muted)' }}>Run requests to detect parameters automatically, or click &quot;+ Add Parameter&quot; to add one manually.</span>
                    </div>
                  )
                }
                return (
                  <div style={{ background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 8, overflow: 'hidden', marginBottom: 10 }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                      <colgroup>
                        <col />
                        <col />
                        <col />
                        <col style={{ width: '34px' }} />
                      </colgroup>
                      <thead>
                        <tr style={{ background: 'var(--ps-bg)', borderBottom: '1px solid var(--ps-border)' }}>
                          {['KEY','PARAMETER NAME','VALUE',''].map((h, i) => (
                            <th key={i} style={{ padding: '6px 10px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: 'var(--ps-text-muted)', letterSpacing: 0.4, borderBottom: '1px solid var(--ps-border)', whiteSpace: 'nowrap' }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {allParams.map((p) => (
                          <ParamRowNoSource
                            key={`${p._tabId}-${p._idx}`}
                            param={p}
                            onRename={(newName) => handleRenameParamForTab(p._tabId, p._idx, newName)}
                            onValueChange={(newVal) => handleValueChangeForTab(p._tabId, p._idx, newVal)}
                            onDelete={() => handleDeleteParamForTab(p._tabId, p._idx)}
                          />
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              })()}
              {/* Manual add param modal */}
            </div>
          )}

          {/* Bottom toolbar */}
          <div style={toolbarFooterStyle}>
            <div style={{ display: 'flex', gap: 10 }}>
              <button
                type="button"
                style={toolbarIconBtnStyle}
                title="Save request"
                onClick={() => persistWorkspace()}
              >
                <SaveIcon />
              </button>
              <button type="button" style={toolbarIconBtnStyle} title={activeTab.isArchived ? 'Unarchive request' : 'Archive request'} onClick={() => updateTab(activeTabId, { isArchived: !activeTab.isArchived })}>
                <ArchiveIcon />
              </button>
              <button type="button" style={toolbarIconBtnStyle} title="Show Java code" onClick={() => openCodeModal('java')}>
                <JavaIcon />
              </button>
              <button type="button" style={toolbarIconBtnStyle} title="Show Python code" onClick={() => openCodeModal('python')}>
                <PythonIcon />
              </button>
              <button type="button" style={toolbarDeleteBtnStyle} title="Delete request" onClick={() => setShowDeleteConfirm(true)}>
                <TrashIcon />
              </button>
            </div>
            <button
              type="button"
              style={{
                ...toolbarRunBtnStyle,
                ...(runHover && !isRunning ? toolbarRunHoverStyle : {}),
                ...(debugMode && !isRunning ? { animation: 'perfzy-glow-pulse 1.8s ease-in-out infinite' } : {}),
              }}
              onClick={handleRun}
              disabled={isRunning}
              title={debugMode ? 'Execute next request' : 'Run request'}
              onMouseEnter={() => setRunHover(true)}
              onMouseLeave={() => setRunHover(false)}
            >
              {isRunning ? <SpinnerIcon /> : debugMode ? <FastForwardIcon /> : <RunIcon />}
            </button>
          </div>
        </div>

        {/* RIGHT PANEL — Response Viewer */}
        <div style={{ ...rightPanelStyle, flex: `0 0 ${490 + sidebarDelta}px` }}>
          {!resp ? (
            <div style={{ color: '#d1d5db', padding: 24, fontSize: 13, flex: 1, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
              <div style={{ maxWidth: '100%', textAlign: 'left', lineHeight: 1.6 }}>
                <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 4, borderBottom: '1px solid #374151', paddingBottom: 6, textAlign: 'center' }}>
                  Welcome to Perfzy API Flow Builder
                </div>
                <div style={{ fontSize: 13.5, color: '#6b7280', marginBottom: 16, textAlign: 'center' }}>
                  Build API workflows and generate performance scripts in minutes.
                </div>

                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontWeight: 600, marginBottom: 4 }}>🚀 Quick Start</div>
                  <div style={{ display: 'flex', gap: 32 }}>
                    <ol style={{ paddingLeft: 18, margin: 0, color: '#6b7280', fontSize: 13.5, flex: 1 }}>
                      <li>Add a request</li>
                      <li>Configure method &amp; endpoint</li>
                      <li>Add headers or body</li>
                    </ol>
                    <ol start={4} style={{ paddingLeft: 18, margin: 0, color: '#6b7280', fontSize: 13.5, flex: 1 }}>
                      <li>Run the request</li>
                      <li>Extract values if needed</li>
                      <li>Generate script</li>
                    </ol>
                  </div>
                </div>

                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontWeight: 600, marginBottom: 4 }}>💡 Tip</div>
                  <div style={{ color: '#6b7280' }}>
                    Use variables like <span style={{ color: '#d2a8ff' }}>{'{{email}}'}</span> or <span style={{ color: '#d2a8ff' }}>{'{{token}}'}</span> to reuse values across requests.
                    Manage them using the <span style={{ color: '#e5e7eb' }}>Parameters</span> button at the top.
                  </div>
                </div>

                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontWeight: 600, marginBottom: 4 }}>🔗 Dynamic Values</div>
                  <div style={{ color: '#6b7280' }}>
                    Use <span style={{ color: '#e5e7eb' }}>&quot;Extractions&quot;</span> to capture values from responses like tokens, session IDs, or user IDs and reuse them in later requests.
                  </div>
                </div>

                <div>
                  <div style={{ fontWeight: 600, marginBottom: 4 }}>⚡ Generate Script</div>
                  <ol style={{ paddingLeft: 18, margin: 0, color: '#6b7280', fontSize: 13.5 }}>
                    <li>Simulate a complete testing flow by executing multiple API requests in sequence.</li>
                    <li>Create a single script using selective requests, which you can execute here itself with correlation auto handled.</li>
                    <li>Create a Java or Python performance script with one click.</li>
                  </ol>
                </div>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontSize: 13 + rightPaneFontDelta }}>
              {/* Request/Response/Recommendations tabs — always-visible tab bar */}
              <div style={{ ...detailTabsRowStyle, flexShrink: 0, padding: '10px 14px 0', marginBottom: 0 }}>
                <button
                  type="button"
                  style={{ ...detailTabBtnStyle, fontSize: 13 + rightPaneFontDelta, ...(detailTab === 'request' ? detailTabActiveStyle : {}) }}
                  onClick={() => setDetailTab('request')}
                >
                  Request
                </button>
                <button
                  type="button"
                  style={{ ...detailTabBtnStyle, fontSize: 13 + rightPaneFontDelta, ...(detailTab === 'response' ? detailTabActiveStyle : {}) }}
                  onClick={() => setDetailTab('response')}
                >
                  Response
                </button>
                <button
                  type="button"
                  style={{ ...detailTabBtnStyle, fontSize: 13 + rightPaneFontDelta, ...(detailTab === 'recommendations' ? detailTabActiveStyle : {}) }}
                  onClick={() => {
                    setDetailTab('recommendations')
                    try { window.sessionStorage.setItem(PERFZY_SEEN_REC_PREFIX + activeTabId, '1') } catch {}
                    setHasSeenRecommendations(true)
                  }}
                  title="Performance and best-practice recommendations"
                >
                  Recommendations
                  {resp && !hasSeenRecommendations && (
                    (() => {
                      let badgeContent = null
                      let bg = ''
                      let fg = '#fff'
                      if (criticalCount > 0) {
                        const total = criticalCount + warningCount
                        badgeContent = total
                        bg = '#b91c1c'
                      } else if (warningCount > 0) {
                        badgeContent = warningCount
                        bg = '#f97316'
                      } else if (infoCount > 0) {
                        badgeContent = infoCount
                        bg = '#d97706'
                      } else {
                        badgeContent = '✓'
                        bg = '#16a34a'
                      }
                      return (
                        <span
                          style={{
                            marginLeft: 6,
                            minWidth: 16,
                            height: 16,
                            padding: '0 4px',
                            borderRadius: 999,
                            background: bg,
                            color: fg,
                            fontSize: 10,
                            fontWeight: 700,
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            lineHeight: 1,
                          }}
                        >
                          {badgeContent}
                        </span>
                      )
                    })()
                  )}
                </button>
              </div>

              {/* Tab content — scrollable, always fills remaining height */}
              <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', padding: '10px 14px 14px', minHeight: 0 }}>

              {detailTab === 'request' && (
                <>
                  <div style={{ ...sectionHeadStyle, fontSize: 14 + rightPaneFontDelta }}>Sent Request</div>
                  <div style={{ fontSize: 13 + rightPaneFontDelta, color: isDark ? '#8b98a5' : '#374151', marginBottom: 6 }}>
                    <span style={methodBadgeStyle(resp.sent_method)}>{resp.sent_method}</span>{' '}
                    <span style={{ color: isDark ? '#e7e9ea' : '#111827', wordBreak: 'break-all' }}>{resp.sent_url}</span>
                  </div>
                  <CollapsibleSection title="Headers" defaultOpen>
                    <KVTable data={resp.sent_headers || {}} />
                  </CollapsibleSection>
                  <CollapsibleSection title="Request Body" defaultOpen>
                    <pre style={preStyle}>
                      {(() => {
                        if (activeTab.lastRequestPreview && activeTab.lastRequestPreview.trim()) {
                          return activeTab.lastRequestPreview
                        }
                        if (resp.sent_payload == null) return 'No request body'
                        if (typeof resp.sent_payload === 'string') return resp.sent_payload
                        try {
                          return JSON.stringify(resp.sent_payload, null, 2)
                        } catch {
                          return String(resp.sent_payload)
                        }
                      })()}
                    </pre>
                  </CollapsibleSection>
                </>
              )}

              {detailTab === 'response' && (
                <>
                  {resp.error && !resp.status_code ? (
                    <div style={{ color: '#f85149', fontSize: 13 + rightPaneFontDelta }}>Error: {resp.error}</div>
                  ) : (
                    <>
                      <div style={{ ...sectionHeadStyle, fontSize: 14 + rightPaneFontDelta, display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span>Response</span>
                          <StatusBadge code={resp.status_code} />
                        </div>
                        {resp.elapsed_ms > 0 && (
                          <span style={{ flex: 1, textAlign: 'center', fontSize: 13 + rightPaneFontDelta, color: '#8b98a5' }}>
                            Response Time: {formatElapsed(resp.elapsed_ms)}
                          </span>
                        )}
                        {responseSizeLabel && (
                          <span style={{ flex: 1, textAlign: 'right', fontSize: 13 + rightPaneFontDelta, color: '#8b98a5' }}>
                            {responseSizeLabel}
                          </span>
                        )}
                      </div>
                      <CollapsibleSection
                        key={`headers-${resp.elapsed_ms || 0}-${resp.status_code || ''}`}
                        title="Headers"
                        defaultOpen={false}
                      >
                        <KVTable data={resp.headers} />
                      </CollapsibleSection>
                      <CollapsibleSection title="Body" defaultOpen>
                        <pre style={preStyle}>{formatBody(resp.body, resp.headers)}</pre>
                      </CollapsibleSection>
                    </>
                  )}

                  {resp.extracted_values && Object.keys(resp.extracted_values).length > 0 && (
                    <div style={{ marginTop: 10 }}>
                      <div style={{ ...sectionHeadStyle, fontSize: 14 + rightPaneFontDelta }}>Extracted Values</div>
                      {Object.entries(resp.extracted_values).map(([k, v]) => (
                        <div key={k} style={{ fontSize: 13 + rightPaneFontDelta, marginBottom: 3, wordBreak: 'break-all' }}>
                          <span style={{ color: '#d2a8ff' }}>{k}</span> ={' '}
                          <span style={{ color: '#7ee787' }}>{String(v)}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {resp.suggested_extractions && (() => {
                    const acceptedSet = recentlyAccepted[activeTabId] || new Set()
                    // Items still pending (not added to extractions AND not recently accepted via this session's +)
                    const pendingItems = resp.suggested_extractions.filter(
                      (s) => !activeTab.extractions.some((e) => e.name === s.name) && !acceptedSet.has(s.name)
                    )
                    // Items that were just accepted this session (show confirmation)
                    const justAccepted = resp.suggested_extractions.filter((s) => acceptedSet.has(s.name))
                    if (pendingItems.length === 0 && justAccepted.length === 0) return null
                    return (
                      <div style={{ marginTop: 10 }}>
                        <div style={{ ...sectionHeadStyle, fontSize: 14 + rightPaneFontDelta }}>Suggested Extractions</div>
                        {justAccepted.map((s, i) => (
                          <div
                            key={`accepted-${i}`}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: 6,
                              marginBottom: 4,
                              fontSize: 12 + rightPaneFontDelta,
                              color: isDark ? '#7ee787' : '#166534',
                              fontStyle: 'italic',
                              opacity: 0.85,
                            }}
                          >
                            <span style={{ fontSize: 13 }}>✓</span>
                            <span>
                              <strong>{s.name}</strong> has been added to Correlations tab and can be used in subsequent requests.
                            </span>
                          </div>
                        ))}
                        {pendingItems.slice(0, 10).map((s, i) => (
                          <div
                            key={i}
                            style={{
                              display: 'flex',
                              alignItems: 'flex-start',
                              flexWrap: 'wrap',
                              gap: 8,
                              marginBottom: 4,
                              fontSize: 13 + rightPaneFontDelta,
                            }}
                          >
                            <button
                              style={{
                                ...smallBtnStyle,
                                fontSize: 12,
                                padding: '2px 8px',
                                flexShrink: 0,
                              }}
                              onClick={() => acceptSuggestion(s)}
                            >
                              +
                            </button>
                            <span style={{ color: '#d2a8ff', flexShrink: 0 }}>{s.name}</span>
                            <span style={{ color: '#6e7681', flexShrink: 0 }}>({s.source})</span>
                            <span style={{ color: '#7ee787', wordBreak: 'break-all' }}>{s.preview}</span>
                          </div>
                        ))}
                        {pendingItems.length > 10 && (
                          <div style={{ fontSize: 11, color: 'var(--ps-text-muted)', marginTop: 4, opacity: 0.7 }}>
                            Showing top 10 of {pendingItems.length}. Use Correlation Assistant for full search.
                          </div>
                        )}
                      </div>
                    )
                  })()}

                  {/* Assistant buttons */}
                  {resp.body && (
                    <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                      <button
                        type="button"
                        style={{ padding: '3px 10px', fontSize: 11, fontWeight: 600, borderRadius: 4, border: '1px solid var(--ps-accent)', background: 'transparent', color: 'var(--ps-accent)', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}
                        onClick={() => { setCorrSearch(''); setCorrSelected(null); setCorrInstanceMode('first'); setCorrSpecificIndex(0); setShowCorrAssistant(true) }}
                      >
                        🔍 Correlation Assistant
                      </button>
                      <button
                        type="button"
                        style={{ padding: '3px 10px', fontSize: 11, fontWeight: 600, borderRadius: 4, border: isDark ? '1px solid rgba(35,134,54,0.5)' : '1px solid rgba(22,101,52,0.4)', background: 'transparent', color: isDark ? '#7ee787' : '#166534', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}
                        onClick={openParamsAssistant}
                      >
                        ⚙ Parameters Assistant
                      </button>
                    </div>
                  )}
                </>
              )}

              {detailTab === 'recommendations' && (
                <div>
                  <div style={{ ...sectionHeadStyle, fontSize: 14 + rightPaneFontDelta, marginBottom: 10 }}>Performance and best-practice recommendations</div>
                  <div style={{ borderTop: '1px solid var(--ps-border)', margin: '4px 0 6px' }} />
                  <div style={{ fontSize: 12, color: 'var(--ps-text-muted)', display: 'flex', gap: 12 }}>
                    <span>
                      <span style={{ fontWeight: 600 }}>CRITICAL:</span>{' '}
                      <span style={{ color: criticalCount > 0 ? '#f97373' : 'var(--ps-text-muted)' }}>{criticalCount}</span>
                    </span>
                    <span>
                      <span style={{ fontWeight: 600 }}>WARNING:</span>{' '}
                      <span style={{ color: warningCount > 0 ? '#facc15' : 'var(--ps-text-muted)' }}>{warningCount}</span>
                    </span>
                    <span>
                      <span style={{ fontWeight: 600 }}>INFO:</span>{' '}
                      <span style={{ color: infoCount > 0 ? '#38bdf8' : 'var(--ps-text-muted)' }}>{infoCount}</span>
                    </span>
                  </div>
                  <div style={{ borderTop: '1px solid var(--ps-border)', margin: '6px 0 10px' }} />
                  {!resp && (
                    <div style={{ fontSize: 13 + rightPaneFontDelta, color: 'var(--ps-text-muted)' }}>
                      Run the request to see performance and best-practice recommendations for this endpoint.
                    </div>
                  )}
                  {resp && recommendations.length === 0 && (
                    <div style={{ fontSize: 13 + rightPaneFontDelta, color: 'var(--ps-text-muted)' }}>
                      No specific recommendations detected for this response. Try exercising more flows or adjusting payloads.
                    </div>
                  )}
                  {resp && recommendations.length > 0 && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                      {([...recommendations].sort((a, b) => {
                        const order = { critical: 0, warning: 1, info: 2 }
                        return (order[a.severity] ?? 3) - (order[b.severity] ?? 3)
                      })).map((rec, idx) => {
                        const color =
                          rec.severity === 'critical'
                            ? '#f85149'
                            : rec.severity === 'warning'
                              ? '#facc15'
                              : '#38bdf8'
                        const badgeBg =
                          rec.severity === 'critical'
                            ? 'rgba(248,81,73,0.12)'
                            : rec.severity === 'warning'
                              ? 'rgba(250,204,21,0.12)'
                              : 'rgba(56,189,248,0.12)'
                        const label =
                          rec.severity === 'critical'
                            ? 'CRITICAL'
                            : rec.severity === 'warning'
                              ? 'WARNING'
                              : 'INFO'
                        return (
                          <div
                            key={idx}
                            style={{
                              border: '1px solid var(--ps-border)',
                              borderRadius: 8,
                              padding: '8px 10px',
                              background: 'var(--ps-card)',
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span
                                  style={{
                                    fontSize: 10,
                                    fontWeight: 700,
                                    letterSpacing: 0.6,
                                    padding: '2px 6px',
                                    borderRadius: 999,
                                    color,
                                    background: badgeBg,
                                  }}
                                >
                                  {label}
                                </span>
                                <span style={{ fontSize: 13 + rightPaneFontDelta, fontWeight: 600, color: 'var(--ps-text)' }}>{rec.title}</span>
                              </div>
                              {rec.category && (
                                <span style={{ fontSize: 11, color: 'var(--ps-text-muted)' }}>{rec.category}</span>
                              )}
                            </div>
                            {rec.details && (
                              <div style={{ fontSize: 12.5, color: 'var(--ps-text-2)', marginBottom: 3 }}>
                                {highlightMetrics(rec.details)}
                              </div>
                            )}
                            {rec.recommendation && (
                              <div style={{ fontSize: 12.5, color: 'var(--ps-text-muted)' }}>
                                <span style={{ fontWeight: 600 }}>Recommendation:</span>{' '}
                                <span>{rec.recommendation}</span>
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              )}


              </div>{/* end tab content scroll */}
            </div>
          )}
        </div>
      </div>

      {/* Script Dialog Modal */}
      {showScriptDialog && (
        <div style={overlayStyle}>
          <div style={{ ...dialogStyle, width: 480 }}>
            <h3 style={{ margin: '0 0 6px', fontSize: 16, color: 'var(--ps-text)' }}>Create Performance Script</h3>
            <p style={{ margin: '0 0 14px', fontSize: 13, color: 'var(--ps-text-muted)', lineHeight: 1.5 }}>
              Please select requests to be included in the generated Python script.
            </p>

            <label style={{ ...labelStyle, display: 'flex', alignItems: 'center', gap: 6 }}>
              Script Name
              <span style={{ color: '#f85149', fontSize: 13 }}>*</span>
            </label>
            <input
              style={{ ...inputStyle, marginBottom: scriptNameError ? 4 : 14, width: '100%', ...(scriptNameError ? { borderColor: '#f85149' } : {}) }}
              placeholder="My API Script"
              value={scriptName}
              onChange={(e) => { setScriptName(e.target.value); if (e.target.value.trim()) setScriptNameError('') }}
            />
            {scriptNameError && (
              <div style={{ fontSize: 12, color: '#f85149', marginBottom: 10 }}>{scriptNameError}</div>
            )}

            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text-muted)', marginBottom: 8 }}>Request Names</div>
            <div style={{ background: 'var(--ps-bg)', border: '1px solid var(--ps-border)', borderRadius: 6, marginBottom: 14, maxHeight: 220, overflowY: 'auto' }}>
              {tabs.filter((t) => !t.isArchived).map((t, i) => (
                <label
                  key={t.id}
                  style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderBottom: i < tabs.filter(x => !x.isArchived).length - 1 ? '1px solid var(--ps-border)' : 'none', cursor: 'pointer' }}
                >
                  <input
                    type="checkbox"
                    checked={!!scriptSelected[t.id]}
                    onChange={(e) => setScriptSelected((p) => ({ ...p, [t.id]: e.target.checked }))}
                    style={{ accentColor: '#1d9bf0', width: 15, height: 15, cursor: 'pointer' }}
                  />
                  <span style={{ fontSize: 13, color: 'var(--ps-text)' }}>{t.name || `Request ${i + 1}`}</span>
                </label>
              ))}
              {tabs.filter((t) => !t.isArchived).length === 0 && (
                <div style={{ padding: '10px 12px', fontSize: 13, color: 'var(--ps-text-muted)' }}>No active requests</div>
              )}
            </div>

            <div style={{ display: 'flex', gap: 8 }}>
              <button style={runBtnStyle} onClick={handleCreateScript} disabled={creating}>
                {creating ? 'Creating...' : 'Generate Script'}
              </button>
              <button style={cancelBtnStyle} onClick={() => setShowScriptDialog(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Success Dialog */}
      {showSuccessDialog && (
        <div style={overlayStyle}>
          <div style={{ ...dialogStyle, width: 400, textAlign: 'center' }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>✅</div>
            <h3 style={{ margin: '0 0 8px', fontSize: 16, color: '#e7e9ea' }}>Script Saved Successfully</h3>
            <p style={{ margin: '0 0 20px', fontSize: 13, color: '#8b98a5', lineHeight: 1.5 }}>
              Your script has been saved and is available under the <span style={{ color: '#e7e9ea', fontWeight: 600 }}>Perfzy</span> tab on the Scripts page.
            </p>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
              <button
                style={{ ...runBtnStyle, padding: '8px 20px' }}
                onClick={() => { setShowSuccessDialog(false); window.location.href = '/scripts' }}
              >
                View Script
              </button>
              <button
                style={{ ...cancelBtnStyle, padding: '8px 20px' }}
                onClick={() => setShowSuccessDialog(false)}
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Request Confirmation Dialog */}
      {showDeleteConfirm && activeTab && (
        <div style={overlayStyle}>
          <div style={{ ...dialogStyle, width: 400 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <span style={{ fontSize: 22, color: '#f85149' }}>🗑</span>
              <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#e7e9ea' }}>Delete Request</h3>
            </div>
            <p style={{ margin: '0 0 1.5rem', color: '#8b98a5', fontSize: 14, lineHeight: 1.5 }}>
              Are you sure you want to delete <strong style={{ color: '#e7e9ea' }}>{activeTab.name}</strong>?
              <br />This action cannot be undone.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button
                type="button"
                style={cancelBtnStyle}
                onClick={() => setShowDeleteConfirm(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                style={{ ...cancelBtnStyle, background: '#da3633', color: '#fff', border: 'none' }}
                onClick={() => { setShowDeleteConfirm(false); removeTab(activeTabId) }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Code Preview Modal (Java / Python) */}
      {codeLanguage && (
        <div style={overlayStyle}>
          <div style={{ ...dialogStyle, width: 700, maxWidth: '90vw' }}>
            <h3 style={{ margin: '0 0 10px', fontSize: 16, color: '#e7e9ea' }}>
              {codeLanguage === 'java' ? 'Java Code' : 'Python Code'}
            </h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontSize: 12, color: '#8b98a5' }}>Generated snippet for the current request.</span>
              <button
                type="button"
                style={smallBtnStyle}
                onClick={() => {
                  if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(codeContent).catch(() => {})
                  }
                }}
              >
                Copy
              </button>
            </div>
            <pre
              style={{
                ...preStyle,
                maxHeight: 360,
                marginBottom: 12,
              }}
            >
              {codeContent}
            </pre>
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button type="button" style={cancelBtnStyle} onClick={closeCodeModal}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Parameter Selection Modal */}
      {showParamModal && (
        <div style={overlayStyle}>
          <div style={{ ...dialogStyle, width: 680, maxWidth: '92vw', maxHeight: '85vh' }}>
            {/* Modal header */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4 }}>
              <div>
                <h3 style={{ margin: '0 0 4px', fontSize: 16, color: isDark ? '#e7e9ea' : '#111827', fontWeight: 700 }}>Select Parameters</h3>
                <p style={{ margin: 0, fontSize: 12, color: '#8b98a5', lineHeight: 1.5 }}>
                  Parameters detected from your request. Select the ones you want to parameterize and give them unique names.
                </p>
              </div>
              <button
                type="button"
                style={{ background: 'none', border: 'none', color: '#8b98a5', cursor: 'pointer', fontSize: 20, lineHeight: 1, padding: '0 4px' }}
                onClick={() => { setShowParamModal(false); setParamNameError('') }}
              >
                ×
              </button>
            </div>
            <div style={{ borderTop: '1px solid #30363d', margin: '12px 0' }} />

            {paramNameError && (
              <div style={{ fontSize: 12, color: '#f85149', background: 'rgba(248,81,73,0.08)', border: '1px solid rgba(248,81,73,0.3)', borderRadius: 6, padding: '7px 10px', marginBottom: 10 }}>
                {paramNameError}
              </div>
            )}

            {/* Legend */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 10, flexWrap: 'wrap' }}>
              {[['body','#1d9bf0'],['query','#22c55e'],['header','#a855f7'],['path','#fb923c']].map(([src, color]) => (
                <span key={src} style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 4, color: '#8b98a5' }}>
                  <span style={{ width: 8, height: 8, borderRadius: 999, background: color, display: 'inline-block' }} />
                  {src}
                </span>
              ))}
            </div>

            {/* Table header */}
            <div style={{ display: 'grid', gridTemplateColumns: '28px 16px 140px 1fr 1fr', gap: 8, alignItems: 'center', padding: '6px 8px', background: '#0d1117', borderRadius: '6px 6px 0 0', border: '1px solid #21262d', borderBottom: 'none', fontSize: 11, fontWeight: 600, color: '#8b98a5', letterSpacing: 0.4 }}>
              <span></span>
              <span></span>
              <span>KEY</span>
              <span>PARAMETER NAME</span>
              <span>VALUE</span>
            </div>

            {/* Rows */}
            <div style={{ border: '1px solid #21262d', borderRadius: '0 0 6px 6px', maxHeight: 300, overflowY: 'auto', marginBottom: 16 }}>
              {pendingParams.length === 0 && (
                <div style={{ padding: '14px 10px', fontSize: 13, color: '#8b98a5', textAlign: 'center' }}>No parameters detected.</div>
              )}
              {pendingParams.map((p, idx) => {
                const sourceColor = { body: '#1d9bf0', query: '#22c55e', header: '#a855f7', path: '#fb923c' }[p.source] || '#8b98a5'
                const isDisabled = p.alreadyParameterized
                const maskedValue = p.masked ? '••••••••' : (p.value || '')
                return (
                  <div
                    key={idx}
                    style={{
                      display: 'grid', gridTemplateColumns: '28px 16px 140px 1fr 1fr', gap: 8, alignItems: 'center',
                      padding: '7px 8px', borderBottom: idx < pendingParams.length - 1 ? '1px solid #21262d' : 'none',
                      background: isDisabled ? 'rgba(0,0,0,0.1)' : 'transparent',
                      opacity: isDisabled ? 0.55 : 1,
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={p.checked}
                      disabled={isDisabled}
                      onChange={(e) => {
                        const next = [...pendingParams]
                        next[idx] = { ...next[idx], checked: e.target.checked }
                        setPendingParams(next)
                        setParamNameError('')
                      }}
                      style={{ accentColor: '#1d9bf0', width: 15, height: 15, cursor: isDisabled ? 'not-allowed' : 'pointer' }}
                    />
                    <span style={{ width: 10, height: 10, borderRadius: 999, background: sourceColor, display: 'inline-block', flexShrink: 0 }} title={p.source} />
                    <span style={{ fontSize: 13, color: isDark ? '#79c0ff' : '#1d4ed8', fontFamily: 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {p.key}
                    </span>
                    <div>
                      {isDisabled ? (
                        <span style={{ fontSize: 11, color: '#22c55e', background: 'rgba(34,197,94,0.12)', borderRadius: 4, padding: '2px 6px' }}>Already parameterized</span>
                      ) : (
                        <input
                          style={{ ...inputStyle, fontSize: 12, padding: '4px 8px' }}
                          value={p.customName}
                          placeholder="custom_name"
                          onChange={(e) => {
                            const next = [...pendingParams]
                            next[idx] = { ...next[idx], customName: e.target.value }
                            setPendingParams(next)
                            setParamNameError('')
                          }}
                        />
                      )}
                    </div>
                    <span style={{ fontSize: 12, color: p.masked ? '#6e7681' : (isDark ? '#c9d1d9' : '#111827'), fontFamily: p.masked ? 'inherit' : 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={p.masked ? 'Sensitive value hidden' : p.value}>
                      {maskedValue}
                    </span>
                  </div>
                )
              })}
            </div>

            {/* Info note */}
            <p style={{ fontSize: 11, color: '#6e7681', margin: '0 0 14px', lineHeight: 1.5 }}>
              Selected parameters will be added to the Parameters tab. Values in the request preview will be replaced with <code style={{ fontFamily: 'monospace', color: '#d2a8ff' }}>{'{{parameter_name}}'}</code>.
            </p>

            <div style={{ display: 'flex', gap: 8 }}>
              <button
                type="button"
                style={{ ...runBtnStyle, background: '#1d9bf0' }}
                onClick={handleAddSelectedParams}
                disabled={!pendingParams.some((p) => p.checked && !p.alreadyParameterized)}
              >
                Add Selected
              </button>
              <button type="button" style={cancelBtnStyle} onClick={() => { setShowParamModal(false); setParamNameError('') }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Parameters Modal (central view for all parameters) */}
      {showVarsModal && (() => {
        // Dirty only when meaningful content (rows with a key) differs from the snapshot taken on open
        const isVarsDirty = JSON.stringify(
          varsDraft.filter((v) => v.key.trim()).map((v) => ({ key: v.key, value: v.value }))
        ) !== varsOriginal

        const allRequestParams = tabs
          .filter((t) => !t.isArchived)
          .flatMap((t) => (t.parameters || []).map((p) => ({ ...p, requestName: t.name || 'Unnamed', tabId: t.id })))
        return (
          <div style={overlayStyle}>
            <div style={{ ...dialogStyle, width: 620, maxWidth: '92vw', maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}>
              {/* Header */}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4, flexShrink: 0 }}>
                <div>
                  <h3 style={{ margin: '0 0 4px', fontSize: 16, color: '#e7e9ea', fontWeight: 700 }}>Parameters</h3>
                  <p style={{ margin: 0, fontSize: 12, color: '#8b98a5', lineHeight: 1.5 }}>
                    All parameters are globally scoped. Reference them in any request using{' '}
                    <code style={{ fontFamily: 'monospace', color: '#d2a8ff' }}>{'{{parameter_name}}'}</code>.
                  </p>
                </div>
              </div>
              <hr style={{ border: 'none', borderTop: '1px solid #30363d', margin: '12px 0 0', flexShrink: 0 }} />

              {/* Scrollable body */}
              <div style={{ flex: 1, overflowY: 'auto', paddingTop: 12 }}>

                {/* ── Section 1: Request Parameters ── */}
                <div style={{ fontSize: 12, fontWeight: 600, color: '#8b98a5', letterSpacing: 0.5, marginBottom: 8, textTransform: 'uppercase' }}>
                  Detected From Requests
                </div>
                {allRequestParams.length === 0 ? (
                  <div style={{ fontSize: 12, color: '#6e7681', marginBottom: 16, padding: '10px 12px', background: '#0d1117', border: '1px solid #21262d', borderRadius: 6 }}>
                    No parameters saved yet. Run a request and select parameters to add them.
                  </div>
                ) : (
                  <div style={{ background: '#0d1117', border: '1px solid #21262d', borderRadius: 6, marginBottom: 16, overflow: 'hidden' }}>
                    {/* Table header */}
                    <div style={{ display: 'grid', gridTemplateColumns: '120px auto 1fr 1fr', gap: 0, background: '#161b22', borderBottom: '1px solid #21262d', padding: '5px 10px', fontSize: 11, fontWeight: 600, color: '#8b98a5', letterSpacing: 0.4 }}>
                      <span>REQUEST</span>
                      <span style={{ paddingLeft: 8 }}>SOURCE</span>
                      <span style={{ paddingLeft: 10 }}>PARAMETER NAME</span>
                      <span style={{ paddingLeft: 10 }}>VALUE</span>
                    </div>
                    {/* Rows */}
                    <div style={{ maxHeight: 220, overflowY: 'auto' }}>
                      {allRequestParams.map((p, idx) => {
                        const sourceColor = { body: '#1d9bf0', query: '#22c55e', header: '#a855f7', path: '#fb923c', manual: '#fbbf24' }[p.source] || '#8b98a5'
                        const sourceBg = { body: 'rgba(29,155,240,0.12)', query: 'rgba(34,197,94,0.12)', header: 'rgba(168,85,247,0.12)', path: 'rgba(251,146,60,0.12)', manual: 'rgba(251,191,36,0.12)' }[p.source] || 'rgba(139,152,165,0.12)'
                        return (
                          <div
                            key={idx}
                            style={{ display: 'grid', gridTemplateColumns: '120px auto 1fr 1fr', gap: 0, alignItems: 'center', padding: '6px 10px', borderBottom: idx < allRequestParams.length - 1 ? '1px solid #21262d' : 'none' }}
                          >
                            <button
                              type="button"
                              title={`Go to Parameters tab of "${p.requestName}"`}
                              onClick={() => {
                                setActiveTabId(p.tabId)
                                setDetailTab('parameters')
                                setShowVarsModal(false)
                              }}
                              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', fontSize: 12, color: '#1d9bf0', textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', width: '100%', textDecoration: 'underline', textDecorationColor: 'rgba(29,155,240,0.4)' }}
                            >
                              {p.requestName}
                            </button>
                            <span style={{ marginLeft: 8, fontSize: 11, fontWeight: 600, padding: '2px 6px', borderRadius: 4, background: sourceBg, color: sourceColor, whiteSpace: 'nowrap', letterSpacing: 0.3 }}>{p.source}</span>
                            <span style={{ paddingLeft: 10, fontSize: 12, color: '#d2a8ff', fontFamily: 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={p.customName}>
                              {p.customName}
                            </span>
                            <span style={{ paddingLeft: 10, fontSize: 12, color: p.masked ? '#6e7681' : '#c9d1d9', fontFamily: p.masked ? 'inherit' : 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                              {p.masked ? '••••••••' : String(p.value || '').substring(0, 40)}
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
                {allRequestParams.length > 0 && (
                  <p style={{ fontSize: 11, color: '#4b5563', margin: '-10px 0 16px', fontStyle: 'italic' }}>
                    Click on a request name to edit its parameters.
                  </p>
                )}

                {/* ── Section 2: Custom Global Parameters ── */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#8b98a5', letterSpacing: 0.5, textTransform: 'uppercase' }}>
                    Custom Parameters
                  </div>
                  <button
                    type="button"
                    style={{ ...smallBtnStyle, background: '#238636', color: '#fff', border: 'none' }}
                    onClick={() => { setVarsDraft([...varsDraft, { key: '', value: '' }]) }}
                  >
                    + Add
                  </button>
                </div>

                {/* Custom params table header */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 28px', gap: 8, padding: '5px 10px', background: '#161b22', border: '1px solid #21262d', borderRadius: '6px 6px 0 0', fontSize: 11, fontWeight: 600, color: '#8b98a5', letterSpacing: 0.4 }}>
                  <span>NAME</span>
                  <span>VALUE</span>
                  <span></span>
                </div>
                <div style={{ border: '1px solid #21262d', borderTop: 'none', borderRadius: '0 0 6px 6px', marginBottom: 16, minHeight: 36 }}>
                  {varsDraft.map((v, index) => (
                    <div key={index} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 28px', gap: 8, alignItems: 'center', padding: '6px 8px', borderBottom: index < varsDraft.length - 1 ? '1px solid #21262d' : 'none' }}>
                      <input
                        style={{ ...inputStyle, fontSize: 13 }}
                        placeholder="parameter_name"
                        value={v.key}
                        onChange={(e) => { const next = [...varsDraft]; next[index] = { ...next[index], key: e.target.value }; setVarsDraft(next) }}
                      />
                      <input
                        style={{ ...inputStyle, fontSize: 13 }}
                        placeholder="value"
                        value={v.value}
                        onChange={(e) => { const next = [...varsDraft]; next[index] = { ...next[index], value: e.target.value }; setVarsDraft(next) }}
                      />
                      <button
                        type="button"
                        style={iconBtnSmStyle}
                        onClick={() => { setVarsDraft(varsDraft.filter((_, j) => j !== index)) }}
                        title="Remove parameter"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                  {varsDraft.length === 0 && (
                    <div style={{ fontSize: 12, color: '#6e7681', padding: '10px 12px' }}>No custom parameters yet. Click &quot;+ Add&quot; to create one.</div>
                  )}
                </div>

              </div>{/* end scrollable body */}

              {/* Footer */}
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, paddingTop: 12, borderTop: '1px solid #30363d', flexShrink: 0 }}>
                <button
                  type="button"
                  style={{ padding: '9px 22px', fontSize: 14, background: isVarsDirty ? '#1d9bf0' : '#111827', color: isVarsDirty ? '#fff' : '#6b7280', border: '1px solid', borderColor: isVarsDirty ? '#1d9bf0' : '#1f2933', borderRadius: 8, cursor: isVarsDirty ? 'pointer' : 'not-allowed', opacity: isVarsDirty ? 1 : 0.7 }}
                  disabled={!isVarsDirty}
                  onClick={() => {
                    const base = globalVars.find((v) => v.key === 'base_url') || { key: 'base_url', value: '' }
                    const cleaned = varsDraft.filter((v) => v.key)
                    setGlobalVars([base, ...cleaned])
                    setVarsOriginal(JSON.stringify(cleaned.map((v) => ({ key: v.key, value: v.value }))))
                    setShowVarsModal(false)
                  }}
                >
                  Save
                </button>
                <button type="button" style={cancelBtnStyle} onClick={() => setShowVarsModal(false)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        )
      })()}

      {/* ── Correlation Assistant Modal ─────────────────────────────────── */}
      {showCorrAssistant && (
        <div style={overlayStyle} onClick={() => setShowCorrAssistant(false)}>
          <div
            style={{ ...dialogStyle, width: 620, maxHeight: '80vh', display: 'flex', flexDirection: 'column' }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div style={{ marginBottom: 10, flexShrink: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <h3 style={{ margin: 0, fontSize: 16, color: '#e7e9ea', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontSize: 18 }}>🔍</span> Correlation Assistant
                </h3>
                <button type="button" style={{ background: 'none', border: 'none', color: '#8b98a5', fontSize: 18, cursor: 'pointer', padding: '2px 6px' }} onClick={() => setShowCorrAssistant(false)}>✕</button>
              </div>
              <p style={{ margin: '4px 0 0', fontSize: 12, color: '#8b98a5', lineHeight: 1.5 }}>
                Search response fields by business name or technical key.
              </p>
            </div>

            {/* Search bar */}
            <div style={{ marginBottom: 12, flexShrink: 0 }}>
              <input
                style={{ ...inputStyle, width: '100%', padding: '8px 12px', fontSize: 13, boxSizing: 'border-box' }}
                placeholder="Type field or component name (example: id, order, product, token)"
                value={corrSearch}
                onChange={(e) => { setCorrSearch(e.target.value); setCorrSelected(null) }}
                autoFocus
              />
            </div>

            {/* Results area */}
            <div style={{ flex: 1, overflowY: 'auto', minHeight: 0 }}>
              {!corrSelected ? (
                // ─── Search Results / Grouped List ───
                (() => {
                  const grouped = searchCandidates(corrCandidates, corrSearch)
                  const entries = [...grouped.entries()].sort((a, b) => b[1].priorityScore - a[1].priorityScore)
                  if (entries.length === 0) {
                    return (
                      <div style={{ padding: '24px 0', textAlign: 'center', fontSize: 13, color: '#6e7681' }}>
                        {corrSearch ? `No matches for "${corrSearch}"` : 'No fields found in response. Make sure the response is valid JSON.'}
                      </div>
                    )
                  }
                  const entityGroups = new Map()
                  for (const [, c] of entries) {
                    if (!entityGroups.has(c.entityName)) entityGroups.set(c.entityName, [])
                    entityGroups.get(c.entityName).push(c)
                  }
                  return (
                    <div>
                      {corrSearch && (
                        <div style={{ fontSize: 11, color: '#8b98a5', marginBottom: 8 }}>
                          Found {entries.length} match{entries.length !== 1 ? 'es' : ''} for &quot;{corrSearch}&quot;
                        </div>
                      )}
                      {[...entityGroups.entries()].map(([entity, fields]) => (
                        <div key={entity} style={{ marginBottom: 8 }}>
                          <div style={{ fontSize: 11, fontWeight: 700, color: '#8b98a5', letterSpacing: 0.4, padding: '4px 0 2px', textTransform: 'uppercase' }}>{entity}</div>
                          {fields.map((c, fi) => {
                            const alreadyAdded = activeTab.extractions.some(
                              (e) => e.expression === c.jsonPath || e.expression === c.groupKey.replace(/\[\*\]/g, '[0]')
                            )
                            return (
                              <div
                                key={fi}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: 10,
                                  padding: '6px 10px',
                                  borderRadius: 6,
                                  cursor: 'pointer',
                                  background: 'var(--ps-card)',
                                  border: '1px solid var(--ps-border)',
                                  marginBottom: 3,
                                  transition: 'background 0.15s',
                                }}
                                onClick={() => {
                                  if (!alreadyAdded) {
                                    setCorrSelected({ entityName: c.entityName, fieldName: c.fieldName, candidate: c })
                                    setCorrInstanceMode('first')
                                    setCorrSpecificIndex(0)
                                  }
                                }}
                                onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(29,155,240,0.08)' }}
                                onMouseLeave={(e) => { e.currentTarget.style.background = 'var(--ps-card)' }}
                              >
                                {c.priorityScore >= 80 && <span style={{ fontSize: 12, flexShrink: 0 }}>⭐</span>}
                                <span style={{ fontSize: 13, color: 'var(--ps-text)', fontWeight: 600, minWidth: 80 }}>{c.fieldName}</span>
                                <span style={{ fontSize: 11, color: '#7ee787', fontFamily: 'monospace', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={String(c.sampleValue)}>
                                  {String(c.sampleValue).substring(0, 50)}
                                </span>
                                {c.totalInstances > 1 && (
                                  <span style={{ fontSize: 10, color: '#8b98a5', background: 'rgba(139,152,165,0.15)', borderRadius: 4, padding: '1px 5px', flexShrink: 0 }}>
                                    ×{c.totalInstances}
                                  </span>
                                )}
                                {alreadyAdded && (
                                  <span style={{ fontSize: 10, color: '#238636', fontWeight: 600, flexShrink: 0 }}>✓ added</span>
                                )}
                              </div>
                            )
                          })}
                        </div>
                      ))}
                    </div>
                  )
                })()
              ) : (
                // ─── Instance Selection + Expression Preview ───
                (() => {
                  const c = corrSelected.candidate
                  const instances = findInstances(corrCandidates, corrSelected.entityName, corrSelected.fieldName)
                  const hasMultiple = c.totalInstances > 1
                  const { jsonPath, varName } = generateExpression(c, corrInstanceMode, corrSpecificIndex)

                  let capturedValue = c.sampleValue
                  if (corrInstanceMode === 'last' && instances.length > 1) {
                    capturedValue = instances[instances.length - 1].sampleValue
                  } else if (corrInstanceMode === 'specific' && instances[corrSpecificIndex]) {
                    capturedValue = instances[corrSpecificIndex].sampleValue
                  }

                  return (
                    <div>
                      <button
                        type="button"
                        style={{ background: 'none', border: 'none', color: '#1d9bf0', cursor: 'pointer', fontSize: 12, padding: 0, marginBottom: 10 }}
                        onClick={() => setCorrSelected(null)}
                      >
                        ← Back to results
                      </button>

                      <div style={{ background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 8, padding: '12px 14px', marginBottom: 12 }}>
                        <div style={{ fontSize: 11, color: isDark ? '#8b98a5' : '#6b7280', letterSpacing: 0.4, fontWeight: 600, marginBottom: 6 }}>SELECTED FIELD</div>
                        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                          <span style={{ fontSize: 14, fontWeight: 700, color: isDark ? '#e7e9ea' : '#111827' }}>{c.entityName}</span>
                          <span style={{ fontSize: 12, color: isDark ? '#8b98a5' : '#6b7280' }}>→</span>
                          <span style={{ fontSize: 14, fontWeight: 600, color: isDark ? '#d2a8ff' : '#7c3aed' }}>{c.fieldName}</span>
                        </div>
                        <div style={{ fontSize: 12, color: isDark ? '#7ee787' : '#15803d', fontFamily: 'monospace', marginTop: 4 }}>
                          Sample: {String(c.sampleValue).substring(0, 80)}
                        </div>
                      </div>

                      {/* Instance selection */}
                      {hasMultiple && (
                        <div style={{ background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 8, padding: '12px 14px', marginBottom: 12 }}>
                          <div style={{ fontSize: 11, color: '#8b98a5', letterSpacing: 0.4, fontWeight: 600, marginBottom: 8 }}>SELECT INSTANCE</div>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                            {[
                              { value: 'first', label: 'First occurrence' },
                              { value: 'last', label: 'Last occurrence' },
                              { value: 'specific', label: 'Specific index' },
                            ].map((opt) => (
                              <label key={opt.value} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--ps-text)', cursor: 'pointer' }}>
                                <input
                                  type="radio"
                                  name="corrInstance"
                                  checked={corrInstanceMode === opt.value}
                                  onChange={() => setCorrInstanceMode(opt.value)}
                                  style={{ accentColor: '#1d9bf0' }}
                                />
                                {opt.label}
                                {opt.value === 'specific' && corrInstanceMode === 'specific' && (
                                  <input
                                    type="number"
                                    min={0}
                                    max={c.totalInstances - 1}
                                    value={corrSpecificIndex}
                                    onChange={(e) => setCorrSpecificIndex(Math.max(0, parseInt(e.target.value) || 0))}
                                    style={{ ...inputStyle, width: 60, fontSize: 12, padding: '3px 6px', marginLeft: 4 }}
                                  />
                                )}
                              </label>
                            ))}
                          </div>
                          <div style={{ fontSize: 11, color: '#8b98a5', marginTop: 6 }}>
                            {c.totalInstances} instance{c.totalInstances !== 1 ? 's' : ''} found in response
                          </div>
                        </div>
                      )}

                      {/* Expression preview */}
                      <div style={{ background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 8, padding: '12px 14px', marginBottom: 12 }}>
                        <div style={{ fontSize: 11, color: isDark ? '#8b98a5' : '#6b7280', letterSpacing: 0.4, fontWeight: 600, marginBottom: 8 }}>GENERATED EXPRESSION</div>
                        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                          <div>
                            <div style={{ fontSize: 10, color: isDark ? '#8b98a5' : '#6b7280', marginBottom: 2 }}>JSONPath</div>
                            <div style={{ fontSize: 13, color: isDark ? '#79c0ff' : '#1d4ed8', fontWeight: 600, fontFamily: 'monospace', background: isDark ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.05)', padding: '4px 8px', borderRadius: 4 }}>{jsonPath}</div>
                          </div>
                          <div>
                            <div style={{ fontSize: 10, color: isDark ? '#8b98a5' : '#6b7280', marginBottom: 2 }}>Variable Name</div>
                            <div style={{ fontSize: 13, color: isDark ? '#d2a8ff' : '#7c3aed', fontWeight: 600, fontFamily: 'monospace', background: isDark ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.05)', padding: '4px 8px', borderRadius: 4 }}>{varName}</div>
                          </div>
                        </div>
                        {capturedValue != null && (
                          <div style={{ marginTop: 8 }}>
                            <div style={{ fontSize: 10, color: isDark ? '#8b98a5' : '#6b7280', marginBottom: 2 }}>Captured Value</div>
                            <div style={{ fontSize: 12, color: isDark ? '#7ee787' : '#15803d', fontWeight: 600, fontFamily: 'monospace', background: isDark ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.05)', padding: '4px 8px', borderRadius: 4, wordBreak: 'break-all' }}>
                              {String(capturedValue).substring(0, 120)}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })()
              )}
            </div>

            {/* Footer */}
            {corrSelected && (
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, paddingTop: 12, borderTop: '1px solid #30363d', flexShrink: 0 }}>
                <button type="button" style={cancelBtnStyle} onClick={() => setCorrSelected(null)}>
                  Cancel
                </button>
                <button
                  type="button"
                  style={{ padding: '8px 20px', fontSize: 13, fontWeight: 600, background: '#238636', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}
                  onClick={() => {
                    const c = corrSelected.candidate
                    const { jsonPath, varName } = generateExpression(c, corrInstanceMode, corrSpecificIndex)
                    const ext = { name: varName, source: 'json_path', expression: jsonPath }
                    updateTab(activeTabId, { extractions: [...activeTab.extractions, ext] })
                    if (c.sampleValue != null) {
                      setVariableCtx((prev) => ({ ...prev, [varName]: String(c.sampleValue) }))
                    }
                    setShowCorrAssistant(false)
                    setCorrSelected(null)
                  }}
                >
                  Add Correlation
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Parameter Modal */}
      {manualParamDraft && (
        <div style={overlayStyle} onClick={() => { setManualParamDraft(null); setParamNameError('') }}>
          <div style={{ ...dialogStyle, width: 420 }} onClick={(e) => e.stopPropagation()}>
            <h3 style={{ margin: '0 0 6px', fontSize: 16, color: 'var(--ps-text)' }}>Add Parameter</h3>
            <p style={{ margin: '0 0 16px', fontSize: 12, color: 'var(--ps-text-muted)', lineHeight: 1.5 }}>
              This parameter will be added to <span style={{ color: 'var(--ps-text)', fontWeight: 600 }}>{activeTab?.name || 'current request'}</span>.
            </p>
            <div style={{ marginBottom: 12 }}>
              <label style={{ ...labelStyle, fontSize: 12 }}>Key</label>
              <input
                style={{ ...inputStyle, fontSize: 13, width: '100%' }}
                placeholder="e.g. email"
                value={manualParamDraft.key}
                onChange={(e) => setManualParamDraft((d) => ({ ...d, key: e.target.value, customName: e.target.value ? 'user_' + e.target.value : '' }))}
              />
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ ...labelStyle, fontSize: 12 }}>Parameter Name</label>
              <input
                style={{ ...inputStyle, fontSize: 13, width: '100%' }}
                placeholder="e.g. user_email"
                value={manualParamDraft.customName}
                onChange={(e) => setManualParamDraft((d) => ({ ...d, customName: e.target.value }))}
              />
            </div>
            <div style={{ marginBottom: 14 }}>
              <label style={{ ...labelStyle, fontSize: 12 }}>Value</label>
              <input
                style={{ ...inputStyle, fontSize: 13, width: '100%' }}
                placeholder="e.g. user@example.com"
                value={manualParamDraft.value}
                onChange={(e) => setManualParamDraft((d) => ({ ...d, value: e.target.value }))}
              />
            </div>
            {paramNameError && (
              <div style={{ fontSize: 12, color: '#f85149', marginBottom: 10 }}>{paramNameError}</div>
            )}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button type="button" style={cancelBtnStyle} onClick={() => { setManualParamDraft(null); setParamNameError('') }}>
                Cancel
              </button>
              <button type="button" style={{ ...smallBtnStyle, background: '#238636', color: '#fff', border: 'none', padding: '6px 18px' }} onClick={handleAddManualParam}>
                Add
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ── Sub-components ────────────────────────────────────────────────────── */

function CollapsibleSection({ title, defaultOpen = false, children }) {
  const [open, setOpen] = useState(defaultOpen)
  const { isDark } = useTheme()
  return (
    <div style={{ marginBottom: 6 }}>
      <div style={{ cursor: 'pointer', fontSize: 13, color: isDark ? '#8b98a5' : '#374151', userSelect: 'none', fontWeight: 600 }} onClick={() => setOpen(!open)}>
        {open ? '▾' : '▸'} {title}
      </div>
      {open && <div style={{ marginLeft: 10 }}>{children}</div>}
    </div>
  )
}

function KVTable({ data }) {
  const { isDark } = useTheme()
  if (!data || typeof data !== 'object') return null
  const entries = Object.entries(data)
  if (entries.length === 0) return <span style={{ fontSize: 12, color: isDark ? '#6e7681' : '#9ca3af' }}>empty</span>
  return (
    <div style={{ fontSize: 12, overflow: 'hidden' }}>
      {entries.map(([k, v]) => (
        <div key={k} style={{ display: 'flex', gap: 8, lineHeight: 1.6 }}>
          <span style={{ color: isDark ? '#79c0ff' : '#1d4ed8', minWidth: 120, flexShrink: 0, fontWeight: 600 }}>{k}</span>
          <span style={{ color: isDark ? '#c9d1d9' : '#111827', wordBreak: 'break-all', minWidth: 0 }}>{String(v).substring(0, 300)}</span>
        </div>
      ))}
    </div>
  )
}

function StatusBadge({ code }) {
  const c = code >= 200 && code < 300 ? '#238636' : code >= 300 && code < 400 ? '#d29922' : '#f85149'
  return <span style={{ fontSize: 13, fontWeight: 700, color: '#fff', background: c, borderRadius: 4, padding: '2px 8px' }}>{code}</span>
}

function formatBody(body, headers) {
  if (!body) return ''
  const ct = (headers?.['content-type'] || headers?.['Content-Type'] || '').toLowerCase()
  if (ct.includes('json')) {
    try { return JSON.stringify(JSON.parse(body), null, 2) } catch { /* fall through */ }
  }
  return body.substring(0, 50000)
}

function methodBadgeStyle(m) {
  const colors = { GET: '#61affe', POST: '#49cc90', PUT: '#fca130', PATCH: '#50e3c2', DELETE: '#f93e3e' }
  return { color: colors[m] || '#8b98a5', fontWeight: 700, fontSize: 13 }
}

function ExecStatusIcon({ status }) {
  if (!status || status === 'not_executed') {
    return (
      <span title="Not executed" style={{ marginLeft: 'auto', flexShrink: 0, display: 'flex', alignItems: 'center' }}>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <circle cx="12" cy="12" r="9" stroke="#6b7280" strokeWidth="2" />
          <path d="M12 7v5l3 3" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
    )
  }
  if (status === 'seq_next') {
    return (
      <span title="Next to execute" style={{ marginLeft: 'auto', flexShrink: 0, display: 'flex', alignItems: 'center' }}>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <circle cx="12" cy="12" r="9" fill="rgba(59,130,246,0.15)" stroke="#60a5fa" strokeWidth="2" />
          <polygon points="9,8 17,12 9,16" fill="#60a5fa" />
        </svg>
      </span>
    )
  }
  if (status === 'passed') {
    return (
      <span title="Passed" style={{ marginLeft: 'auto', flexShrink: 0, display: 'flex', alignItems: 'center' }}>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <circle cx="12" cy="12" r="9" fill="rgba(34,197,94,0.15)" stroke="#22c55e" strokeWidth="2" />
          <path d="M8 12l3 3 5-5" stroke="#22c55e" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
    )
  }
  // failed
  return (
    <span title="Failed" style={{ marginLeft: 'auto', flexShrink: 0, display: 'flex', alignItems: 'center' }}>
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="12" cy="12" r="9" fill="rgba(248,81,73,0.15)" stroke="#f85149" strokeWidth="2" />
        <path d="M9 9l6 6M15 9l-6 6" stroke="#f85149" strokeWidth="2.2" strokeLinecap="round" />
      </svg>
    </span>
  )
}

function SaveIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1d9bf0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 3h11l3 3v15H5z" />
      <path d="M9 3v5h6V3" />
      <path d="M9 13h6v5H9z" />
    </svg>
  )
}

function ArchiveIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="4" rx="1" />
      <path d="M5 7v13h14V7" />
      <path d="M10 12h4" />
    </svg>
  )
}

function JavaIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 256 346" style={{ display: 'block' }}>
      <path d="M83 267s-14 8 9 11c28 3 42 3 72-4 0 0 8 5 19 9-69 30-156-2-100-16z" fill="#5382A1"/>
      <path d="M74 230s-15 11 8 14c30 3 53 3 93-4 0 0 6 5 14 8-83 24-176 2-115-18z" fill="#5382A1"/>
      <path d="M143 166c17 19-4 36-4 36s42-22 23-49c-18-25-31-38 42-81 0 0-115 29-61 94z" fill="#E76F00"/>
      <path d="M233 295s10 8-11 15c-40 11-168 15-203 0-13-5 11-13 19-14 8-2 12-2 12-2-14-10-90 20-39 28 141 22 256-9 222-27z" fill="#5382A1"/>
      <path d="M95 190s-64 15-23 21c17 2 52 2 85-1 27-3 53-8 53-8s-9 4-16 8c-64 17-189 9-153-8 30-14 54-12 54-12z" fill="#5382A1"/>
      <path d="M202 253c65-34 35-66 14-62-5 1-7 2-7 2s2-3 6-5c42-15 74 44-14 67 0 0 1-1 1-2z" fill="#5382A1"/>
      <path d="M162 0s36 36-34 92c-57 45-13 71 0 100-33-30-58-56-41-81 24-36 91-53 75-111z" fill="#E76F00"/>
      <path d="M95 345c63 4 159-2 161-34 0 0-4 12-51 21-53 10-118 9-157 3 0 0 8 6 47 10z" fill="#5382A1"/>
    </svg>
  )
}

function PythonIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 32 32" fill="none">
      <path d="M15.9 2c-1.5 0-2.9.2-4.1.5C8.9 3.3 8.3 4.7 8.3 6.8v2.5h7.7v.9H6.4c-2.3 0-4.3 1.4-4.9 4-.7 3-.8 4.9 0 8 .5 2.3 1.8 4 4.1 4h2.6V23c0-2.6 2.2-4.8 4.9-4.8h7.7c2.2 0 3.9-1.8 3.9-4V7.3c0-2.1-1.8-3.7-3.9-4.1C19.3 2.6 17.5 2 15.9 2zm-4.2 2.8c.8 0 1.5.7 1.5 1.5s-.7 1.4-1.5 1.4-1.4-.6-1.4-1.4.6-1.5 1.4-1.5z" fill="#3776ab"/>
      <path d="M24.4 10.2v3c0 2.7-2.3 5-4.9 5h-7.7c-2.1 0-3.9 1.8-3.9 4v6.8c0 2.1 1.9 3.4 3.9 4 2.5.7 4.8.8 7.7 0 1.9-.6 3.9-1.7 3.9-4v-2.8h-7.7v-.9H26c2.3 0 3.1-1.6 3.9-4 .8-2.5.8-4.8 0-8-.5-2.3-1.6-4-3.9-4h-1.6zm-4.3 15c.8 0 1.4.6 1.4 1.4s-.6 1.5-1.4 1.5-1.5-.7-1.5-1.5.7-1.4 1.5-1.4z" fill="#ffd43b"/>
    </svg>
  )
}

function TrashIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6" />
      <path d="M8 6V4h8v2" />
      <path d="M19 6v14H5V6" />
      <line x1="10" y1="11" x2="10" y2="17" />
      <line x1="14" y1="11" x2="14" y2="17" />
    </svg>
  )
}

function RunIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="0" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="7 4 19 12 7 20 7 4" fill="currentColor" />
    </svg>
  )
}

function SpinnerIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24">
      <circle
        cx="12"
        cy="12"
        r="8"
        stroke="rgba(255,255,255,0.25)"
        strokeWidth="3"
        fill="none"
      />
      <path
        d="M20 12a8 8 0 0 0-8-8"
        stroke="#ffffff"
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
      >
        <animateTransform
          attributeName="transform"
          type="rotate"
          from="0 12 12"
          to="360 12 12"
          dur="0.8s"
          repeatCount="indefinite"
        />
      </path>
    </svg>
  )
}

function FastForwardIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="0" strokeLinecap="round" strokeLinejoin="round">
      {/* Left play triangle (slightly larger) */}
      <polygon points="5 4 15 12 5 20 5 4" fill="currentColor" />
      {/* Right play triangle, offset for fast-forward */}
      <polygon points="10 4 20 12 10 20 10 4" fill="currentColor" />
    </svg>
  )
}

function formatElapsed(ms) {
  if (!ms || ms <= 0) return ''
  if (ms < 1000) return `${ms} ms`
  const sec = ms / 1000
  return `${sec.toFixed(2)} sec`
}

// ── Parameter detection helpers (pure functions, defined outside component) ──

function isSensitiveKey(key) {
  return /password|passwd|secret|token|api[_-]?key|credential|private|auth(?:orization)?/i.test(key || '')
}

function isSystemHeader(key) {
  const lower = (key || '').toLowerCase()
  return ['content-type', 'accept', 'host', 'content-length', 'user-agent', 'accept-encoding', 'connection', 'cache-control', 'accept-language'].includes(lower)
}

function isPathVariable(seg) {
  if (/^\d+$/.test(seg)) return true
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(seg)) return true
  if (seg.length >= 4 && /\d/.test(seg) && /[a-zA-Z]/.test(seg)) return true
  return false
}

function detectParams(tab) {
  const out = []
  const mode = tab.payloadMode || 'none'

  if (mode === 'json_kv') {
    ;(tab.jsonFields || []).forEach(({ key, value }) => {
      if (key && key.trim()) out.push({ key: key.trim(), value: value || '', source: 'body', masked: isSensitiveKey(key) })
    })
  } else if (mode === 'raw_json') {
    try {
      const obj = JSON.parse(tab.rawJson || '{}')
      if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
        Object.entries(obj).forEach(([k, v]) => {
          if (k) out.push({ key: k, value: String(v ?? ''), source: 'body', masked: isSensitiveKey(k) })
        })
      }
    } catch { /* ignore invalid JSON */ }
  } else if (mode === 'formdata') {
    ;(tab.formFields || []).forEach(({ key, value }) => {
      if (key && key.trim()) out.push({ key: key.trim(), value: value || '', source: 'body', masked: isSensitiveKey(key) })
    })
  } else if (mode === 'urlencoded') {
    ;(tab.urlencodedFields || []).forEach(({ key, value }) => {
      if (key && key.trim()) out.push({ key: key.trim(), value: value || '', source: 'body', masked: isSensitiveKey(key) })
    })
  }

  const pathStr = tab.path || ''
  const qIdx = pathStr.indexOf('?')
  if (qIdx >= 0) {
    pathStr.substring(qIdx + 1).split('&').forEach((pair) => {
      const eqIdx = pair.indexOf('=')
      if (eqIdx < 0) return
      const k = pair.substring(0, eqIdx).trim()
      const v = (() => { try { return decodeURIComponent(pair.substring(eqIdx + 1)) } catch { return pair.substring(eqIdx + 1) } })()
      if (k) out.push({ key: k, value: v, source: 'query', masked: isSensitiveKey(k) })
    })
  }

  ;(tab.headers || []).forEach(({ key, value }) => {
    if (key && key.trim() && !isSystemHeader(key)) {
      out.push({ key: key.trim(), value: value || '', source: 'header', masked: isSensitiveKey(key) })
    }
  })

  const pathPart = qIdx >= 0 ? pathStr.substring(0, qIdx) : pathStr
  pathPart.split('/').filter(Boolean).forEach((seg) => {
    if (isPathVariable(seg)) {
      out.push({ key: seg, value: seg, source: 'path', masked: false })
    }
  })

  return out
}

function parameterizePreview(preview, params) {
  if (!preview || !params || !params.length) return preview
  let result = preview
  params.forEach(({ customName, value }) => {
    if (!value || !customName) return
    try {
      const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      result = result.replace(new RegExp(escaped, 'g'), `{{${customName}}}`)
    } catch { /* ignore regex errors */ }
  })
  return result
}

// ── ParamRow sub-component ─────────────────────────────────────────────────

function ParamRow({ param, sourceBg, sourceColor, onRename, onValueChange, onDelete }) {
  const [editingName, setEditingName] = useState(param.customName || param.key)
  const [editingValue, setEditingValue] = useState(param.value || '')
  const [showMasked, setShowMasked] = useState(false)
  const hideTimerRef = useRef(null)

  // Sync if parent changes the stored value
  useEffect(() => { setEditingName(param.customName || param.key) }, [param.customName, param.key])
  useEffect(() => { setEditingValue(param.value || '') }, [param.value])
  useEffect(() => () => { if (hideTimerRef.current) clearTimeout(hideTimerRef.current) }, [])

  function toggleShow() {
    if (showMasked) {
      clearTimeout(hideTimerRef.current)
      setShowMasked(false)
    } else {
      setShowMasked(true)
      hideTimerRef.current = setTimeout(() => setShowMasked(false), 5000)
    }
  }

  const inputBase = {
    padding: '5px 8px', fontSize: 12, background: 'var(--ps-input-bg)', color: 'var(--ps-text)',
    border: '1px solid var(--ps-border)', borderRadius: 4, outline: 'none',
    boxSizing: 'border-box', fontFamily: 'monospace', width: '100%',
  }

  // ParamRow renders a <tr> so it participates in the parent <table> column layout
  return (
    <tr style={{ borderBottom: '1px solid var(--ps-border)' }}>
      {/* SOURCE */}
      <td style={{ padding: '6px 10px', verticalAlign: 'middle', whiteSpace: 'nowrap' }}>
        <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 5px', borderRadius: 4, background: sourceBg, color: sourceColor, display: 'inline-block', textAlign: 'center', letterSpacing: 0.3 }}>
          {param.source}
        </span>
      </td>
      {/* KEY */}
      <td style={{ padding: '6px 10px', verticalAlign: 'middle', overflow: 'hidden' }}>
        <span style={{ fontSize: 12, color: 'var(--ps-accent)', fontFamily: 'monospace', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {param.key}
        </span>
      </td>
      {/* CUSTOM NAME */}
      <td style={{ padding: '4px 6px', verticalAlign: 'middle' }}>
        <input
          style={inputBase}
          value={editingName}
          onChange={(e) => setEditingName(e.target.value)}
          onBlur={() => { if (editingName.trim() && editingName.trim() !== param.customName) onRename(editingName.trim()); else setEditingName(param.customName || param.key) }}
          onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); else if (e.key === 'Escape') { setEditingName(param.customName || param.key); e.currentTarget.blur() } }}
          title="Click to rename. Press Enter to save."
        />
      </td>
      {/* VALUE */}
      <td style={{ padding: '4px 6px', verticalAlign: 'middle' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <input
            style={{ ...inputBase, flex: 1, minWidth: 0, width: 'auto' }}
            type={param.masked && !showMasked ? 'password' : 'text'}
            value={editingValue}
            onChange={(e) => setEditingValue(e.target.value)}
            onBlur={() => { if (editingValue !== param.value) onValueChange(editingValue) }}
            onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur() }}
            placeholder="value"
            title={param.masked ? (showMasked ? 'Visible — will hide in 5s' : 'Sensitive value') : param.value}
          />
          {param.masked && (
            <button
              type="button"
              onClick={toggleShow}
              title={showMasked ? 'Hide value' : 'Reveal for 5 seconds'}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: showMasked ? '#f97316' : 'var(--ps-text-muted)', padding: '2px', display: 'flex', alignItems: 'center', flexShrink: 0 }}
            >
              {showMasked ? <EyeOffIcon /> : <EyeIcon />}
            </button>
          )}
        </div>
      </td>
      {/* DELETE */}
      <td style={{ padding: '4px 6px', verticalAlign: 'middle', textAlign: 'center' }}>
        <button
          type="button"
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#f85149', fontSize: 16, padding: '0 2px', lineHeight: 1 }}
          title="Remove parameter"
          onClick={onDelete}
        >
          ×
        </button>
      </td>
    </tr>
  )
}

function EyeIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function EyeOffIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
      <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
      <line x1="1" y1="1" x2="23" y2="23" />
    </svg>
  )
}

function ParamRowNoSource({ param, onRename, onValueChange, onDelete }) {
  const [editingName, setEditingName] = useState(param.customName || param.key)
  const [editingValue, setEditingValue] = useState(param.value || '')
  const [showMasked, setShowMasked] = useState(false)
  const hideTimerRef = useRef(null)

  useEffect(() => { setEditingName(param.customName || param.key) }, [param.customName, param.key])
  useEffect(() => { setEditingValue(param.value || '') }, [param.value])
  useEffect(() => () => { if (hideTimerRef.current) clearTimeout(hideTimerRef.current) }, [])

  function toggleShow() {
    if (showMasked) { clearTimeout(hideTimerRef.current); setShowMasked(false) }
    else { setShowMasked(true); hideTimerRef.current = setTimeout(() => setShowMasked(false), 5000) }
  }

  const inputBase = {
    padding: '5px 8px', fontSize: 12, background: 'var(--ps-input-bg)', color: 'var(--ps-text)',
    border: '1px solid var(--ps-border)', borderRadius: 4, outline: 'none',
    boxSizing: 'border-box', fontFamily: 'monospace', width: '100%',
  }

  return (
    <tr style={{ borderBottom: '1px solid var(--ps-border)' }}>
      <td style={{ padding: '6px 10px', verticalAlign: 'middle', overflow: 'hidden' }}>
        <span style={{ fontSize: 12, color: 'var(--ps-accent)', fontFamily: 'monospace', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {param.key}
        </span>
      </td>
      <td style={{ padding: '4px 6px', verticalAlign: 'middle' }}>
        <input
          style={inputBase}
          value={editingName}
          onChange={(e) => setEditingName(e.target.value)}
          onBlur={() => { if (editingName.trim() && editingName.trim() !== param.customName) onRename(editingName.trim()); else setEditingName(param.customName || param.key) }}
          onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); else if (e.key === 'Escape') { setEditingName(param.customName || param.key); e.currentTarget.blur() } }}
          title="Click to rename. Press Enter to save."
        />
      </td>
      <td style={{ padding: '4px 6px', verticalAlign: 'middle' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <input
            style={{ ...inputBase, flex: 1, minWidth: 0, width: 'auto' }}
            type={param.masked && !showMasked ? 'password' : 'text'}
            value={editingValue}
            onChange={(e) => setEditingValue(e.target.value)}
            onBlur={() => { if (editingValue !== param.value) onValueChange(editingValue) }}
            onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); else if (e.key === 'Escape') { setEditingValue(param.value || ''); e.currentTarget.blur() } }}
            title="Click to edit. Press Enter to save."
          />
          {param.masked && (
            <button
              type="button"
              style={{ background: 'none', border: 'none', padding: 2, cursor: 'pointer', color: 'var(--ps-text-muted)', flexShrink: 0 }}
              onClick={toggleShow}
              title={showMasked ? 'Hide value' : 'Show value for 5 seconds'}
            >
              {showMasked ? <EyeOffIcon /> : <EyeIcon />}
            </button>
          )}
        </div>
      </td>
      <td style={{ padding: '4px 6px', verticalAlign: 'middle', textAlign: 'center' }}>
        <button type="button" style={{ background: 'none', border: 'none', color: '#f97373', cursor: 'pointer', fontSize: 16, padding: '0 4px', lineHeight: 1 }} onClick={onDelete} title="Remove parameter">×</button>
      </td>
    </tr>
  )
}

/* ── Styles ────────────────────────────────────────────────────────────── */

const globalBarStyle = {
  display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center',
  background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 8,
  padding: '8px 14px', fontSize: 13,
}
const flowPanelStyle = {
  flex: '0 0 190px',
  background: 'var(--ps-bg)',
  border: '1px solid var(--ps-border)',
  borderRadius: 8,
  display: 'flex',
  flexDirection: 'column',
  maxHeight: 'calc(100vh - 200px)',
  overflow: 'hidden',
}
const flowTabsRowStyle = {
  display: 'flex',
  gap: 6,
  padding: '6px 8px 4px',
  borderBottom: '1px solid var(--ps-border)',
}
const flowTabBtnStyle = {
  padding: '4px 12px',
  fontSize: 12,
  fontWeight: 500,
  borderRadius: 999,
  border: 'none',
  cursor: 'pointer',
  background: 'transparent',
  color: 'var(--ps-text-muted)',
}
const flowTabActiveStyle = {
  background: '#1d9bf0',
  color: '#fff',
}
const flowHeaderStyle = {
  padding: '8px 10px',
  borderBottom: '1px solid var(--ps-border)',
  fontSize: 12,
  fontWeight: 600,
  color: 'var(--ps-text)',
}
const flowListStyle = {
  flex: 1,
  overflowY: 'auto',
  padding: '4px 4px 4px 6px',
}
const flowItemStyle = {
  width: '100%',
  textAlign: 'left',
  border: 'none',
  background: 'transparent',
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  padding: '6px 8px',
  borderRadius: 6,
  cursor: 'pointer',
  marginBottom: 2,
}
const flowItemInactiveStyle = {
  background: 'transparent',
  color: 'var(--ps-text-muted)',
}
const flowItemActiveStyle = {
  background: 'var(--ps-hover)',
  color: 'var(--ps-text)',
}
const flowIndexStyle = {
  width: 18,
  height: 18,
  borderRadius: 999,
  background: 'var(--ps-card)',
  border: '1px solid var(--ps-border)',
  fontSize: 11,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: 'var(--ps-text-muted)',
}
const flowLabelStyle = {
  fontSize: 13,
  flex: 1,
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
}
const flowAddBtnStyle = {
  border: 'none',
  borderTop: '1px solid var(--ps-border)',
  padding: '8px 10px',
  fontSize: 13,
  background: 'var(--ps-bg)',
  color: 'var(--ps-accent)',
  cursor: 'pointer',
  textAlign: 'left',
}
const leftPanelStyle = {
  flex: '0 0 492px', background: 'var(--ps-bg)', border: '1px solid var(--ps-border)',
  borderRadius: 8, display: 'flex', flexDirection: 'column',
  maxHeight: 'calc(100vh - 200px)', overflow: 'hidden',
}
const rightPanelStyle = {
  flex: '0 0 490px', background: 'var(--ps-bg)', border: '1px solid var(--ps-border)',
  borderRadius: 8, height: 'calc(100vh - 200px)', maxHeight: 'calc(100vh - 200px)',
  overflow: 'hidden', display: 'flex', flexDirection: 'column',
}
const scrollBtnStyle = {
  background: 'transparent',
  border: 'none',
  color: '#8b98a5',
  fontSize: 16,
  cursor: 'pointer',
  padding: '4px 6px',
  lineHeight: 1,
  alignSelf: 'center',
  flexShrink: 0,
}
const tabCloseBtnStyle = {
  fontSize: 13,
  cursor: 'pointer',
  color: 'inherit',
  opacity: 0.7,
  lineHeight: 1,
  marginLeft: 2,
  padding: '0 1px',
}
const labelStyle = { display: 'block', fontSize: 13, fontWeight: 600, color: 'var(--ps-text-muted)', marginBottom: 4 }
const inputStyle = {
  width: '100%', padding: '7px 10px', fontSize: 14, background: 'var(--ps-input-bg)',
  color: 'var(--ps-text)', border: '1px solid var(--ps-border)', borderRadius: 6,
  outline: 'none', boxSizing: 'border-box',
}

const designerScrollStyle = {
  padding: 0, flex: 1, overflowY: 'auto',
}
const designerSectionStyle = {
  padding: '14px 16px',
  borderBottom: '1px solid var(--ps-border)',
  margin: '6px 0',
}
const fieldRowStyle = {
  display: 'flex', alignItems: 'center', gap: 10,
}
const fieldLabelStyle = {
  fontSize: 13, fontWeight: 600, color: 'var(--ps-text-muted)',
  width: 105, flexShrink: 0, marginBottom: 0,
}
const dInputStyle = {
  padding: '6px 10px', fontSize: 13, background: 'var(--ps-input-bg)',
  color: 'var(--ps-text)', border: '1px solid var(--ps-border)', borderRadius: 5,
  outline: 'none', boxSizing: 'border-box', width: '100%',
}
const dTextareaStyle = {
  ...dInputStyle, resize: 'vertical', fontFamily: 'monospace', fontSize: 12,
  lineHeight: 1.5, width: '100%',
}
const dPreStyle = {
  fontSize: 12, color: 'var(--ps-text-muted)', background: 'var(--ps-bg)',
  borderRadius: 5, padding: '8px 10px', margin: 0, overflow: 'auto', maxHeight: 200,
  whiteSpace: 'pre-wrap', wordBreak: 'break-all', lineHeight: 1.5,
  border: '1px solid var(--ps-border)',
}
const addBtnStyle = {
  fontSize: 12, padding: '3px 10px', background: 'transparent', color: '#1d9bf0',
  border: '1px solid #1d9bf0', borderRadius: 4, cursor: 'pointer', fontWeight: 500,
}
const removeBtnStyle = {
  background: 'none', border: 'none', color: '#f85149', cursor: 'pointer',
  fontSize: 15, padding: '0 4px', lineHeight: 1, flexShrink: 0,
}
const inputSmallStyle = { ...inputStyle, width: 120, padding: '5px 8px', fontSize: 13 }
const textareaStyle = {
  ...inputStyle, resize: 'vertical', fontFamily: 'monospace', fontSize: 13,
  lineHeight: 1.5, width: '100%',
}
const smallBtnStyle = {
  fontSize: 12, padding: '4px 12px', background: 'var(--ps-card)',
  color: 'var(--ps-text-2)', border: '1px solid var(--ps-border)', borderRadius: 5, cursor: 'pointer',
}
const iconBtnSmStyle = {
  background: 'none', border: 'none', color: '#f85149', cursor: 'pointer',
  fontSize: 16, padding: '0 5px', lineHeight: 1,
}
const runBtnStyle = {
  padding: '9px 22px', fontSize: 14, fontWeight: 600, background: '#238636',
  color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer',
}
const createScriptBtnStyle = {
  padding: '7px 20px', fontSize: 14, fontWeight: 600, background: '#1d9bf0',
  color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer',
}
const secondaryActionBtnStyle = {
  padding: '6px 16px', fontSize: 13, fontWeight: 500, background: 'var(--ps-card)',
  color: 'var(--ps-text-2)', border: '1px solid var(--ps-border)', borderRadius: 6, cursor: 'pointer',
}
const cancelBtnStyle = {
  padding: '9px 22px', fontSize: 14, background: 'var(--ps-card)', color: 'var(--ps-text-2)',
  border: '1px solid var(--ps-border)', borderRadius: 8, cursor: 'pointer',
}
const sectionHeadStyle = { fontSize: 14, fontWeight: 600, color: 'var(--ps-text)', marginBottom: 6 }
const toolbarFooterStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '8px 14px',
  borderTop: '1px solid var(--ps-border)',
  background: 'var(--ps-bg)',
  flexShrink: 0,
}
const toolbarIconBtnStyle = {
  width: 32,
  height: 32,
  borderRadius: 8,
  border: '1px solid var(--ps-border)',
  background: 'var(--ps-card)',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: 'var(--ps-text-2)',
  cursor: 'pointer',
}
const toolbarDeleteBtnStyle = {
  ...toolbarIconBtnStyle,
  color: '#f97373',
}
const toolbarRunBtnStyle = {
  width: 38,
  height: 38,
  borderRadius: 999,
  border: 'none',
  background: '#238636',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: '#fff',
  cursor: 'pointer',
}
const toolbarRunHoverStyle = {
  transform: 'scale(1.08)',
  boxShadow: '0 0 12px rgba(35, 134, 54, 0.6)',
}
const detailTabsRowStyle = {
  display: 'flex',
  gap: 4,
  marginBottom: 10,
  borderBottom: '1px solid var(--ps-border)',
}
const detailTabBtnStyle = {
  padding: '4px 10px',
  fontSize: 13,
  background: 'transparent',
  border: 'none',
  borderBottom: '2px solid var(--ps-bg)',
  color: 'var(--ps-text-muted)',
  cursor: 'pointer',
  fontWeight: 500,
}
const detailTabActiveStyle = {
  color: 'var(--ps-text)',
  borderBottom: '2px solid var(--ps-accent)',
}
const preStyle = {
  fontSize: 12, color: 'var(--ps-text-2)', background: 'var(--ps-card)', borderRadius: 6,
  padding: 10, margin: 0, overflowY: 'auto', overflowX: 'hidden', maxHeight: 300, whiteSpace: 'pre-wrap',
  wordBreak: 'break-all', lineHeight: 1.5,
}
const overlayStyle = {
  position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex',
  justifyContent: 'center', alignItems: 'center', zIndex: 9999,
}
const dialogStyle = {
  background: 'var(--ps-card)', border: '1px solid var(--ps-border)', borderRadius: 10,
  padding: 24, width: 540, maxHeight: '80vh', overflow: 'auto',
}
const dialogThStyle = {
  textAlign: 'left', fontSize: 13, color: 'var(--ps-text-muted)', padding: '6px 8px',
  borderBottom: '1px solid var(--ps-border)',
}
const dialogTdStyle = {
  fontSize: 14, padding: '6px 8px', borderBottom: '1px solid var(--ps-border)', color: 'var(--ps-text-2)',
}

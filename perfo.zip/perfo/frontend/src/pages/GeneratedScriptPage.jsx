import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getPythonScript } from '../api'

export default function GeneratedScriptPage() {
  const { scriptId } = useParams()
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    getPythonScript(scriptId)
      .then(setCode)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [scriptId])

  if (loading) return <p>Loading...</p>
  if (error) return <p style={{ color: '#f4212e' }}>{error}</p>

  return (
    <div>
      <div style={{ marginBottom: '1rem' }}>
        <Link to="/app/scripts">← Scripts</Link>
        {' · '}
        <Link to={`/app/scripts/${scriptId}`}>View parsed APIs</Link>
      </div>
      <h1 style={{ marginTop: 0 }}>Generated Python Script</h1>
      <pre
        style={{
          background: '#16181c',
          padding: '1rem',
          borderRadius: 8,
          overflow: 'auto',
          fontSize: 13,
          lineHeight: 1.5,
          border: '1px solid #2f3336',
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
        }}
      >
        <code>{code || '(empty)'}</code>
      </pre>
    </div>
  )
}

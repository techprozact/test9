import { useState, useEffect, useCallback, useRef } from 'react'
import { useTheme } from '../context/ThemeContext'
import {
  listScripts,
  listScenarios,
  createScenario,
  updateScenario,
  deleteScenario,
  getScriptParameters,
} from '../api'

/* ────────────────── helpers ────────────────── */

function fmtDate(d) {
  if (!d) return '—'
  const dt = typeof d === 'string' ? new Date(d) : d
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

function totalUsers(scripts) {
  return (scripts || []).reduce((s, sc) => s + (parseInt(sc.users, 10) || 0), 0)
}

const EMPTY_SCRIPT_ENTRY = () => ({
  _key: Date.now() + Math.random(),
  script_id: '',
  script_name: '',
  users: 10,
  pacing: '5',
  think_time: '3',
  parameters: {},
})

/* ────────────────────────────────────────────── */

export default function LoadDesignerPage() {
  const { t, isDark } = useTheme()

  /* ── list state ── */
  const [scenarios, setScenarios] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  /* ── form state ── */
  const [view, setView] = useState('list') // 'list' | 'form'
  const [editId, setEditId] = useState(null)
  const [scenarioName, setScenarioName] = useState('')
  const [scenarioDesc, setScenarioDesc] = useState('')
  const [duration, setDuration] = useState('5')
  const [durationUnit, setDurationUnit] = useState('m')
  const [rampUp, setRampUp] = useState('30')
  const [rampUpUnit, setRampUpUnit] = useState('s')
  const [rampDown, setRampDown] = useState('15')
  const [rampDownUnit, setRampDownUnit] = useState('s')
  const [scriptEntries, setScriptEntries] = useState([])
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState('')

  /* ── script picker ── */
  const [perfzyScripts, setPerfzyScripts] = useState([])
  const [showScriptPicker, setShowScriptPicker] = useState(false)
  const [scriptSearch, setScriptSearch] = useState('')
  const pickerRef = useRef(null)

  /* ── param modal ── */
  const [paramModal, setParamModal] = useState(null) // { entryIdx, params: [{name,default_value,source}], grid: [[]] }
  const [mirrorFirstVuser, setMirrorFirstVuser] = useState(false)

  /* ── delete confirm ── */
  const [deleteConfirm, setDeleteConfirm] = useState(null)

  /* ── list search ── */
  const [listSearch, setListSearch] = useState('')

  /* ── hover states ── */
  const [hoveredCard, setHoveredCard] = useState(null)
  const [hoveredRow, setHoveredRow] = useState(null)

  /* ────── data loading ────── */

  const loadScenarios = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await listScenarios()
      setScenarios(data)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  const loadPerfzyScripts = useCallback(async () => {
    try {
      const all = await listScripts()
      setPerfzyScripts(all.filter((s) => (s.script_type || '').toLowerCase() === 'perfzy'))
    } catch (_) {}
  }, [])

  useEffect(() => {
    loadScenarios()
    loadPerfzyScripts()
  }, [loadScenarios, loadPerfzyScripts])

  /* ── close picker on outside click ── */
  useEffect(() => {
    function handleClick(e) {
      if (pickerRef.current && !pickerRef.current.contains(e.target)) setShowScriptPicker(false)
    }
    if (showScriptPicker) document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [showScriptPicker])

  /* ────── form helpers ────── */

  function openNewForm() {
    setEditId(null)
    setScenarioName('')
    setScenarioDesc('')
    setDuration('5')
    setDurationUnit('m')
    setRampUp('30')
    setRampUpUnit('s')
    setRampDown('15')
    setRampDownUnit('s')
    setScriptEntries([])
    setSaveError('')
    setView('form')
  }

  function openEditForm(sc) {
    setEditId(sc.id)
    setScenarioName(sc.scenario_name || '')
    setScenarioDesc(sc.description || '')
    const dur = sc.duration || '5m'
    setDuration(dur.replace(/[^0-9.]/g, '') || '5')
    setDurationUnit(dur.replace(/[0-9.]/g, '') || 'm')
    const ru = sc.ramp_up || '30s'
    setRampUp(ru.replace(/[^0-9.]/g, '') || '30')
    setRampUpUnit(ru.replace(/[0-9.]/g, '') || 's')
    const rd = sc.ramp_down || '15s'
    setRampDown(rd.replace(/[^0-9.]/g, '') || '15')
    setRampDownUnit(rd.replace(/[0-9.]/g, '') || 's')
    let scripts = []
    try {
      scripts = typeof sc.scripts_json === 'string' ? JSON.parse(sc.scripts_json) : sc.scripts_json || []
    } catch (_) {}
    setScriptEntries(scripts.map((s) => ({ ...s, _key: Date.now() + Math.random() })))
    setSaveError('')
    setView('form')
  }

  function addScript(script) {
    setScriptEntries((prev) => [
      ...prev,
      { ...EMPTY_SCRIPT_ENTRY(), script_id: script.id, script_name: script.script_name },
    ])
    setShowScriptPicker(false)
    setScriptSearch('')
  }

  function updateEntry(idx, field, value) {
    setScriptEntries((prev) => prev.map((e, i) => (i === idx ? { ...e, [field]: value } : e)))
  }

  function removeEntry(idx) {
    setScriptEntries((prev) => prev.filter((_, i) => i !== idx))
  }

  /* ────── param modal ────── */

  async function openParamModal(entryIdx) {
    const entry = scriptEntries[entryIdx]
    if (!entry?.script_id) return
    const params = await getScriptParameters(entry.script_id)
    if (!params.length) {
      alert('No configurable parameters found for this script.')
      return
    }
    const numUsers = parseInt(entry.users, 10) || 1
    const existingParams = entry.parameters || {}
    const grid = []
    for (let u = 0; u < numUsers; u++) {
      const row = {}
      for (const p of params) {
        const arr = existingParams[p.name] || []
        row[p.name] = arr[u] !== undefined ? arr[u] : (u === 0 ? p.default_value : '')
      }
      grid.push(row)
    }
    setParamModal({ entryIdx, params, grid })
    setMirrorFirstVuser(false)
  }

  function updateParamCell(userIdx, paramName, value) {
    setParamModal((prev) => {
      if (!prev) return prev
      // When mirroring is active and the edit is on VUser 1 (index 0),
      // propagate the new value to all other VUsers for the same parameter.
      const grid = prev.grid.map((row, i) => {
        if (i === userIdx) return { ...row, [paramName]: value }
        if (mirrorFirstVuser && userIdx === 0) return { ...row, [paramName]: value }
        return row
      })
      return { ...prev, grid }
    })
  }

  function applyParams() {
    if (!paramModal) return
    const { entryIdx, params, grid } = paramModal
    const parameters = {}
    for (const p of params) {
      parameters[p.name] = grid.map((row) => row[p.name] || '')
    }
    updateEntry(entryIdx, 'parameters', parameters)
    setParamModal(null)
  }

  /* ────── save / delete ────── */

  async function handleSave() {
    if (!scenarioName.trim()) {
      setSaveError('Please enter a scenario name.')
      return
    }

    // Validate that all script entries with parameters have values for every VUser
    for (const entry of scriptEntries) {
      const params = entry.parameters || {}
      const paramNames = Object.keys(params)
      if (!paramNames.length) continue
      const numUsers = parseInt(entry.users, 10) || 1
      for (const paramName of paramNames) {
        const values = params[paramName] || []
        for (let u = 0; u < numUsers; u++) {
          if (!values[u] || !String(values[u]).trim()) {
            setSaveError(
              `Please provide parameter values for all vusers under Script Parameters (script: "${entry.script_name || entry.script_id}", parameter: "${paramName}", VUser ${u + 1} is missing a value).`
            )
            return
          }
        }
      }
    }

    setSaveError('')
    setSaving(true)
    try {
      const payload = {
        scenario_name: scenarioName.trim(),
        description: scenarioDesc.trim(),
        duration: `${duration}${durationUnit}`,
        ramp_up: `${rampUp}${rampUpUnit}`,
        ramp_down: `${rampDown}${rampDownUnit}`,
        scripts: scriptEntries.map(({ _key, ...rest }) => rest),
      }
      if (editId) {
        await updateScenario(editId, payload)
      } else {
        await createScenario(payload)
      }
      await loadScenarios()
      setView('list')
    } catch (e) {
      alert(e.message)
    } finally {
      setSaving(false)
    }
  }

  async function handleDelete(id) {
    try {
      await deleteScenario(id)
      setDeleteConfirm(null)
      await loadScenarios()
    } catch (e) {
      alert(e.message)
    }
  }

  /* ────────────────── styles ────────────────── */

  const pageStyle = {
    minHeight: '100%',
    background: t.pageBg,
    padding: '28px 32px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  }
  const cardStyle = {
    background: t.bgRaised,
    border: `1px solid ${t.border}`,
    borderRadius: 12,
    boxShadow: t.cardShadow,
    transition: 'border-color 0.15s, box-shadow 0.15s',
  }
  const cardHoverStyle = {
    borderColor: t.accent,
    boxShadow: isDark ? `0 0 0 1px ${t.accent}40, 0 4px 20px rgba(0,0,0,0.3)` : `0 0 0 1px ${t.accent}30, 0 4px 16px rgba(0,0,0,0.08)`,
  }
  const inputStyle = {
    background: t.bgInput,
    border: `1px solid ${t.border}`,
    borderRadius: 8,
    color: t.textPrimary,
    padding: '8px 12px',
    fontSize: 13,
    outline: 'none',
    width: '100%',
    transition: 'border-color 0.15s',
  }
  const inputFocusColor = t.accent
  const labelStyle = {
    color: t.textTertiary,
    fontSize: 11,
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: '0.04em',
    marginBottom: 6,
  }
  const primaryBtn = {
    background: t.accent,
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    padding: '9px 20px',
    fontSize: 13,
    fontWeight: 600,
    cursor: 'pointer',
    transition: 'opacity 0.15s, box-shadow 0.15s',
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
  }
  const secondaryBtn = {
    background: 'transparent',
    color: t.textSecondary,
    border: `1px solid ${t.border}`,
    borderRadius: 8,
    padding: '8px 18px',
    fontSize: 13,
    fontWeight: 500,
    cursor: 'pointer',
    transition: 'background 0.15s, border-color 0.15s',
  }
  const dangerBtn = {
    ...secondaryBtn,
    color: '#ef4444',
    borderColor: isDark ? '#ef444430' : '#ef444440',
  }
  const overlayStyle = {
    position: 'fixed',
    inset: 0,
    background: 'rgba(0,0,0,0.55)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    backdropFilter: 'blur(4px)',
  }
  const dialogStyle = {
    background: t.bgRaised,
    border: `1px solid ${t.border}`,
    borderRadius: 14,
    padding: 0,
    maxWidth: 900,
    width: '90vw',
    maxHeight: '80vh',
    overflow: 'hidden',
    boxShadow: isDark ? '0 24px 64px rgba(0,0,0,0.6)' : '0 16px 48px rgba(0,0,0,0.15)',
    display: 'flex',
    flexDirection: 'column',
  }
  const unitSelectStyle = {
    background: t.bgOverlay,
    border: `1px solid ${t.border}`,
    borderRadius: '0 8px 8px 0',
    color: t.textSecondary,
    padding: '8px 8px',
    fontSize: 12,
    fontWeight: 600,
    outline: 'none',
    cursor: 'pointer',
    borderLeft: 'none',
  }
  const pillBadge = (color) => ({
    display: 'inline-flex',
    alignItems: 'center',
    gap: 4,
    padding: '2px 8px',
    borderRadius: 20,
    fontSize: 11,
    fontWeight: 600,
    background: `${color}18`,
    color: color,
    border: `1px solid ${color}30`,
  })

  /* ────── SVG icons ────── */

  const PlusIcon = () => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M8 3v10M3 8h10" />
    </svg>
  )
  const EditIcon = () => (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M11.5 1.5l3 3L5 14H2v-3L11.5 1.5z" />
    </svg>
  )
  const TrashIcon = () => (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M2 4h12M5 4V2h6v2M6 7v5M10 7v5" /><path d="M3 4l1 10h8l1-10" />
    </svg>
  )
  const ScriptIcon = () => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M4 2h6l3 3v9H4V2z" /><path d="M10 2v3h3" /><path d="M6 8h4M6 10.5h3" />
    </svg>
  )
  const UsersIcon = () => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="6" cy="5" r="2.5" /><path d="M1 14c0-3 2.5-5 5-5s5 2 5 5" />
      <circle cx="11" cy="4.5" r="1.8" /><path d="M12 9c2 0 3 1.5 3 4" />
    </svg>
  )
  const ClockIcon = () => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="8" r="6" /><path d="M8 4.5V8l2.5 1.5" />
    </svg>
  )
  const ChevronIcon = () => (
    <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M6 4l4 4-4 4" />
    </svg>
  )
  const ParamsIcon = () => (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M2 4h12M2 8h12M2 12h12" /><circle cx="5" cy="4" r="1.5" fill="currentColor" /><circle cx="10" cy="8" r="1.5" fill="currentColor" /><circle cx="7" cy="12" r="1.5" fill="currentColor" />
    </svg>
  )
  const CloseIcon = () => (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M4 4l8 8M12 4l-8 8" />
    </svg>
  )
  const RocketIcon = () => (
    <svg width="40" height="40" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1">
      <path d="M8 2 L13.5 13 L8 10.5 L2.5 13 Z" strokeLinejoin="round" />
    </svg>
  )

  /* ────────────────── RENDER: LIST VIEW ────────────────── */

  if (view === 'list') {
    const filteredScenarios = scenarios.filter((sc) =>
      !listSearch || sc.scenario_name.toLowerCase().includes(listSearch.toLowerCase()) ||
      (sc.description || '').toLowerCase().includes(listSearch.toLowerCase())
    )
    return (
      <div style={pageStyle}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 22 }}>
          <div>
            <h1 style={{ color: t.textPrimary, fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: '-0.01em' }}>Load Designer</h1>
            <p style={{ color: t.textMuted, fontSize: 13, margin: '4px 0 0' }}>Design and manage load test scenarios with configurable scripts, users, and parameters</p>
          </div>
          <button
            style={primaryBtn}
            onClick={openNewForm}
            onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.9'; e.currentTarget.style.boxShadow = `0 0 0 3px ${t.accent}30` }}
            onMouseLeave={(e) => { e.currentTarget.style.opacity = '1'; e.currentTarget.style.boxShadow = 'none' }}
          >
            <PlusIcon /> New Scenario
          </button>
        </div>

        {/* Search bar */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ position: 'relative', maxWidth: 340 }}>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke={t.textFaint} strokeWidth="1.5"
              style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
              <circle cx="6.5" cy="6.5" r="4" /><path d="M10 10l3 3" />
            </svg>
            <input
              style={{ ...inputStyle, paddingLeft: 32, fontSize: 13 }}
              placeholder="Search scenarios..."
              value={listSearch}
              onChange={(e) => setListSearch(e.target.value)}
              onFocus={(e) => { e.target.style.borderColor = t.accent }}
              onBlur={(e) => { e.target.style.borderColor = t.border }}
            />
          </div>
        </div>

        {/* Loading / Error */}
        {loading && <p style={{ color: t.textMuted, fontSize: 13 }}>Loading scenarios...</p>}
        {error && <p style={{ color: '#ef4444', fontSize: 13 }}>{error}</p>}

        {/* Empty state */}
        {!loading && !error && scenarios.length === 0 && (
          <div style={{
            ...cardStyle,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '64px 32px',
            textAlign: 'center',
          }}>
            <div style={{ marginBottom: 16, opacity: 0.5 }}><RocketIcon /></div>
            <h3 style={{ color: t.textPrimary, fontSize: 16, fontWeight: 600, margin: '0 0 8px' }}>No scenarios yet</h3>
            <p style={{ color: t.textMuted, fontSize: 13, margin: '0 0 20px', maxWidth: 360 }}>
              Create your first load test scenario by adding scripts, configuring virtual users, and defining test parameters.
            </p>
            <button style={primaryBtn} onClick={openNewForm}><PlusIcon /> Create Scenario</button>
          </div>
        )}

        {/* Scenarios table */}
        {!loading && !error && scenarios.length > 0 && (
          <div style={{ ...cardStyle, overflow: 'hidden', padding: 0 }}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed', minWidth: 780 }}>
              <colgroup>
                  <col style={{ width: '22%' }} />
                  <col style={{ width: '20%' }} />
                  <col style={{ width: '9%' }} />
                  <col style={{ width: '9%' }} />
                  <col style={{ width: '10%' }} />
                  <col style={{ width: '10%' }} />
                  <col style={{ width: '10%' }} />
                  <col style={{ width: '10%' }} />
                </colgroup>
                <thead>
                  <tr style={{ background: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(15,23,42,0.025)' }}>
                    {[
                      'Scenario Name', 'Description', 'Scripts',
                      'Total VUs', 'Steady State', 'Ramp-up', 'Ramp-down', 'Last Updated',
                    ].map((h, i) => (
                      <th key={h} style={{
                        padding: i === 0 ? '11px 10px 11px 18px' : '11px 10px',
                        textAlign: 'left',
                        color: t.textTertiary,
                        fontSize: 11,
                        fontWeight: 600,
                        textTransform: 'uppercase',
                        letterSpacing: '0.04em',
                        borderBottom: `2px solid ${t.border}`,
                        whiteSpace: 'nowrap',
                      }}>{h}</th>
                    ))}
                    <th style={{
                      padding: '11px 18px 11px 10px',
                      textAlign: 'right',
                      color: t.textTertiary,
                      fontSize: 11,
                      fontWeight: 600,
                      textTransform: 'uppercase',
                      letterSpacing: '0.04em',
                      borderBottom: `2px solid ${t.border}`,
                      whiteSpace: 'nowrap',
                      width: 90,
                    }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredScenarios.length === 0 ? (
                    <tr>
                      <td colSpan={9} style={{ padding: '32px 18px', textAlign: 'center', color: t.textMuted, fontSize: 13 }}>
                        No scenarios match "{listSearch}".
                      </td>
                    </tr>
                  ) : (
                    filteredScenarios.map((sc, idx) => {
                      let scripts = []
                      try {
                        scripts = typeof sc.scripts_json === 'string' ? JSON.parse(sc.scripts_json) : sc.scripts_json || []
                      } catch (_) {}
                      const isHovered = hoveredCard === sc.id
                      const rowBg = isHovered
                        ? (isDark ? 'rgba(255,255,255,0.045)' : 'rgba(15,23,42,0.04)')
                        : idx % 2 === 1 ? t.tableRowAlt : 'transparent'
                      return (
                        <tr
                          key={sc.id}
                          style={{ background: rowBg, cursor: 'pointer', transition: 'background 0.1s' }}
                          onMouseEnter={() => setHoveredCard(sc.id)}
                          onMouseLeave={() => setHoveredCard(null)}
                          onClick={() => openEditForm(sc)}
                        >
                          {/* Scenario name */}
                          <td style={{ padding: '12px 10px 12px 18px', borderBottom: `1px solid ${t.border}` }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                              <div style={{
                                width: 28, height: 28, borderRadius: 8, flexShrink: 0,
                                background: `${t.accent}15`,
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                              }}>
                                <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.5">
                                  <path d="M8 2 L13.5 13 L8 10.5 L2.5 13 Z" strokeLinejoin="round" />
                                </svg>
                              </div>
                              <span style={{
                                color: t.textPrimary, fontSize: 13, fontWeight: 600,
                                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                              }}>
                                {sc.scenario_name}
                              </span>
                            </div>
                          </td>
                          {/* Description */}
                          <td style={{ padding: '12px 10px', borderBottom: `1px solid ${t.border}` }}>
                            <span style={{
                              color: t.textMuted, fontSize: 12,
                              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                              display: 'block',
                            }}>
                              {sc.description || <span style={{ color: t.textFaint, fontStyle: 'italic' }}>—</span>}
                            </span>
                          </td>
                          {/* Scripts count */}
                          <td style={{ padding: '12px 10px', borderBottom: `1px solid ${t.border}` }}>
                            <span style={pillBadge(t.accent)}>
                              {scripts.length}
                            </span>
                          </td>
                          {/* Total VUs */}
                          <td style={{ padding: '12px 10px', borderBottom: `1px solid ${t.border}` }}>
                            <span style={pillBadge('#a78bfa')}>
                              {totalUsers(scripts)}
                            </span>
                          </td>
                          {/* Duration */}
                          <td style={{ padding: '12px 10px', borderBottom: `1px solid ${t.border}` }}>
                            <span style={{
                              color: t.textSecondary, fontSize: 12, fontWeight: 600,
                              fontVariantNumeric: 'tabular-nums',
                            }}>
                              {sc.duration || '—'}
                            </span>
                          </td>
                          {/* Ramp-up */}
                          <td style={{ padding: '12px 10px', borderBottom: `1px solid ${t.border}` }}>
                            <span style={{ color: t.textMuted, fontSize: 12 }}>{sc.ramp_up || '—'}</span>
                          </td>
                          {/* Ramp-down */}
                          <td style={{ padding: '12px 10px', borderBottom: `1px solid ${t.border}` }}>
                            <span style={{ color: t.textMuted, fontSize: 12 }}>{sc.ramp_down || '—'}</span>
                          </td>
                          {/* Last updated */}
                          <td style={{ padding: '12px 10px', borderBottom: `1px solid ${t.border}` }}>
                            <span style={{ color: t.textFaint, fontSize: 11 }}>{fmtDate(sc.updated_at || sc.created_at)}</span>
                          </td>
                          {/* Actions */}
                          <td style={{ padding: '12px 18px 12px 10px', borderBottom: `1px solid ${t.border}`, textAlign: 'right' }} onClick={(e) => e.stopPropagation()}>
                            <div style={{ display: 'inline-flex', gap: 4 }}>
                              <button
                                style={{
                                  background: 'none', border: `1px solid ${t.border}`,
                                  borderRadius: 6, color: t.textMuted,
                                  cursor: 'pointer', padding: '4px 7px',
                                  display: 'inline-flex', alignItems: 'center',
                                  transition: 'all 0.12s',
                                }}
                                onClick={() => openEditForm(sc)}
                                title="Edit scenario"
                                onMouseEnter={(e) => { e.currentTarget.style.borderColor = t.accent; e.currentTarget.style.color = t.accent; e.currentTarget.style.background = `${t.accent}10` }}
                                onMouseLeave={(e) => { e.currentTarget.style.borderColor = t.border; e.currentTarget.style.color = t.textMuted; e.currentTarget.style.background = 'none' }}
                              >
                                <EditIcon />
                              </button>
                              <button
                                style={{
                                  background: 'none', border: `1px solid ${isDark ? '#ef444430' : '#ef444435'}`,
                                  borderRadius: 6, color: '#ef4444',
                                  cursor: 'pointer', padding: '4px 7px',
                                  display: 'inline-flex', alignItems: 'center',
                                  transition: 'all 0.12s',
                                }}
                                onClick={() => setDeleteConfirm(sc)}
                                title="Delete scenario"
                                onMouseEnter={(e) => { e.currentTarget.style.background = '#ef444415'; e.currentTarget.style.borderColor = '#ef444460' }}
                                onMouseLeave={(e) => { e.currentTarget.style.background = 'none'; e.currentTarget.style.borderColor = isDark ? '#ef444430' : '#ef444435' }}
                              >
                                <TrashIcon />
                              </button>
                            </div>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Delete confirm modal */}
        {deleteConfirm && (
          <div style={overlayStyle} onClick={() => setDeleteConfirm(null)}>
            <div style={{ ...dialogStyle, maxWidth: 420, padding: 24 }} onClick={(e) => e.stopPropagation()}>
              <h3 style={{ color: t.textPrimary, fontSize: 16, fontWeight: 600, margin: '0 0 8px' }}>Delete Scenario</h3>
              <p style={{ color: t.textMuted, fontSize: 13, margin: '0 0 20px' }}>
                Are you sure you want to delete <strong style={{ color: t.textPrimary }}>{deleteConfirm.scenario_name}</strong>? This action cannot be undone.
              </p>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button style={secondaryBtn} onClick={() => setDeleteConfirm(null)}>Cancel</button>
                <button style={{ ...primaryBtn, background: '#ef4444' }} onClick={() => handleDelete(deleteConfirm.id)}>Delete</button>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  /* ────────────────── RENDER: FORM VIEW ────────────────── */

  const filteredScripts = perfzyScripts.filter((s) => {
    if (scriptSearch && !s.script_name.toLowerCase().includes(scriptSearch.toLowerCase())) return false
    return !scriptEntries.some((e) => e.script_id === s.id)
  })

  return (
    <div style={pageStyle}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 24 }}>
        <button
          style={{ ...secondaryBtn, padding: '5px 8px', borderRadius: 6 }}
          onClick={() => setView('list')}
          title="Back"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 3L5 8l5 5" /></svg>
        </button>
        <h1 style={{ color: t.textPrimary, fontSize: 20, fontWeight: 700, margin: 0 }}>
          {editId ? 'Edit Scenario' : 'New Scenario'}
        </h1>
      </div>

      <div style={{ maxWidth: 960, margin: '0 auto' }}>
        {/* ── General Settings ── */}
        <div style={{ ...cardStyle, padding: '20px 24px', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: `${t.accent}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.5"><rect x="2" y="2" width="12" height="12" rx="2" /><path d="M5 6h6M5 9h4" /></svg>
            </div>
            <span style={{ color: t.textPrimary, fontSize: 14, fontWeight: 600 }}>General Settings</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <div style={labelStyle}>Scenario Name *</div>
              <input
                style={inputStyle}
                value={scenarioName}
                onChange={(e) => setScenarioName(e.target.value)}
                placeholder="E.g., E-Commerce Checkout Flow"
                onFocus={(e) => { e.target.style.borderColor = inputFocusColor }}
                onBlur={(e) => { e.target.style.borderColor = t.border }}
              />
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <div style={labelStyle}>Description</div>
              <textarea
                style={{ ...inputStyle, resize: 'vertical', minHeight: 52 }}
                value={scenarioDesc}
                onChange={(e) => setScenarioDesc(e.target.value)}
                placeholder="Optional description for this scenario"
                rows={2}
                onFocus={(e) => { e.target.style.borderColor = inputFocusColor }}
                onBlur={(e) => { e.target.style.borderColor = t.border }}
              />
            </div>
            {/* Duration row */}
            {[
              { label: 'Steady State', val: duration, setVal: setDuration, unit: durationUnit, setUnit: setDurationUnit, ph: '5' },
              { label: 'Ramp-up', val: rampUp, setVal: setRampUp, unit: rampUpUnit, setUnit: setRampUpUnit, ph: '30' },
              { label: 'Ramp-down', val: rampDown, setVal: setRampDown, unit: rampDownUnit, setUnit: setRampDownUnit, ph: '15' },
            ].map((f) => (
              <div key={f.label}>
                <div style={labelStyle}>{f.label}</div>
                <div style={{ display: 'flex' }}>
                  <input
                    type="number"
                    min="0"
                    style={{ ...inputStyle, borderRadius: '8px 0 0 8px', width: 'auto', flex: 1 }}
                    value={f.val}
                    onChange={(e) => f.setVal(e.target.value)}
                    placeholder={f.ph}
                    onFocus={(e) => { e.target.style.borderColor = inputFocusColor }}
                    onBlur={(e) => { e.target.style.borderColor = t.border }}
                  />
                  <select value={f.unit} onChange={(e) => f.setUnit(e.target.value)} style={unitSelectStyle}>
                    <option value="s">sec</option>
                    <option value="m">min</option>
                    <option value="h">hr</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Scripts ── */}
        <div style={{ ...cardStyle, padding: '20px 24px', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: `${t.accentPurple}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <ScriptIcon />
              </div>
              <span style={{ color: t.textPrimary, fontSize: 14, fontWeight: 600 }}>Scripts</span>
              {scriptEntries.length > 0 && (
                <span style={{ color: t.textFaint, fontSize: 12 }}>({scriptEntries.length})</span>
              )}
            </div>
            <div style={{ position: 'relative' }} ref={pickerRef}>
              <button
                style={{ ...primaryBtn, padding: '7px 14px', fontSize: 12 }}
                onClick={() => { setShowScriptPicker(!showScriptPicker); setScriptSearch('') }}
              >
                <PlusIcon /> Add Script
              </button>
              {showScriptPicker && (
                <div style={{
                  position: 'absolute',
                  top: '100%',
                  right: 0,
                  marginTop: 6,
                  width: 320,
                  background: t.dropdownBg,
                  border: `1px solid ${t.dropdownBorder}`,
                  borderRadius: 10,
                  boxShadow: t.dropdownShadow,
                  zIndex: 50,
                  overflow: 'hidden',
                }}>
                  <div style={{ padding: '8px 10px', borderBottom: `1px solid ${t.border}` }}>
                    <input
                      autoFocus
                      style={{ ...inputStyle, fontSize: 12, padding: '6px 10px' }}
                      placeholder="Search Perfzy scripts..."
                      value={scriptSearch}
                      onChange={(e) => setScriptSearch(e.target.value)}
                    />
                  </div>
                  <div style={{ maxHeight: 220, overflowY: 'auto' }}>
                    {filteredScripts.length === 0 && (
                      <div style={{ padding: '16px 14px', color: t.textMuted, fontSize: 12, textAlign: 'center' }}>
                        {perfzyScripts.length === 0 ? 'No Perfzy scripts available. Create one in API Studio.' : 'No matching scripts.'}
                      </div>
                    )}
                    {filteredScripts.map((s) => (
                      <div
                        key={s.id}
                        style={{
                          padding: '10px 14px',
                          cursor: 'pointer',
                          fontSize: 13,
                          color: t.textPrimary,
                          borderBottom: `1px solid ${t.border}`,
                          transition: 'background 0.1s',
                        }}
                        onClick={() => addScript(s)}
                        onMouseEnter={(e) => { e.currentTarget.style.background = t.bgHover }}
                        onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent' }}
                      >
                        <div style={{ fontWeight: 500 }}>{s.script_name}</div>
                        <div style={{ color: t.textFaint, fontSize: 11, marginTop: 2 }}>ID: {s.id}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ── Script table ── */}
          <div style={{ overflowX: 'auto', borderRadius: 10, border: scriptEntries.length === 0 ? `2px dashed ${t.border}` : `1px solid ${t.border}` }}>
            {scriptEntries.length === 0 ? (
              <div style={{ padding: '36px 20px', textAlign: 'center' }}>
                <div style={{ marginBottom: 8, opacity: 0.35 }}>
                  <svg width="28" height="28" viewBox="0 0 16 16" fill="none" stroke={t.textMuted} strokeWidth="1"><path d="M4 2h6l3 3v9H4V2z" /><path d="M10 2v3h3" /><path d="M6 8h4M6 10.5h3" /></svg>
                </div>
                <p style={{ color: t.textMuted, fontSize: 13, margin: 0 }}>
                  No scripts added yet. Click <strong style={{ color: t.textSecondary }}>+ Add Script</strong> to include Perfzy scripts in this scenario.
                </p>
              </div>
            ) : (
              <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed', minWidth: 700 }}>
                <colgroup>
                  <col style={{ width: 44 }} />
                  <col style={{ width: '28%' }} />
                  <col style={{ width: '14%' }} />
                  <col style={{ width: '14%' }} />
                  <col style={{ width: '14%' }} />
                  <col style={{ width: '22%' }} />
                  <col style={{ width: 52 }} />
                </colgroup>
                <thead>
                  <tr style={{ background: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(15,23,42,0.03)' }}>
                    {['#', 'Script Name', 'Virtual Users', 'Pacing (sec)', 'Think Time (sec)', 'Parameters', ''].map((h, i) => (
                      <th key={i} style={{
                        padding: i === 0 ? '10px 0 10px 14px' : '10px 10px',
                        textAlign: i === 0 ? 'center' : 'left',
                        color: t.textTertiary,
                        fontSize: 11,
                        fontWeight: 600,
                        textTransform: 'uppercase',
                        letterSpacing: '0.04em',
                        borderBottom: `2px solid ${t.border}`,
                        whiteSpace: 'nowrap',
                      }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {scriptEntries.map((entry, idx) => {
                    const paramCount = entry.parameters ? Object.keys(entry.parameters).length : 0
                    const filledCount = paramCount > 0
                      ? Object.values(entry.parameters).reduce((s, vals) => s + vals.filter(Boolean).length, 0)
                      : 0
                    const totalParamVals = paramCount > 0
                      ? Object.values(entry.parameters).reduce((s, vals) => s + vals.length, 0)
                      : 0
                    const isRowHovered = hoveredRow === entry._key
                    return (
                      <tr
                        key={entry._key}
                        style={{
                          background: isRowHovered
                            ? (isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.03)')
                            : (idx % 2 === 1 ? t.tableRowAlt : 'transparent'),
                          transition: 'background 0.1s',
                        }}
                        onMouseEnter={() => setHoveredRow(entry._key)}
                        onMouseLeave={() => setHoveredRow(null)}
                      >
                        {/* # */}
                        <td style={{ padding: '8px 0 8px 14px', textAlign: 'center', borderBottom: `1px solid ${t.border}` }}>
                          <span style={{
                            width: 22, height: 22, borderRadius: 6,
                            background: `${t.accent}18`, color: t.accent,
                            fontSize: 11, fontWeight: 700,
                            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                          }}>{idx + 1}</span>
                        </td>
                        {/* Script name */}
                        <td style={{ padding: '8px 10px', borderBottom: `1px solid ${t.border}` }}>
                          <div style={{ fontWeight: 600, fontSize: 13, color: t.textPrimary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {entry.script_name || '—'}
                          </div>
                          <div style={{ fontSize: 10, color: t.textFaint, marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            ID: {entry.script_id}
                          </div>
                        </td>
                        {/* Virtual Users */}
                        <td style={{ padding: '8px 10px', borderBottom: `1px solid ${t.border}` }}>
                          <input
                            type="number" min="1"
                            style={{ ...inputStyle, padding: '5px 8px', fontSize: 12, borderRadius: 6 }}
                            value={entry.users}
                            onChange={(e) => updateEntry(idx, 'users', e.target.value)}
                            onFocus={(e) => { e.target.style.borderColor = inputFocusColor }}
                            onBlur={(e) => { e.target.style.borderColor = t.border }}
                          />
                        </td>
                        {/* Pacing */}
                        <td style={{ padding: '8px 10px', borderBottom: `1px solid ${t.border}` }}>
                          <input
                            type="number" min="0" step="0.5"
                            style={{ ...inputStyle, padding: '5px 8px', fontSize: 12, borderRadius: 6 }}
                            value={entry.pacing}
                            onChange={(e) => updateEntry(idx, 'pacing', e.target.value)}
                            onFocus={(e) => { e.target.style.borderColor = inputFocusColor }}
                            onBlur={(e) => { e.target.style.borderColor = t.border }}
                          />
                        </td>
                        {/* Think Time */}
                        <td style={{ padding: '8px 10px', borderBottom: `1px solid ${t.border}` }}>
                          <input
                            type="number" min="0" step="0.5"
                            style={{ ...inputStyle, padding: '5px 8px', fontSize: 12, borderRadius: 6 }}
                            value={entry.think_time}
                            onChange={(e) => updateEntry(idx, 'think_time', e.target.value)}
                            onFocus={(e) => { e.target.style.borderColor = inputFocusColor }}
                            onBlur={(e) => { e.target.style.borderColor = t.border }}
                          />
                        </td>
                        {/* Parameters */}
                        <td style={{ padding: '8px 10px', borderBottom: `1px solid ${t.border}` }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <button
                              style={{
                                background: paramCount > 0 ? `${t.accentPurple}18` : 'transparent',
                                border: `1px solid ${paramCount > 0 ? t.accentPurple + '40' : t.border}`,
                                borderRadius: 7,
                                color: paramCount > 0 ? t.accentPurple : t.textMuted,
                                padding: '4px 10px',
                                fontSize: 11,
                                fontWeight: 600,
                                cursor: 'pointer',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 4,
                                whiteSpace: 'nowrap',
                                transition: 'all 0.15s',
                              }}
                              onClick={() => openParamModal(idx)}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = `${t.accentPurple}25`
                                e.currentTarget.style.borderColor = t.accentPurple + '60'
                                e.currentTarget.style.color = t.accentPurple
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = paramCount > 0 ? `${t.accentPurple}18` : 'transparent'
                                e.currentTarget.style.borderColor = paramCount > 0 ? t.accentPurple + '40' : t.border
                                e.currentTarget.style.color = paramCount > 0 ? t.accentPurple : t.textMuted
                              }}
                            >
                              <ParamsIcon />
                              {paramCount > 0 ? `${paramCount} param${paramCount !== 1 ? 's' : ''}` : 'Set params'}
                            </button>
                            {paramCount > 0 && totalParamVals > 0 && (
                              <span style={{ fontSize: 10, color: t.textFaint, whiteSpace: 'nowrap' }}>
                                {filledCount}/{totalParamVals} filled
                              </span>
                            )}
                          </div>
                        </td>
                        {/* Remove */}
                        <td style={{ padding: '8px 12px 8px 4px', borderBottom: `1px solid ${t.border}`, textAlign: 'center' }}>
                          <button
                            style={{
                              background: 'none', border: 'none',
                              color: t.textFaint,
                              cursor: 'pointer', padding: '4px 6px',
                              borderRadius: 6,
                              display: 'inline-flex', alignItems: 'center',
                              transition: 'color 0.15s, background 0.15s',
                            }}
                            onClick={() => removeEntry(idx)}
                            title="Remove"
                            onMouseEnter={(e) => { e.currentTarget.style.color = '#ef4444'; e.currentTarget.style.background = '#ef444415' }}
                            onMouseLeave={(e) => { e.currentTarget.style.color = t.textFaint; e.currentTarget.style.background = 'none' }}
                          >
                            <TrashIcon />
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
                {/* Footer summary row */}
                <tfoot>
                  <tr style={{ background: isDark ? 'rgba(255,255,255,0.02)' : 'rgba(15,23,42,0.02)' }}>
                    <td colSpan={2} style={{ padding: '8px 14px', borderTop: `2px solid ${t.border}` }}>
                      <span style={{ color: t.textFaint, fontSize: 11, fontWeight: 600 }}>
                        {scriptEntries.length} script{scriptEntries.length !== 1 ? 's' : ''} total
                      </span>
                    </td>
                    <td style={{ padding: '8px 10px', borderTop: `2px solid ${t.border}` }}>
                      <span style={{ color: t.accent, fontSize: 12, fontWeight: 700 }}>
                        {scriptEntries.reduce((s, e) => s + (parseInt(e.users, 10) || 0), 0)}
                      </span>
                      <span style={{ color: t.textFaint, fontSize: 11 }}> VUs</span>
                    </td>
                    <td colSpan={4} style={{ padding: '8px 10px', borderTop: `2px solid ${t.border}` }} />
                  </tr>
                </tfoot>
              </table>
            )}
          </div>
        </div>

        {/* ── Footer actions ── */}
        {saveError && (
          <div style={{
            background: isDark ? 'rgba(239,68,68,0.1)' : 'rgba(239,68,68,0.07)',
            border: '1px solid rgba(239,68,68,0.35)',
            borderRadius: 8,
            padding: '10px 14px',
            marginBottom: 12,
            display: 'flex',
            alignItems: 'flex-start',
            gap: 8,
          }}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#ef4444" strokeWidth="1.5" style={{ flexShrink: 0, marginTop: 1 }}>
              <circle cx="8" cy="8" r="6" />
              <path d="M8 5v3M8 10.5v.5" strokeLinecap="round" />
            </svg>
            <span style={{ fontSize: 13, color: '#ef4444', lineHeight: 1.5 }}>{saveError}</span>
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, paddingTop: 4, paddingBottom: 32 }}>
          <button
            style={secondaryBtn}
            onClick={() => { setView('list'); setSaveError('') }}
            onMouseEnter={(e) => { e.currentTarget.style.background = t.bgHover }}
            onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent' }}
          >
            Cancel
          </button>
          <button
            style={{ ...primaryBtn, opacity: saving ? 0.6 : 1 }}
            onClick={handleSave}
            disabled={saving}
            onMouseEnter={(e) => { if (!saving) { e.currentTarget.style.opacity = '0.9'; e.currentTarget.style.boxShadow = `0 0 0 3px ${t.accent}30` } }}
            onMouseLeave={(e) => { e.currentTarget.style.opacity = saving ? '0.6' : '1'; e.currentTarget.style.boxShadow = 'none' }}
          >
            {saving ? 'Saving...' : (editId ? 'Update Scenario' : 'Save Scenario')}
          </button>
        </div>
      </div>

      {/* ────── Parameter Modal ────── */}
      {paramModal && (
        <div style={overlayStyle} onClick={() => setParamModal(null)}>
          <div style={dialogStyle} onClick={(e) => e.stopPropagation()}>
            {/* Header */}
            <div style={{ padding: '16px 20px', borderBottom: `1px solid ${t.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
              <div>
                <h3 style={{ color: t.textPrimary, fontSize: 15, fontWeight: 600, margin: 0 }}>
                  Configure Parameters
                </h3>
                <p style={{ color: t.textMuted, fontSize: 12, margin: '3px 0 0' }}>
                  {scriptEntries[paramModal.entryIdx]?.script_name} — {paramModal.grid.length} virtual user{paramModal.grid.length !== 1 ? 's' : ''}
                </p>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: t.textMuted, cursor: 'pointer', padding: 4 }}
                onClick={() => setParamModal(null)}
              >
                <CloseIcon />
              </button>
            </div>

            {/* Table */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>
              {/* Mirror checkbox — only relevant when there are multiple VUsers */}
              {paramModal.grid.length > 1 && (
                <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginBottom: 14, cursor: 'pointer', userSelect: 'none' }}>
                  <input
                    type="checkbox"
                    checked={mirrorFirstVuser}
                    style={{ accentColor: '#1d9bf0', width: 14, height: 14, cursor: 'pointer', flexShrink: 0 }}
                    onChange={(e) => {
                      const checked = e.target.checked
                      setMirrorFirstVuser(checked)
                      if (checked) {
                        // Immediately propagate VUser 1 values to all other VUsers
                        setParamModal((prev) => {
                          if (!prev || prev.grid.length < 2) return prev
                          const firstRow = prev.grid[0]
                          const grid = prev.grid.map((row, i) => i === 0 ? row : { ...firstRow })
                          return { ...prev, grid }
                        })
                      }
                    }}
                  />
                  <span style={{ fontSize: 12, color: t.textMuted, lineHeight: 1.4 }}>
                    Use Virtual User 1 values as a template — propagate to all other virtual users
                  </span>
                </label>
              )}
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: paramModal.params.length * 150 + 60 }}>
                  <thead>
                    <tr>
                      <th style={{
                        ...labelStyle,
                        padding: '8px 10px',
                        textAlign: 'center',
                        borderBottom: `2px solid ${t.border}`,
                        width: 50,
                        position: 'sticky',
                        top: 0,
                        background: t.bgRaised,
                      }}>#</th>
                      {paramModal.params.map((p) => (
                        <th key={p.name} style={{
                          ...labelStyle,
                          padding: '8px 10px',
                          textAlign: 'left',
                          borderBottom: `2px solid ${t.border}`,
                          position: 'sticky',
                          top: 0,
                          background: t.bgRaised,
                          minWidth: 140,
                        }}>
                          {p.name}
                          <span style={{ fontWeight: 400, fontSize: 9, marginLeft: 4, color: t.textFaint, textTransform: 'none' }}>({p.source})</span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {paramModal.grid.map((row, uIdx) => (
                      <tr key={uIdx} style={{ background: uIdx % 2 === 1 ? t.tableRowAlt : 'transparent' }}>
                        <td style={{ padding: '6px 10px', textAlign: 'center', color: t.textFaint, fontSize: 12, fontWeight: 600, borderBottom: `1px solid ${t.border}` }}>
                          {uIdx + 1}
                        </td>
                        {paramModal.params.map((p) => (
                          <td key={p.name} style={{ padding: '4px 6px', borderBottom: `1px solid ${t.border}` }}>
                            <input
                              style={{ ...inputStyle, padding: '5px 8px', fontSize: 12, borderRadius: 6 }}
                              value={row[p.name] || ''}
                              onChange={(e) => updateParamCell(uIdx, p.name, e.target.value)}
                              placeholder={p.default_value || p.name}
                              onFocus={(e) => { e.target.style.borderColor = inputFocusColor }}
                              onBlur={(e) => { e.target.style.borderColor = t.border }}
                            />
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Footer */}
            <div style={{ padding: '12px 20px', borderTop: `1px solid ${t.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10, flexShrink: 0 }}>
              <button style={secondaryBtn} onClick={() => setParamModal(null)}>Cancel</button>
              <button style={primaryBtn} onClick={applyParams}>Apply Parameters</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

import { useState, useEffect, useRef, useMemo } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { useTheme } from '../context/ThemeContext'
import { listScripts, listScenarios, listExecutions, getExecutionSummary } from '../api'
import { fetchAllTelemetry, replayTelemetry, computeApiTxStats } from '../analytics/replayEngine'
import { analyzeTestResults, computeVerdict } from '../analytics/perforaPostAnalysis'


function parseSnapshot(raw) {
  if (!raw) return {}
  try { return typeof raw === 'string' ? JSON.parse(raw) : raw } catch { return {} }
}

function fmtDate(iso) {
  if (!iso) return '—'
  const d = new Date(iso)
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

// Derive the single most critical finding from an execution summary (no telemetry needed)
function getHeadlineFinding(summary) {
  if (!summary) return null
  const { avg_rt = 0, error_pct = 0, p95 = 0 } = summary
  if (error_pct >= 5)
    return { severity: 'critical', category: 'Reliability', title: 'Too many errors — app is not ready for this load' }
  if (avg_rt >= 1000)
    return { severity: 'critical', category: 'Response Time', title: avg_rt >= 2000 ? 'App is critically slow — system appears overloaded' : 'App is very slow — users will likely give up' }
  if (avg_rt > 0 && p95 > 0 && p95 / avg_rt > 4)
    return { severity: 'critical', category: 'Response Time', title: 'Some users waited much longer — response times are very inconsistent' }
  if (error_pct >= 2)
    return { severity: 'warning', category: 'Reliability', title: 'Noticeable errors — some users are hitting failures' }
  if (avg_rt >= 500)
    return { severity: 'warning', category: 'Response Time', title: 'App feels slow — users will notice delays' }
  if (avg_rt > 0 && p95 > 0 && p95 / avg_rt > 2.5)
    return { severity: 'warning', category: 'Response Time', title: 'Response times are inconsistent — some users wait much longer' }
  if (error_pct >= 0.5)
    return { severity: 'info', category: 'Reliability', title: 'Mostly reliable — a small number of errors worth investigating' }
  if (avg_rt >= 200)
    return { severity: 'info', category: 'Response Time', title: 'Decent response times — room to improve' }
  if (avg_rt > 0)
    return { severity: 'good', category: 'Response Time', title: 'App responds quickly — users won\'t notice any delay' }
  return null
}

const STATUS_COLORS = {
  passed: { bg: 'rgba(34,197,94,0.1)', border: 'rgba(34,197,94,0.25)', text: '#22c55e', dot: '#22c55e' },
  failed: { bg: 'rgba(248,81,73,0.1)', border: 'rgba(248,81,73,0.25)', text: '#f85149', dot: '#f85149' },
  running: { bg: 'rgba(29,155,240,0.1)', border: 'rgba(29,155,240,0.25)', text: '#1d9bf0', dot: '#1d9bf0' },
}

function StatusBadge({ status }) {
  const c = STATUS_COLORS[status] || STATUS_COLORS.passed
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '2px 8px', borderRadius: 999, fontSize: 11, fontWeight: 600,
      background: c.bg, border: `1px solid ${c.border}`, color: c.text,
      textTransform: 'capitalize',
    }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: c.dot, flexShrink: 0 }} />
      {status}
    </span>
  )
}



function MetricCard({ icon, label, value, sub, accent, breakdown }) {
  const { t } = useTheme()
  return (
    <div style={{
      background: t.bgBase, border: `1px solid ${t.border}`, borderRadius: 12,
      padding: '20px 22px', display: 'flex', flexDirection: 'column', gap: 10,
      transition: 'border-color 0.15s',
      position: 'relative', overflow: 'hidden',
      boxShadow: t.cardShadow,
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 2,
        background: accent || 'transparent',
        borderRadius: '12px 12px 0 0',
      }} />
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 12, fontWeight: 500, color: t.textMuted, letterSpacing: 0.2 }}>{label}</span>
        <span style={{
          width: 30, height: 30, borderRadius: 8, background: `${accent}18`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: accent, flexShrink: 0,
        }}>
          {icon}
        </span>
      </div>
      <div>
        <div style={{ fontSize: 28, fontWeight: 700, color: t.textPrimary, lineHeight: 1.1, letterSpacing: -0.5 }}>
          {value}
        </div>
        {sub && (
          <div style={{ fontSize: 11.5, color: t.textMuted, marginTop: 4 }}>
            {sub}
          </div>
        )}
      </div>
      {breakdown && breakdown.length > 0 && (
        <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginTop: -2 }}>
          {breakdown.map(p => (
            <span key={p.label} style={{
              fontSize: 10.5, padding: '2px 7px', borderRadius: 99,
              background: `${accent}12`, border: `1px solid ${accent}25`,
              color: t.textMuted, fontWeight: 500,
            }}>
              {p.label} <strong style={{ color: t.textSecondary }}>{p.value}</strong>
            </span>
          ))}
        </div>
      )}
    </div>
  )
}


function QuickActionCard({ title, desc, icon, action, comingSoon, accent }) {
  const { t } = useTheme()
  const [hovered, setHovered] = useState(false)
  const navigate = useNavigate()
  return (
    <div
      onClick={comingSoon ? undefined : action}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered && !comingSoon ? t.bgOverlay : t.bgBase,
        border: `1px solid ${hovered && !comingSoon ? accent + '40' : t.border}`,
        borderRadius: 10, padding: '18px 20px',
        cursor: comingSoon ? 'default' : 'pointer',
        transition: 'background 0.15s, border-color 0.15s',
        display: 'flex', flexDirection: 'column', gap: 10,
        position: 'relative', boxShadow: t.cardShadow,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 9,
          background: comingSoon ? t.bgHover : `${accent}18`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: comingSoon ? t.textFaint : accent, flexShrink: 0,
        }}>
          {icon}
        </div>
        {comingSoon && (
          <span style={{
            fontSize: 9, fontWeight: 700, padding: '2px 6px', borderRadius: 999,
            background: 'rgba(251,191,36,0.08)', color: '#ca8a04',
            border: '1px solid rgba(251,191,36,0.18)', letterSpacing: 0.4,
          }}>
            SOON
          </span>
        )}
        {!comingSoon && hovered && (
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke={accent} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 7h8M7 3l4 4-4 4" />
          </svg>
        )}
      </div>
      <div>
        <div style={{ fontSize: 13.5, fontWeight: 600, color: comingSoon ? t.textMuted : t.textPrimary, marginBottom: 4 }}>
          {title}
        </div>
        <div style={{ fontSize: 12, color: t.textFaint, lineHeight: 1.5 }}>
          {desc}
        </div>
      </div>
    </div>
  )
}

function EmptyActivity({ navigate }) {
  const { t } = useTheme()
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '40px 20px', textAlign: 'center',
    }}>
      <div style={{
        width: 56, height: 56, borderRadius: 14, background: `${t.accent}14`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16,
        border: `1px solid ${t.accent}25`,
      }}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={t.accent} strokeWidth="1.5">
          <polygon points="5,3 19,12 5,21" strokeLinejoin="round" />
        </svg>
      </div>
      <div style={{ fontSize: 14, fontWeight: 600, color: t.textTertiary, marginBottom: 6 }}>No test runs yet</div>
      <div style={{ fontSize: 12, color: t.textFaint, marginBottom: 18, lineHeight: 1.6, maxWidth: 220 }}>
        Build your first API script or record a flow to get started with performance testing.
      </div>
      <button
        onClick={() => navigate('/app/perfzy')}
        style={{
          padding: '8px 16px', borderRadius: 7, fontSize: 12, fontWeight: 600,
          background: `${t.accent}14`, border: `1px solid ${t.accent}40`,
          color: t.accent, cursor: 'pointer',
        }}
      >
        Open API Studio
      </button>
    </div>
  )
}

export default function DashboardPage() {
  const { t } = useTheme()
  const navigate = useNavigate()

  const [dashData, setDashData] = useState({ scripts: [], scenarios: [], runs: [], summaries: {}, loading: true })
  const [lastRunPanel, setLastRunPanel] = useState({ open: false, loading: false, findings: [], verdict: null, runId: null })

  useEffect(() => {
    async function load() {
      try {
        const [scripts, scenarios, runs] = await Promise.all([
          listScripts().catch(() => []),
          listScenarios().catch(() => []),
          listExecutions().catch(() => []),
        ])
        const completed = (runs || []).filter(r => ['COMPLETED', 'FAILED', 'ABORTED'].includes(r.status))
        const summaryResults = await Promise.all(
          completed.map(r => getExecutionSummary(r.id).catch(() => null))
        )
        const summaries = {}
        completed.forEach((r, i) => { if (summaryResults[i]) summaries[r.id] = summaryResults[i] })
        setDashData({ scripts: scripts || [], scenarios: scenarios || [], runs: runs || [], summaries, loading: false })
      } catch {
        setDashData(prev => ({ ...prev, loading: false }))
      }
    }
    load()
  }, [])

  const { scripts, scenarios, runs, summaries, loading } = dashData

  // ── Full Perfora analysis (lazy — triggered on "view more") ──────────────
  async function openLastRunPanel(run) {
    setLastRunPanel({ open: true, loading: true, findings: [], verdict: null, runId: run.id })
    try {
      const records  = await fetchAllTelemetry(run.id)
      const chartData = replayTelemetry(records)
      const { apiStats, txStats } = computeApiTxStats(records)
      const snap    = parseSnapshot(run.scenario_snapshot)
      const totalVUs = run.total_users_target || (snap?.scripts || []).reduce((s, sc) => s + (parseInt(sc.users || sc.vus) || 0), 0)
      const findings = analyzeTestResults({ chartData, apiStats, txStats, totalVUs })
      const verdict  = computeVerdict(findings)
      setLastRunPanel({ open: true, loading: false, findings, verdict, runId: run.id })
    } catch {
      setLastRunPanel(prev => ({ ...prev, loading: false }))
    }
  }

  // ── Script breakdown ──────────────────────────────────────────────────────
  const perfzyCount   = scripts.filter(s => (s.script_type || '').toLowerCase() === 'perfzy').length
  const recordedCount = scripts.filter(s => (s.script_type || '').toLowerCase() === 'recorded').length
  const uploadedCount = scripts.filter(s => {
    const tp = (s.script_type || '').toLowerCase()
    return tp !== 'perfzy' && tp !== 'recorded'
  }).length

  // ── Sequential run number map ─────────────────────────────────────────────
  const runSeqMap = useMemo(() => {
    const sorted = [...runs].sort((a, b) => new Date(a.start_time || 0) - new Date(b.start_time || 0))
    const m = {}
    sorted.forEach((r, i) => { m[r.id] = i + 1 })
    return m
  }, [runs])

  // ── Scenario name map ─────────────────────────────────────────────────────
  const scenarioMap = useMemo(() => {
    const m = {}
    scenarios.forEach(s => { m[String(s.id)] = s.scenario_name })
    return m
  }, [scenarios])

  // ── Slow APIs: unique script names whose avg RT across runs > 500ms ───────
  const slowApisCount = useMemo(() => {
    const scriptRtMap = {}
    runs.forEach(run => {
      const sum = summaries[run.id]
      if (!sum || !sum.avg_rt) return
      const snap = parseSnapshot(run.scenario_snapshot)
      const scriptNames = (snap?.scripts || []).map(s => s.script_name).filter(Boolean)
      const keys = scriptNames.length > 0
        ? scriptNames
        : [scenarioMap[String(run.scenario_id)] || 'Unknown']
      keys.forEach(name => {
        if (!scriptRtMap[name]) scriptRtMap[name] = { total: 0, count: 0 }
        scriptRtMap[name].total += sum.avg_rt
        scriptRtMap[name].count += 1
      })
    })
    return Object.values(scriptRtMap).filter(v => v.count > 0 && (v.total / v.count) > 500).length
  }, [runs, summaries, scenarioMap])

  // ── Recent runs (last 10, newest first) ───────────────────────────────────
  const recentRuns = useMemo(() =>
    [...runs]
      .sort((a, b) => new Date(b.start_time || 0) - new Date(a.start_time || 0))
      .slice(0, 10)
  , [runs])

  // ── Last completed run + headline finding ─────────────────────────────────
  const lastRun = useMemo(() =>
    [...runs]
      .filter(r => ['COMPLETED', 'FAILED', 'ABORTED'].includes(r.status))
      .sort((a, b) => new Date(b.start_time || 0) - new Date(a.start_time || 0))[0] || null
  , [runs])

  const headlineFinding = useMemo(() =>
    lastRun ? getHeadlineFinding(summaries[lastRun.id] || null) : null
  , [lastRun, summaries])

  const metrics = [
    {
      label: 'Scripts', value: loading ? '…' : scripts.length,
      sub: scripts.length ? `${scripts.length} script${scripts.length !== 1 ? 's' : ''} in your workspace` : 'No scripts yet',
      icon: <ApiIcon />, accent: '#1d9bf0',
      breakdown: [
        { label: 'Perfzy', value: perfzyCount },
        { label: 'Recorded', value: recordedCount },
        { label: 'Uploaded', value: uploadedCount },
      ],
    },
    {
      label: 'Scenarios', value: loading ? '…' : scenarios.length,
      sub: scenarios.length ? `${scenarios.length} load scenario${scenarios.length !== 1 ? 's' : ''} configured` : 'No scenarios configured yet',
      icon: <LoadIcon />, accent: '#a78bfa',
    },
    {
      label: 'Total Runs', value: loading ? '…' : runs.length,
      sub: runs.length ? `${runs.filter(r => r.status === 'COMPLETED').length} completed · ${runs.filter(r => r.status === 'FAILED').length} failed` : 'No test runs yet',
      icon: <PlayIcon />, accent: '#06b6d4',
    },
    {
      label: 'APIs above 500ms', value: loading ? '…' : slowApisCount,
      sub: slowApisCount > 0 ? 'Unique scripts with avg RT > 500ms' : runs.length ? 'All scripts responding within 500ms' : 'No performance data yet',
      icon: <SpeedIcon />, accent: slowApisCount > 0 ? '#f97316' : '#22c55e',
    },
  ]

  const quickActions = [
    {
      title: 'API Studio', desc: 'Build and chain API requests into performance test scripts.',
      icon: <ApiIcon size={18} />, accent: '#1d9bf0',
      action: () => navigate('/app/perfzy'),
    },
    {
      title: 'Flow Recorder', desc: 'Record real browser interactions and convert to load tests.',
      icon: <RecordIcon size={18} />, accent: '#a78bfa',
      action: () => navigate('/app/record'),
    },
    {
      title: 'Load Designer', desc: 'Configure VU ramps, duration, and load scenarios.',
      icon: <LoadIcon size={18} />, accent: '#f97316',
      action: () => navigate('/app/load-designer'),
    },
    {
      title: 'Quick Test', desc: 'Instantly fire a simple load test with minimal setup.',
      icon: <QuickIcon size={18} />, accent: '#22c55e',
      action: () => navigate('/app/quick-test'),
    },
  ]

  return (
    <div style={{ maxWidth: 1300, margin: '0 auto', padding: '4px 0 32px' }}>

      {/* ── Welcome banner ── */}
      <div style={{
        background: t.isDark
          ? 'linear-gradient(135deg, #0d1f38 0%, #0f1e35 40%, #0d1117 100%)'
          : 'linear-gradient(135deg, #eff6ff 0%, #f0f9ff 50%, #f8fafc 100%)',
        border: `1px solid ${t.isDark ? '#1d3554' : '#bfdbfe'}`,
        borderRadius: 14, padding: '24px 32px',
        marginBottom: 28, position: 'relative', overflow: 'hidden',
        boxShadow: t.cardShadow,
      }}>
        <div style={{
          position: 'absolute', top: -40, right: -40, width: 200, height: 200,
          borderRadius: '50%', background: 'radial-gradient(circle, rgba(29,155,240,0.08) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', bottom: -60, left: 60, width: 160, height: 160,
          borderRadius: '50%', background: 'radial-gradient(circle, rgba(167,139,250,0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 24 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <div style={{
                width: 8, height: 8, borderRadius: '50%', background: '#22c55e',
                boxShadow: '0 0 8px #22c55e',
              }} />
              <span style={{ fontSize: 11.5, color: '#22c55e', fontWeight: 500, letterSpacing: 0.3 }}>WORKSPACE READY</span>
            </div>
            <h1 style={{ margin: 0, marginTop: 8, fontSize: 22, fontWeight: 700, letterSpacing: -0.4, marginBottom: 6 }}>
              Welcome to PT<span style={{ color: t.textPrimary, fontWeight: 700 }}>I</span>
            </h1>
            <p style={{ margin: 0, fontSize: 13.5, color: t.textMuted, lineHeight: 1.6, maxWidth: 480 }}>
              <span style={{ fontWeight: 600, fontSize: 14.5 }}>Performance testing intelligence for modern engineering teams.</span>
              <br />
              Build API scripts, upload HAR flows, and simulate realistic concurrency to detect performance risks early — powered by intelligent analysis.
            </p>
          </div>
          <div style={{ display: 'flex', flexDirection: 'row', gap: 10, flexShrink: 0, flexWrap: 'wrap' }}>
            <button
              onClick={() => navigate('/app/perfzy')}
              style={{
                padding: '9px 18px', borderRadius: 8, fontSize: 13, fontWeight: 600,
                background: t.accent, border: 'none', color: '#fff', cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 7,
                boxShadow: `0 2px 12px ${t.accent}40`,
                transition: 'opacity 0.15s', whiteSpace: 'nowrap',
              }}
              onMouseEnter={e => e.currentTarget.style.opacity = '0.9'}
              onMouseLeave={e => e.currentTarget.style.opacity = '1'}
            >
              <svg width="13" height="13" viewBox="0 0 14 14" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 7h8M7 3l4 4-4 4" />
              </svg>
              Open API Studio
            </button>
            <button
              onClick={() => navigate('/app/upload')}
              style={{
                padding: '9px 18px', borderRadius: 8, fontSize: 13, fontWeight: 600,
                background: t.isDark ? 'rgba(167,139,250,0.12)' : 'rgba(124,58,237,0.08)',
                border: `1px solid ${t.isDark ? 'rgba(167,139,250,0.3)' : 'rgba(124,58,237,0.2)'}`,
                color: t.accentPurple, cursor: 'pointer',
                transition: 'background 0.15s', whiteSpace: 'nowrap',
              }}
              onMouseEnter={e => e.currentTarget.style.background = t.isDark ? 'rgba(167,139,250,0.18)' : 'rgba(124,58,237,0.12)'}
              onMouseLeave={e => e.currentTarget.style.background = t.isDark ? 'rgba(167,139,250,0.12)' : 'rgba(124,58,237,0.08)'}
            >
              Upload HAR
            </button>
          </div>
        </div>
      </div>

      {/* ── Metric cards ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 28 }}>
        {metrics.map(m => <MetricCard key={m.label} {...m} />)}
      </div>

      {/* ── Main content grid ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 18, marginBottom: 28 }}>

        {/* ── Recent Runs ── */}
        <div style={{
          background: t.bgBase, border: `1px solid ${t.border}`, borderRadius: 12,
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
          boxShadow: t.cardShadow,
        }}>
          <div style={{
            padding: '16px 20px', borderBottom: `1px solid ${t.border}`,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: t.textPrimary }}>Recent Runs</div>
              <div style={{ fontSize: 11.5, color: t.textMuted, marginTop: 1 }}>Latest performance test executions</div>
            </div>
            {runs.length > 0 && (
              <span style={{ fontSize: 11, color: t.textFaint, fontWeight: 500 }}>
                Showing last {recentRuns.length} of {runs.length}
              </span>
            )}
          </div>

          {loading ? (
            <div style={{ padding: '32px 20px', textAlign: 'center', color: t.textFaint, fontSize: 13 }}>Loading…</div>
          ) : recentRuns.length === 0 ? (
            <EmptyActivity navigate={navigate} />
          ) : (
            <>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 520 }}>
                  <thead>
                    <tr style={{ borderBottom: `1px solid ${t.border}` }}>
                      {['RUN #', 'SCENARIO', 'SCRIPTS', 'VUSERs', 'STATUS', 'DATE / TIME'].map(h => (
                        <th key={h} style={{
                          padding: '9px 14px', textAlign: 'left',
                          fontSize: 10.5, fontWeight: 600, color: t.textFaint, letterSpacing: 0.5,
                          whiteSpace: 'nowrap',
                        }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {recentRuns.map((run, i) => {
                      const snap    = parseSnapshot(run.scenario_snapshot)
                      const scripts = snap?.scripts || []
                      const scenName = scenarioMap[String(run.scenario_id)]
                        || scripts[0]?.script_name
                        || `Run ${runSeqMap[run.id] || '?'}`
                      const totalVUs = run.total_users_target || scripts.reduce((s, sc) => s + (parseInt(sc.users || sc.vus) || 0), 0)
                      const status   = (run.status || 'unknown').toLowerCase()
                      const stColor  = STATUS_COLORS[status === 'completed' ? 'passed' : status === 'failed' || status === 'aborted' ? 'failed' : 'running'] || STATUS_COLORS.passed
                      return (
                        <tr
                          key={run.id}
                          onClick={() => navigate(`/app/test-results?open=${run.id}`)}
                          style={{
                            borderBottom: i < recentRuns.length - 1 ? `1px solid ${t.border}` : 'none',
                            background: i % 2 === 0 ? 'transparent' : t.tableRowAlt,
                            cursor: 'pointer',
                            transition: 'background 0.12s',
                          }}
                          onMouseEnter={e => e.currentTarget.style.background = t.bgHover}
                          onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : t.tableRowAlt}
                        >
                          <td style={{ padding: '10px 14px' }}>
                            <span style={{
                              fontSize: 11.5, fontWeight: 700, fontFamily: 'monospace',
                              color: t.accent, background: `${t.accent}10`,
                              padding: '2px 7px', borderRadius: 5,
                            }}>
                              {runSeqMap[run.id] || '?'}
                            </span>
                          </td>
                          <td style={{ padding: '10px 14px', fontSize: 12.5, color: t.textSecondary, fontWeight: 500, maxWidth: 160 }}>
                            <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                              {scenName}
                            </span>
                          </td>
                          <td style={{ padding: '10px 14px', fontSize: 12, color: t.textTertiary, textAlign: 'center' }}>
                            {scripts.length || 1}
                          </td>
                          <td style={{ padding: '10px 14px', fontSize: 12, color: t.textTertiary, textAlign: 'center' }}>
                            {totalVUs || '—'}
                          </td>
                          <td style={{ padding: '10px 14px' }}>
                            <span style={{
                              display: 'inline-flex', alignItems: 'center', gap: 5,
                              padding: '2px 8px', borderRadius: 999, fontSize: 11, fontWeight: 600,
                              background: stColor.bg, border: `1px solid ${stColor.border}`, color: stColor.text,
                              textTransform: 'capitalize',
                            }}>
                              <span style={{ width: 5, height: 5, borderRadius: '50%', background: stColor.dot, flexShrink: 0 }} />
                              {status}
                            </span>
                          </td>
                          <td style={{ padding: '10px 14px', fontSize: 11.5, color: t.textFaint, whiteSpace: 'nowrap' }}>
                            {fmtDate(run.start_time)}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
              <div style={{
                padding: '10px 16px', borderTop: `1px solid ${t.border}`,
                display: 'flex', justifyContent: 'flex-end',
              }}>
                <button
                  onClick={() => navigate('/app/test-results')}
                  style={{
                    display: 'inline-flex', alignItems: 'center', gap: 5,
                    padding: '5px 12px', borderRadius: 6, fontSize: 12, fontWeight: 500,
                    background: `${t.accent}10`, border: `1px solid ${t.accent}30`,
                    color: t.accent, cursor: 'pointer', transition: 'background 0.12s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = `${t.accent}1c`}
                  onMouseLeave={e => e.currentTarget.style.background = `${t.accent}10`}
                >
                  View all results
                  <svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 7h8M7 3l4 4-4 4" />
                  </svg>
                </button>
              </div>
            </>
          )}
        </div>

        {/* ── Right column: Last Test Analysis + Quick Actions ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>

          {/* ── Last Test Analysis ── */}
          {(() => {
            const sev = headlineFinding?.severity
            const sevColor = { critical: '#ef4444', warning: '#f59e0b', info: '#06b6d4', good: '#22c55e' }[sev] || t.accent
            return (
              <div style={{
                background: t.bgBase, border: `1px solid ${t.border}`, borderRadius: 12,
                display: 'flex', flexDirection: 'column', overflow: 'hidden',
                boxShadow: t.cardShadow, flexShrink: 0,
              }}>
                {/* Header */}
                <div style={{
                  padding: '10px 16px', borderBottom: `1px solid ${t.border}`,
                  display: 'flex', alignItems: 'center', gap: 8,
                }}>
                  <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                    <path d="M5.5 8l1.8 1.8L10.5 6" />
                  </svg>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: t.textPrimary }}>Last Test Analysis</div>
                  <div style={{ fontSize: 10, color: t.textFaint, marginLeft: 2 }}>· Perfora Guardian</div>
                </div>

                {/* Body */}
                <div style={{ padding: '10px 14px 12px', display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {loading ? (
                    <div style={{ color: t.textFaint, fontSize: 12 }}>Loading…</div>
                  ) : !lastRun ? (
                    <div style={{ color: t.textFaint, fontSize: 12, lineHeight: 1.6 }}>
                      No completed test runs yet. Run a test to see Perfora analysis here.
                    </div>
                  ) : !headlineFinding ? (
                    <div style={{ fontSize: 12, color: t.textMuted, lineHeight: 1.6 }}>
                      Summary not available for this run.
                    </div>
                  ) : (
                    <>
                      {/* Finding card — run ID right-aligned in the badge row */}
                      <div style={{
                        background: sevColor + '0c',
                        border: `1px solid ${sevColor}28`,
                        borderLeft: `3px solid ${sevColor}`,
                        borderRadius: 8, padding: '9px 11px',
                      }}>
                        {/* Badges row */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
                          <span style={{
                            fontSize: 9, fontWeight: 700, padding: '1px 5px', borderRadius: 4,
                            background: sevColor + '18', color: sevColor, textTransform: 'uppercase', letterSpacing: '0.04em', flexShrink: 0,
                          }}>{headlineFinding.severity}</span>
                          <span style={{
                            fontSize: 9, color: t.textFaint, textTransform: 'uppercase',
                            letterSpacing: '0.04em', fontWeight: 600, flexShrink: 0,
                          }}>{headlineFinding.category}</span>
                          <span style={{
                            marginLeft: 'auto', fontSize: 9.5, fontWeight: 700, fontFamily: 'monospace',
                            color: t.accent, background: `${t.accent}12`,
                            padding: '1px 5px', borderRadius: 4, flexShrink: 0,
                          }}>
                            Run {runSeqMap[lastRun.id] || '?'}
                          </span>
                        </div>
                        {/* Title — max 2 lines */}
                        <div style={{
                          fontSize: 12, fontWeight: 600, color: t.textPrimary, lineHeight: 1.45,
                          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
                          overflow: 'hidden', textOverflow: 'ellipsis',
                        }}>
                          {headlineFinding.title}
                        </div>
                      </div>

                      {/* View more link */}
                      <button
                        onClick={() => openLastRunPanel(lastRun)}
                        style={{
                          alignSelf: 'flex-start', display: 'inline-flex', alignItems: 'center', gap: 4,
                          padding: '4px 10px', borderRadius: 6, fontSize: 11, fontWeight: 600,
                          background: `${t.accent}10`, border: `1px solid ${t.accent}30`,
                          color: t.accent, cursor: 'pointer',
                          transition: 'background 0.12s',
                        }}
                        onMouseEnter={e => e.currentTarget.style.background = `${t.accent}1c`}
                        onMouseLeave={e => e.currentTarget.style.background = `${t.accent}10`}
                      >
                        <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M8 1.5L14 4v4C14 11.5 11 14 8 15c-3-1-6-3.5-6-7V4z" />
                        </svg>
                        View full analysis
                      </button>
                    </>
                  )}
                </div>
              </div>
            )
          })()}

          {/* ── Quick Actions ── */}
          <div style={{
            background: t.bgBase, border: `1px solid ${t.border}`, borderRadius: 12,
            display: 'flex', flexDirection: 'column', overflow: 'hidden',
            boxShadow: t.cardShadow, flex: 1, minHeight: 0,
          }}>
            <div style={{ padding: '12px 16px', borderBottom: `1px solid ${t.border}`, flexShrink: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: t.textPrimary }}>Quick Actions</div>
              <div style={{ fontSize: 11, color: t.textMuted, marginTop: 1 }}>Jump into a testing workflow</div>
            </div>
            <div style={{ padding: 10, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, flex: 1, minHeight: 0, alignContent: 'stretch' }}>
              {quickActions.map(a => <QuickActionCard key={a.title} {...a} />)}
            </div>
          </div>
        </div>
      </div>

      {/* ── Perfora Guardian Panel Modal ── */}
      {lastRunPanel.open && createPortal(
        <div
          style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)',
            backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
            zIndex: 9600, display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
            padding: '32px 16px',
          }}
          onClick={e => { if (e.target === e.currentTarget) setLastRunPanel(prev => ({ ...prev, open: false })) }}
        >
          <div style={{
            background: t.bgRaised || t.bgBase, border: `1px solid ${t.border}`,
            borderRadius: 16, width: '100%', maxWidth: 740,
            maxHeight: 'calc(100vh - 64px)', display: 'flex', flexDirection: 'column',
            boxShadow: '0 24px 80px rgba(0,0,0,0.45)',
          }}>
            {/* Header */}
            <div style={{
              padding: '18px 22px 16px', borderBottom: `1px solid ${t.border}`,
              display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{
                  width: 42, height: 42, borderRadius: 12,
                  background: `linear-gradient(135deg, ${t.accent}22, ${t.accent}0a)`,
                  border: `1.5px solid ${t.accent}40`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                }}>
                  <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                    <path d="M5.5 8l1.8 1.8L10.5 6" />
                  </svg>
                </div>
                <div>
                  <div style={{ color: t.textPrimary, fontSize: 16, fontWeight: 700 }}>Perfora Guardian</div>
                  <div style={{ color: t.textMuted, fontSize: 12, marginTop: 2 }}>
                    Last test analysis · Run {lastRun ? (runSeqMap[lastRun.id] || '?') : '?'}
                    {!lastRunPanel.loading && ` · ${lastRunPanel.findings.length} finding${lastRunPanel.findings.length !== 1 ? 's' : ''}`}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setLastRunPanel(prev => ({ ...prev, open: false }))}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, padding: 4, lineHeight: 1, borderRadius: 6, marginTop: 2 }}
              >
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 4L4 12M4 4l8 8" /></svg>
              </button>
            </div>

            {lastRunPanel.loading ? (
              <div style={{ padding: '48px 22px', textAlign: 'center', color: t.textFaint, fontSize: 13 }}>
                Loading full analysis…
              </div>
            ) : lastRunPanel.findings.length === 0 ? (
              <div style={{ padding: '48px 22px', textAlign: 'center', color: t.textFaint, fontSize: 13 }}>
                No findings could be generated for this run.
              </div>
            ) : (
              <>
                {/* Verdict banner */}
                {(() => {
                  const verdict = lastRunPanel.verdict || computeVerdict(lastRunPanel.findings)
                  const crit = lastRunPanel.findings.filter(f => f.severity === 'critical').length
                  const warn = lastRunPanel.findings.filter(f => f.severity === 'warning').length
                  const info = lastRunPanel.findings.filter(f => f.severity === 'info').length
                  const good = lastRunPanel.findings.filter(f => f.severity === 'good').length
                  return (
                    <div style={{
                      margin: '14px 22px 0',
                      background: verdict.color + '12',
                      border: `1px solid ${verdict.color}35`,
                      borderRadius: 10, padding: '12px 16px',
                      display: 'flex', alignItems: 'center', gap: 14, flexShrink: 0,
                    }}>
                      <div style={{
                        width: 44, height: 44, borderRadius: 10, flexShrink: 0,
                        background: verdict.color + '20', display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        {verdict.label === 'Excellent' || verdict.label === 'Passing' ? (
                          <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={verdict.color} strokeWidth="2"><path d="M2 8l4 4 8-8" /></svg>
                        ) : verdict.label === 'Needs Improvement' ? (
                          <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={verdict.color} strokeWidth="1.8"><circle cx="8" cy="8" r="6.5" /><path d="M8 5v3.5M8 10.5v.5" /></svg>
                        ) : (
                          <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={verdict.color} strokeWidth="1.8"><path d="M8 2L14.5 13H1.5Z" /><path d="M8 6v3.5M8 11v.5" /></svg>
                        )}
                      </div>
                      <div>
                        <div style={{ color: verdict.color, fontSize: 14, fontWeight: 700 }}>{verdict.label}</div>
                        <div style={{ color: t.textSecondary, fontSize: 12, marginTop: 2, lineHeight: 1.4 }}>{verdict.description}</div>
                      </div>
                      <div style={{ marginLeft: 'auto', display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                        {[
                          { label: 'Critical', count: crit, color: '#ef4444' },
                          { label: 'Warning',  count: warn, color: '#f59e0b' },
                          { label: 'Info',     count: info, color: '#06b6d4' },
                          { label: 'Good',     count: good, color: '#22c55e' },
                        ].filter(s => s.count > 0).map(s => (
                          <span key={s.label} style={{
                            display: 'inline-flex', alignItems: 'center', gap: 4,
                            padding: '3px 8px', borderRadius: 20,
                            background: s.color + '18', border: `1px solid ${s.color}35`,
                            color: s.color, fontSize: 11, fontWeight: 700, whiteSpace: 'nowrap',
                          }}>
                            <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor' }} />
                            {s.count} {s.label}
                          </span>
                        ))}
                      </div>
                    </div>
                  )
                })()}

                {/* Findings list */}
                <div style={{ overflowY: 'auto', padding: '14px 22px 20px', flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {lastRunPanel.findings.map(f => {
                    const col = { critical: '#ef4444', warning: '#f59e0b', info: '#06b6d4', good: '#22c55e' }[f.severity] || '#6b7280'
                    const cat2icon = {
                      'Response Time': <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="8" cy="8" r="6.5"/><path d="M8 4.5v4l2.5 2"/></svg>,
                      'Stability':     <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M2 10 L5 6 L7 8 L10 4 L12 7 L14 5"/></svg>,
                      'Reliability':   <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M8 1.5L14 4v4C14 11.5 11 14 8 15c-3-1-6-3.5-6-7V4z"/><path d="M5.5 8l1.8 1.8L10.5 6"/></svg>,
                      'Throughput':    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="1.5" y="6" width="3" height="8" rx="1"/><rect x="6.5" y="4" width="3" height="10" rx="1"/><rect x="11.5" y="1.5" width="3" height="12.5" rx="1"/></svg>,
                      'Endpoints':     <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="8" cy="5" r="2.5"/><path d="M3 13c0-3 2-5 5-5s5 2 5 5"/></svg>,
                    }
                    return (
                      <div key={f.id} style={{
                        background: col + '08', border: `1px solid ${col}28`,
                        borderLeft: `3px solid ${col}`, borderRadius: 10, padding: '12px 14px',
                      }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 7px', borderRadius: 4, background: col + '18', color: col, fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                            {f.severity}
                          </span>
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                            {cat2icon[f.category] || null}
                            {f.category}
                          </span>
                          <span style={{ color: t.textPrimary, fontSize: 13, fontWeight: 700, marginLeft: 2 }}>{f.title}</span>
                        </div>
                        <div style={{ color: t.textSecondary, fontSize: 12, lineHeight: 1.55, whiteSpace: 'pre-line', marginBottom: f.recommendation ? 8 : 0 }}>{f.finding}</div>
                        {f.recommendation && (
                          <div style={{ marginTop: 8, paddingTop: 8, borderTop: `1px solid ${col}20`, display: 'flex', alignItems: 'flex-start', gap: 7 }}>
                            <svg style={{ flexShrink: 0, marginTop: 1 }} width="12" height="12" viewBox="0 0 16 16" fill="none" stroke={col} strokeWidth="2"><path d="M8 1v7M8 12v1M3 5l2 2M13 5l-2 2"/><circle cx="8" cy="13" r="1" fill={col} stroke="none"/></svg>
                            <div style={{ color: t.textMuted, fontSize: 11.5, lineHeight: 1.5 }}>
                              <span style={{ color: col, fontWeight: 700 }}>Recommendation: </span>
                              {f.recommendation}
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>

                {/* Footer */}
                <div style={{ borderTop: `1px solid ${t.border}`, padding: '11px 22px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: t.textFaint, fontSize: 11 }}>
                    <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M8 1.5L14 4v4C14 11.5 11 14 8 15c-3-1-6-3.5-6-7V4z"/></svg>
                    Perfora Guardian · Post-test static analysis
                  </div>
                  <button
                    onClick={() => navigate(`/app/test-results?open=${lastRunPanel.runId}`)}
                    style={{
                      background: `${t.accent}10`, border: `1px solid ${t.accent}30`,
                      borderRadius: 7, padding: '5px 14px', color: t.accent,
                      fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5,
                    }}
                  >
                    Open in Test Results
                    <svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7h8M7 3l4 4-4 4"/></svg>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>,
        document.body
      )}

      {/* ── Getting Started ── */}
      <div style={{
        background: t.bgBase, border: `1px solid ${t.border}`, borderRadius: 12,
        overflow: 'hidden', boxShadow: t.cardShadow,
      }}>
        <div style={{ padding: '16px 20px', borderBottom: `1px solid ${t.border}` }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: t.textPrimary }}>Getting Started</div>
          <div style={{ fontSize: 11.5, color: t.textMuted, marginTop: 1 }}>Follow these steps to run your first load test</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0 }}>
          {[
            { step: '01', title: 'Build your API script', desc: 'Use API Studio to chain multiple requests into a complete user flow.', link: '/app/perfzy', linkLabel: 'Open API Studio', accent: '#1d9bf0' },
            { step: '02', title: 'Define parameters', desc: 'Extract dynamic values like tokens or IDs as reusable script parameters.', link: null, linkLabel: null, accent: '#a78bfa' },
            { step: '03', title: 'Design load scenario', desc: 'Set virtual users, ramp-up patterns, and test duration in Load Designer.', link: '/app/load-designer', linkLabel: 'Open Load Designer', accent: '#f97316' },
            { step: '04', title: 'Test Results', desc: 'Review response times, error rates, percentiles and Perfora insights after each run.', link: '/app/test-results', linkLabel: 'Open Test Results', accent: '#22c55e' },
          ].map((s, i, arr) => (
            <div key={s.step} style={{
              padding: '20px 22px',
              borderRight: i < arr.length - 1 ? `1px solid ${t.border}` : 'none',
              position: 'relative',
            }}>
              <div style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                width: 28, height: 28, borderRadius: 8,
                background: `${s.accent}14`, border: `1px solid ${s.accent}30`,
                fontSize: 11, fontWeight: 700, color: s.accent, marginBottom: 12,
                letterSpacing: 0.3,
              }}>
                {s.step}
              </div>
              <div style={{ fontSize: 13, fontWeight: 600, color: t.textSecondary, marginBottom: 6 }}>{s.title}</div>
              <div style={{ fontSize: 12, color: t.textFaint, lineHeight: 1.6, marginBottom: s.link !== null ? 14 : 0 }}>{s.desc}</div>
              {s.link && (
                <button
                  onClick={() => navigate(s.link)}
                  style={{
                    padding: '5px 12px', borderRadius: 6, fontSize: 11.5, fontWeight: 500,
                    background: `${s.accent}12`, border: `1px solid ${s.accent}30`,
                    color: s.accent, cursor: 'pointer',
                  }}
                >
                  {s.linkLabel}
                </button>
              )}
              {!s.link && s.linkLabel && (
                <span style={{
                  display: 'inline-block', padding: '3px 9px', borderRadius: 6, fontSize: 10.5,
                  background: 'rgba(75,85,99,0.12)', border: '1px solid rgba(75,85,99,0.2)',
                  color: '#4b5563', fontWeight: 500,
                }}>
                  {s.linkLabel}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ── Icons ── */
function ApiIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <polyline points="4,5 1,8 4,11" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="12,5 15,8 12,11" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="9" y1="2" x2="7" y2="14" strokeLinecap="round" />
    </svg>
  )
}
function PlayIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <polygon points="4,2 14,8 4,14" strokeLinejoin="round" />
    </svg>
  )
}
function CheckIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <circle cx="8" cy="8" r="6.5" />
      <polyline points="5,8 7,10 11,6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function SpeedIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path d="M3 12 A6.5 6.5 0 1 1 13 12" strokeLinecap="round" />
      <line x1="8" y1="8" x2="11" y2="5.5" strokeLinecap="round" />
      <circle cx="8" cy="8" r="1.2" fill="currentColor" stroke="none" />
    </svg>
  )
}
function RecordIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <circle cx="8" cy="8" r="6.5" />
      <circle cx="8" cy="8" r="2.5" fill="currentColor" stroke="none" />
    </svg>
  )
}
function LoadIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path d="M8 2 L13.5 13 L8 10.5 L2.5 13 Z" strokeLinejoin="round" />
    </svg>
  )
}
function QuickIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <polygon points="4,2 14,8 4,14" strokeLinejoin="round" />
    </svg>
  )
}

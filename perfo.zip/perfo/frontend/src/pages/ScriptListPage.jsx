import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { listScripts, downloadScript, correlateScript, downloadCorrelatedScript, deleteScript } from '../api'
import ScriptValidatorModal from '../components/ScriptValidatorModal'
import { useTheme } from '../context/ThemeContext'

export default function ScriptListPage() {
  const { t } = useTheme()
  const [scripts, setScripts] = useState([])
  const [activeTab, setActiveTab] = useState('recorded')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [correlating, setCorrelating] = useState({})
  const [correlated, setCorrelated] = useState({})
  const [correlationError, setCorrelationError] = useState({})
  const [validatingScript, setValidatingScript] = useState(null)
  const [deleteConfirm, setDeleteConfirm] = useState(null) // { id, name }
  const [deleting, setDeleting] = useState({})

  useEffect(() => {
    listScripts()
      .then(setScripts)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  async function handleCorrelate(scriptId) {
    setCorrelating((prev) => ({ ...prev, [scriptId]: true }))
    setCorrelationError((prev) => ({ ...prev, [scriptId]: null }))
    try {
      const data = await correlateScript(scriptId)
      setCorrelated((prev) => ({ ...prev, [scriptId]: data }))
    } catch (e) {
      setCorrelationError((prev) => ({ ...prev, [scriptId]: e.message }))
    } finally {
      setCorrelating((prev) => ({ ...prev, [scriptId]: false }))
    }
  }

  function confirmDelete(script) {
    setDeleteConfirm({ id: script.id, name: script.script_name })
  }

  async function handleDelete() {
    if (!deleteConfirm) return
    const { id } = deleteConfirm
    setDeleting((prev) => ({ ...prev, [id]: true }))
    setDeleteConfirm(null)
    try {
      await deleteScript(id)
      setScripts((prev) => prev.filter((s) => s.id !== id))
    } catch (e) {
      setError(e.message)
    } finally {
      setDeleting((prev) => ({ ...prev, [id]: false }))
    }
  }

  async function handleDownloadCorrelated(scriptId, scriptName) {
    try {
      const name = (scriptName || 'script').replace(/\.[^.]+$/, '') + '_correlated.py'
      await downloadCorrelatedScript(scriptId, name)
    } catch (e) {
      setCorrelationError((prev) => ({ ...prev, [scriptId]: e.message }))
    }
  }

  const recordedScripts = scripts.filter((s) => (s.script_type || '').toLowerCase() === 'recorded')
  const perfzyScripts = scripts.filter((s) => (s.script_type || '').toLowerCase() === 'perfzy')
  const harBasedScripts = scripts.filter((s) => {
    const t = (s.script_type || '').toLowerCase()
    return t !== 'recorded' && t !== 'perfzy'
  })
  const visibleScripts = activeTab === 'recorded' ? recordedScripts : activeTab === 'perfzy' ? perfzyScripts : harBasedScripts

  const s = getStyles(t)

  if (loading) return <p style={{ color: t.textTertiary }}>Loading scripts...</p>
  if (error) return <p style={{ color: '#f4212e' }}>{error}</p>

  return (
    <div>
      <h2 style={{ fontSize: 20, marginBottom: 25, marginTop: 0, color: t.textPrimary }}>
        Scripts<span style={{ color: t.textTertiary, fontWeight: 400, fontSize: 14, marginLeft: 8 }}>Browse and manage your generated test scripts</span>
      </h2>
      {scripts.length === 0 ? (
        <p style={{ color: t.textTertiary, fontSize: 14 }}>No scripts uploaded yet. <Link to="/app/upload">Upload one</Link>.</p>
      ) : (
        <>
          <div style={s.tabsRowStyle}>
            <button
              type="button"
              onClick={() => setActiveTab('recorded')}
              style={{ ...s.tabStyle, ...(activeTab === 'recorded' ? s.activeTabStyle : {}) }}
            >
              Recorded ({recordedScripts.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('har')}
              style={{ ...s.tabStyle, ...(activeTab === 'har' ? s.activeTabStyle : {}) }}
            >
              HAR based ({harBasedScripts.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('perfzy')}
              style={{ ...s.tabStyle, ...(activeTab === 'perfzy' ? s.activeTabStyle : {}) }}
            >
              Perfzy ({perfzyScripts.length})
            </button>
          </div>

          {visibleScripts.length === 0 ? (
            <p style={{ color: t.textTertiary, fontSize: 14 }}>
              No {activeTab === 'recorded' ? 'recorded' : activeTab === 'perfzy' ? 'Perfzy' : 'HAR based'} scripts yet.
            </p>
          ) : (
            <table style={s.tableStyle}>
              <thead>
                <tr>
                  <th style={{ ...s.thStyle, width: 180 }}>Name</th>
                  <th style={{ ...s.thStyle, width: 198 }}>Uploaded</th>
                  <th style={{ ...s.thStyleCenter, width: 64 }}>View API</th>
                  <th style={{ ...s.thStyleCenter, width: 72 }}>Raw Script</th>
                  <th style={{ ...s.thStyleCenter, width: 72 }}>Correlation</th>
                  <th style={{ ...s.thStyleCenter, width: 64 }}>Validate</th>
                  <th style={{ ...s.thStyleCenter, width: 56 }}>Delete</th>
                </tr>
              </thead>
              <tbody>
                {visibleScripts.map((sc) => {
                  const isCorrelating = correlating[sc.id]
                  const isDone = !!correlated[sc.id] || !!sc.has_correlated_script
                  const err = correlationError[sc.id]
                  const report = correlated[sc.id]?.report || (
                    sc.correlated_params != null
                      ? { correlated_params: sc.correlated_params }
                      : null
                  )

                  return (
                    <tr key={sc.id}>
                      <td style={s.tdStyle}>{sc.script_name}</td>
                      <td style={s.tdStyle}>{sc.upload_time ? new Date(sc.upload_time).toLocaleString() : '-'}</td>
                      <td style={s.tdStyleCenter}>
                        <Link
                          to={`/app/scripts/${sc.id}`}
                          style={s.iconLinkStyle}
                          aria-label={`View APIs for ${sc.script_name}`}
                          title="View APIs"
                        >
                          <EyeIcon />
                        </Link>
                      </td>
                      <td style={s.tdStyleCenter}>
                        <button
                          type="button"
                          onClick={() => downloadScript(sc.id, (sc.script_name || 'script').replace(/\.[^.]+$/, '') + '.py')}
                          style={s.iconButtonStyle}
                          aria-label={`Download script ${sc.script_name}`}
                          title="Download Script"
                        >
                          <DownloadIcon />
                        </button>
                      </td>
                      <td style={s.tdStyleCenter}>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.35rem' }}>
                          {isDone ? (
                            <button
                              type="button"
                              onClick={() => handleDownloadCorrelated(sc.id, sc.script_name)}
                              style={s.iconCorrelatedButtonStyle}
                              aria-label={`Download final script for ${sc.script_name}`}
                              title="Download Final Script"
                            >
                              <DownloadIcon />
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleCorrelate(sc.id)}
                              disabled={isCorrelating}
                              style={{
                                ...s.iconCorrelateButtonStyle,
                                opacity: isCorrelating ? 0.7 : 1,
                                cursor: isCorrelating ? 'not-allowed' : 'pointer',
                              }}
                              aria-label={`Create final script for ${sc.script_name}`}
                              title="Create Final Script"
                            >
                              {isCorrelating ? <span style={s.spinnerStyle} /> : <CorrelateIcon />}
                            </button>
                          )}

                          {err && <div style={{ color: '#f4212e', fontSize: 12 }}>{err}</div>}

                          {report && (
                            <div style={s.reportStyle}>
                              <span>Correlated {report.correlated_params} params</span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td style={s.tdStyleCenter}>
                        <button
                          type="button"
                          onClick={() => setValidatingScript(sc)}
                          style={s.iconValidateButtonStyle}
                          aria-label={`Validate script ${sc.script_name}`}
                          title="Validate Script"
                        >
                          <PlayIcon />
                        </button>
                      </td>
                      <td style={s.tdStyleCenter}>
                        <button
                          type="button"
                          onClick={() => confirmDelete(sc)}
                          disabled={!!deleting[sc.id]}
                          style={s.iconDeleteButtonStyle}
                          aria-label={`Delete script ${sc.script_name}`}
                          title="Delete Script"
                        >
                          <TrashIcon />
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          )}
        </>
      )}

      {validatingScript && (
        <ScriptValidatorModal
          scriptId={validatingScript.id}
          scriptName={validatingScript.script_name}
          onClose={() => setValidatingScript(null)}
        />
      )}

      {deleteConfirm && (
        <div style={s.overlayStyle}>
          <div style={s.confirmDialogStyle}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <span style={{ fontSize: 22, color: '#f85149' }}>🗑</span>
              <h3 style={{ margin: 0, fontSize: 14, fontWeight: 600, color: t.textPrimary }}>Delete Script</h3>
            </div>
            <p style={{ margin: '0 0 1.5rem', color: t.textTertiary, fontSize: 13, lineHeight: 1.5 }}>
              Are you sure you want to delete <strong style={{ color: t.textPrimary }}>{deleteConfirm.name}</strong>?
              <br />This will remove all associated transactions and correlation data. This action cannot be undone.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                style={s.cancelBtnStyle}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDelete}
                style={s.deleteBtnStyle}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function EyeIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function DownloadIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3v12" />
      <path d="m7 10 5 5 5-5" />
      <path d="M5 21h14" />
    </svg>
  )
}

function CorrelateIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="11" cy="11" r="6" />
      <path d="m20 20-4.2-4.2" />
      <path d="M9.5 11h3" />
      <path d="M11 9.5v3" />
    </svg>
  )
}

function PlayIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polygon points="6 3 20 12 6 21 6 3" />
    </svg>
  )
}

function TrashIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
      <path d="M10 11v6" />
      <path d="M14 11v6" />
      <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
    </svg>
  )
}

function getStyles(t) {
  const base = { borderBottom: `1px solid ${t.border}` }
  const iconBase = { width: 32, height: 32, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', border: 'none', borderRadius: 6, color: '#fff', cursor: 'pointer' }
  return {
    tableStyle: { width: 'auto', borderCollapse: 'collapse', tableLayout: 'fixed' },
    thStyle: { textAlign: 'left', padding: '0.75rem', ...base, color: t.textSecondary },
    tdStyle: { padding: '0.75rem', ...base, verticalAlign: 'top', color: t.textPrimary },
    thStyleCenter: { textAlign: 'center', fontSize: 11, fontWeight: 600, color: t.textTertiary, padding: '0.5rem 0.35rem', whiteSpace: 'nowrap', ...base },
    tdStyleCenter: { ...base, textAlign: 'center', padding: '0.5rem 0.35rem' },
    tabsRowStyle: { display: 'flex', gap: '0.75rem', marginBottom: '1rem', borderBottom: `1px solid ${t.border}` },
    tabStyle: { padding: '0.75rem 1rem', background: 'transparent', color: t.textTertiary, border: 'none', borderBottom: '2px solid transparent', cursor: 'pointer', fontSize: 13, fontWeight: 600 },
    activeTabStyle: { color: t.textPrimary, borderBottomColor: t.accent },
    iconButtonStyle: { ...iconBase, background: t.accent },
    iconCorrelateButtonStyle: { ...iconBase, background: '#238636' },
    iconCorrelatedButtonStyle: { ...iconBase, background: '#8957e5' },
    iconValidateButtonStyle: { ...iconBase, background: '#d29922' },
    iconLinkStyle: { ...iconBase, background: t.borderMuted, textDecoration: 'none' },
    iconDeleteButtonStyle: { ...iconBase, background: 'rgba(248,81,73,0.15)', color: '#f85149', border: '1px solid rgba(248,81,73,0.3)' },
    reportStyle: { fontSize: 11, color: '#7ee787', textAlign: 'center', whiteSpace: 'nowrap' },
    overlayStyle: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999 },
    confirmDialogStyle: { background: t.dropdownBg, border: `1px solid ${t.dropdownBorder}`, borderRadius: 12, padding: '1.5rem', width: 400, maxWidth: '90vw', boxShadow: t.dropdownShadow },
    cancelBtnStyle: { padding: '0.5rem 1.25rem', background: 'transparent', color: t.textTertiary, border: `1px solid ${t.borderMuted}`, borderRadius: 6, cursor: 'pointer', fontSize: 13, fontWeight: 600 },
    deleteBtnStyle: { padding: '0.5rem 1.25rem', background: '#da3633', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13, fontWeight: 600 },
    spinnerStyle: { display: 'inline-block', width: 14, height: 14, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.6s linear infinite' },
  }
}

if (typeof document !== 'undefined' && !document.getElementById('perfsense-spin')) {
  const style = document.createElement('style')
  style.id = 'perfsense-spin'
  style.textContent = '@keyframes spin { to { transform: rotate(360deg); } }'
  document.head.appendChild(style)
}

import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getScriptTransactions, downloadScript, API_BASE } from '../api'

const DEBUG = true

export default function ScriptPreviewPage() {
  const { scriptId } = useParams()
  const [transactions, setTransactions] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [debugInfo, setDebugInfo] = useState(null)

  useEffect(() => {
    if (DEBUG) {
      console.log('[perfSense] ScriptPreviewPage: mount/update', {
        scriptIdFromUrl: scriptId,
        scriptIdType: typeof scriptId,
        currentPath: window.location.pathname,
      })
    }
    if (scriptId == null || String(scriptId).trim() === '') {
      setError('Script not found')
      setDebugInfo({ reason: 'scriptId empty or null', scriptId })
      setLoading(false)
      return
    }
    const url = `${API_BASE}/scripts/${encodeURIComponent(String(scriptId).trim())}/transactions`
    setDebugInfo({ scriptId, url, note: 'Requesting...' })
    getScriptTransactions(scriptId)
      .then((data) => {
        if (DEBUG) console.log('[perfSense] ScriptPreviewPage: got transactions', data?.length ?? data)
        setTransactions(data)
        setDebugInfo((prev) => ({ ...prev, note: 'OK', count: Array.isArray(data) ? data.length : '-' }))
      })
      .catch((e) => {
        if (DEBUG) console.log('[perfSense] ScriptPreviewPage: error', e.message, e.debug, e.body)
        setError(e.message)
        setDebugInfo((prev) => ({
          ...prev,
          note: 'Error',
          error: e.message,
          serverDebug: e.debug || e.body?.debug || null,
        }))
      })
      .finally(() => setLoading(false))
  }, [scriptId])

  if (loading) return <p>Loading...</p>
  if (error) {
    return (
      <div>
        <p style={{ color: '#f4212e' }}>{error}</p>
        {DEBUG && debugInfo && (
          <div style={{ marginTop: '1rem', padding: '1rem', background: '#16181c', borderRadius: 8, fontSize: 13, fontFamily: 'monospace', whiteSpace: 'pre-wrap' }}>
            <div><strong>Debug</strong></div>
            <div>scriptId from URL: <code>{JSON.stringify(debugInfo.scriptId)}</code> (type: {typeof debugInfo.scriptId})</div>
            <div>Request URL: <code>{debugInfo.url}</code></div>
            <div>Note: {debugInfo.note}</div>
            {debugInfo.error && <div>Error: {debugInfo.error}</div>}
            {debugInfo.serverDebug ? (
              <div style={{ marginTop: '0.75rem', paddingTop: '0.75rem', borderTop: '1px solid #2f3336' }}>
                <strong>Server response (which backend answered):</strong>
                <div>Store: <code>{debugInfo.serverDebug.store}</code></div>
                <div>DATABASE_URL set: <code>{String(debugInfo.serverDebug.database_url_set)}</code></div>
                <div>Requested script_id: <code>{String(debugInfo.serverDebug.requested_script_id)}</code></div>
                <div>Known script IDs in this store: <code>{JSON.stringify(debugInfo.serverDebug.known_script_ids_in_this_store)}</code></div>
                {debugInfo.serverDebug.tip && <div style={{ color: '#1d9bf0', marginTop: '0.5rem' }}>{debugInfo.serverDebug.tip}</div>}
              </div>
            ) : (
              <div style={{ marginTop: '0.75rem', color: '#8b98a5' }}>
                Open <a href="http://localhost:8000/debug" target="_blank" rel="noopener noreferrer">http://localhost:8000/debug</a> to see which store this backend uses.
              </div>
            )}
          </div>
        )}
      </div>
    )
  }

  const handleDownload = () => {
    downloadScript(scriptId).catch((e) => setError(e.message))
  }

  return (
    <div>
      <div style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
        <Link to="/app/scripts">← Scripts</Link>
        <button type="button" onClick={handleDownload} style={downloadBtnStyle}>
          Download script
        </button>
      </div>
      <h1 style={{ marginTop: 0 }}>Parsed APIs</h1>
      <p style={{ color: '#8b98a5', margin: '0 0 1rem' }}>{transactions.length} request{transactions.length !== 1 ? 's' : ''} captured</p>
      {transactions.length === 0 ? (
        <p style={{ color: '#8b98a5' }}>No transactions parsed for this script.</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {transactions.map((t, idx) => (
            <details key={t.id || idx} style={cardStyle}>
              <summary style={summaryStyle}>
                <span style={methodBadgeStyle(t.http_method)}>{t.http_method || 'GET'}</span>
                <span style={{ flex: 1, wordBreak: 'break-all', color: '#e7e9ea' }}>{t.request_url}</span>
                <span style={{ color: '#8b98a5', fontSize: 12, whiteSpace: 'nowrap' }}>{t.transaction_name}</span>
              </summary>
              <div style={detailBodyStyle}>
                <div style={detailRow}><strong style={labelStyle}>Transaction</strong> {t.transaction_name}</div>
                <div style={detailRow}><strong style={labelStyle}>Order</strong> {t.execution_order}</div>
                <div style={detailRow}><strong style={labelStyle}>Method</strong> {t.http_method}</div>
                <div style={detailRow}><strong style={labelStyle}>URL</strong> <span style={{ wordBreak: 'break-all' }}>{t.request_url}</span></div>
                {t.headers && Object.keys(t.headers).length > 0 && (
                  <div style={{ marginTop: '0.5rem' }}>
                    <strong style={labelStyle}>Headers</strong>
                    <pre style={preStyle}>{JSON.stringify(t.headers, null, 2)}</pre>
                  </div>
                )}
                {t.payload != null && (
                  <div style={{ marginTop: '0.5rem' }}>
                    <strong style={labelStyle}>Payload / Body</strong>
                    <pre style={preStyle}>{typeof t.payload === 'string' ? t.payload : JSON.stringify(t.payload, null, 2)}</pre>
                  </div>
                )}
              </div>
            </details>
          ))}
        </div>
      )}
    </div>
  )
}

const cardStyle = {
  background: '#16181c',
  border: '1px solid #2f3336',
  borderRadius: 8,
  overflow: 'hidden',
}
const summaryStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '0.75rem',
  padding: '0.75rem 1rem',
  cursor: 'pointer',
  userSelect: 'none',
  fontSize: 14,
}
const methodBadgeStyle = (method) => ({
  padding: '2px 8px',
  borderRadius: 4,
  fontWeight: 700,
  fontSize: 12,
  fontFamily: 'monospace',
  color: '#fff',
  background: (method || '').toUpperCase() === 'POST' ? '#da3633'
    : (method || '').toUpperCase() === 'PUT' ? '#d29922'
    : (method || '').toUpperCase() === 'DELETE' ? '#f85149'
    : '#238636',
  minWidth: 48,
  textAlign: 'center',
  flexShrink: 0,
})
const detailBodyStyle = { padding: '0.75rem 1rem', borderTop: '1px solid #2f3336', fontSize: 13 }
const detailRow = { marginBottom: '0.35rem', color: '#e7e9ea' }
const labelStyle = { color: '#8b98a5', display: 'inline-block', width: 90 }
const preStyle = {
  background: '#0d1117',
  padding: '0.75rem',
  borderRadius: 6,
  overflow: 'auto',
  maxHeight: 200,
  fontSize: 12,
  color: '#e7e9ea',
  margin: '0.35rem 0 0',
  whiteSpace: 'pre-wrap',
  wordBreak: 'break-all',
}
const downloadBtnStyle = {
  padding: '0.5rem 1rem',
  background: '#1d9bf0',
  color: '#fff',
  border: 'none',
  borderRadius: 6,
  fontWeight: 600,
  cursor: 'pointer',
}

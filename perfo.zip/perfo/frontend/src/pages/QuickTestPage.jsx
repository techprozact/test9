import { useState, useEffect, useRef, useMemo } from 'react'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { useTheme } from '../context/ThemeContext'
import { listScenarios, startExecution, stopExecution, listExecutions, getScriptTransactions } from '../api'
import ErrorLogsModal from '../components/ErrorLogsModal'
import PerformanceTable from '../components/PerformanceTable'
import { useAnalytics } from '../analytics/useAnalytics'
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar, ComposedChart,
  ResponsiveContainer, Tooltip, CartesianGrid, XAxis, YAxis, ReferenceLine,
} from 'recharts'

/* ─────────────────────────── data generation ─────────────────────────── */

function genEmptyData() {
  const pts = Array.from({ length: 24 }, (_, i) => i)
  return {
    throughput:   pts.map(t => ({ t, v: 0 })),
    avg_rt:       pts.map(t => ({ t, v: 0 })),
    hits:         pts.map(t => ({ t, v: 0 })),
    active_vus:   pts.map(t => ({ t, v: 0 })),
    error_rate:   pts.map(t => ({ t, v: 0 })),
    requests:     pts.map(t => ({ t, v: 0 })),
    latency:      pts.map(t => ({ t, p50: 0, p90: 0, p95: 0, p99: 0 })),
    ux_variance:  pts.map(t => ({ t, v: 0 })),
  }
}

function nextTick(prev, tick, targetVUs) {
  const rampTicks = 5
  const factor = Math.min(1, tick / rampTicks)
  const j = (n, pct = 0.05) => Math.max(0, n + (Math.random() * 2 - 1) * n * pct)
  const slide = (arr, pt) => [...arr.slice(1), pt]
  const lastT = (prev.throughput.at(-1)?.t ?? 0) + 1

  const tps    = tick === 0 ? 8  : Math.round(j(400 * factor, 0.04))
  const avgRt  = tick === 0 ? 18 : Math.round(j(126 * (0.25 + 0.75 * factor), 0.05))
  const p50Rt  = Math.round(j(avgRt * 0.74, 0.06))
  const p95Rt  = Math.round(j(avgRt * 3.3,  0.05))
  const vus    = Math.min(targetVUs, Math.round(targetVUs * factor))
  let cumReq   = prev.requests.at(-1)?.v ?? 0
  cumReq += tps
  // UX Variance = P95 - P50 (spread from median to 95th percentile)
  const uxVar  = tick < 2 ? 0 : Math.max(0, p95Rt - p50Rt)

  return {
    throughput:  slide(prev.throughput,  { t: lastT, v: tps }),
    avg_rt:      slide(prev.avg_rt,      { t: lastT, v: avgRt }),
    hits:        slide(prev.hits,        { t: lastT, v: Math.round(j(tps * 0.96, 0.03)) }),
    active_vus:  slide(prev.active_vus,  { t: lastT, v: vus }),
    error_rate:  slide(prev.error_rate,  {
      t: lastT,
      v: tick < 2 ? 0 : parseFloat(j(0.42, 0.15).toFixed(2)),
    }),
    requests:    slide(prev.requests,    { t: lastT, v: cumReq }),
    latency:     slide(prev.latency, {
      t: lastT,
      p50: p50Rt,
      p90: Math.round(j(avgRt * 2.0, 0.06)),
      p95: p95Rt,
      p99: Math.round(j(p95Rt * 1.42, 0.05)),
    }),
    ux_variance: slide(prev.ux_variance, { t: lastT, v: uxVar }),
  }
}

/* ─────────────────────────── metric config ─────────────────────────── */

const METRICS = [
  // ── Row 1 ──
  { key: 'active_vus',  label: 'Active Virtual Users',    unit: 'VUs',    color: '#3b82f6', type: 'area',       idleMax: 100,  hasPerItem: false },
  { key: 'throughput',  label: 'Throughput',               unit: 'TPS',    color: '#06b6d4', type: 'area',       idleMax: 500,  hasPerItem: true,  perItemField: 'tps'    },
  { key: 'avg_rt',      label: 'Avg Response Time',        unit: 'ms',     color: '#10b981', type: 'line',       idleMax: 300,  hasPerItem: true,  perItemField: 'avgRt'  },
  { key: 'hits',        label: 'Hits / Second',            unit: 'hits/s', color: '#f59e0b', type: 'bar',        idleMax: 500,  hasPerItem: true,  perItemField: 'tps'    },
  // ── Row 2 ──
  { key: 'error_rate',  label: 'Error Rate',               unit: '%',      color: '#ef4444', type: 'area',       idleMax: 5,    hasPerItem: true,  perItemField: 'errPct' },
  { key: 'requests',    label: 'Requests Completed',       unit: '',       color: '#14b8a6', type: 'area',       idleMax: 1000, hasPerItem: false },
  { key: 'latency',     label: 'Latency Trend',            unit: 'ms',     color: '#a78bfa', type: 'multi-line', idleMax: 500,  hasPerItem: false },
  { key: 'ux_variance', label: 'User Experience Variance', unit: 'ms',     color: '#f472b6', type: 'area',       idleMax: 400,  hasPerItem: false },
]

const LAT_COLORS = { p50: '#06b6d4', p90: '#10b981', p95: '#8b5cf6', p99: '#f59e0b' }

// Palette for individual API / transaction series lines
const SERIES_PALETTE = [
  '#f59e0b', '#3b82f6', '#ec4899', '#8b5cf6',
  '#06b6d4', '#84cc16', '#f97316', '#14b8a6',
  '#ef4444', '#a855f7', '#0ea5e9', '#d946ef',
]

// Per-metric table column definitions for the expanded overlay
// avgRow(nonZeroVals, totReqs, totErrs, lastVal) → cell values array
// seriesRow(apiStats, graphPts)                  → cell values array
const TABLE_DEFS = {
  avg_rt: {
    cols: [
      { label: 'Avg RT (ms)', isFail: false },
      { label: 'Min RT (ms)', isFail: false },
      { label: 'Max RT (ms)', isFail: false },
      { label: 'Calls',       isFail: false },
      { label: 'Fail',        isFail: true  },
    ],
    avgRow:    (v, totReqs, totErrs) => [
      v.length ? Math.round(v.reduce((s, x) => s + x, 0) / v.length) : 0,
      v.length ? Math.min(...v) : 0,
      v.length ? Math.max(...v) : 0,
      totReqs ?? null,
      totErrs ?? null,
    ],
    seriesRow: (st) => [
      st?.avg ?? 0, st?.min ?? null, st?.max ?? null,
      st ? (st.pass || 0) + (st.fail || 0) : null,
      st?.fail ?? null,
    ],
  },
  throughput: {
    cols: [
      { label: 'Avg TPS',  isFail: false },
      { label: 'Peak TPS', isFail: false },
      { label: 'Calls',    isFail: false },
      { label: 'Fail',     isFail: true  },
    ],
    avgRow:    (v, totReqs, totErrs) => [
      v.length ? Math.round(v.reduce((s, x) => s + x, 0) / v.length) : 0,
      v.length ? Math.max(...v) : 0,
      totReqs ?? null,
      totErrs ?? null,
    ],
    seriesRow: (st, gpts) => {
      const tpsV = (gpts || []).map(p => p.tps).filter(x => x > 0)
      return [
        tpsV.length ? Math.round(tpsV.reduce((s, x) => s + x, 0) / tpsV.length) : 0,
        tpsV.length ? Math.max(...tpsV) : 0,
        st ? (st.pass || 0) + (st.fail || 0) : null,
        st?.fail ?? null,
      ]
    },
  },
  hits: {
    cols: [
      { label: 'Avg Hits/s',  isFail: false },
      { label: 'Peak Hits/s', isFail: false },
      { label: 'Calls',       isFail: false },
      { label: 'Fail',        isFail: true  },
    ],
    avgRow:    (v, totReqs, totErrs) => [
      v.length ? Math.round(v.reduce((s, x) => s + x, 0) / v.length) : 0,
      v.length ? Math.max(...v) : 0,
      totReqs ?? null,
      totErrs ?? null,
    ],
    seriesRow: (st, gpts) => {
      const tpsV = (gpts || []).map(p => p.tps).filter(x => x > 0)
      return [
        tpsV.length ? Math.round(tpsV.reduce((s, x) => s + x, 0) / tpsV.length) : 0,
        tpsV.length ? Math.max(...tpsV) : 0,
        st ? (st.pass || 0) + (st.fail || 0) : null,
        st?.fail ?? null,
      ]
    },
  },
  error_rate: {
    cols: [
      { label: 'Error %', isFail: true  },
      { label: 'Errors',  isFail: true  },
      { label: 'Calls',   isFail: false },
      { label: 'Pass',    isFail: false },
    ],
    avgRow:    (_v, totReqs, totErrs, lastVal) => {
      const pass = totReqs != null && totErrs != null ? Math.max(0, totReqs - totErrs) : null
      return [Number(lastVal ?? 0).toFixed(2), totErrs ?? null, totReqs ?? null, pass]
    },
    seriesRow: (st) => {
      const total  = st ? (st.pass || 0) + (st.fail || 0) : 0
      const errPct = total > 0 && st ? ((st.fail / total) * 100).toFixed(2) : '0.00'
      return [errPct, st?.fail ?? null, total || null, st?.pass ?? null]
    },
  },
}

/* ─────────────────────────── tooltip helpers ─────────────────────────── */

function fmtElapsed(sampleIdx) {
  const secs = (sampleIdx ?? 0) * 5
  if (secs < 60) return `${secs}s`
  const m = Math.floor(secs / 60)
  const s = String(secs % 60).padStart(2, '0')
  return `${m}:${s} min`
}

function buildTipText(payload, label, unit, isMulti) {
  if (!payload?.length) return ''
  const time = fmtElapsed(label)
  if (isMulti) {
    return payload.map(p => `${p.name?.toUpperCase()}: ${p.value}`).join('  ') + `  (${time})`
  }
  const val  = payload[0]?.value ?? 0
  const disp = unit ? `${val} ${unit}` : `${val}`
  return `${disp}  (${time})`
}

/* ─────────────────────────── helpers ─────────────────────────── */

function fmtLocalTime(date) {
  if (!date) return '—'
  return date.toLocaleTimeString(undefined, {
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
  })
}

function parseSecs(str) {
  const m = String(str || '0').match(/^(\d+(?:\.\d+)?)\s*([smh]?)$/i)
  if (!m) return 0
  const v = parseFloat(m[1])
  const u = (m[2] || 's').toLowerCase()
  return u === 'm' ? v * 60 : u === 'h' ? v * 3600 : v
}

function fmtTime(secs) {
  if (!secs || secs <= 0) return '0s'
  if (secs < 60) return `${Math.round(secs)}s`
  const m = Math.floor(secs / 60), s = Math.round(secs % 60)
  return s > 0 ? `${m}m ${s}s` : `${m}m`
}

function fmtHHMMSS(totalSecs) {
  const s = Math.max(0, Math.round(totalSecs))
  const hh = Math.floor(s / 3600)
  const mm = Math.floor((s % 3600) / 60)
  const ss = s % 60
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`
}

function getPhase(elapsed, rampUpSecs, totalSecs, rampDownSecs) {
  if (elapsed <= 0) return 'Initializing'
  if (elapsed < rampUpSecs) return 'Ramp-up'
  if (elapsed >= totalSecs) return 'Completed'
  if (elapsed >= totalSecs - rampDownSecs) return 'Ramp-down'
  return 'Stable'
}

function mapPhaseLabel(phase) {
  if (!phase || phase === 'Initializing' || phase === 'Ramp-up') return 'Ramp-up'
  if (phase === 'Stable') return 'Steady-State'
  if (phase === 'Ramp-down' || phase === 'Completed') return 'Ramp-down'
  return 'Ramp-up'
}

function getPhaseColor(phase) {
  const p = mapPhaseLabel(phase)
  if (p === 'Steady-State') return '#22c55e'
  if (p === 'Ramp-up')      return '#f59e0b'
  if (p === 'Ramp-down')    return '#f97316'
  return '#8b8b9e'
}

function getCardStats(metricKey, data, targetVUs, isRunning = false) {
  const arr  = data[metricKey] || []
  const vals = arr.map(d => d.v ?? 0)
  const pos  = vals.filter(v => v > 0)
  const min  = pos.length ? Math.min(...pos) : 0
  const max  = pos.length ? Math.max(...pos) : 0
  const avg  = pos.length ? Math.round(pos.reduce((s, v) => s + v, 0) / pos.length) : 0
  const cur  = vals.at(-1) ?? 0
  const sorted = [...pos].sort((a, b) => a - b)
  const p95v = sorted.length ? (sorted[Math.floor(sorted.length * 0.95)] ?? sorted.at(-1)) : 0

  switch (metricKey) {
    case 'avg_rt':
      return [
        { label: 'Min', val: `${min} ms` },
        { label: 'Max', val: `${max} ms` },
        { label: 'Avg', val: `${avg} ms` },
        { label: 'P95', val: `${p95v} ms` },
      ]
    case 'throughput':
      return isRunning
        ? [{ label: 'Avg', val: `${avg}` }, { label: 'Peak', val: `${max}` }, { label: 'Live', val: `${cur}` }]
        : [{ label: 'Avg', val: `${avg}` }, { label: 'Peak', val: `${max}` }]
    case 'hits':
      return isRunning
        ? [{ label: 'Avg', val: `${avg}` }, { label: 'Peak', val: `${max}` }, { label: 'Live', val: `${cur}` }]
        : [{ label: 'Avg', val: `${avg}` }, { label: 'Peak', val: `${max}` }]
    case 'error_rate': {
      // Prefer the exact cumulative count stored on the graph point (never drops to 0)
      const totalErrors = arr.at(-1)?.totalErrors
        ?? Math.round((data.requests?.at(-1)?.v ?? 0) * ((cur || 0) / 100))
      return [
        { label: 'Error %',   val: `${cur.toFixed ? cur.toFixed(2) : cur}%` },
        { label: 'Total Err', val: `${totalErrors}` },
        { label: 'Failed',    val: `${totalErrors}` },
      ]
    }
    case 'active_vus':
      return [
        { label: 'Active',  val: `${cur}` },
        { label: 'Target',  val: `${targetVUs || 100}` },
        { label: 'Peak',    val: `${max}` },
      ]
    case 'requests': {
      const total = cur
      const rate  = data.throughput?.at(-1)?.v ?? 0
      const err   = data.error_rate?.at(-1)?.v ?? 0
      const succ  = total > 0 ? (100 - err).toFixed(1) : '0.0'
      return [
        { label: 'Total',   val: total > 999 ? `${(total / 1000).toFixed(1)}K` : `${total}` },
        { label: 'Rate',    val: `${rate}/s` },
        { label: 'Success', val: `${succ}%` },
      ]
    }
    case 'latency': {
      const last = arr.at(-1) ?? {}
      return [
        { label: 'P50', val: `${last.p50 ?? 0} ms` },
        { label: 'P90', val: `${last.p90 ?? 0} ms` },
        { label: 'P95', val: `${last.p95 ?? 0} ms` },
        { label: 'P99', val: `${last.p99 ?? 0} ms` },
      ]
    }
    case 'ux_variance': {
      const spread = cur
      const latLast = (data.latency || []).at(-1) ?? {}
      const p50 = latLast.p50 ?? 0
      const p95 = latLast.p95 ?? 0
      return [
        { label: 'Spread',   val: `${spread} ms` },
        { label: 'P95',      val: `${p95} ms`    },
        { label: 'Median',   val: `${p50} ms`    },
      ]
    }
    default:
      return []
  }
}

/* ─────────────────────────── main component ─────────────────────────── */

export default function QuickTestPage() {
  const { t, isDark } = useTheme()
  const navigate = useNavigate()

  const [scenarios,    setScenarios]    = useState([])
  const [selectedId,   setSelectedId]   = useState('')
  const [duration,     setDuration]     = useState('5m')
  const [rampUp,       setRampUp]       = useState('30s')
  const [rampDown,     setRampDown]     = useState('15s')
  const [testState,    setTestState]    = useState('idle')   // idle | starting | running | completed
  const [bootStage,    setBootStage]    = useState(-1)      // -1 = not booting, 0..N = current stage
  const [elapsed,      setElapsed]      = useState(0)
  const [chartData,    setChartData]    = useState(genEmptyData)
  const [tickCount,    setTickCount]    = useState(0)
  const [testStartTime, setTestStartTime] = useState(null)
  const [testEndTime,   setTestEndTime]   = useState(null)
  const [frozenData,   setFrozenData]   = useState(null)
  const [testRunId,    setTestRunId]    = useState(null)
  const [runSeqNumber, setRunSeqNumber] = useState(null)
  const [usingMock,    setUsingMock]    = useState(false)

  const [expandedKey,          setExpandedKey]          = useState(null)
  const [hoveredCard,          setHoveredCard]          = useState(null)
  const [ttip,                 setTtip]                 = useState({ visible: false, text: '', x: 0, y: 0 })
  const [expandedHiddenSeries, setExpandedHiddenSeries] = useState({})   // { [metricKey]: Set<string> }
  const [expandedTableMode,    setExpandedTableMode]    = useState({})   // { [metricKey]: 'api' | 'tx' }

  const [showWarning5m,       setShowWarning5m]       = useState(false)
  const [showCompletionPopup, setShowCompletionPopup] = useState(false)
  const [errorModal,          setErrorModal]          = useState(null) // { scriptId, scriptName }
  const [showGuardianPanel,   setShowGuardianPanel]   = useState(false)
  const [guardianToast,       setGuardianToast]       = useState(null)
  const [subtleHint,          setSubtleHint]          = useState(null)
  const subtleHintTimerRef = useRef(null)
  const warning5mShownRef     = useRef(false)
  const guardianToastTimerRef = useRef(null)
  const guardianToastBufRef   = useRef([])     // 3-second aggregation buffer
  const guardianToastDebRef   = useRef(null)   // debounce timer for aggregation

  const tickRef        = useRef(0)
  const targetVUsRef   = useRef(100)
  const dataInterval   = useRef(null)
  const elapsedInterval = useRef(null)
  const testStartMsRef = useRef(0)       // wall-clock epoch ms when test started
  const ttipRef        = useRef({ visible: false, text: '' })

  // Analytics engine — active only when we have a real backend execution
  const totalDurSecs = parseSecs(rampUp) + parseSecs(duration) + parseSecs(rampDown)
  const analytics = useAnalytics(testRunId, {
    active: testState === 'running' && !!testRunId,
    totalDurationSecs: totalDurSecs,
  })
  const guardianAlerts     = analytics.guardianAlerts     ?? []
  const guardianToastQueue = analytics.guardianToastQueue ?? []
  const guardianRiskScore  = analytics.guardianRiskScore  ?? 0
  const guardianSubtleHint = analytics.guardianSubtleHint ?? null

  /* ── load scenarios ── */
  useEffect(() => {
    listScenarios().then(d => setScenarios(d || [])).catch(() => {})
  }, [])

  /* ── restore running session from sessionStorage on mount ── */
  useEffect(() => {
    try {
      const saved = sessionStorage.getItem('qt_session')
      if (!saved) return
      const sess = JSON.parse(saved)
      if (sess.testState !== 'running' || !sess.testRunId) return
      setTestRunId(sess.testRunId)
      if (sess.runSeqNumber) setRunSeqNumber(sess.runSeqNumber)
      setTestState('running')
      setSelectedId(sess.selectedId || '')
      setDuration(sess.duration || '5m')
      setRampUp(sess.rampUp || '30s')
      setRampDown(sess.rampDown || '15s')
      if (sess.testStartTime) setTestStartTime(new Date(sess.testStartTime))
      const startMs = sess.testStartMs || Date.now()
      testStartMsRef.current = startMs  // must be set before setTestState('running')
    } catch { /* ignore corrupt storage */ }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /* ── persist running session to sessionStorage ── */
  useEffect(() => {
    if (testState === 'running' && testRunId) {
      try {
        sessionStorage.setItem('qt_session', JSON.stringify({
          testRunId,
          testState,
          selectedId,
          duration,
          rampUp,
          rampDown,
          testStartMs: testStartMsRef.current,
          testStartTime: testStartTime?.toISOString() || null,
          runSeqNumber,
        }))
      } catch { /* ignore */ }
    } else if (testState === 'idle') {
      sessionStorage.removeItem('qt_session')
    }
  }, [testRunId, testState, selectedId, duration, rampUp, rampDown, testStartTime, runSeqNumber])

  const BOOT_STAGES = [
    { label: 'Loading Scripts',            icon: '📦' },
    { label: 'Initializing Data Pipeline', icon: '🔄' },
    { label: 'Starting Process Engine',    icon: '⚙️' },
    { label: 'Forking Virtual User Threads', icon: '🧵' },
    { label: 'Connecting Metrics Engine',  icon: '📊' },
    { label: 'Starting Load Test',          icon: '🚀' },
  ]

  /* ── inject keyframes ── */
  useEffect(() => {
    if (document.getElementById('qt2-styles')) return
    const el = document.createElement('style')
    el.id = 'qt2-styles'
    el.textContent = `
      @keyframes qt2Pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.35;transform:scale(0.8)} }
      @keyframes qt2FadeIn { from{opacity:0;transform:scale(0.975)} to{opacity:1;transform:scale(1)} }
      @keyframes qt2SlideDown { from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:translateY(0)} }
      @keyframes qt2SlideUp { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
      @keyframes qt2Spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
      @keyframes qt2StageIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
      @keyframes qt2DotPulse { 0%,80%,100%{transform:scale(0);opacity:0.4} 40%{transform:scale(1);opacity:1} }
      @keyframes qt2ProgressGlow { 0%{box-shadow:0 0 4px rgba(99,102,241,0.3)} 50%{box-shadow:0 0 16px rgba(99,102,241,0.6)} 100%{box-shadow:0 0 4px rgba(99,102,241,0.3)} }
    `
    document.head.appendChild(el)
  }, [])

  /* ── global mouse tracker for cursor-relative tooltip ── */
  useEffect(() => {
    const onMove = e => {
      if (ttipRef.current.visible) {
        setTtip(prev => ({ ...prev, x: e.clientX, y: e.clientY }))
      }
    }
    window.addEventListener('mousemove', onMove)
    return () => window.removeEventListener('mousemove', onMove)
  }, [])

  /* ── elapsed counter — single source of truth, driven by testState ──
       Handles fresh starts AND session restores without any race conditions.
       testStartMsRef.current must be set before testState → 'running'. */
  useEffect(() => {
    if (testState !== 'running') {
      clearInterval(elapsedInterval.current)
      elapsedInterval.current = null
      return
    }
    // Immediately sync, then tick every second
    setElapsed(Math.floor((Date.now() - testStartMsRef.current) / 1000))
    clearInterval(elapsedInterval.current)
    elapsedInterval.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - testStartMsRef.current) / 1000))
    }, 1000)
    return () => {
      clearInterval(elapsedInterval.current)
      elapsedInterval.current = null
    }
  }, [testState])

  /* ── cleanup ── */
  useEffect(() => () => {
    clearInterval(dataInterval.current)
    clearInterval(elapsedInterval.current)
  }, [])

  /* ── auto-complete when backend reports test finished ── */
  useEffect(() => {
    const s = analytics.testStatus?.status
    if (testRunId && testState === 'running' && (s === 'COMPLETED' || s === 'FAILED' || s === 'ABORTED' || s === 'STOPPED')) {
      sessionStorage.removeItem('qt_session')
      setFrozenData(analytics.chartData)
      setTestEndTime(new Date())
      setTestState('completed') // useEffect[testState] stops the elapsed interval
      setShowCompletionPopup(true)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [analytics.testStatus])

  /* ── 5-minute warning before test ends ── */
  useEffect(() => {
    if (testState !== 'running') return
    const totalSecs = parseSecs(rampUp) + parseSecs(duration) + parseSecs(rampDown)
    const remaining = Math.max(0, totalSecs - elapsed)
    if (totalSecs > 300 && remaining <= 300 && remaining > 0 && !warning5mShownRef.current) {
      warning5mShownRef.current = true
      setShowWarning5m(true)
      setTimeout(() => setShowWarning5m(false), 8000)
    }
  }, [testState, elapsed, duration, rampUp, rampDown])

  /* ── Guardian toast — fires only for NEW alert creation and RECURRING transitions
   * (the Guardian lifecycle engine guarantees onToast is called at most once per
   * rule per lifecycle phase, so there is no spam risk).
   * Multiple simultaneous transitions are batched via a 3 s aggregation window.  */
  useEffect(() => {
    if (!guardianToastQueue.length) return
    const latest = guardianToastQueue[guardianToastQueue.length - 1]

    // Add to aggregation buffer
    guardianToastBufRef.current.push(latest)

    // Debounce: wait 3 s for more toasts before showing
    if (guardianToastDebRef.current) clearTimeout(guardianToastDebRef.current)
    guardianToastDebRef.current = setTimeout(() => {
      const buf = guardianToastBufRef.current
      guardianToastBufRef.current = []
      if (!buf.length) return

      let toast
      if (buf.length === 1) {
        toast = {
          severity:  buf[0].severity,
          ruleCode:  buf[0].ruleCode,
          state:     buf[0].state,
          time:      buf[0].firstDetectedAt,
          message:   buf[0].state === 'RECURRING'
            ? `Issue recurred: ${buf[0].ruleCode} — ${buf[0].message}`
            : buf[0].message,
        }
      } else {
        const hasCrit = buf.some(e => e.severity === 'critical')
        const hasWarn = buf.some(e => e.severity === 'warning')
        toast = {
          severity: hasCrit ? 'critical' : hasWarn ? 'warning' : 'info',
          ruleCode: 'BATCH',
          state:    'NEW',
          time:     buf[buf.length - 1].firstDetectedAt,
          message:  `${buf.length} new performance issue${buf.length > 1 ? 's' : ''} detected. Open Guardian to review.`,
        }
      }

      setGuardianToast(toast)
      if (guardianToastTimerRef.current) clearTimeout(guardianToastTimerRef.current)
      guardianToastTimerRef.current = setTimeout(() => setGuardianToast(null), 7000)
    }, 3000)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [guardianToastQueue.length])

  /* ── Subtle hint toast — fires only on substantial state transitions (risk-tier
   * crossings, RESOLVED, STABLE, or critical severity escalation). The Guardian
   * enforces a 90-second per-direction cooldown so this never spams.            */
  useEffect(() => {
    if (!guardianSubtleHint) return
    setSubtleHint(guardianSubtleHint)
    if (subtleHintTimerRef.current) clearTimeout(subtleHintTimerRef.current)
    subtleHintTimerRef.current = setTimeout(() => setSubtleHint(null), 6000)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [guardianSubtleHint?._id])

  /* ── computed scenario scripts ── */
  const scenarioScripts = useMemo(() => {
    if (!selectedId) return []
    const sc = scenarios.find(s => String(s.id) === selectedId)
    if (!sc?.scripts_json) return []
    try { return JSON.parse(sc.scripts_json) } catch { return [] }
  }, [selectedId, scenarios])

  /* ── transaction name map: { "scriptId:seqNum" → txName } ── */
  const [txNameMap, setTxNameMap] = useState({})
  useEffect(() => {
    if (!scenarioScripts.length) return
    let cancelled = false
    async function fetchNames() {
      const map = {}
      for (const sc of scenarioScripts) {
        const sid = String(sc.script_id || sc.id || '')
        if (!sid) continue
        try {
          const txs = await getScriptTransactions(sid)
          for (const tx of (txs || [])) {
            map[`${sid}:${tx.execution_order}`] = tx.transaction_name || `Step ${tx.execution_order}`
          }
        } catch { /* non-fatal */ }
      }
      if (!cancelled) setTxNameMap(map)
    }
    fetchNames()
    return () => { cancelled = true }
  }, [scenarioScripts])

  /* ── target VUs from scenario ── */
  const totalTargetVUs = useMemo(() => {
    const sum = scenarioScripts.reduce((s, sc) => s + (parseInt(sc.users) || 0), 0)
    return sum || 100
  }, [scenarioScripts])

  useEffect(() => {
    targetVUsRef.current = totalTargetVUs
  }, [totalTargetVUs])

  /* ── derived display data ── */
  // Priority: frozen snapshot > live analytics > mock chart data
  const displayData = useMemo(() => {
    if (frozenData) return frozenData
    if (testRunId && analytics.chartData && analytics.chartData.throughput?.length > 0) {
      return analytics.chartData
    }
    return chartData
  }, [frozenData, testRunId, analytics.chartData, chartData])

  /* ── expanded overlay: per-series entries + merged chart data ── */
  const expandedSeriesData = useMemo(() => {
    const m = METRICS.find(x => x.key === expandedKey)
    if (!m?.hasPerItem || !expandedKey) return { entries: [], mergedData: null }

    const mode = expandedTableMode[expandedKey] || 'api'
    const rawGraphData = mode === 'tx'
      ? (analytics.txGraphData || {})
      : (analytics.apiGraphData || {})

    const keys = Object.keys(rawGraphData)
    if (!keys.length) return { entries: [], mergedData: null }

    const entries = keys.slice(0, 14).map((k, i) => ({
      id:      k,
      label:   mode === 'tx' ? (txNameMap[k] || k) : k,
      color:   SERIES_PALETTE[i % SERIES_PALETTE.length],
      safeKey: `_s${i}`,
    }))

    const mainArr = displayData[expandedKey] || []

    // build t → point lookup for each series
    const seriesMaps = {}
    for (const entry of entries) {
      const pts = rawGraphData[entry.id] || []
      const map = {}
      for (const pt of pts) map[pt.t] = pt
      seriesMaps[entry.id] = map
    }

    const mergedData = mainArr.map(pt => {
      const merged = { ...pt }
      for (const entry of entries) {
        const apiPt = seriesMaps[entry.id]?.[pt.t]
        merged[entry.safeKey] = apiPt ? (apiPt[m.perItemField] ?? null) : null
      }
      return merged
    })

    return { entries, mergedData }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expandedKey, expandedTableMode, analytics.apiGraphData, analytics.txGraphData, displayData, txNameMap])

  /* ── script table rows (real analytics or mock approximation) ── */
  const scriptTableRows = useMemo(() => {
    if (testState === 'idle') return []
    const liveData = displayData
    const scripts = scenarioScripts.length > 0
      ? scenarioScripts
      : [{ script_name: selectedId ? 'Default Script' : 'No Scenario', users: 100 }]
    const totalUsers = scripts.reduce((s, sc) => s + (parseInt(sc.users) || 0), 0) || 100
    const globalTps   = liveData.throughput?.at(-1)?.v ?? 0
    const globalAvgRt = liveData.avg_rt?.at(-1)?.v ?? 0
    const globalActiveVUs = liveData.active_vus?.at(-1)?.v ?? 0

    const realPerScript = analytics.perScript || {}

    return scripts.map(sc => {
      const scriptId = String(sc.script_id || sc.id || '')
      const target = parseInt(sc.users) || 0
      const rampUpSecs   = parseSecs(rampUp)
      const steadySecs   = parseSecs(duration)
      const rampDownSecs = parseSecs(rampDown)
      const totalSecs    = rampUpSecs + steadySecs + rampDownSecs
      const phase = testState === 'completed'
        ? 'Completed'
        : getPhase(elapsed, rampUpSecs, totalSecs, rampDownSecs)

      const real = testRunId && realPerScript[scriptId]
      if (real) {
        const tx_passed = Math.max(0, (real.totalRequests || 0) - (real.totalErrors || 0))
        return {
          scriptId,
          name:       sc.script_name || 'Script',
          target,
          running:    real.activeVUs ?? 0,
          pending:    Math.max(0, target - (real.activeVUs ?? 0)),
          vu_failed:  0,
          tx_passed,
          tx_failed:  real.totalErrors ?? 0,
          tps:        real.tps ?? 0,
          avg_rt:     real.avgRt ?? 0,
          max_rt:     real.maxRt ?? 0,
          phase,
        }
      }

      // Mock fallback
      const share   = totalUsers > 0 ? target / totalUsers : 1
      const running = Math.round(globalActiveVUs * share)
      const tps     = Math.round(globalTps * share)
      const tick    = tickRef.current
      const tx_passed = Math.max(0, Math.round(tick * tps * 4.8))
      return {
        scriptId,
        name:      sc.script_name || 'Script',
        target,
        running,
        pending:   Math.max(0, target - running),
        vu_failed: 0,
        tx_passed,
        tx_failed: Math.round(tx_passed * 0.018),
        tps,
        avg_rt:    globalAvgRt,
        max_rt:    0,
        phase,
      }
    })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testState, displayData, scenarioScripts, selectedId, elapsed, duration, rampUp, rampDown, tickCount, testRunId, analytics.perScript])

  /* ── global header stats ── */
  const globalStats = useMemo(() => {
    if (testState === 'idle' || testState === 'starting') return null
    const data = displayData
    const steadySecs   = parseSecs(duration)   // user input = steady-state
    const rampUpSecs   = parseSecs(rampUp)
    const rampDownSecs = parseSecs(rampDown)
    const totalSecs    = rampUpSecs + steadySecs + rampDownSecs   // true total
    const remaining    = Math.max(0, totalSecs - elapsed)
    const tps          = data.throughput?.at(-1)?.v ?? 0
    const activeVUs    = data.active_vus?.at(-1)?.v ?? 0

    // Prefer analytics cumulative error count when available
    let totalErrors
    if (testRunId && analytics.cumulative) {
      totalErrors = analytics.cumulative.totalErrors ?? 0
    } else {
      const errRate  = data.error_rate?.at(-1)?.v ?? 0
      const totalReq = data.requests?.at(-1)?.v ?? 0
      totalErrors = Math.round(totalReq * ((errRate || 0) / 100))
    }

    const phase = testState === 'completed'
      ? 'Completed'
      : getPhase(elapsed, rampUpSecs, totalSecs, rampDownSecs)
    return { elapsed, remaining, totalSecs, steadySecs, activeVUs, totalErrors, tps, phase }
  }, [testState, displayData, elapsed, duration, rampUp, rampDown, testRunId, analytics.cumulative])

  /* ── can user start a test? ── */
  const canRunTest = !!(selectedId && duration?.trim() && rampUp?.trim() && rampDown?.trim())

  /* ── handlers ── */

  function handleScenarioChange(e) {
    const id = e.target.value
    setSelectedId(id)
    const sc = scenarios.find(s => String(s.id) === id)
    if (sc) {
      setDuration(sc.duration || '5m')
      setRampUp(sc.ramp_up || '30s')
      setRampDown(sc.ramp_down || '15s')
    }
  }

  async function handleRunStop() {
    if (testState === 'running') {
      // ── STOP ──
      clearInterval(dataInterval.current)
      sessionStorage.removeItem('qt_session')
      if (testRunId) {
        try { await stopExecution(testRunId) } catch { /* best-effort */ }
        setFrozenData(analytics.chartData || chartData)
      } else {
        setFrozenData(chartData)
      }
      setTestEndTime(new Date())
      setTestState('completed')
      setShowCompletionPopup(true)
      return
    }

    // ── START (boot animation → actual test) ──
    setTestState('starting')
    setBootStage(0)
    setFrozenData(null)
    setTestEndTime(null)
    setShowCompletionPopup(false)
    setShowWarning5m(false)
    warning5mShownRef.current = false
    setShowGuardianPanel(false)
    setGuardianToast(null)
    setSubtleHint(null)
    if (guardianToastTimerRef.current) clearTimeout(guardianToastTimerRef.current)
    if (guardianToastDebRef.current)   clearTimeout(guardianToastDebRef.current)
    if (subtleHintTimerRef.current)    clearTimeout(subtleHintTimerRef.current)
    guardianToastBufRef.current = []

    // Walk through boot stages (3s each), then actually fire the test
    for (let i = 0; i < BOOT_STAGES.length; i++) {
      await new Promise(r => setTimeout(r, i === BOOT_STAGES.length - 1 ? 5000 : 3000))
      if (i < BOOT_STAGES.length - 1) setBootStage(i + 1)
    }

    // Now actually start the test
    tickRef.current = 0
    targetVUsRef.current = totalTargetVUs
    setElapsed(0)
    setTickCount(0)
    const startNow = new Date()
    setTestStartTime(startNow)
    testStartMsRef.current = startNow.getTime()
    setTestRunId(null)
    setUsingMock(false)

    const freshData = genEmptyData()
    setChartData(freshData)

    try {
      const scriptConfigs = scenarioScripts.map(sc => ({
        script_id:   String(sc.script_id || sc.id || ''),
        script_name: sc.script_name || sc.name || 'Script',
        users:       parseInt(sc.users) || 1,
        pacing:      sc.pacing || '0s',
        think_time:  sc.think_time || '0s',
        parameters:  sc.parameters || {},
      }))
      if (!scriptConfigs.length) throw new Error('No scripts configured')

      const result = await startExecution({
        scenario_id: selectedId,
        scripts: scriptConfigs,
        duration,
        ramp_up: rampUp,
        ramp_down: rampDown,
      })
      setTestRunId(result.test_run_id)
      listExecutions().then(allRuns => {
        const sorted = [...(allRuns || [])].sort((a, b) => new Date(a.start_time || 0) - new Date(b.start_time || 0))
        const idx = sorted.findIndex(r => r.id === result.test_run_id)
        if (idx >= 0) setRunSeqNumber(idx + 1)
      }).catch(() => {})
    } catch {
      setUsingMock(true)
      dataInterval.current = setInterval(() => {
        tickRef.current += 1
        const tick = tickRef.current
        setTickCount(tick)
        setChartData(prev => nextTick(prev, tick, targetVUsRef.current))
      }, 5000)
    }

    setBootStage(-1)
    setTestState('running')
  }

  function handleRunAgain() {
    sessionStorage.removeItem('qt_session')
    setTestState('idle')
    setBootStage(-1)
    setChartData(genEmptyData())
    setElapsed(0)
    setTickCount(0)
    setFrozenData(null)
    setTestStartTime(null)
    setTestEndTime(null)
    setTestRunId(null)
    setRunSeqNumber(null)
    setUsingMock(false)
    setShowCompletionPopup(false)
    setShowWarning5m(false)
    warning5mShownRef.current = false
    analytics.reset()
    tickRef.current = 0
  }

  function handleCompletionOk() {
    setShowCompletionPopup(false)
    handleRunAgain()
  }

  function handleGoToResults() {
    setShowCompletionPopup(false)
    const rid = testRunId
    handleRunAgain()
    navigate(`/app/test-results${rid ? `?open=${encodeURIComponent(rid)}` : ''}`)
  }

  /* ── expand helpers ── */
  function handleCardClick(key) {
    setExpandedKey(key)
  }
  function handleCloseExpanded() {
    setExpandedKey(null)
  }

  /* ── styles ── */

  const pageStyle = {
    minHeight: '100%',
    background: t.pageBg,
    padding: '24px 28px 32px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    boxSizing: 'border-box',
  }
  const card = {
    background: t.bgRaised,
    border: `1px solid ${t.border}`,
    borderRadius: 12,
    boxShadow: t.cardShadow,
  }
  const input = {
    background: t.bgInput,
    border: `1px solid ${t.border}`,
    borderRadius: 8,
    color: t.textPrimary,
    padding: '8px 12px',
    fontSize: 13,
    outline: 'none',
    width: '100%',
    transition: 'border-color 0.15s',
    boxSizing: 'border-box',
  }
  const label11 = {
    color: t.textTertiary,
    fontSize: 11,
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: '0.04em',
    marginBottom: 5,
    display: 'block',
  }
  const selectStyle = {
    ...input,
    paddingRight: 32,
    cursor: 'pointer',
    appearance: 'none',
    WebkitAppearance: 'none',
    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='11' height='11' viewBox='0 0 16 16' fill='none' stroke='%236b7280' stroke-width='2'%3E%3Cpath d='M4 6l4 4 4-4'/%3E%3C/svg%3E")`,
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'right 10px center',
  }

  /* ── chart renderer ── */

  function renderChart(metricKey, data, expanded, extraSeries = [], hiddenSeriesSet = new Set()) {
    const m = METRICS.find(x => x.key === metricKey)
    if (!m || !data) return null
    const arr  = data[metricKey] || []
    const idle = testState === 'idle'
    const grid = isDark ? 'rgba(255,255,255,0.055)' : 'rgba(0,0,0,0.055)'
    const ax   = t.textFaint
    const axisProps = {
      tick:      { fill: ax, fontSize: 10 },
      axisLine:  false,
      tickLine:  false,
    }
    const miniMargin  = { top: 2, right: 1, left: 1, bottom: 1 }
    const largeMargin = { top: 10, right: 24, left: 0, bottom: 8 }
    const margin = expanded ? largeMargin : miniMargin
    const yDomain = idle ? [0, m.idleMax] : [0, 'auto']

    const vals = arr.map(d => d.v ?? 0).filter(v => v > 0)
    const peak = vals.length ? Math.max(...vals) : 0
    const cur  = arr.at(-1)?.v ?? 0

    const showMain = !hiddenSeriesSet.has('_average')
    const visibleExtra = expanded ? extraSeries.filter(s => !hiddenSeriesSet.has(s.id)) : []

    /* shared chart event handlers — update the portal tooltip */
    const chartMove = ({ activePayload, activeLabel }) => {
      if (!activePayload?.length) return
      const isMulti = m.type === 'multi-line'
      const text = buildTipText(activePayload, activeLabel, m.unit, isMulti)
      ttipRef.current = { visible: true, text }
      setTtip(prev => ({ ...prev, visible: true, text }))
    }
    const chartLeave = () => {
      ttipRef.current = { visible: false, text: '' }
      setTtip(prev => ({ ...prev, visible: false }))
    }
    const cursorLine = { stroke: m.color, strokeWidth: 1, strokeDasharray: '4 2', strokeOpacity: 0.45 }
    const hiddenTip  = <Tooltip content={() => null} cursor={cursorLine} />

    if (m.type === 'area') {
      const gid = `qt-g-${metricKey}`
      return (
        <AreaChart data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <defs>
            <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%"   stopColor={m.color} stopOpacity={idle ? 0.06 : (expanded ? 0.22 : 0.3)} />
              <stop offset="100%" stopColor={m.color} stopOpacity={0.01} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded && <XAxis dataKey="t" {...axisProps} label={{ value: 'Sample', fill: ax, fontSize: 9, position: 'insideBottom', offset: -2 }} />}
          {!expanded && <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={yDomain} width={expanded ? 44 : 32} />
          {hiddenTip}
          {expanded && peak > 0 && <ReferenceLine y={peak} stroke={m.color} strokeDasharray="5 3" strokeOpacity={0.55} label={{ value: `Peak ${peak}`, fill: m.color, fontSize: 9, position: 'insideTopRight' }} />}
          {expanded && cur > 0 && cur !== peak && <ReferenceLine y={cur} stroke={m.color} strokeDasharray="2 3" strokeOpacity={0.35} label={{ value: `Now ${cur}`, fill: ax, fontSize: 9, position: 'insideBottomRight' }} />}
          {showMain && <Area type="monotone" dataKey="v" stroke={m.color} strokeWidth={idle ? 1 : (expanded ? 2.5 : 1.8)} fill={`url(#${gid})`} dot={false} isAnimationActive={false} strokeOpacity={idle ? 0.25 : 1} />}
          {visibleExtra.map(s => (
            <Line key={s.safeKey} type="monotone" dataKey={s.safeKey} stroke={s.color} strokeWidth={1.5} dot={false} isAnimationActive={false} strokeOpacity={0.85} connectNulls />
          ))}
        </AreaChart>
      )
    }

    if (m.type === 'line') {
      return (
        <LineChart data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded && <XAxis dataKey="t" {...axisProps} />}
          {!expanded && <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={yDomain} width={expanded ? 44 : 32} />
          {hiddenTip}
          {expanded && peak > 0 && <ReferenceLine y={peak} stroke={m.color} strokeDasharray="5 3" strokeOpacity={0.55} label={{ value: `Peak ${peak}`, fill: m.color, fontSize: 9, position: 'insideTopRight' }} />}
          {expanded && cur > 0 && cur !== peak && <ReferenceLine y={cur} stroke={m.color} strokeDasharray="2 3" strokeOpacity={0.35} label={{ value: `Now`, fill: ax, fontSize: 9, position: 'insideBottomRight' }} />}
          {showMain && <Line type="monotone" dataKey="v" stroke={m.color} strokeWidth={idle ? 1 : (expanded ? 2.5 : 1.8)} dot={false} isAnimationActive={false} strokeOpacity={idle ? 0.25 : 1} />}
          {visibleExtra.map(s => (
            <Line key={s.safeKey} type="monotone" dataKey={s.safeKey} stroke={s.color} strokeWidth={1.5} dot={false} isAnimationActive={false} strokeOpacity={0.85} connectNulls />
          ))}
        </LineChart>
      )
    }

    if (m.type === 'bar') {
      const useComposed = expanded && visibleExtra.length > 0
      const ChartEl = useComposed ? ComposedChart : BarChart
      return (
        <ChartEl data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded && <XAxis dataKey="t" {...axisProps} />}
          {!expanded && <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={yDomain} width={expanded ? 44 : 32} />
          <Tooltip content={() => null} cursor={{ fill: m.color, fillOpacity: 0.06 }} />
          {expanded && peak > 0 && <ReferenceLine y={peak} stroke={m.color} strokeDasharray="5 3" strokeOpacity={0.55} label={{ value: `Peak`, fill: m.color, fontSize: 9, position: 'insideTopRight' }} />}
          {showMain && <Bar dataKey="v" fill={m.color} radius={[2, 2, 0, 0]} opacity={idle ? 0.15 : 0.78} isAnimationActive={false} />}
          {visibleExtra.map(s => (
            <Line key={s.safeKey} type="monotone" dataKey={s.safeKey} stroke={s.color} strokeWidth={1.5} dot={false} isAnimationActive={false} strokeOpacity={0.85} connectNulls />
          ))}
        </ChartEl>
      )
    }

    if (m.type === 'multi-line') {
      const latKeys = expanded ? ['p50', 'p90', 'p95', 'p99'] : ['p50', 'p95', 'p99']
      const latPeak = Math.max(...arr.flatMap(d => latKeys.map(k => d[k] ?? 0)))
      const latCursor = { stroke: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.15)', strokeWidth: 1, strokeDasharray: '4 2' }
      return (
        <LineChart data={arr} margin={margin} onMouseMove={chartMove} onMouseLeave={chartLeave}>
          <CartesianGrid strokeDasharray="3 3" stroke={grid} />
          {expanded && <XAxis dataKey="t" {...axisProps} />}
          {!expanded && <XAxis dataKey="t" {...axisProps} tick={false} />}
          <YAxis {...axisProps} domain={[0, idle ? m.idleMax : 'auto']} width={expanded ? 44 : 32} />
          <Tooltip content={() => null} cursor={latCursor} />
          {expanded && latPeak > 0 && <ReferenceLine y={latPeak} stroke={LAT_COLORS.p99} strokeDasharray="5 3" strokeOpacity={0.4} label={{ value: `P99 Peak`, fill: ax, fontSize: 9, position: 'insideTopRight' }} />}
          {latKeys.map(dk => (
            <Line key={dk} type="monotone" dataKey={dk} stroke={LAT_COLORS[dk]} strokeWidth={idle ? 1 : (expanded ? 2 : 1.5)} dot={false} name={dk} isAnimationActive={false} strokeOpacity={idle ? 0.2 : 1} />
          ))}
        </LineChart>
      )
    }
    return null
  }

  /* ── icons ── */
  const PlayIcon  = () => <svg width="13" height="13" viewBox="0 0 16 16" fill="currentColor"><path d="M5 3l9 5-9 5V3z" /></svg>
  const StopIcon  = () => <svg width="11" height="11" viewBox="0 0 16 16" fill="currentColor"><rect x="3" y="3" width="10" height="10" rx="1.5" /></svg>
  const RefreshIcon = () => <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M14 8A6 6 0 1 1 8 2a6 6 0 0 1 4.24 1.76L14 2v4h-4l1.76-1.76" /></svg>

  const expandedMeta = METRICS.find(x => x.key === expandedKey)

  /* ══════════════════════════════════ RENDER ══════════════════════════════════ */

  return (
    <div style={pageStyle}>

      {/* ── Page header ── */}
      <div style={{ marginBottom: 16 }}>
        <h1 style={{ color: t.textPrimary, fontSize: 21, fontWeight: 700, margin: 0, letterSpacing: '-0.01em' }}>Quick Test</h1>
        <p style={{ color: t.textMuted, fontSize: 13, margin: '3px 0 0' }}>Select a load scenario and execute with live performance monitoring</p>
      </div>

      {/* ══ PERFORA GUARDIAN ROW — above the card, right-aligned ══ */}
      {testState === 'running' && (() => {
        // "Active" = issues that are still firing (NEW / OBSERVING / RECURRING)
        const activeAlerts = guardianAlerts.filter(a => a.state === 'NEW' || a.state === 'OBSERVING' || a.state === 'RECURRING')
        const stableAlerts = guardianAlerts.filter(a => a.state === 'STABLE')
        const critCount    = activeAlerts.filter(a => a.severity === 'critical').length
        const warnCount    = activeAlerts.filter(a => a.severity === 'warning').length
        const activeCount  = activeAlerts.length
        const totalCount   = guardianAlerts.filter(a => a.state !== 'RESOLVED').length  // badge: active + stable
        const riskColor    = guardianRiskScore >= 81 ? '#ef4444'
                           : guardianRiskScore >= 51 ? '#f97316'
                           : guardianRiskScore >= 21 ? '#f59e0b'
                           : guardianRiskScore >  0  ? '#06b6d4'
                           :                           '#22c55e'
        const riskLabel    = guardianRiskScore >= 81 ? 'CRITICAL'
                           : guardianRiskScore >= 51 ? 'HIGH'
                           : guardianRiskScore >= 21 ? 'MODERATE'
                           : guardianRiskScore >  0  ? 'LOW'
                           :                           'NONE'
        const badgeColor   = critCount > 0 ? '#ef4444' : warnCount > 0 ? '#f59e0b' : activeCount > 0 ? t.accent : '#22c55e'
        return (
          <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            {/* Risk indicator — standalone chip, left of the button */}
            {guardianRiskScore > 0 && (
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 4,
                padding: '3px 8px', borderRadius: 6,
                background: riskColor + '15',
                border: `1px solid ${riskColor}35`,
                color: riskColor, fontSize: 10, fontWeight: 800,
                letterSpacing: '0.04em', whiteSpace: 'nowrap',
              }}>
                <svg width="9" height="9" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M8 2L14.5 13H1.5Z" /><path d="M8 6.5v3M8 11v.5" />
                </svg>
                {riskLabel} {guardianRiskScore}
              </div>
            )}
            {/* Perfora Guardian button */}
            <button
              onClick={() => setShowGuardianPanel(true)}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 7,
                background: isDark ? 'rgba(99,102,241,0.12)' : 'rgba(99,102,241,0.08)',
                color: t.accent,
                border: `1px solid ${t.accent}40`,
                borderRadius: 8, padding: '0 12px', height: 28,
                fontSize: 11, fontWeight: 700, cursor: 'pointer',
                transition: 'background 0.15s, border-color 0.15s',
                whiteSpace: 'nowrap',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.2)' : 'rgba(99,102,241,0.14)'; e.currentTarget.style.borderColor = t.accent + '80' }}
              onMouseLeave={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.12)' : 'rgba(99,102,241,0.08)'; e.currentTarget.style.borderColor = t.accent + '40' }}
            >
              <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                <path d="M5.5 8l1.8 1.8L10.5 6" />
              </svg>
              Perfora Guardian
              {totalCount > 0 ? (
                <span style={{
                  minWidth: 17, height: 17, borderRadius: 9, padding: '0 5px',
                  background: badgeColor, color: '#fff',
                  fontSize: 10, fontWeight: 800,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  lineHeight: 1,
                }}>{totalCount}</span>
              ) : (
                <span style={{
                  width: 6, height: 6, borderRadius: '50%',
                  background: '#22c55e', boxShadow: '0 0 4px #22c55e',
                  animation: 'qt2Pulse 1.5s ease-in-out infinite',
                }} />
              )}
            </button>
          </div>
        )
      })()}

      {/* ══ EXECUTION CONTROLS ══ */}
      <div style={{ ...card, padding: '16px 20px', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, flexWrap: 'wrap' }}>

          {/* Scenario */}
          <div style={{ flex: '1 1 200px', minWidth: 150, maxWidth: 280 }}>
            <label style={label11}>Select Load Scenario</label>
            <div style={{ position: 'relative' }}>
              <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke={t.textFaint} strokeWidth="1.5"
                style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', zIndex: 1 }}>
                <path d="M8 2 L13.5 13 L8 10.5 L2.5 13 Z" strokeLinejoin="round" />
              </svg>
              <select style={{ ...selectStyle, paddingLeft: 29 }} value={selectedId} onChange={handleScenarioChange}>
                <option value="">— Select —</option>
                {scenarios.map(sc => <option key={sc.id} value={String(sc.id)}>{sc.scenario_name}</option>)}
              </select>
            </div>
          </div>

          {/* Read-only: Total VUsers and Total Duration */}
          {[
            {
              lbl: 'Total VUsers',
              val: selectedId ? String(totalTargetVUs) : '—',
            },
            {
              lbl: 'Total Duration',
              val: selectedId
                ? fmtHHMMSS(parseSecs(rampUp) + parseSecs(duration) + parseSecs(rampDown))
                : '—',
            },
          ].map(f => (
            <div key={f.lbl} style={{ flex: '0 1 110px', minWidth: 90 }}>
              <label style={label11}>{f.lbl}</label>
              <div style={{
                ...input,
                display: 'flex', alignItems: 'center',
                background: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)',
                color: t.textSecondary,
                cursor: 'default',
                userSelect: 'none',
                fontVariantNumeric: 'tabular-nums',
                fontWeight: 600,
              }}>{f.val}</div>
            </div>
          ))}

          {/* Editable time fields */}
          {[
            { lbl: 'Steady State', val: duration,  set: setDuration,  ph: '5m'  },
            { lbl: 'Ramp-up',      val: rampUp,    set: setRampUp,    ph: '30s' },
            { lbl: 'Ramp-down',    val: rampDown,  set: setRampDown,  ph: '15s' },
          ].map(f => (
            <div key={f.lbl} style={{ flex: '0 1 95px', minWidth: 72 }}>
              <label style={label11}>{f.lbl}</label>
              <input style={input} value={f.val} placeholder={f.ph}
                onChange={e => f.set(e.target.value)}
                onFocus={e => { e.target.style.borderColor = t.accent }}
                onBlur={e => { e.target.style.borderColor = t.border }} />
            </div>
          ))}

          {/* Status */}
          <div style={{ flex: '0 0 auto' }}>
            <label style={label11}>Status</label>
            {(() => {
              const statusLabel = testState === 'idle' ? 'Ready'
                : testState === 'starting' ? 'Starting'
                : testState === 'running' ? 'Running' : 'Stopped'
              const clr = testState === 'idle' ? t.textFaint
                : testState === 'starting' ? '#f59e0b'
                : testState === 'running' ? '#22c55e' : '#f97316'
              return (
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 7,
                  padding: '0 14px', height: 36,
                  borderRadius: 8,
                  border: `1px solid ${testState === 'idle' ? t.border : clr + '40'}`,
                  background: testState === 'idle' ? 'transparent' : (isDark ? clr + '12' : clr + '0e'),
                  fontSize: 12, fontWeight: 600, color: testState === 'idle' ? t.textMuted : clr,
                  minWidth: 100, whiteSpace: 'nowrap',
                }}>
                  <span style={{
                    width: 7, height: 7, borderRadius: '50%', background: clr,
                    animation: (testState === 'running' || testState === 'starting') ? 'qt2Pulse 1.3s ease-in-out infinite' : 'none',
                    boxShadow: (testState === 'running' || testState === 'starting') ? `0 0 5px ${clr}` : 'none',
                  }} />
                  {statusLabel}
                </div>
              )
            })()}
          </div>

          {/* Action button — pushed to the right edge */}
          <div style={{ flex: '0 0 auto', marginLeft: 'auto' }}>
            <label style={{ ...label11, visibility: 'hidden' }}>_</label>
            {testState === 'completed' ? (
                <button onClick={handleRunAgain} style={{
                  display: 'inline-flex', alignItems: 'center', gap: 7,
                  background: t.accent, color: '#fff', border: 'none',
                  borderRadius: 8, padding: '0 20px', height: 36,
                  fontSize: 13, fontWeight: 600, cursor: 'pointer',
                }}
                  onMouseEnter={e => { e.currentTarget.style.opacity = '0.85' }}
                  onMouseLeave={e => { e.currentTarget.style.opacity = '1' }}
                ><RefreshIcon /> Run Again</button>
              ) : testState === 'starting' ? (
                <div style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}>
                  <button disabled style={{
                    display: 'inline-flex', alignItems: 'center', gap: 7,
                    background: t.accent, color: '#fff', border: 'none',
                    borderRadius: 8, padding: '0 20px', height: 36,
                    fontSize: 13, fontWeight: 600, opacity: 0.35, filter: 'blur(1px)',
                    cursor: 'default',
                  }}><PlayIcon /> Run Test</button>
                  <span style={{
                    position: 'absolute', inset: 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <span style={{ display: 'inline-block', width: 20, height: 20, animation: 'qt2Spin 0.8s linear infinite' }}>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="10" stroke="#fff" strokeWidth="3" opacity="0.25" />
                        <path d="M12 2a10 10 0 0 1 10 10" stroke="#fff" strokeWidth="3" strokeLinecap="round" />
                      </svg>
                    </span>
                  </span>
                </div>
              ) : (
                <button
                  onClick={handleRunStop}
                  disabled={testState === 'idle' && !canRunTest}
                  style={{
                    display: 'inline-flex', alignItems: 'center', gap: 7,
                    background: testState === 'running' ? '#ef4444' : t.accent,
                    color: '#fff', border: 'none',
                    borderRadius: 8, padding: '0 20px', height: 36,
                    fontSize: 13, fontWeight: 600,
                    cursor: testState === 'idle' && !canRunTest ? 'not-allowed' : 'pointer',
                    opacity: testState === 'idle' && !canRunTest ? 0.5 : 1,
                    transition: 'background 0.2s, opacity 0.2s',
                  }}
                  onMouseEnter={e => { if (canRunTest || testState === 'running') e.currentTarget.style.opacity = '0.85' }}
                  onMouseLeave={e => { e.currentTarget.style.opacity = testState === 'idle' && !canRunTest ? '0.5' : '1' }}
                >
                  {testState === 'running' ? <><StopIcon /> Stop</> : <><PlayIcon /> Run Test</>}
                </button>
              )}
          </div>
        </div>
      </div>

      {/* ══ EMPTY STATE ══ */}
      {testState === 'idle' && (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          minHeight: 380, padding: '60px 24px',
          animation: 'qt2FadeIn 0.3s ease-out',
        }}>
          <div style={{
            width: 64, height: 64, borderRadius: 16,
            background: isDark ? 'rgba(99,102,241,0.1)' : 'rgba(99,102,241,0.07)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 20,
          }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={t.accent} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 3v18h18" /><path d="M7 16l4-8 4 4 5-9" />
            </svg>
          </div>
          <div style={{ fontSize: 18, fontWeight: 700, color: t.textPrimary, marginBottom: 8, letterSpacing: '-0.01em' }}>
            Select a Load Scenario
          </div>
          <div style={{ fontSize: 13, color: t.textMuted, textAlign: 'center', maxWidth: 420, lineHeight: 1.6 }}>
            No test is currently running. Choose a scenario from the dropdown above and click
            <span style={{ fontWeight: 600, color: t.textSecondary }}> Run Test </span>
            to begin. Live performance graphs and real-time metrics will appear here once the test starts.
          </div>
        </div>
      )}

      {/* ══ BOOT ANIMATION ══ */}
      {testState === 'starting' && (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          minHeight: 380, padding: '40px 24px',
          animation: 'qt2FadeIn 0.3s ease-out',
        }}>
          {/* Progress stages */}
          <div style={{ width: '100%', maxWidth: 440, marginBottom: 32 }}>
            {BOOT_STAGES.map((stage, i) => {
              const done = i < bootStage
              const active = i === bootStage
              const pending = i > bootStage
              return (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 14, padding: '10px 0',
                  opacity: pending ? 0.3 : 1,
                  animation: active ? 'qt2StageIn 0.4s ease-out' : 'none',
                  transition: 'opacity 0.3s',
                }}>
                  {/* Step indicator */}
                  <div style={{
                    width: 36, height: 36, borderRadius: 10, flexShrink: 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: done ? '#22c55e' : active ? t.accent : (isDark ? 'rgba(255,255,255,0.06)' : 'rgba(15,23,42,0.06)'),
                    color: done || active ? '#fff' : t.textFaint,
                    fontSize: 14,
                    animation: active ? 'qt2ProgressGlow 1.5s ease-in-out infinite' : 'none',
                    transition: 'background 0.3s',
                  }}>
                    {done ? (
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
                    ) : active ? (
                      <span style={{ display: 'inline-block', width: 16, height: 16, animation: 'qt2Spin 0.8s linear infinite' }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" opacity="0.3" />
                          <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                        </svg>
                      </span>
                    ) : (
                      <span style={{ fontSize: 11, fontWeight: 700 }}>{i + 1}</span>
                    )}
                  </div>
                  {/* Label */}
                  <div>
                    <div style={{
                      fontSize: 13, fontWeight: active ? 700 : done ? 600 : 500,
                      color: active ? t.textPrimary : done ? '#22c55e' : t.textMuted,
                      transition: 'color 0.3s',
                    }}>{stage.label}</div>
                    {active && (
                      <div style={{
                        display: 'flex', gap: 3, marginTop: 4,
                      }}>
                        {[0, 1, 2].map(d => (
                          <span key={d} style={{
                            width: 5, height: 5, borderRadius: '50%', background: t.accent,
                            animation: `qt2DotPulse 1.4s ${d * 0.16}s ease-in-out infinite`,
                          }} />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Holding message */}
          <div style={{
            fontSize: 12, color: t.textMuted, textAlign: 'center', lineHeight: 1.6,
            maxWidth: 820, width: '100%', padding: '16px 28px',
            background: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(15,23,42,0.025)',
            borderRadius: 10, border: `1px solid ${t.border}`,
          }}>
            <div style={{ fontWeight: 600, color: t.textSecondary, marginBottom: 4 }}>Please hold while we set up your test environment</div>
            <div style={{ whiteSpace: 'nowrap' }}>Provisioning virtual users, calibrating metrics pipeline, and establishing connections to the performance engine.</div>
          </div>
        </div>
      )}

      {/* ══ EXECUTION STATUS PANEL ══ */}
      {testState !== 'idle' && testState !== 'starting' && globalStats && (
        <div style={{ ...card, marginBottom: 14, overflow: 'hidden', animation: 'qt2SlideDown 0.22s ease-out' }}>

          {/* Global header */}
          <div style={{
            display: 'flex', gap: 0,
            borderBottom: `1px solid ${t.border}`,
            background: isDark ? 'rgba(255,255,255,0.02)' : 'rgba(15,23,42,0.02)',
          }}>
            {/* ── Merged: Run ID · Start Time · End Time ── */}
            <div style={{ flex: 2, padding: '11px 16px', borderRight: `1px solid ${t.border}` }}>
              <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start', justifyContent: 'space-between' }}>
                {[
                  { lbl: 'Run ID',     val: runSeqNumber ? `${runSeqNumber}` : (testRunId ? testRunId.slice(0, 8) : '—'), mono: true },
                  { lbl: 'Start Time', val: fmtLocalTime(testStartTime) },
                  { lbl: 'End Time',   val: fmtLocalTime(testEndTime) },
                ].map(item => (
                  <div key={item.lbl} style={{ flex: 1 }}>
                    <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3, whiteSpace: 'nowrap' }}>{item.lbl}</div>
                    <div style={{ fontSize: 13, fontWeight: 700, fontVariantNumeric: 'tabular-nums', fontFamily: item.mono ? 'monospace' : 'inherit', color: item.mono ? t.accent : t.textPrimary, whiteSpace: 'nowrap' }}>{item.val}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* ── Standard cells ── */}
            {[
              { label: 'Elapsed Time', val: fmtTime(globalStats.elapsed),  accent: false },
              { label: 'Remaining',    val: fmtTime(globalStats.remaining), accent: false },
              { label: 'Running VUs',  val: globalStats.activeVUs,          accent: true  },
              { label: 'Total Errors', val: globalStats.totalErrors,        accent: globalStats.totalErrors > 0 },
              { label: 'Overall TPS',  val: `${globalStats.tps}`,           accent: true  },
            ].map((s, i, arr) => (
              <div key={s.label} style={{
                flex: 1, padding: '11px 16px', textAlign: 'center',
                borderRight: `1px solid ${t.border}`,
              }}>
                <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>{s.label}</div>
                <div style={{
                  fontSize: 15, fontWeight: 700, fontVariantNumeric: 'tabular-nums',
                  color: s.accent && String(s.val) !== '0'
                    ? (s.label === 'Total Errors' && globalStats.totalErrors > 0 ? '#ef4444' : t.accent)
                    : t.textPrimary,
                }}>{s.val}</div>
              </div>
            ))}

            {/* ── Test Phase ── */}
            <div style={{ flex: 1, padding: '11px 16px', textAlign: 'center' }}>
              <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>Test Phase</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: getPhaseColor(globalStats.phase) }}>
                {mapPhaseLabel(globalStats.phase)}
              </div>
            </div>
          </div>

          {/* Script execution table */}
          {scriptTableRows.length > 0 && (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed', minWidth: 900 }}>
                <colgroup>
                  <col style={{ width: '18%' }} />{/* Script Name */}
                  {/* VUsers: Target, Running, Pending, Failed */}
                  <col style={{ width: '7%' }} />
                  <col style={{ width: '7%' }} />
                  <col style={{ width: '7%' }} />
                  <col style={{ width: '7%' }} />
                  {/* Transactions: Passed, Failed, TPS, Avg RT, Max RT */}
                  <col style={{ width: '9%' }} />
                  <col style={{ width: '7%' }} />
                  <col style={{ width: '8%' }} />
                  <col style={{ width: '10%' }} />
                  <col style={{ width: '10%' }} />
                </colgroup>
                <thead>
                  {/* Parent group row */}
                  <tr style={{ background: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)' }}>
                    <th rowSpan={2} style={{
                      padding: '8px 12px', textAlign: 'left',
                      color: t.textTertiary, fontSize: 10, fontWeight: 600,
                      textTransform: 'uppercase', letterSpacing: '0.04em',
                      borderBottom: `1px solid ${t.border}`,
                      borderRight: `1px solid ${t.border}`,
                      whiteSpace: 'nowrap', verticalAlign: 'bottom',
                    }}>Script Name</th>
                    <th colSpan={4} style={{
                      padding: '6px 12px', textAlign: 'center',
                      color: '#3b82f6', fontSize: 10, fontWeight: 700,
                      textTransform: 'uppercase', letterSpacing: '0.06em',
                      borderBottom: `1px solid ${t.border}`,
                      borderRight: `1px solid ${t.border}`,
                      background: isDark ? 'rgba(59,130,246,0.07)' : 'rgba(59,130,246,0.05)',
                    }}>Virtual Users</th>
                    <th colSpan={5} style={{
                      padding: '6px 12px', textAlign: 'center',
                      color: '#22c55e', fontSize: 10, fontWeight: 700,
                      textTransform: 'uppercase', letterSpacing: '0.06em',
                      borderBottom: `1px solid ${t.border}`,
                      background: isDark ? 'rgba(34,197,94,0.07)' : 'rgba(34,197,94,0.05)',
                    }}>Transactions</th>
                  </tr>
                  {/* Sub-column row */}
                  <tr style={{ background: isDark ? 'rgba(255,255,255,0.025)' : 'rgba(15,23,42,0.025)' }}>
                    {[
                      { lbl: 'Target',   grp: 'vu' },
                      { lbl: 'Running',  grp: 'vu' },
                      { lbl: 'Pending',  grp: 'vu' },
                      { lbl: 'Failed',   grp: 'vu', last: true },
                      { lbl: 'Passed',   grp: 'tx' },
                      { lbl: 'Failed',   grp: 'tx' },
                      { lbl: 'TPS',      grp: 'tx' },
                      { lbl: 'Avg RT',   grp: 'tx' },
                      { lbl: 'Max RT',   grp: 'tx' },
                    ].map(h => (
                      <th key={`${h.grp}-${h.lbl}`} style={{
                        padding: '6px 12px', textAlign: 'left',
                        color: t.textTertiary, fontSize: 10, fontWeight: 600,
                        textTransform: 'uppercase', letterSpacing: '0.04em',
                        borderBottom: `1px solid ${t.border}`,
                        borderRight: h.last ? `1px solid ${t.border}` : 'none',
                        whiteSpace: 'nowrap',
                      }}>{h.lbl}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {scriptTableRows.map((row, i) => (
                    <tr key={i} style={{ background: i % 2 === 1 ? t.tableRowAlt : 'transparent' }}>
                      {/* Script Name */}
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, borderRight: `1px solid ${t.border}`, color: t.textPrimary, fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{row.name}</td>
                      {/* VUsers */}
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{row.target}</td>
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: '#3b82f6', fontSize: 12, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{row.running}</td>
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textMuted, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{row.pending}</td>
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, borderRight: `1px solid ${t.border}`, color: row.vu_failed > 0 ? '#ef4444' : t.textFaint, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{row.vu_failed}</td>
                      {/* Transactions */}
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: '#22c55e', fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{row.tx_passed.toLocaleString()}</td>
                      <td
                        style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: row.tx_failed > 0 ? '#ef4444' : t.textMuted, fontSize: 12, fontVariantNumeric: 'tabular-nums', cursor: row.tx_failed > 0 && testRunId ? 'pointer' : 'default', textDecoration: row.tx_failed > 0 && testRunId ? 'underline' : 'none' }}
                        onClick={() => row.tx_failed > 0 && testRunId && setErrorModal({ scriptId: row.scriptId, scriptName: row.name })}
                        title={row.tx_failed > 0 && testRunId ? 'Click to view error details' : ''}
                      >{row.tx_failed}</td>
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.accent, fontSize: 12, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{row.tps}</td>
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{row.avg_rt} ms</td>
                      <td style={{ padding: '9px 12px', borderBottom: `1px solid ${t.border}`, color: t.textSecondary, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>{row.max_rt} ms</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ══ METRICS GRID ══ */}
      {testState !== 'idle' && testState !== 'starting' && <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
        {METRICS.map(m => {
          const stats    = getCardStats(m.key, displayData, totalTargetVUs, testState === 'running')
          const dispVal  = (() => {
            if (testState === 'idle') return '0'
            const arr = displayData[m.key] || []
            if (!arr.length) return '0'
            // Cumulative metrics: use last value
            if (m.key === 'error_rate') { const v = arr.at(-1)?.v ?? 0; return v.toFixed ? v.toFixed(2) : String(v) }
            if (m.key === 'requests')   { const v = arr.at(-1)?.v ?? 0; return v > 999 ? `${(v / 1000).toFixed(1)}K` : String(Math.round(v)) }
            if (m.key === 'active_vus') { return String(Math.round(arr.at(-1)?.v ?? 0)) }
            // Latency: avg P50
            if (m.key === 'latency') {
              const p50s = arr.map(d => d.p50 ?? 0).filter(v => v > 0)
              return p50s.length ? String(Math.round(p50s.reduce((s, v) => s + v, 0) / p50s.length)) : '0'
            }
            // All other rolling metrics (avg_rt, throughput, hits, ux_variance): show avg
            const nonZero = arr.map(d => d.v ?? 0).filter(v => v > 0)
            return nonZero.length ? String(Math.round(nonZero.reduce((s, v) => s + v, 0) / nonZero.length)) : '0'
          })()
          const isHov  = hoveredCard === m.key

          return (
            <div
              key={m.key}
              style={{
                background: t.bgRaised,
                border: `1px solid ${isHov ? m.color + '55' : t.border}`,
                borderRadius: 11,
                overflow: 'hidden',
                cursor: 'pointer',
                boxShadow: isHov
                  ? isDark ? `0 0 0 1px ${m.color}25, 0 6px 20px rgba(0,0,0,0.35)` : `0 0 0 1px ${m.color}20, 0 4px 14px rgba(0,0,0,0.09)`
                  : t.cardShadow,
                transition: 'border-color 0.15s, box-shadow 0.15s',
              }}
              onMouseEnter={() => setHoveredCard(m.key)}
              onMouseLeave={() => setHoveredCard(null)}
              onClick={() => handleCardClick(m.key)}
            >
              {/* Header */}
              <div style={{ padding: '10px 12px 4px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                  <span style={{
                    width: 6, height: 6, borderRadius: '50%', background: m.color, flexShrink: 0,
                    opacity: testState === 'idle' ? 0.4 : 1,
                    boxShadow: testState === 'running' ? `0 0 5px ${m.color}` : 'none',
                  }} />
                  <span style={{ color: t.textTertiary, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{m.label}</span>
                </div>
              </div>

              {/* Value */}
              <div style={{ padding: '2px 12px 5px', display: 'flex', alignItems: 'baseline', gap: 5 }}>
                <span style={{
                  color: testState === 'idle' ? t.textFaint : t.textPrimary,
                  fontSize: m.key === 'latency' ? 17 : 20,
                  fontWeight: 700,
                  fontVariantNumeric: 'tabular-nums',
                  lineHeight: 1,
                }}>
                  {dispVal}
                </span>
                {m.unit && m.key !== 'latency' && m.key !== 'ux_variance' && m.key !== 'error_rate' && m.key !== 'requests' && m.key !== 'active_vus' && (
                  <span style={{ color: t.textFaint, fontSize: 10 }}>avg {m.unit}</span>
                )}
                {(m.key === 'error_rate' || m.key === 'requests' || m.key === 'active_vus') && m.unit && (
                  <span style={{ color: t.textFaint, fontSize: 10 }}>{m.unit}</span>
                )}
                {m.key === 'latency' && (
                  <span style={{ color: t.textFaint, fontSize: 9 }}>ms (avg p50)</span>
                )}
                {m.key === 'ux_variance' && (
                  <span style={{ color: t.textFaint, fontSize: 9 }}>ms avg · P95 − P50</span>
                )}
              </div>

              {/* Mini chart */}
              <div style={{ height: 82 }}>
                <ResponsiveContainer width="100%" height="100%">
                  {renderChart(m.key, displayData, false)}
                </ResponsiveContainer>
              </div>

              {/* Stats strip */}
              <div style={{
                borderTop: `1px solid ${t.border}`,
                padding: '5px 12px',
                display: 'flex',
                gap: 0,
                background: isDark ? 'rgba(0,0,0,0.12)' : 'rgba(15,23,42,0.018)',
              }}>
                {stats.map((s, i) => (
                  <div key={s.label} style={{
                    flex: 1,
                    textAlign: i === 0 ? 'left' : 'center',
                    borderRight: i < stats.length - 1 ? `1px solid ${t.border}` : 'none',
                    paddingRight: i < stats.length - 1 ? 6 : 0,
                    paddingLeft: i > 0 ? 6 : 0,
                  }}>
                    <div style={{ color: t.textFaint, fontSize: 9, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.03em' }}>{s.label}</div>
                    <div style={{ color: t.textSecondary, fontSize: 11, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{s.val}</div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
      }

      {/* Hint */}
      {testState !== 'idle' && testState !== 'starting' && (
        <p style={{ color: t.textFaint, fontSize: 11, textAlign: 'center', marginTop: 8, marginBottom: 0 }}>
          {`Click any metric card to expand in focus view · Graphs refresh every 5s${testRunId ? ' · Live telemetry' : usingMock ? ' · Simulated data' : ''}`}
        </p>
      )}

      {/* ══ PERFORMANCE BREAKDOWN TABLE ══ */}
      {testState !== 'idle' && testState !== 'starting' && Object.keys(analytics.apiStats || {}).length > 0 && (() => {
        const txRows = Object.entries(txNameMap)
          .map(([key, name]) => ({ key, name }))
          .sort((a, b) => {
            const [, sa] = a.key.split(':'); const [, sb] = b.key.split(':')
            return (parseInt(sa) || 0) - (parseInt(sb) || 0)
          })
        return (
          <PerformanceTable
            apiStats={analytics.apiStats}
            txStats={analytics.txStats}
            txRows={txRows}
            theme={t}
            isDark={isDark}
          />
        )
      })()}

      {/* ══ EXPANDED OVERLAY ══ */}
      {expandedKey && expandedMeta && createPortal(
        <div
          style={{
            position: 'fixed', inset: 0,
            background: isDark ? 'rgba(0,0,0,0.75)' : 'rgba(0,0,0,0.5)',
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
            zIndex: 9000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
          onClick={e => { if (e.target === e.currentTarget) handleCloseExpanded() }}
        >
          {(() => {
            const { entries: seriesEntries, mergedData } = expandedSeriesData
            const hiddenSet   = expandedHiddenSeries[expandedKey] || new Set()
            const tableMode   = expandedTableMode[expandedKey] || 'api'
            const hasSeries   = expandedMeta.hasPerItem && seriesEntries.length > 0
            const chartData_  = hasSeries && mergedData
              ? { ...displayData, [expandedKey]: mergedData }
              : displayData

            // Stats source for the table rows
            const statsSource = tableMode === 'tx' ? analytics.txStats : analytics.apiStats
            const graphSource = tableMode === 'tx' ? analytics.txGraphData : analytics.apiGraphData

            // All selectable series IDs (including the "_average" main line)
            const allIds = ['_average', ...seriesEntries.map(s => s.id)]
            const allVisible = allIds.every(id => !hiddenSet.has(id))
            const someHidden = allIds.some(id => hiddenSet.has(id))

            // Compute overall series avg/min/max from displayData for the "Average" row
            const mainVals = (displayData[expandedKey] || []).map(d => d.v ?? 0).filter(v => v > 0)
            const mainAvg  = mainVals.length ? Math.round(mainVals.reduce((s, v) => s + v, 0) / mainVals.length) : 0
            const mainMin  = mainVals.length ? Math.min(...mainVals) : 0
            const mainMax  = mainVals.length ? Math.max(...mainVals) : 0

            const thCell = (center = false) => ({
              padding: '7px 10px',
              textAlign: center ? 'right' : 'left',
              color: t.textTertiary,
              fontSize: 10,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              borderBottom: `1px solid ${t.border}`,
              whiteSpace: 'nowrap',
              background: isDark ? 'rgba(255,255,255,0.025)' : 'rgba(15,23,42,0.025)',
            })
            const tdCell = (right = false, fail = false, val = 0) => ({
              padding: '6px 10px',
              textAlign: right ? 'right' : 'left',
              fontSize: 12,
              fontVariantNumeric: 'tabular-nums',
              color: fail && val > 0 ? '#ef4444' : right ? t.textSecondary : t.textPrimary,
              borderBottom: `1px solid ${isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)'}`,
              whiteSpace: 'nowrap',
            })

            return (
              <div
                style={{
                  background: t.bgRaised,
                  border: `1px solid ${expandedMeta.color}45`,
                  borderRadius: 16,
                  padding: '20px 24px 16px',
                  width: '88vw', maxWidth: 1040,
                  maxHeight: '92vh',
                  overflowY: 'auto',
                  boxShadow: isDark
                    ? `0 0 0 1px ${expandedMeta.color}18, 0 32px 80px rgba(0,0,0,0.72)`
                    : `0 0 0 1px ${expandedMeta.color}18, 0 20px 56px rgba(0,0,0,0.2)`,
                  animation: 'qt2FadeIn 0.18s ease-out',
                  position: 'relative',
                }}
              >
                {/* Close button */}
                <button
                  onClick={handleCloseExpanded}
                  style={{
                    position: 'sticky', top: 0, float: 'right',
                    width: 30, height: 30,
                    borderRadius: 8,
                    border: `1px solid ${t.border}`,
                    background: t.bgInput,
                    color: t.textMuted,
                    cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 16, lineHeight: 1,
                    transition: 'background 0.15s, color 0.15s, border-color 0.15s',
                    zIndex: 2,
                    marginBottom: -30,
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(239,68,68,0.15)' : 'rgba(239,68,68,0.08)'; e.currentTarget.style.color = '#ef4444'; e.currentTarget.style.borderColor = '#ef444440' }}
                  onMouseLeave={e => { e.currentTarget.style.background = t.bgInput; e.currentTarget.style.color = t.textMuted; e.currentTarget.style.borderColor = t.border }}
                  aria-label="Close"
                >
                  ✕
                </button>

                {/* Expanded header */}
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14, paddingRight: 36 }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                      <span style={{
                        width: 9, height: 9, borderRadius: '50%', background: expandedMeta.color,
                        boxShadow: `0 0 8px ${expandedMeta.color}`,
                        animation: testState === 'running' ? 'qt2Pulse 1.3s ease-in-out infinite' : 'none',
                      }} />
                      <span style={{ color: t.textPrimary, fontSize: 17, fontWeight: 700 }}>{expandedMeta.label}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                      <span style={{ color: t.textFaint, fontSize: 11 }}>Click ✕ or backdrop to close</span>
                      {testStartTime && (
                        <span style={{ color: t.textFaint, fontSize: 11 }}>
                          Started: {fmtLocalTime(testStartTime)}
                        </span>
                      )}
                      <span style={{ color: t.textFaint, fontSize: 11 }}>
                        Window: {displayData[expandedKey]?.length ?? 0} samples
                      </span>
                    </div>
                  </div>

                  {/* Large value + stats */}
                  <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: 20 }}>
                    <div style={{
                      color: testState === 'idle' ? t.textFaint : t.textPrimary,
                      fontSize: expandedMeta.key === 'latency' ? 20 : 34,
                      fontWeight: 800, fontVariantNumeric: 'tabular-nums',
                      lineHeight: 1, letterSpacing: '-0.02em',
                    }}>
                      {(() => {
                        if (testState === 'idle') return '0'
                        const arr = displayData[expandedKey] || []
                        if (!arr.length) return '0'
                        // Cumulative metrics: show last value
                        if (expandedMeta.key === 'error_rate') { const v = arr.at(-1)?.v ?? 0; return `${v.toFixed ? v.toFixed(2) : v}%` }
                        if (expandedMeta.key === 'requests')   { const v = arr.at(-1)?.v ?? 0; return v > 999 ? `${(v / 1000).toFixed(1)}K` : String(Math.round(v)) }
                        if (expandedMeta.key === 'active_vus') { return String(Math.round(arr.at(-1)?.v ?? 0)) }
                        // Latency: avg P50 / avg P95
                        if (expandedMeta.key === 'latency') {
                          const avgOf = key => { const s = arr.map(d => d[key] ?? 0).filter(v => v > 0); return s.length ? Math.round(s.reduce((a,v)=>a+v,0)/s.length) : 0 }
                          return `P50: ${avgOf('p50')} / P95: ${avgOf('p95')}`
                        }
                        // All rolling metrics: avg of non-zero samples
                        const nz = arr.map(d => d.v ?? 0).filter(v => v > 0)
                        const avg = nz.length ? Math.round(nz.reduce((s,v)=>s+v,0)/nz.length) : 0
                        if (expandedMeta.key === 'ux_variance') return `${avg} ms`
                        return String(avg)
                      })()}
                    </div>
                    {expandedMeta.unit && !['latency','ux_variance','error_rate','requests','active_vus'].includes(expandedMeta.key) && (
                      <div style={{ color: t.textMuted, fontSize: 12, marginTop: 2 }}>avg {expandedMeta.unit}</div>
                    )}
                    {(expandedMeta.key === 'error_rate' || expandedMeta.key === 'requests' || expandedMeta.key === 'active_vus') && expandedMeta.unit && (
                      <div style={{ color: t.textMuted, fontSize: 12, marginTop: 2 }}>{expandedMeta.unit}</div>
                    )}
                    {expandedMeta.key === 'ux_variance' && (
                      <div style={{ color: t.textMuted, fontSize: 11, marginTop: 3 }}>avg P95 − P50 spread</div>
                    )}
                    {/* Latency legend */}
                    {expandedMeta.key === 'latency' && (
                      <div style={{ display: 'flex', gap: 10, marginTop: 6, justifyContent: 'flex-end' }}>
                        {Object.entries(LAT_COLORS).map(([k, c]) => (
                          <span key={k} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: t.textMuted }}>
                            <span style={{ width: 16, height: 2.5, borderRadius: 2, background: c, display: 'inline-block' }} />
                            {k.toUpperCase()}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Full chart */}
                <div style={{ height: 340 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    {renderChart(expandedKey, chartData_, true, seriesEntries, hiddenSet)}
                  </ResponsiveContainer>
                </div>

                {/* Bottom stats row */}
                <div style={{
                  display: 'flex', gap: 0, marginTop: 12,
                  borderTop: `1px solid ${t.border}`,
                  paddingTop: 12,
                }}>
                  {getCardStats(expandedKey, displayData, totalTargetVUs, testState === 'running').map((s, i, arr) => (
                    <div key={s.label} style={{
                      flex: 1, textAlign: 'center',
                      borderRight: i < arr.length - 1 ? `1px solid ${t.border}` : 'none',
                      paddingRight: 12, paddingLeft: i > 0 ? 12 : 0,
                    }}>
                      <div style={{ color: t.textFaint, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 3 }}>{s.label}</div>
                      <div style={{ color: t.textPrimary, fontSize: 14, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{s.val}</div>
                    </div>
                  ))}
                </div>

                {/* ── Transaction/API breakdown table with checkboxes ── */}
                {hasSeries && (() => {
                  const tableDef = TABLE_DEFS[expandedKey]
                  if (!tableDef) return null

                  const allMainPts = displayData[expandedKey] || []
                  const lastVal    = allMainPts.at(-1)?.v ?? 0
                  const nonZeroV   = allMainPts.map(d => d.v ?? 0).filter(v => v > 0)
                  const totReqs    = analytics.cumulative?.totalRequests ?? null
                  const totErrs    = analytics.cumulative?.totalErrors   ?? null

                  const avgVals = tableDef.avgRow(nonZeroV, totReqs, totErrs, lastVal)

                  const tableRows = [{
                    id: '_average', label: 'Average (All)', color: expandedMeta.color, vals: avgVals,
                  }, ...seriesEntries.map(s => {
                    const st   = statsSource?.[s.id]
                    const gpts = graphSource?.[s.id] || []
                    return { id: s.id, label: s.label, color: s.color, vals: tableDef.seriesRow(st, gpts) }
                  })]

                  return (
                    <div style={{ marginTop: 18, borderTop: `1px solid ${t.border}`, paddingTop: 14 }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                        <span style={{ color: t.textMuted, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                          Transaction Summary
                        </span>
                        <div style={{
                          display: 'flex', gap: 3,
                          background: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)',
                          borderRadius: 7, padding: '3px 4px', border: `1px solid ${t.border}`,
                        }}>
                          {[['api', 'API Wise'], ['tx', 'Transaction Wise']].map(([mode, label]) => (
                            <button
                              key={mode}
                              onClick={() => setExpandedTableMode(prev => ({ ...prev, [expandedKey]: mode }))}
                              style={{
                                padding: '4px 13px', fontSize: 11, fontWeight: 600,
                                border: 'none', borderRadius: 5, cursor: 'pointer',
                                background: tableMode === mode
                                  ? (isDark ? 'rgba(99,102,241,0.22)' : 'rgba(99,102,241,0.12)')
                                  : 'transparent',
                                color: tableMode === mode ? t.accent : t.textMuted,
                                transition: 'background 0.15s, color 0.15s',
                              }}
                            >{label}</button>
                          ))}
                        </div>
                      </div>

                      <div style={{ overflowX: 'auto', borderRadius: 8, border: `1px solid ${t.border}` }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 560 }}>
                          <thead>
                            <tr>
                              <th style={thCell(false)}>
                                <label style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', userSelect: 'none' }}>
                                  <input
                                    type="checkbox"
                                    checked={allVisible}
                                    ref={el => { if (el) el.indeterminate = someHidden && !allIds.every(id => hiddenSet.has(id)) }}
                                    onChange={() => {
                                      setExpandedHiddenSeries(prev => ({
                                        ...prev,
                                        [expandedKey]: allVisible ? new Set(allIds) : new Set(),
                                      }))
                                    }}
                                    style={{ cursor: 'pointer', accentColor: t.accent }}
                                  />
                                  Series
                                </label>
                              </th>
                              {tableDef.cols.map((col, ci) => (
                                <th key={ci} style={thCell(true)}>{col.label}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {tableRows.map((row, ri) => {
                              const isHidden = hiddenSet.has(row.id)
                              return (
                                <tr
                                  key={row.id}
                                  style={{
                                    background: ri % 2 === 0 ? 'transparent' : (isDark ? 'rgba(255,255,255,0.018)' : 'rgba(15,23,42,0.018)'),
                                    opacity: isHidden ? 0.4 : 1,
                                    transition: 'opacity 0.15s, background 0.1s',
                                  }}
                                  onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(99,102,241,0.07)' : 'rgba(99,102,241,0.045)' }}
                                  onMouseLeave={e => { e.currentTarget.style.background = ri % 2 === 0 ? 'transparent' : (isDark ? 'rgba(255,255,255,0.018)' : 'rgba(15,23,42,0.018)') }}
                                >
                                  <td style={{ ...tdCell(false), maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                    <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', userSelect: 'none' }}>
                                      <input
                                        type="checkbox"
                                        checked={!isHidden}
                                        onChange={() => {
                                          setExpandedHiddenSeries(prev => {
                                            const next = new Set(prev[expandedKey] || [])
                                            if (next.has(row.id)) next.delete(row.id)
                                            else next.add(row.id)
                                            return { ...prev, [expandedKey]: next }
                                          })
                                        }}
                                        style={{ cursor: 'pointer', accentColor: row.color, flexShrink: 0 }}
                                      />
                                      <span style={{ width: 10, height: 10, borderRadius: '50%', background: row.color, flexShrink: 0, display: 'inline-block', boxShadow: `0 0 4px ${row.color}88` }} />
                                      <span title={row.label} style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: t.textPrimary, fontSize: 12 }}>{row.label}</span>
                                    </label>
                                  </td>
                                  {tableDef.cols.map((col, ci) => {
                                    const cellVal = row.vals[ci]
                                    return (
                                      <td key={ci} style={tdCell(true, col.isFail, parseFloat(cellVal) || 0)}>
                                        {cellVal != null ? cellVal : '—'}
                                      </td>
                                    )
                                  })}
                                </tr>
                              )
                            })}
                          </tbody>
                        </table>
                      </div>
                      <p style={{ color: t.textFaint, fontSize: 10, marginTop: 6, marginBottom: 0, textAlign: 'right' }}>
                        Toggle checkboxes to show / hide individual series on the graph above
                      </p>
                    </div>
                  )
                })()}
              </div>
            )
          })()}
        </div>,
        document.body
      )}

      {/* ══ CURSOR-ANCHORED TOOLTIP (always right of cursor, rendered at page level) ══ */}
      {ttip.visible && ttip.text && createPortal(
        <div
          style={{
            position: 'fixed',
            left: ttip.x + 14,
            top: ttip.y - 10,
            background: 'rgba(15,15,20,0.82)',
            color: '#fff',
            fontSize: 11,
            fontWeight: 600,
            padding: '3px 9px',
            borderRadius: 5,
            whiteSpace: 'nowrap',
            pointerEvents: 'none',
            letterSpacing: '0.01em',
            lineHeight: 1.6,
            zIndex: 99999,
            boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
          }}
        >
          {ttip.text}
        </div>,
        document.body
      )}

      {/* ══ GUARDIAN TOAST ══ */}
      {guardianToast && createPortal(
        <div style={{
          position: 'fixed', top: 24, right: 24,
          zIndex: 9999, animation: 'qt2SlideDown 0.25s ease-out',
          maxWidth: 400,
        }}>
          <div style={{
            background: isDark ? 'rgba(18,18,32,0.97)' : 'rgba(255,255,255,0.97)',
            border: `1px solid ${guardianToast.severity === 'critical' ? '#ef444440' : guardianToast.severity === 'warning' ? '#f59e0b40' : t.accent + '40'}`,
            borderLeft: `3px solid ${guardianToast.severity === 'critical' ? '#ef4444' : guardianToast.severity === 'warning' ? '#f59e0b' : t.accent}`,
            borderRadius: 10, padding: '12px 16px',
            boxShadow: '0 10px 36px rgba(0,0,0,0.22)',
            display: 'flex', alignItems: 'flex-start', gap: 10,
          }}>
            {/* severity icon */}
            <div style={{
              width: 28, height: 28, borderRadius: 7, flexShrink: 0,
              background: guardianToast.severity === 'critical' ? 'rgba(239,68,68,0.12)' : guardianToast.severity === 'warning' ? 'rgba(245,158,11,0.12)' : 'rgba(99,102,241,0.1)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {guardianToast.severity === 'critical'
                ? <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round"><path d="M8 2L14.5 13H1.5Z"/><path d="M8 6v3.5M8 11.5v.5"/></svg>
                : guardianToast.severity === 'warning'
                  ? <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 5v3.5M8 10.5v.5"/></svg>
                  : <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="2" strokeLinecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 7v4M8 5v.5"/></svg>
              }
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 3 }}>
                <svg width="9" height="9" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
                  <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                </svg>
                <span style={{ fontSize: 10, fontWeight: 700, color: t.accent, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Perfora Guardian
                </span>
                <span style={{
                  fontSize: 9, fontWeight: 600, padding: '1px 6px', borderRadius: 4,
                  background: guardianToast.severity === 'critical' ? 'rgba(239,68,68,0.12)' : guardianToast.severity === 'warning' ? 'rgba(245,158,11,0.12)' : 'rgba(99,102,241,0.1)',
                  color: guardianToast.severity === 'critical' ? '#ef4444' : guardianToast.severity === 'warning' ? '#f59e0b' : t.accent,
                  textTransform: 'uppercase', letterSpacing: '0.04em',
                }}>
                  {guardianToast.state === 'RECURRING' ? 'RECURRED' : guardianToast.severity}
                </span>
                {guardianToast.ruleCode && guardianToast.ruleCode !== 'BATCH' && (
                  <span style={{ fontSize: 9, color: t.textFaint, fontFamily: 'monospace' }}>{guardianToast.ruleCode}</span>
                )}
                <span style={{ fontSize: 9, color: t.textFaint, marginLeft: 'auto' }}>T+{guardianToast.time}s</span>
              </div>
              <div style={{ fontSize: 11, color: t.textPrimary, fontWeight: 500, lineHeight: 1.5 }}>
                {guardianToast.message}
              </div>
            </div>
            <button onClick={() => setGuardianToast(null)} style={{
              background: 'transparent', border: 'none', color: t.textFaint,
              cursor: 'pointer', padding: '2px 4px', fontSize: 14, lineHeight: 1, flexShrink: 0,
            }}>×</button>
          </div>
        </div>,
        document.body
      )}

      {/* ── Subtle Guardian hint — bottom-right, muted, fires only on substantial
           transitions (risk-tier cross / RESOLVED / STABLE / critical escalation) ── */}
      {subtleHint && createPortal(
        <div style={{
          position: 'fixed', bottom: 28, right: 24,
          zIndex: 9997, animation: 'qt2SlideUp 0.22s ease-out',
        }}>
          <div style={{
            background: isDark ? 'rgba(15,15,26,0.94)' : 'rgba(250,250,253,0.97)',
            border: `1px solid ${subtleHint.direction === 'degradation' ? 'rgba(245,158,11,0.22)' : 'rgba(20,184,166,0.22)'}`,
            borderLeft: `3px solid ${subtleHint.direction === 'degradation' ? '#f59e0b' : '#14b8a6'}`,
            borderRadius: 9, padding: '9px 12px',
            boxShadow: '0 6px 22px rgba(0,0,0,0.16)',
            display: 'flex', alignItems: 'center', gap: 9, maxWidth: 330,
          }}>
            <div style={{
              width: 22, height: 22, borderRadius: 6, flexShrink: 0,
              background: subtleHint.direction === 'degradation' ? 'rgba(245,158,11,0.1)' : 'rgba(20,184,166,0.1)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {subtleHint.direction === 'degradation'
                ? <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="#f59e0b" strokeWidth="2.2" strokeLinecap="round"><path d="M8 3v10M3 8l5 5 5-5"/></svg>
                : <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="#14b8a6" strokeWidth="2.2" strokeLinecap="round"><path d="M8 13V3M3 8l5-5 5 5"/></svg>
              }
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 1,
                color: subtleHint.direction === 'degradation' ? '#f59e0b' : '#14b8a6' }}>
                Perfora Guardian
              </div>
              <div style={{ fontSize: 11, color: t.textPrimary, fontWeight: 500, lineHeight: 1.4 }}>
                {subtleHint.label}
              </div>
            </div>
            <button
              onClick={() => { setSubtleHint(null); setShowGuardianPanel(true) }}
              style={{
                background: 'transparent',
                border: `1px solid ${subtleHint.direction === 'degradation' ? 'rgba(245,158,11,0.28)' : 'rgba(20,184,166,0.28)'}`,
                borderRadius: 5, cursor: 'pointer', padding: '3px 8px',
                fontSize: 9, fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase',
                color: subtleHint.direction === 'degradation' ? '#f59e0b' : '#14b8a6', flexShrink: 0,
              }}
            >View</button>
            <button onClick={() => setSubtleHint(null)} style={{
              background: 'transparent', border: 'none', color: t.textFaint,
              cursor: 'pointer', padding: '1px 3px', fontSize: 13, lineHeight: 1, flexShrink: 0,
            }}>×</button>
          </div>
        </div>,
        document.body
      )}

      {/* ══ 5-MINUTE WARNING TOAST ══ */}
      {showWarning5m && createPortal(
        <div style={{
          position: 'fixed', top: 24, left: '50%', transform: 'translateX(-50%)',
          zIndex: 10000, animation: 'qt2SlideDown 0.25s ease-out',
        }}>
          <div style={{
            background: isDark ? 'rgba(30,30,45,0.96)' : 'rgba(255,255,255,0.97)',
            border: `1px solid ${isDark ? 'rgba(99,102,241,0.3)' : 'rgba(99,102,241,0.2)'}`,
            borderRadius: 12, padding: '14px 22px',
            boxShadow: '0 12px 40px rgba(0,0,0,0.25)',
            display: 'flex', alignItems: 'center', gap: 12,
            maxWidth: 520,
          }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(99,102,241,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.5"><circle cx="8" cy="8" r="6" /><path d="M8 4.5V8l2.5 1.5" /></svg>
            </div>
            <div>
              <div style={{ color: t.textPrimary, fontSize: 13, fontWeight: 600, marginBottom: 2 }}>Test completing in 5 minutes</div>
              <div style={{ color: t.textMuted, fontSize: 12 }}>Access results from the <span style={{ color: t.accent, fontWeight: 600 }}>Test Results</span> page on completion.</div>
            </div>
            <button onClick={() => setShowWarning5m(false)} style={{
              background: 'transparent', border: 'none', color: t.textFaint,
              cursor: 'pointer', padding: 4, fontSize: 16, lineHeight: 1, flexShrink: 0,
            }}>×</button>
          </div>
        </div>,
        document.body
      )}

      {/* ══ PERFORA GUARDIAN PANEL ══ */}
      {showGuardianPanel && createPortal(
        <div
          style={{
            position: 'fixed', inset: 0,
            background: 'rgba(0,0,0,0.48)',
            backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)',
            zIndex: 10001,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
          onClick={e => { if (e.target === e.currentTarget) setShowGuardianPanel(false) }}
        >
          <div style={{
            background: isDark ? 'rgba(14,14,26,0.98)' : '#fff',
            border: `1px solid ${t.border}`,
            borderRadius: 18, width: '88vw', maxWidth: 700,
            maxHeight: '84vh', display: 'flex', flexDirection: 'column',
            boxShadow: isDark ? '0 0 0 1px rgba(99,102,241,0.12), 0 32px 80px rgba(0,0,0,0.7)' : '0 20px 64px rgba(0,0,0,0.2)',
            animation: 'qt2FadeIn 0.18s ease-out',
            overflow: 'hidden',
          }}>

            {/* ── Panel Header ── */}
            <div style={{
              padding: '20px 24px 16px',
              borderBottom: `1px solid ${t.border}`,
              display: 'flex', alignItems: 'center', gap: 12,
              background: isDark ? 'rgba(99,102,241,0.05)' : 'rgba(99,102,241,0.03)',
              flexShrink: 0,
            }}>
              <div style={{
                width: 40, height: 40, borderRadius: 11, flexShrink: 0,
                background: 'rgba(99,102,241,0.12)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                  <path d="M5.5 8l1.8 1.8L10.5 6" />
                </svg>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ color: t.textPrimary, fontSize: 16, fontWeight: 700 }}>Perfora Guardian</div>
                <div style={{ color: t.textFaint, fontSize: 11, marginTop: 1 }}>
                  {(() => {
                    const active = guardianAlerts.filter(a => a.state === 'NEW' || a.state === 'OBSERVING' || a.state === 'RECURRING').length
                    const stable = guardianAlerts.filter(a => a.state === 'STABLE').length
                    const resolved = guardianAlerts.filter(a => a.state === 'RESOLVED').length
                    if (!guardianAlerts.length) return 'Live issue-centric performance monitoring'
                    const parts = []
                    if (active)   parts.push(`${active} active`)
                    if (stable)   parts.push(`${stable} stable`)
                    if (resolved) parts.push(`${resolved} resolved`)
                    return `Issue tracker · ${parts.join(' · ')}`
                  })()}
                </div>
              </div>
              {/* Severity pills (active issues only) */}
              {guardianAlerts.length > 0 && (() => {
                const active = guardianAlerts.filter(a => a.state === 'NEW' || a.state === 'OBSERVING' || a.state === 'RECURRING')
                const crit = active.filter(a => a.severity === 'critical').length
                const warn = active.filter(a => a.severity === 'warning').length
                const info = active.filter(a => a.severity === 'info').length
                return (
                  <div style={{ display: 'flex', gap: 6, marginRight: 8 }}>
                    {crit > 0 && <span style={{ fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 5, background: 'rgba(239,68,68,0.12)', color: '#ef4444' }}>{crit} Critical</span>}
                    {warn > 0 && <span style={{ fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 5, background: 'rgba(245,158,11,0.12)', color: '#f59e0b' }}>{warn} Warning</span>}
                    {info > 0 && <span style={{ fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 5, background: isDark ? 'rgba(99,102,241,0.14)' : 'rgba(99,102,241,0.09)', color: t.accent }}>{info} Info</span>}
                  </div>
                )
              })()}
              <button onClick={() => setShowGuardianPanel(false)} style={{
                width: 30, height: 30, borderRadius: 8, flexShrink: 0,
                background: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(15,23,42,0.05)',
                border: `1px solid ${t.border}`,
                color: t.textMuted, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, lineHeight: 1,
              }}>×</button>
            </div>

            {/* ── Alert lifecycle list ── */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }}>
              {guardianAlerts.length === 0 ? (
                <div style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center',
                  justifyContent: 'center', padding: '48px 24px', gap: 14,
                }}>
                  <div style={{
                    width: 56, height: 56, borderRadius: 16,
                    background: isDark ? 'rgba(99,102,241,0.08)' : 'rgba(99,102,241,0.06)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <svg width="24" height="24" viewBox="0 0 16 16" fill="none" stroke={t.accent} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M8 1.5 L14 4 L14 8 C14 11.5 11 14 8 15 C5 14 2 11.5 2 8 L2 4 Z" />
                      <circle cx="8" cy="9" r="1.2" fill={t.accent} stroke="none" />
                      <path d="M8 6v1.5" />
                    </svg>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ color: t.textPrimary, fontSize: 14, fontWeight: 600, marginBottom: 6 }}>Guardian is monitoring</div>
                    <div style={{ color: t.textFaint, fontSize: 12 }}>No issues detected yet — Guardian evaluates rolling patterns every 5s.<br/>Issues will appear here and update as the test progresses.</div>
                  </div>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {/* Sort: NEW/OBSERVING/RECURRING first, then STABLE, then RESOLVED */}
                  {[...guardianAlerts]
                    .sort((a, b) => {
                      const order = { NEW: 0, RECURRING: 1, OBSERVING: 2, STABLE: 3, RESOLVED: 4 }
                      return (order[a.state] ?? 5) - (order[b.state] ?? 5)
                    })
                    .map(alert => {
                      const isActive   = alert.state === 'NEW' || alert.state === 'OBSERVING' || alert.state === 'RECURRING'
                      const isStable   = alert.state === 'STABLE'
                      const isResolved = alert.state === 'RESOLVED'
                      const isPrimary  = !!alert.isPrimary
                      const hasNotes   = isActive && Array.isArray(alert.impactNotes) && alert.impactNotes.length > 0

                      const sevClr = alert.severity === 'critical' ? '#ef4444'
                                   : alert.severity === 'warning'  ? '#f59e0b'
                                   : t.accent

                      // Visual hierarchy:
                      // · Primary incidents: full-intensity border (4px) + full background
                      // · Non-primary active: softer border (2px) + reduced background
                      // · Stable/Resolved: dimmed
                      const borderClr = isResolved ? t.border
                                      : isStable   ? (isDark ? 'rgba(34,197,94,0.3)' : 'rgba(34,197,94,0.5)')
                                      : sevClr

                      const borderWidth = isPrimary ? '4px' : isActive && !isPrimary ? '2px' : '3px'

                      const bgAlpha = isPrimary
                        ? (alert.severity === 'critical' ? '0.09' : '0.08')
                        : '0.04'   // secondary active alerts use lighter background

                      const bgClr = isResolved
                        ? (isDark ? 'rgba(255,255,255,0.02)' : 'rgba(15,23,42,0.02)')
                        : isStable
                        ? (isDark ? 'rgba(34,197,94,0.05)' : 'rgba(34,197,94,0.04)')
                        : alert.severity === 'critical'
                        ? `rgba(239,68,68,${bgAlpha})`
                        : alert.severity === 'warning'
                        ? `rgba(245,158,11,${bgAlpha})`
                        : isDark ? 'rgba(99,102,241,0.06)' : 'rgba(99,102,241,0.04)'

                      // State badge config
                      const stateLabel = alert.state
                      const stateClr   = isResolved ? '#6b7280'
                                       : isStable   ? '#22c55e'
                                       : alert.state === 'RECURRING' ? '#f97316'
                                       : alert.state === 'OBSERVING' ? '#f59e0b'
                                       : '#3b82f6'  // NEW

                      // Status section icon
                      const statusIcon = isResolved
                        ? <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round"><circle cx="8" cy="8" r="6"/><path d="M5.5 8l1.8 1.8L10.5 6"/></svg>
                        : isStable
                        ? <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round"><circle cx="8" cy="8" r="6"/><path d="M5.5 8l1.8 1.8L10.5 6"/></svg>
                        : alert.state === 'RECURRING'
                        ? <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="#f97316" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2.5 8a5.5 5.5 0 0 1 9-4.2M13.5 8a5.5 5.5 0 0 1-9 4.2M2.5 3.8v4h4"/></svg>
                        : alert.state === 'OBSERVING'
                        ? <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 5v3.5M8 10.5v.5"/></svg>
                        : <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round"><circle cx="8" cy="8" r="6"/><path d="M8 5v3.5M8 10.5v.5"/></svg>

                      // Confidence badge config
                      const confClr  = alert.confidenceLevel === 'HIGH'   ? '#a78bfa'
                                     : alert.confidenceLevel === 'MEDIUM' ? '#60a5fa'
                                     : '#94a3b8'

                      return (
                        <div key={alert.id} style={{
                          background: bgClr,
                          border: `1px solid ${borderClr}${isActive ? (isPrimary ? '45' : '28') : '50'}`,
                          borderLeft: `${borderWidth} solid ${borderClr}`,
                          borderRadius: 10, padding: '12px 14px',
                          opacity: isResolved ? 0.55 : isActive && !isPrimary ? 0.88 : 1,
                          transition: 'opacity 0.2s',
                        }}>
                          {/* ─ Top row: severity + rule + primary tag + confidence + state ─ */}
                          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 7, flexWrap: 'wrap' }}>
                            {/* Severity badge */}
                            <span style={{
                              fontSize: 9, fontWeight: 800, padding: '2px 6px', borderRadius: 4,
                              background: `${sevClr}18`, color: isActive ? sevClr : t.textFaint,
                              textTransform: 'uppercase', letterSpacing: '0.05em',
                            }}>{alert.severity}</span>
                            {/* Rule code */}
                            <span style={{ fontSize: 10, fontWeight: 700, color: isActive ? t.textSecondary : t.textFaint, fontFamily: 'monospace', letterSpacing: '0.02em' }}>{alert.ruleCode}</span>
                            {/* PRIMARY incident badge */}
                            {isPrimary && (
                              <span style={{
                                fontSize: 8, fontWeight: 800, padding: '1px 6px', borderRadius: 3,
                                background: `${sevClr}20`, color: sevClr,
                                textTransform: 'uppercase', letterSpacing: '0.06em',
                                border: `1px solid ${sevClr}35`,
                              }}>⬛ INCIDENT</span>
                            )}
                            {/* Confidence badge (only when OBSERVING or higher) */}
                            {isActive && alert.confidenceLevel && alert.state !== 'NEW' && (
                              <span style={{
                                fontSize: 8, fontWeight: 700, padding: '1px 5px', borderRadius: 3,
                                background: `${confClr}16`, color: confClr,
                                textTransform: 'uppercase', letterSpacing: '0.04em',
                              }}>{alert.confidenceLevel}</span>
                            )}
                            {/* Recurrence badge */}
                            {alert.recurrenceCount > 0 && (
                              <span style={{ fontSize: 9, fontWeight: 700, padding: '2px 6px', borderRadius: 4, background: 'rgba(249,115,22,0.14)', color: '#f97316' }}>
                                ↩ ×{alert.recurrenceCount}
                              </span>
                            )}
                            {/* State badge */}
                            <span style={{
                              marginLeft: 'auto',
                              fontSize: 9, fontWeight: 800, padding: '2px 7px', borderRadius: 4,
                              background: `${stateClr}18`, color: stateClr,
                              textTransform: 'uppercase', letterSpacing: '0.05em',
                              display: 'inline-flex', alignItems: 'center', gap: 4,
                            }}>
                              {(alert.state === 'OBSERVING' || alert.state === 'RECURRING') && (
                                <span style={{ width: 5, height: 5, borderRadius: '50%', background: stateClr, animation: 'qt2Pulse 1.5s ease-in-out infinite' }} />
                              )}
                              {stateLabel}
                            </span>
                            {/* Timeline */}
                            <span style={{ fontSize: 9, color: t.textFaint, fontFamily: 'monospace' }}>
                              {isActive
                                ? `Active since T+${alert.firstDetectedAt}s`
                                : isStable
                                ? `Stable ~${Math.max(1, Math.round((alert.stableDurationSecs ?? 0) / 60))}m`
                                : `T+${alert.firstDetectedAt}s`}
                            </span>
                          </div>

                          {/* ─ Detection message ─ */}
                          <div style={{
                            fontSize: 12, color: isActive ? t.textPrimary : t.textMuted,
                            lineHeight: 1.6, fontWeight: 500, marginBottom: 9,
                          }}>
                            {alert.message}
                          </div>

                          {/* ─ Status divider ─ */}
                          <div style={{ borderTop: `1px solid ${borderClr}20`, marginBottom: 8 }} />

                          {/* ─ Status narrative ─ */}
                          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 7 }}>
                            <span style={{ flexShrink: 0, marginTop: 1 }}>{statusIcon}</span>
                            <span style={{ fontSize: 11, color: isActive ? t.textSecondary : t.textFaint, lineHeight: 1.55 }}>
                              {alert.statusMessage}
                            </span>
                          </div>

                          {/* ─ System Impact notes (shown only on primary incidents) ─ */}
                          {hasNotes && (
                            <div style={{
                              marginTop: 10,
                              padding: '8px 10px',
                              borderRadius: 7,
                              background: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)',
                              border: `1px solid ${borderClr}25`,
                            }}>
                              <div style={{
                                fontSize: 9, fontWeight: 800, color: t.textFaint,
                                textTransform: 'uppercase', letterSpacing: '0.07em',
                                marginBottom: 5,
                              }}>System Impact</div>
                              {alert.impactNotes.map((note, i) => (
                                <div key={i} style={{
                                  display: 'flex', alignItems: 'flex-start', gap: 6,
                                  marginBottom: i < alert.impactNotes.length - 1 ? 4 : 0,
                                }}>
                                  <span style={{ color: sevClr, fontSize: 11, lineHeight: 1, marginTop: 2, flexShrink: 0 }}>•</span>
                                  <span style={{ fontSize: 11, color: t.textMuted, lineHeight: 1.5 }}>{note}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )
                    })
                  }
                </div>
              )}
            </div>

            {/* ── Panel Footer ── */}
            <div style={{
              padding: '12px 24px',
              borderTop: `1px solid ${t.border}`,
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              background: isDark ? 'rgba(0,0,0,0.2)' : 'rgba(15,23,42,0.02)',
              flexShrink: 0,
            }}>
              <span style={{ fontSize: 10, color: t.textFaint }}>
                Rules evaluated every 5s · Review cycle: 45s (critical) / 60s (ramp) / 90s (steady)
              </span>
              {testState === 'running' && (
                <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, color: '#22c55e', fontWeight: 600 }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#22c55e', boxShadow: '0 0 4px #22c55e', animation: 'qt2Pulse 1.5s ease-in-out infinite' }} />
                  Guardian Active
                </span>
              )}
            </div>

          </div>
        </div>,
        document.body
      )}

      {/* ══ TEST COMPLETION POPUP ══ */}
      {showCompletionPopup && createPortal(
        <div
          style={{
            position: 'fixed', inset: 0,
            background: 'rgba(0,0,0,0.45)',
            backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
            zIndex: 10000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <div style={{
            background: isDark ? 'rgba(22,22,35,0.98)' : '#fff',
            border: `1px solid ${t.border}`,
            borderRadius: 16, padding: '28px 32px', width: 440,
            boxShadow: '0 24px 72px rgba(0,0,0,0.35)',
            animation: 'qt2FadeIn 0.2s ease-out',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{
                width: 42, height: 42, borderRadius: 12,
                background: 'rgba(34,197,94,0.1)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <svg width="22" height="22" viewBox="0 0 16 16" fill="none" stroke="#22c55e" strokeWidth="1.8"><circle cx="8" cy="8" r="6" /><path d="M5.5 8l1.8 1.8L10.5 6" /></svg>
              </div>
              <div>
                <div style={{ color: t.textPrimary, fontSize: 17, fontWeight: 700 }}>Test Completed</div>
              </div>
            </div>
            <p style={{ color: t.textSecondary, fontSize: 14, margin: '0 0 8px', lineHeight: 1.6 }}>
              Your load test has finished successfully.
            </p>
            <p style={{ color: t.textSecondary, fontSize: 13, margin: '0 0 24px', lineHeight: 1.6 }}>
              Please access test results from the <span style={{ color: t.accent, fontWeight: 600 }}>Test Results</span> page
              {testRunId && <> for Run ID: <span style={{ fontFamily: 'monospace', color: t.accent, fontWeight: 700 }}>{runSeqNumber ? `${runSeqNumber}` : testRunId.slice(0, 8)}</span></>}
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button onClick={handleCompletionOk} style={{
                padding: '9px 22px', fontSize: 13, fontWeight: 600, borderRadius: 8,
                border: `1px solid ${t.border}`, background: 'transparent', color: t.textSecondary,
                cursor: 'pointer', transition: 'background 0.15s',
              }}
                onMouseEnter={e => { e.currentTarget.style.background = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)' }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent' }}
              >OK</button>
              <button onClick={handleGoToResults} style={{
                padding: '9px 22px', fontSize: 13, fontWeight: 600, borderRadius: 8,
                border: 'none', background: t.accent, color: '#fff',
                cursor: 'pointer', transition: 'opacity 0.15s',
              }}
                onMouseEnter={e => { e.currentTarget.style.opacity = '0.85' }}
                onMouseLeave={e => { e.currentTarget.style.opacity = '1' }}
              >Go to Test Results</button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* ══ ERROR LOGS MODAL ══ */}
      {errorModal && testRunId && (
        <ErrorLogsModal
          testRunId={testRunId}
          scriptId={errorModal.scriptId}
          scriptName={errorModal.scriptName}
          onClose={() => setErrorModal(null)}
        />
      )}
    </div>
  )
}

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { ThemeProvider } from './context/ThemeContext'
import Layout from './components/Layout'
import DashboardPage from './pages/DashboardPage'
import PerfzyPage from './pages/PerfzyPage'
import UploadPage from './pages/UploadPage'
import ScriptListPage from './pages/ScriptListPage'
import ScriptPreviewPage from './pages/ScriptPreviewPage'
import ComingSoonPage from './pages/ComingSoonPage'
import LoadDesignerPage from './pages/LoadDesignerPage'
import QuickTestPage from './pages/QuickTestPage'
import TestResultsPage from './pages/TestResultsPage'

const API_BASE = 'http://localhost:8000'
export { API_BASE }

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          {/* Root redirects straight into the app */}
          <Route path="/" element={<Navigate to="/app" replace />} />

          {/* App shell */}
          <Route path="/app" element={<Layout />}>
            <Route index element={<DashboardPage />} />
            <Route path="perfzy" element={<PerfzyPage />} />
            <Route path="upload" element={<UploadPage />} />
            <Route path="load-designer" element={<LoadDesignerPage />} />
            <Route path="quick-test" element={<QuickTestPage />} />
            <Route path="test-results" element={<TestResultsPage />} />
            <Route path="reports" element={<ComingSoonPage feature="Reports" />} />
            <Route path="scripts" element={<ScriptListPage />} />
            <Route path="scripts/:scriptId" element={<ScriptPreviewPage />} />
          </Route>

          {/* Redirect old bare paths */}
          <Route path="/perfzy" element={<Navigate to="/app/perfzy" replace />} />
          <Route path="/upload" element={<Navigate to="/app/upload" replace />} />
          <Route path="/scripts" element={<Navigate to="/app/scripts" replace />} />
          <Route path="/scripts/:scriptId" element={<Navigate to="/app/scripts" replace />} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  )
}

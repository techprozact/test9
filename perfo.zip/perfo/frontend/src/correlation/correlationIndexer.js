/**
 * Correlation Indexer — flattens a JSON response into searchable CorrelationCandidate entries.
 *
 * Runs once per response, caches the result. Search is O(n) filter over the flat list.
 */

const PRIORITY_KEYWORDS = new Set([
  'token', 'access_token', 'auth_token', 'refresh_token', 'id_token',
  'csrf', 'csrftoken', 'csrf_token', 'session', 'sessionid', 'session_id',
  'nonce', 'api_key', 'apikey', 'key', 'secret',
  'id', 'user_id', 'userid', 'account_id', 'order_id',
])

const PRIORITY_FRAGMENTS = ['token', 'csrf', 'session', 'nonce', 'auth', 'key', 'secret', 'id']

function computePriority(fieldName, depth) {
  const lower = fieldName.toLowerCase()
  if (PRIORITY_KEYWORDS.has(lower)) return 100 - depth
  if (PRIORITY_FRAGMENTS.some((f) => lower.includes(f))) return 80 - depth
  return 50 - depth
}

function deriveEntity(pathParts) {
  for (let i = pathParts.length - 2; i >= 0; i--) {
    const seg = pathParts[i]
    if (seg.match(/^\[\d+\]$/)) continue
    const clean = seg.replace(/\[\d+\]$/, '')
    if (clean && clean !== '$') {
      let name = clean.replace(/_/g, ' ')
      name = name.charAt(0).toUpperCase() + name.slice(1)
      if (name.endsWith('s') && name.length > 3) {
        name = name.slice(0, -1)
      }
      return name
    }
  }
  return 'Root'
}

function normalizedGroupKey(jsonPath) {
  return jsonPath.replace(/\[\d+\]/g, '[*]')
}

/**
 * @typedef {Object} CorrelationCandidate
 * @property {string} jsonPath      — Full JSONPath e.g. $.items[0].id
 * @property {string} fieldName     — Leaf field name e.g. "id"
 * @property {string} entityName    — Derived parent entity e.g. "Item"
 * @property {number} depth         — Nesting depth
 * @property {*}      sampleValue   — First encountered value
 * @property {number} priorityScore — Higher = more likely correlation target
 * @property {string} groupKey      — Normalized path with [*] for grouping
 * @property {number[]} indices     — All array indices where this field appears
 * @property {number} totalInstances — How many instances of this group exist
 */

/**
 * Flatten a parsed JSON object into CorrelationCandidate entries.
 * @param {*} data — Parsed JSON
 * @param {number} [maxDepth=10]
 * @returns {CorrelationCandidate[]}
 */
export function indexJsonResponse(data, maxDepth = 10) {
  if (data == null || typeof data !== 'object') return []

  const candidates = []
  const groupMap = new Map()

  function walk(obj, path, pathParts, depth) {
    if (depth > maxDepth) return
    if (obj == null) return

    if (Array.isArray(obj)) {
      const limit = Math.min(obj.length, 50)
      for (let i = 0; i < limit; i++) {
        const item = obj[i]
        if (item != null && typeof item === 'object') {
          walk(item, `${path}[${i}]`, [...pathParts, `[${i}]`], depth + 1)
        } else if (item != null) {
          const fieldName = pathParts[pathParts.length - 1]?.replace(/\[\d+\]$/, '') || 'item'
          addCandidate(`${path}[${i}]`, fieldName, pathParts, depth + 1, item, i)
        }
      }
      return
    }

    if (typeof obj === 'object') {
      for (const [key, value] of Object.entries(obj)) {
        const childPath = `${path}.${key}`
        const childParts = [...pathParts, key]

        if (value == null) continue

        if (typeof value === 'object') {
          walk(value, childPath, childParts, depth + 1)
        } else {
          addCandidate(childPath, key, childParts, depth + 1, value, null)
        }
      }
    }
  }

  function addCandidate(jsonPath, fieldName, pathParts, depth, sampleValue, arrayIdx) {
    const entityName = deriveEntity(pathParts)
    const priorityScore = computePriority(fieldName, depth)
    const gKey = normalizedGroupKey(jsonPath)

    const candidate = {
      jsonPath,
      fieldName,
      entityName,
      depth,
      sampleValue,
      priorityScore,
      groupKey: gKey,
      indices: arrayIdx != null ? [arrayIdx] : [],
      totalInstances: 1,
    }

    candidates.push(candidate)

    if (!groupMap.has(gKey)) {
      groupMap.set(gKey, candidate)
    } else {
      const existing = groupMap.get(gKey)
      existing.totalInstances++
      if (arrayIdx != null && !existing.indices.includes(arrayIdx)) {
        existing.indices.push(arrayIdx)
      }
    }
  }

  walk(data, '$', ['$'], 0)

  return candidates
}

/**
 * Group candidates by entity+field, keeping only one representative per group.
 * @param {CorrelationCandidate[]} candidates
 * @returns {Map<string, CorrelationCandidate>} key = "Entity→field"
 */
export function groupByEntityField(candidates) {
  const grouped = new Map()
  for (const c of candidates) {
    const key = `${c.entityName}→${c.fieldName}`
    if (!grouped.has(key)) {
      grouped.set(key, { ...c })
    } else {
      const existing = grouped.get(key)
      existing.totalInstances = Math.max(existing.totalInstances, c.totalInstances)
      if (c.priorityScore > existing.priorityScore) {
        Object.assign(existing, { ...c, totalInstances: existing.totalInstances })
      }
    }
  }
  return grouped
}

/**
 * Search candidates by query string — matches field name AND entity name.
 * @param {CorrelationCandidate[]} candidates
 * @param {string} query
 * @returns {Map<string, CorrelationCandidate>} grouped results
 */
export function searchCandidates(candidates, query) {
  if (!query || !query.trim()) {
    return groupByEntityField(candidates)
  }
  const lower = query.toLowerCase().trim()
  const filtered = candidates.filter(
    (c) =>
      c.fieldName.toLowerCase().includes(lower) ||
      c.entityName.toLowerCase().includes(lower)
  )
  return groupByEntityField(filtered)
}

/**
 * Find all instances of a specific entity+field combination.
 * @param {CorrelationCandidate[]} candidates
 * @param {string} entityName
 * @param {string} fieldName
 * @returns {CorrelationCandidate[]}
 */
export function findInstances(candidates, entityName, fieldName) {
  const seen = new Set()
  const results = []
  for (const c of candidates) {
    if (c.entityName === entityName && c.fieldName === fieldName && !seen.has(c.jsonPath)) {
      seen.add(c.jsonPath)
      results.push(c)
    }
  }
  return results
}

/**
 * Generate JSONPath for a given selection.
 * @param {CorrelationCandidate} candidate
 * @param {'first'|'last'|'specific'|'all'} instanceMode
 * @param {number} [specificIndex=0]
 * @returns {{ jsonPath: string, varName: string }}
 */
export function generateExpression(candidate, instanceMode = 'first', specificIndex = 0) {
  let jsonPath = candidate.groupKey

  if (instanceMode === 'first') {
    jsonPath = jsonPath.replace(/\[\*\]/g, '[0]')
  } else if (instanceMode === 'last') {
    const lastIdx = Math.max(0, candidate.totalInstances - 1)
    jsonPath = jsonPath.replace(/\[\*\]/g, `[${lastIdx}]`)
  } else if (instanceMode === 'specific') {
    jsonPath = jsonPath.replace(/\[\*\]/g, `[${specificIndex}]`)
  }

  const varName = `${candidate.entityName.toLowerCase().replace(/\s+/g, '_')}_${candidate.fieldName.toLowerCase().replace(/\s+/g, '_')}`

  return { jsonPath, varName }
}

const _cache = new WeakMap()

/**
 * Get or compute the indexed candidates for a response body string.
 * Caches by parsed object reference.
 * @param {string} bodyStr
 * @returns {CorrelationCandidate[]}
 */
export function getOrIndexResponse(bodyStr) {
  if (!bodyStr || typeof bodyStr !== 'string') return []
  try {
    const parsed = JSON.parse(bodyStr)
    if (_cache.has(parsed)) return _cache.get(parsed)
    const candidates = indexJsonResponse(parsed)
    _cache.set(parsed, candidates)
    return candidates
  } catch {
    return []
  }
}

/**
 * Index response body (always fresh, no cache).
 * @param {string} bodyStr
 * @returns {CorrelationCandidate[]}
 */
export function indexResponseBody(bodyStr) {
  if (!bodyStr || typeof bodyStr !== 'string') return []
  try {
    const parsed = JSON.parse(bodyStr)
    return indexJsonResponse(parsed)
  } catch {
    return []
  }
}
